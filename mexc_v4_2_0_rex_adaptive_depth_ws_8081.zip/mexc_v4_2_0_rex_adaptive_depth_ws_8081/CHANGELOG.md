# V4.2.0

- Full-universe conservé : toutes les routes 2-leg restent surveillées.
- Remplacement du Diff.Depth permanent par `BookTicker 10ms` sur tout l'univers.
- `Partial Book Depth 20` dynamique sur les symboles de routes BBO+.
- Hot-depth TTL 30 s, souscriptions/désouscriptions automatiques.
- Validation `Depth top == BBO top` avant toute opportunité concrète.
- Cooldown 5 s par route pour la restitution, pas pour la détection.
- Tableau principal limité aux opportunités réellement depth-vérifiées.
- Tableau séparé des routes BBO+ en phase WARMING / DEPTH_READY / DEPTH_SYNCED.
- Mesures distinctes BBO transport/decode et Depth transport/decode.
- Export des candidate windows et opportunités concrètes.
