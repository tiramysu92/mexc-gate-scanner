from __future__ import annotations
import argparse,json,os,signal,threading,time,traceback
import psutil
from flask import Flask,jsonify,render_template,request
from waitress import serve
from v4rex import __version__
from v4rex.core import Store,pct
from v4rex.db import DB
from v4rex.universe import UniverseBuilder
from v4rex.collector import Collector
from v4rex.engine import Engine

parser=argparse.ArgumentParser();parser.add_argument('config',nargs='?',default='config.json');args=parser.parse_args();cfg=json.load(open(args.config,encoding='utf-8'))
if cfg.get('mode')!='SHADOW':raise SystemExit('V4.2 qualification build is SHADOW ONLY')
started=time.time();stop_event=threading.Event();thread_state={};thread_lock=threading.RLock();process=psutil.Process(os.getpid());process.cpu_percent(None)
db=DB(cfg['db_path']);universe=UniverseBuilder(cfg).build()
if not universe.routes or not universe.symbols:raise SystemExit('Universe vide')
UniverseBuilder.save_snapshot(universe,cfg.get('universe_snapshot_path','exchange_info_v420_start.json.gz'));db.save_universe(universe.symbols);db.set_meta('version',__version__);db.set_meta('started_at',started);db.set_meta('config',cfg);db.set_meta('universe',universe.as_dict())
store=Store(cfg.get('update_queue_max',200000));collector=Collector(cfg,store,[s.symbol for s in universe.symbols],universe.ws_groups,db.log_collector_error);engine=Engine(cfg,store,db,universe,collector);app=Flask(__name__,template_folder='templates')

def safe_thread(name,fn):
    def w():
        with thread_lock:thread_state[name]={'alive':True,'started':time.time(),'last_ok':None,'error':None}
        try:fn()
        except Exception as exc:
            with thread_lock:thread_state[name]['alive']=False;thread_state[name]['error']=repr(exc);thread_state[name]['traceback']=traceback.format_exc()
            db.log_collector_error({'ts':time.time(),'kind':'THREAD_FATAL','symbol':None,'detail':f'{name}:{exc}','traceback':traceback.format_exc()})
        finally:
            with thread_lock:
                if name in thread_state:thread_state[name]['alive']=False
    t=threading.Thread(target=w,daemon=True,name=name);t.start();return t

def collector_loop():collector.run()
def sweep_loop():
    inter=float(cfg.get('analytical_sweep_s',5))
    while not stop_event.is_set():
        t=time.monotonic();engine.sweep_once();thread_state['analytical-sweep']['last_ok']=time.time();stop_event.wait(max(0,inter-(time.monotonic()-t)))
def fast_loop():
    deb=float(cfg.get('fast_watch_debounce_ms',20))/1000
    while not stop_event.is_set():
        ch=store.drain_updates(.25,deb,int(cfg.get('fast_watch_max_queue_batch',50000)))
        if ch:engine.fast_once(ch)
        thread_state['fast-opportunity']['last_ok']=time.time()
def sample_loop():
    inter=float(cfg.get('market_sample_interval_s',5))
    while not stop_event.is_set():db.add_market_samples(collector.symbol_status());thread_state['market-sampler']['last_ok']=time.time();stop_event.wait(inter)
def health_loop():
    inter=float(cfg.get('health_interval_s',5))
    while not stop_event.is_set():
        cs=collector.status();cnt=db.counts();
        try:cpu=process.cpu_percent(None);rss=process.memory_info().rss/1024/1024
        except Exception:cpu=rss=None
        hd=cs['hot_depth'];db.add_health({'uptime_s':time.time()-started,'bbo_ready':cs['ready'],'total_symbols':cs['symbols'],'bbo_ws_connected':cs['ws_connected'],'bbo_ws_total':cs['ws_total'],'bbo_msg_rate':cs['msg_rate_10s'],'bbo_rx_queue':cs['rx_queue_total'],'bbo_rx_age_ms':cs['rx_queue_age_max_ms'],'bbo_decode_p95':cs['decode_lag_p95_max_ms'],'hot_symbols':hd['hot_symbols'],'depth_ws_connected':hd['ws_connected'],'depth_ws_total':hd['ws_total'],'depth_queue':hd['queue'],'cpu_pct':cpu,'rss_mb':rss,'db_mb':cnt['db_mb'],'update_queue':store.update_queue_size(),'update_drops':store.update_drops});thread_state['health']['last_ok']=time.time();thread_state['collector']['last_ok']=time.time() if cs['messages'] else None;stop_event.wait(inter)
for n,f in [('collector',collector_loop),('analytical-sweep',sweep_loop),('fast-opportunity',fast_loop),('market-sampler',sample_loop),('health',health_loop)]:safe_thread(n,f)

def quality(rows):
    return {'ready':sum(1 for x in rows if x['ready']),'total':len(rows),'transport_p50_ms':pct([x['transport_age_ms'] for x in rows],.5),'transport_p95_ms':pct([x['transport_age_ms'] for x in rows],.95),'decode_p50_ms':pct([x['decode_lag_ms'] for x in rows],.5),'decode_p95_ms':pct([x['decode_lag_ms'] for x in rows],.95),'spread_p50_bps':pct([x['spread_bps'] for x in rows],.5),'spread_p95_bps':pct([x['spread_bps'] for x in rows],.95)}
def safe_cfg():return {k:v for k,v in cfg.items() if 'key' not in k.lower() and 'secret' not in k.lower()}
@app.get('/healthz')
def healthz():
    with thread_lock:t={k:dict(v) for k,v in thread_state.items()}
    return jsonify(ok=bool(t) and all(v.get('alive') for v in t.values()),mode='SHADOW',version=__version__,port=cfg['port'],threads=t)
@app.get('/api/status')
def status():
    sy=collector.symbol_status();cs=collector.status();es=engine.status();cnt=db.counts();st=db.opportunity_stats(24)
    try:cpu=process.cpu_percent(None);rss=process.memory_info().rss/1024/1024
    except Exception:cpu=rss=None
    with thread_lock:t={k:dict(v) for k,v in thread_state.items()}
    return jsonify({'version':__version__,'mode':'SHADOW','uptime_s':time.time()-started,'port':cfg['port'],'universe':{'symbols':len(universe.symbols),'routes':len(universe.routes),'tokens':len(set(s.base for s in universe.symbols)),'excluded':len(universe.excluded),'ws_groups':len(universe.ws_groups)},'collector':cs,'quality':quality(sy),'engine':es,'opportunity_stats':st,'store':{'update_queue':store.update_queue_size(),'update_drops':store.update_drops},'db':cnt,'process':{'cpu_pct':cpu,'rss_mb':rss},'threads':t,'config':safe_cfg(),'reasons':db.reasons()[:40]})
@app.get('/api/smoke')
def smoke():
    cs=collector.status(); es=engine.status(); cnt=db.counts(); st=db.opportunity_stats(24)
    try: cpu=process.cpu_percent(None); rss=process.memory_info().rss/1024/1024
    except Exception: cpu=rss=None
    ws=collector.ws_status(); worst=sorted(ws,key=lambda x:(x.get('rx_queue_age_ms') or 0),reverse=True)[:8]
    return jsonify({'version':__version__,'uptime_s':time.time()-started,'universe':{'tokens':len(set(s.base for s in universe.symbols)),'symbols':len(universe.symbols),'routes':len(universe.routes)},'bbo':{'ready':cs['ready'],'ws':f"{cs['ws_connected']}/{cs['ws_total']}",'msg_rate_10s':cs['msg_rate_10s'],'rx_queue_total':cs['rx_queue_total'],'rx_queue_age_max_ms':cs['rx_queue_age_max_ms'],'decode_p95_max_ms':cs['decode_lag_p95_max_ms'],'transport_p50_ms':cs['transport_p50_ms'],'transport_p95_ms':cs['transport_p95_ms'],'errors':cs['errors'],'reconnects':cs['reconnects']},'hot_depth':cs['hot_depth'],'engine':es,'opportunity_stats':st,'db':cnt,'process':{'cpu_pct':cpu,'rss_mb':rss},'store':{'update_queue':store.update_queue_size(),'update_drops':store.update_drops},'worst_bbo_ws':[{k:x.get(k) for k in ('id','msg_rate_10s','rx_queue','rx_queue_age_ms','decode_lag_p95_ms','rx_drops','errors')} for x in worst],'recent_errors':db.recent_errors(10)})

@app.get('/api/opportunities')
def opp():return jsonify(db.recent_opportunities(int(request.args.get('limit',150)),float(request.args.get('hours',24)),int(request.args.get('min_rank',1))))
@app.get('/api/candidates')
def cand():return jsonify(db.recent_candidates(int(request.args.get('limit',100)),float(request.args.get('hours',1))))
@app.get('/api/viability')
def via():return jsonify(db.route_viability(float(request.args.get('hours',24)),int(request.args.get('limit',150))))
@app.get('/api/route-activity')
def ra():return jsonify(db.route_activity(int(request.args.get('limit',250))))
@app.get('/api/profiles')
def prof():return jsonify(db.profile_summary(int(request.args.get('limit',150))))
@app.get('/api/ws')
def ws():return jsonify(collector.ws_status())
@app.get('/api/depth-ws')
def dws():return jsonify(collector.depth_ws_status())
@app.get('/api/symbols')
def syms():return jsonify(collector.symbol_status())
@app.get('/api/errors')
def errs():return jsonify(db.recent_errors(int(request.args.get('limit',100))))
@app.get('/api/universe')
def uni():return jsonify(universe.as_dict())
@app.get('/')
def index():return render_template('index.html')
def shutdown(*_):
    stop_event.set();collector.stop=True;engine.flush(True);raise SystemExit(0)
for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,shutdown)
if __name__=='__main__':serve(app,host='0.0.0.0',port=int(cfg['port']),threads=int(cfg.get('http_threads',8)))
