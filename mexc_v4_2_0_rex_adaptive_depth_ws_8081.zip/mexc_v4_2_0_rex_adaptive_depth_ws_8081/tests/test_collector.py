import json
from v4rex.collector import Envelope,decode_bbo,decode_depth,control_frame

def test_control_text(): assert control_frame('{"id":0,"code":0,"msg":"PONG"}')['msg']=='PONG'
def test_control_binary(): assert control_frame(b'{"id":0,"code":0,"msg":"PONG"}')['msg']=='PONG'
def test_control_protobuf_none(): assert control_frame(b'\x08\x01') is None

def test_decode_bbo():
    e=Envelope();e.symbol='BTCUSDT';e.sendTime=123;e.publicAggreBookTicker.bidPrice='100';e.publicAggreBookTicker.bidQuantity='2';e.publicAggreBookTicker.askPrice='101';e.publicAggreBookTicker.askQuantity='3';e.publicAggreBookTicker.version='77'
    x=decode_bbo(e.SerializeToString());assert x['symbol']=='BTCUSDT';assert x['bid']==100;assert x['ask']==101;assert x['version']==77

def test_decode_bbo_crossed_rejected():
    e=Envelope();e.symbol='X';e.publicAggreBookTicker.bidPrice='101';e.publicAggreBookTicker.bidQuantity='1';e.publicAggreBookTicker.askPrice='100';e.publicAggreBookTicker.askQuantity='1';assert decode_bbo(e.SerializeToString()) is None

def test_decode_depth():
    e=Envelope();e.symbol='X';e.sendTime=100;e.publicLimitDepths.version='9';a=e.publicLimitDepths.asks.add();a.price='11';a.quantity='2';b=e.publicLimitDepths.bids.add();b.price='10';b.quantity='3';x=decode_depth(e.SerializeToString());assert x['version']==9;assert x['asks'][0].p==11;assert x['bids'][0].q==3

def test_depth_sorts():
    e=Envelope();e.symbol='X';e.publicLimitDepths.version='1'
    for p in ('9','10'):
        z=e.publicLimitDepths.bids.add();z.price=p;z.quantity='1'
    for p in ('12','11'):
        z=e.publicLimitDepths.asks.add();z.price=p;z.quantity='1'
    x=decode_depth(e.SerializeToString());assert [z.p for z in x['bids']]==[10,9];assert [z.p for z in x['asks']]==[11,12]
