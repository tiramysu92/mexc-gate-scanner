from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, Iterable
import queue
import threading
import time

@dataclass(frozen=True)
class L:
    p: float
    q: float

@dataclass(frozen=True)
class BBO:
    symbol: str
    bid: float
    bid_qty: float
    ask: float
    ask_qty: float
    version: Optional[int]
    exchange_ms: Optional[int]
    recv_wall_ms: Optional[float]
    recv_ns: int
    apply_ns: int
    ws_id: int | None = None
    state: str = "VALID"

    @property
    def spread_bps(self) -> Optional[float]:
        if self.bid <= 0 or self.ask <= 0:
            return None
        return (self.ask / self.bid - 1.0) * 1e4

    def transport_delay_ms(self, clock_offset_ms: float = 0.0) -> Optional[float]:
        if not self.exchange_ms or self.recv_wall_ms is None:
            return None
        return (float(self.recv_wall_ms) + clock_offset_ms) - float(self.exchange_ms)

    @property
    def decode_lag_ms(self) -> float:
        return max(0.0, (self.apply_ns - self.recv_ns) / 1e6)

    @property
    def inactivity_ms(self) -> float:
        return max(0.0, (time.monotonic_ns() - self.apply_ns) / 1e6)

@dataclass(frozen=True)
class DepthBook:
    symbol: str
    bids: Tuple[L, ...]
    asks: Tuple[L, ...]
    version: Optional[int]
    exchange_ms: Optional[int]
    recv_wall_ms: Optional[float]
    recv_ns: int
    apply_ns: int
    ws_id: int | None = None
    state: str = "VALID"

    @property
    def best_bid(self):
        return self.bids[0].p if self.bids else None

    @property
    def best_ask(self):
        return self.asks[0].p if self.asks else None

    def transport_delay_ms(self, clock_offset_ms: float = 0.0) -> Optional[float]:
        if not self.exchange_ms or self.recv_wall_ms is None:
            return None
        return (float(self.recv_wall_ms) + clock_offset_ms) - float(self.exchange_ms)

    @property
    def decode_lag_ms(self) -> float:
        return max(0.0, (self.apply_ns - self.recv_ns) / 1e6)

    @property
    def inactivity_ms(self) -> float:
        return max(0.0, (time.monotonic_ns() - self.apply_ns) / 1e6)

class Store:
    """Authoritative BBO store for the full universe + hot partial-depth store.

    The update queue is a wake-up hint only. Dropping a hint never corrupts market
    state; it only reduces fast-watcher temporal resolution and is counted.
    """
    def __init__(self, update_queue_max: int = 200000):
        self._lock = threading.RLock()
        self._bbo: dict[str, BBO] = {}
        self._depth: dict[str, DepthBook] = {}
        self._updates = queue.Queue(maxsize=int(update_queue_max))
        self.update_drops = 0

    def _signal(self, symbol: str):
        try:
            self._updates.put_nowait(symbol)
        except queue.Full:
            self.update_drops += 1

    def put_bbo(self, x: BBO):
        with self._lock:
            old = self._bbo.get(x.symbol)
            if old and old.version is not None and x.version is not None and x.version < old.version:
                return False
            self._bbo[x.symbol] = x
        self._signal(x.symbol)
        return True

    def put_depth(self, x: DepthBook):
        with self._lock:
            old = self._depth.get(x.symbol)
            if old and old.version is not None and x.version is not None and x.version < old.version:
                return False
            self._depth[x.symbol] = x
        self._signal(x.symbol)
        return True

    def drop_depth(self, symbol: str):
        with self._lock:
            self._depth.pop(symbol, None)
        self._signal(symbol)

    def get_bbo(self, symbol: str) -> Optional[BBO]:
        with self._lock:
            return self._bbo.get(symbol)

    def get_depth(self, symbol: str) -> Optional[DepthBook]:
        with self._lock:
            return self._depth.get(symbol)

    def snapshot_bbo(self):
        with self._lock:
            return dict(self._bbo)

    def snapshot_depth(self):
        with self._lock:
            return dict(self._depth)

    def drain_updates(self, timeout_s=.1, debounce_s=.025, max_items=20000):
        try:
            first = self._updates.get(timeout=max(0.0, timeout_s))
        except queue.Empty:
            return set()
        out = {first}; deadline = time.monotonic() + max(0.0, debounce_s)
        while len(out) < max_items:
            remain = deadline - time.monotonic()
            if remain <= 0:
                break
            try:
                out.add(self._updates.get(timeout=min(remain, .005)))
            except queue.Empty:
                continue
        while len(out) < max_items:
            try: out.add(self._updates.get_nowait())
            except queue.Empty: break
        return out

    def update_queue_size(self):
        try: return self._updates.qsize()
        except Exception: return 0


def buy(levels: Iterable[L], quote: float, fraction: float = .25):
    quote=float(quote)
    if quote<=0:return 0.0,0.0,1.0
    f=max(0.0,min(1.0,float(fraction))); rem=quote;base=spent=0.0
    for x in levels:
        if x.p<=0 or x.q<=0:continue
        take=min(rem,x.p*x.q*f)
        if take<=0:continue
        base+=take/x.p;spent+=take;rem-=take
        if rem<=1e-10:break
    return base,(spent/base if base else 0.0),spent/quote


def sell(levels: Iterable[L], base: float, fraction: float = .25):
    base=float(base)
    if base<=0:return 0.0,0.0,1.0
    f=max(0.0,min(1.0,float(fraction)));rem=base;sold=out=0.0
    for x in levels:
        if x.p<=0 or x.q<=0:continue
        take=min(rem,x.q*f)
        if take<=0:continue
        sold+=take;out+=take*x.p;rem-=take
        if rem<=1e-10:break
    return out,(out/sold if sold else 0.0),sold/base


def cost_for_base(asks: Iterable[L], base: float, fraction: float=.25):
    base=float(base)
    if base<=0:return 0.0,0.0,1.0
    f=max(0.0,min(1.0,float(fraction)));rem=base;got=cost=0.0
    for x in asks:
        if x.p<=0 or x.q<=0:continue
        take=min(rem,x.q*f)
        if take<=0:continue
        got+=take;cost+=take*x.p;rem-=take
        if rem<=1e-10:break
    return cost,(cost/got if got else 0.0),got/base


def max_traversable_quote(asks: Iterable[L], bids: Iterable[L], fraction: float=.25):
    f=max(0.0,min(1.0,float(fraction)));aa=tuple(asks);bb=tuple(bids)
    base=min(sum(max(0,x.q)*f for x in aa),sum(max(0,x.q)*f for x in bb))
    cost,_,cov=cost_for_base(aa,base,f)
    return cost if cov>=.999999 else 0.0


def pct(values,p:float):
    vals=sorted(v for v in values if v is not None)
    if not vals:return None
    if len(vals)==1:return float(vals[0])
    k=(len(vals)-1)*p;lo=int(k);hi=min(len(vals)-1,lo+1);w=k-lo
    return float(vals[lo]*(1-w)+vals[hi]*w)
