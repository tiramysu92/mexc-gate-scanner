import time
from types import SimpleNamespace
from v4rex.core import Store,Book,L
from v4rex.engine import Engine
from v4rex.db import DB

class Clock: offset_ms=0

def book(sym,bid,ask,send=None,age_ms=0):
    now=time.monotonic_ns()-int(age_ms*1e6); wall=time.time()*1000
    return Book(sym,(L(bid,1000),),(L(ask,1000),),1,100,send or int(wall),wall,now,now,'VALID')

def make(tmp_path,b2_bid=10.2,age=0):
    cfg={'fee_bps_default':5,'min_expected_edge_bps':10,'max_local_age_ms':250,'max_exchange_age_ms':500,'max_transport_age_ms':500,'max_local_skew_ms':150,'max_exchange_skew_ms':150,
         'test_sizes_usd':[100],'depth_fractions':[1.0],'raw_watch_threshold_bps':0,'aggregate_flush_s':999,'opportunity_cooldown_s':5,'fast_watch_route_cooldown_ms':0}
    store=Store(); store.put(book('SOLUSDT',9.9,10.0,age_ms=age)); store.put(book('SOLUSDC',b2_bid,b2_bid+0.1,age_ms=age))
    route=SimpleNamespace(route='USDT>SOL>USDC',token='SOL',stable_a='USDT',stable_b='USDC',symbol1='SOLUSDT',symbol2='SOLUSDC')
    uni=SimpleNamespace(routes=[route],by_symbol={}); db=DB(str(tmp_path/'x.db')); return Engine(cfg,store,db,uni,Clock()),route,db

def test_positive_edge_and_fee(tmp_path):
    e,r,_=make(tmp_path,10.2); x=e._evaluate(r,100,1.0)
    assert x.raw_edge_bps>0 and x.net_edge_bps<x.raw_edge_bps and x.data_valid

def test_fee_can_kill_raw_edge(tmp_path):
    e,r,_=make(tmp_path,10.005); x=e._evaluate(r,100,1.0)
    assert x.raw_edge_bps>0 and x.net_edge_bps<0

def test_inactivity_is_timing_not_book_corruption(tmp_path):
    e,r,_=make(tmp_path,10.2,age=400); x=e._evaluate(r,100,1.0)
    assert 'INACTIVITY_LOCAL' in x.timing_reasons and x.data_valid and not x.timing_valid

def test_bbo_prefilter_skips_depth_when_negative(tmp_path):
    e,r,_=make(tmp_path,9.8); b,d,p=e._process_routes([r],fast=False)
    assert b==1 and d==0 and p==0

def test_positive_bbo_runs_depth_and_creates_hit(tmp_path):
    e,r,db=make(tmp_path,10.2); b,d,p=e._process_routes([r],fast=False); e.flush(force=True)
    assert b==1 and d==1 and p==1
    hits=db.recent_opportunities(10,24,1); assert len(hits)==1 and hits[0]['route']==r.route

def test_cooldown_bucket_deduplicates_route(tmp_path):
    e,r,db=make(tmp_path,10.2); e._process_routes([r],fast=False); e._process_routes([r],fast=False); e.flush(force=True)
    hits=db.recent_opportunities(10,24,1); assert len(hits)==1 and hits[0]['observations']==2

def test_sweep_covers_route(tmp_path):
    e,r,db=make(tmp_path,10.2); b,d=e.sweep_once(); e.flush(force=True)
    assert b==1 and d==1 and e.sweeps==1 and db.route_activity(1)[0]['quick_scans']>=1
