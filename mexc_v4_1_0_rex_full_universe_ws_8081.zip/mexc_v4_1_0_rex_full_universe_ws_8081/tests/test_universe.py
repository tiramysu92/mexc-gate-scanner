from v4rex.universe import parse_exchange_info, balanced_ws_groups, SymbolRule

def payload():
    return {'symbols':[
      {'symbol':'SOLUSDT','status':'ENABLED','baseAsset':'SOL','quoteAsset':'USDT','isSpotTradingAllowed':True,'baseAssetPrecision':4,'quotePrecision':4},
      {'symbol':'SOLUSDC','status':'ENABLED','baseAsset':'SOL','quoteAsset':'USDC','isSpotTradingAllowed':True},
      {'symbol':'SOLUSD1','status':'PAUSED','baseAsset':'SOL','quoteAsset':'USD1','isSpotTradingAllowed':True},
      {'symbol':'SUIUSDT','status':'ENABLED','baseAsset':'SUI','quoteAsset':'USDT','isSpotTradingAllowed':False},
      {'symbol':'BTCUSDT','status':'ENABLED','baseAsset':'BTC','quoteAsset':'USDT','isSpotTradingAllowed':True},
      {'symbol':'BTCUSDC','status':'ENABLED','baseAsset':'BTC','quoteAsset':'USDC','isSpotTradingAllowed':True},
      {'symbol':'ONLYUSDT','status':'ENABLED','baseAsset':'ONLY','quoteAsset':'USDT','isSpotTradingAllowed':True},
    ]}

def test_full_universe_selects_all_tokens_with_two_markets():
    cfg={'universe_mode':'FULL_STABLECOIN_2LEG','stablecoins':['USDT','USDC','USD1'],'require_default_symbols':True}
    ds={'SOLUSDT','SOLUSDC','SOLUSD1','SUIUSDT','BTCUSDT','BTCUSDC','ONLYUSDT'}
    u=parse_exchange_info(payload(),cfg,ds)
    assert {s.symbol for s in u.symbols}=={'SOLUSDT','SOLUSDC','BTCUSDT','BTCUSDC'}
    assert {r.route for r in u.routes}=={'USDT>SOL>USDC','USDC>SOL>USDT','USDT>BTC>USDC','USDC>BTC>USDT'}

def test_single_quote_token_excluded():
    cfg={'universe_mode':'FULL_STABLECOIN_2LEG','stablecoins':['USDT','USDC'],'require_default_symbols':True}
    ds={'SOLUSDT','SOLUSDC','BTCUSDT','BTCUSDC','ONLYUSDT'}
    u=parse_exchange_info(payload(),cfg,ds)
    ex=[x for x in u.excluded if x['symbol']=='ONLYUSDT']
    assert ex and 'TOKEN_LT2_STABLE_QUOTES' in ex[0]['reasons']

def test_allowlist_can_narrow_diagnostic_run():
    cfg={'universe_mode':'FULL_STABLECOIN_2LEG','token_allowlist':['SOL'],'stablecoins':['USDT','USDC'],'require_default_symbols':True}
    u=parse_exchange_info(payload(),cfg,{'SOLUSDT','SOLUSDC','BTCUSDT','BTCUSDC'})
    assert {s.base for s in u.symbols}=={'SOL'}

def test_activity_is_attached_and_groups_balanced():
    cfg={'universe_mode':'FULL_STABLECOIN_2LEG','stablecoins':['USDT','USDC'],'require_default_symbols':True,'ws_group_size':2}
    ticks=[{'symbol':'SOLUSDT','count':1000},{'symbol':'SOLUSDC','count':900},{'symbol':'BTCUSDT','count':800},{'symbol':'BTCUSDC','count':700}]
    u=parse_exchange_info(payload(),cfg,{'SOLUSDT','SOLUSDC','BTCUSDT','BTCUSDC'},ticks)
    assert len(u.ws_groups)==2
    assert all(g['symbol_count']<=2 for g in u.ws_groups)
    # Same-token correlated markets should be spread when balancing permits it.
    groups=[set(g['symbols']) for g in u.ws_groups]
    assert not any({'SOLUSDT','SOLUSDC'} <= g for g in groups)

def test_ws_groups_hard_cap_30():
    syms=[]
    for i in range(31):
        syms.append(SymbolRule(f'T{i}USDT',f'T{i}','USDT','ENABLED',True,True,None,None,None,None,None,None,None,None,float(i+1),None,None))
    g=balanced_ws_groups(syms,100)
    assert max(x['symbol_count'] for x in g)<=30
