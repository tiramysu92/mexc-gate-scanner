from v4rex.db import DB

def test_db_schema_and_error(tmp_path):
    db=DB(str(tmp_path/'x.db')); db.log_collector_error({'ts':1,'kind':'X','symbol':'SOLUSDT','detail':'d','a':2})
    assert db.counts()['collector_errors']==1; assert db.recent_errors(1)[0]['kind']=='X'

def test_opportunity_cooldown_upsert(tmp_path):
    db=DB(str(tmp_path/'x.db'))
    h={'bucket_ts':100.0,'first_ts':101.0,'last_ts':101.0,'route':'USDT>SOL>USDC','token':'SOL','stable_a':'USDT','stable_b':'USDC','symbol1':'SOLUSDT','symbol2':'SOLUSDC','observations':1,
       'class':'RAW_POSITIVE','class_rank':1,'score':1,'size':25.0,'fraction':.25,'bbo_raw_bps':5,'raw_edge_bps':4,'fee_bps_leg1':5,'fee_bps_leg2':5,'net_edge_bps':-6,'expected_edge_bps':-6,
       'potential_pnl_usd':-.015,'cov1':1,'cov2':1,'max_traversable_quote':100,'vwap1':10,'vwap2':10.004,'local_age1_ms':10,'local_age2_ms':12,'exchange_age1_ms':20,'exchange_age2_ms':22,
       'transport_age1_ms':10,'transport_age2_ms':10,'local_skew_ms':2,'exchange_skew_ms':2,'timing_valid':1,'accepted':0,'reasons':'EDGE_EXPECTED'}
    db.upsert_opportunity_hits([h]); h2=dict(h); h2['last_ts']=104; h2['observations']=1; h2['score']=2; h2['raw_edge_bps']=8
    db.upsert_opportunity_hits([h2]); rows=db.recent_opportunities(10,1e9,1)
    assert len(rows)==1 and rows[0]['observations']==2 and rows[0]['raw_edge_bps']==8 and rows[0]['last_ts']==104

def test_route_activity_upsert(tmp_path):
    db=DB(str(tmp_path/'x.db')); r={'route':'USDT>SOL>USDC','token':'SOL','stable_a':'USDT','stable_b':'USDC','quick_scans':1,'bbo_positive':1,'max_bbo_bps':2,'last_bbo_bps':2,'last_ts':1}
    db.upsert_route_activity([r]); db.upsert_route_activity([r]); x=db.route_activity(1)[0]
    assert x['quick_scans']==2 and x['bbo_positive']==2
