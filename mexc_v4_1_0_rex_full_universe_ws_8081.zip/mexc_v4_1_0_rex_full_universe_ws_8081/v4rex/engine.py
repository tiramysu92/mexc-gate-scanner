from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import Counter, defaultdict
import math, threading, time
from .core import buy, sell, max_traversable_quote

@dataclass
class Eval:
    route:str; token:str; stable_a:str; stable_b:str; symbol1:str; symbol2:str
    size:float; fraction:float
    raw_edge_bps:float|None; net_edge_bps:float|None; expected_edge_bps:float|None
    fee_bps_leg1:float; fee_bps_leg2:float; fee_source:str
    cov1:float; cov2:float; max_traversable_quote:float; vwap1:float; vwap2:float
    local_age1_ms:float; local_age2_ms:float
    exchange_age1_ms:float|None; exchange_age2_ms:float|None
    transport_age1_ms:float|None; transport_age2_ms:float|None
    local_skew_ms:float; exchange_skew_ms:float|None
    data_valid:bool; timing_valid:bool; accepted:bool
    hard_reasons:tuple[str,...]; timing_reasons:tuple[str,...]; reasons:tuple[str,...]
    ts:float
    def as_dict(self):
        d=asdict(self); d['reasons']='|'.join(self.reasons) if self.reasons else 'OK'; return d

class Engine:
    """Full-universe 2-leg scanner.

    Scalability invariant: a BBO prefilter runs on every route. Full multi-level depth
    (all configured sizes/fractions) is only evaluated when BBO raw edge is positive.
    Depth cannot improve upon top-of-book pricing, so this does not miss a raw-positive
    executable profile while avoiding 30k+ depth walks on every sweep.
    """
    def __init__(self,cfg,store,db,universe,clock):
        self.cfg=cfg; self.store=store; self.db=db; self.universe=universe; self.clock=clock
        self.routes_by_symbol=defaultdict(list)
        for r in universe.routes:
            self.routes_by_symbol[r.symbol1].append(r); self.routes_by_symbol[r.symbol2].append(r)
        self.lock=threading.RLock()
        self.pending_activity={}; self.pending_profiles={}; self.pending_hits={}; self.pending_reasons=Counter()
        self.last_flush=time.monotonic(); self.last_fast_route_ns={}
        self.sweeps=0; self.sweep_ms=0.0; self.last_sweep_bbo=0; self.last_sweep_depth=0
        self.fast_batches=0; self.fast_ms=0.0; self.fast_routes=0; self.fast_bbo=0; self.fast_depth=0
        self.total_bbo_checks=0; self.total_depth_evals=0; self.qualified_evals=0
        self.last_positive_routes=0

    def _fee_bps(self,symbol):
        rule=getattr(self.universe,'by_symbol',{}).get(symbol); raw=getattr(rule,'taker_commission',None) if rule else None
        try:
            v=float(raw)
            if 0<=v<=0.02: return v*1e4,'exchangeInfo'
        except Exception: pass
        return float(self.cfg.get('fee_bps_default',5.0)),'config_default'

    def _quick_bbo(self,r):
        x=self.store.get(r.symbol1); y=self.store.get(r.symbol2)
        if not x or not y or x.state!='VALID' or y.state!='VALID' or not x.asks or not y.bids or x.asks[0].p<=0:
            return None
        return (y.bids[0].p/x.asks[0].p-1.0)*1e4

    def _evaluate(self,r,size,f):
        x=self.store.get(r.symbol1); y=self.store.get(r.symbol2); now=time.time()
        if not x or not y: return None
        base,v1,c1=buy(x.asks,size,f); out,v2,c2=sell(y.bids,base,f); full=c1>=.999 and c2>=.999
        raw=((out/size)-1)*1e4 if full and size>0 else None
        fee1,src1=self._fee_bps(r.symbol1); fee2,src2=self._fee_bps(r.symbol2); f1=fee1/1e4; f2=fee2/1e4
        net=((out*(1-f1)*(1-f2)/size)-1)*1e4 if full and size>0 else None
        reserve=sum(float(self.cfg.get(k,0)) for k in ('slippage_reserve_bps','latency_reserve_bps','exit_risk_reserve_bps'))
        expected=(net-reserve) if net is not None else None
        la1=x.age_ms; la2=y.age_ms; ea1=x.exchange_age_ms(self.clock.offset_ms); ea2=y.exchange_age_ms(self.clock.offset_ms)
        ta1=x.transport_age_ms(self.clock.offset_ms); ta2=y.transport_age_ms(self.clock.offset_ms)
        lsk=abs(x.apply_ns-y.apply_ns)/1e6; esk=abs(float(x.exchange_ms)-float(y.exchange_ms)) if x.exchange_ms and y.exchange_ms else None
        hard=[]; timing=[]
        if x.state!='VALID' or y.state!='VALID': hard.append('BOOK')
        if c1<.999: hard.append('DEPTH_L1')
        if c2<.999: hard.append('DEPTH_L2')
        # Inactivity/skew describe strict execution timing; they are not proof that the WS/book is corrupt.
        if la1>float(self.cfg.get('max_local_age_ms',250)) or la2>float(self.cfg.get('max_local_age_ms',250)): timing.append('INACTIVITY_LOCAL')
        if ea1 is None or ea2 is None: timing.append('EXCHANGE_TS_MISSING')
        elif ea1>float(self.cfg.get('max_exchange_age_ms',500)) or ea2>float(self.cfg.get('max_exchange_age_ms',500)): timing.append('INACTIVITY_EXCHANGE')
        if ta1 is not None and ta1>float(self.cfg.get('max_transport_age_ms',500)): timing.append('TRANSPORT_AGE')
        if ta2 is not None and ta2>float(self.cfg.get('max_transport_age_ms',500)): timing.append('TRANSPORT_AGE')
        if lsk>float(self.cfg.get('max_local_skew_ms',150)): timing.append('UPDATE_SKEW_LOCAL')
        if esk is None: timing.append('EXCHANGE_SKEW_MISSING')
        elif esk>float(self.cfg.get('max_exchange_skew_ms',150)): timing.append('UPDATE_SKEW_EXCHANGE')
        hard=tuple(dict.fromkeys(hard)); timing=tuple(dict.fromkeys(timing)); data_valid=not hard; timing_valid=not timing
        accepted=data_valid and timing_valid and expected is not None and expected>=float(self.cfg.get('min_expected_edge_bps',10.0))
        reasons=list(hard)+list(timing)
        if data_valid and timing_valid and not accepted: reasons.append('EDGE_EXPECTED')
        return Eval(r.route,r.token,r.stable_a,r.stable_b,r.symbol1,r.symbol2,float(size),float(f),raw,net,expected,fee1,fee2,src1 if src1==src2 else src1+'+'+src2,
                    c1,c2,max_traversable_quote(x.asks,y.bids,f),v1,v2,la1,la2,ea1,ea2,ta1,ta2,lsk,esk,data_valid,timing_valid,accepted,hard,timing,tuple(reasons),now)

    @staticmethod
    def _class(e):
        if e.accepted: return 'QUALIFIED',3
        if e.data_valid and e.net_edge_bps is not None and e.net_edge_bps>0: return 'NET_POSITIVE',2
        if e.data_valid and e.raw_edge_bps is not None and e.raw_edge_bps>0: return 'RAW_POSITIVE',1
        return 'NOT_OPPORTUNITY',0

    @classmethod
    def _score(cls,e):
        klass,rank=cls._class(e)
        edge=e.expected_edge_bps if rank>=2 and e.expected_edge_bps is not None else e.raw_edge_bps
        pnl=(e.size*(e.expected_edge_bps or 0)/1e4) if e.expected_edge_bps is not None else -1e9
        return rank*1e12 + pnl*1e8 + (edge or -1e9)*1e3 + e.size

    def _record_activity(self,r,bbo):
        with self.lock:
            a=self.pending_activity.get(r.route)
            if not a:
                a={'route':r.route,'token':r.token,'stable_a':r.stable_a,'stable_b':r.stable_b,'quick_scans':0,'bbo_positive':0,'max_bbo_bps':None,'last_bbo_bps':None,'last_ts':time.time()}; self.pending_activity[r.route]=a
            a['quick_scans']+=1; a['last_ts']=time.time(); a['last_bbo_bps']=bbo
            if bbo is not None:
                a['bbo_positive']+=int(bbo>float(self.cfg.get('raw_watch_threshold_bps',0.0)))
                a['max_bbo_bps']=bbo if a['max_bbo_bps'] is None else max(a['max_bbo_bps'],bbo)

    def _record_profile(self,e):
        k=(e.route,e.size,e.fraction)
        with self.lock:
            a=self.pending_profiles.get(k)
            if not a:
                a={'route':e.route,'token':e.token,'stable_a':e.stable_a,'stable_b':e.stable_b,'size':e.size,'fraction':e.fraction,
                   'samples':0,'data_valid':0,'timing_valid':0,'raw_positive':0,'net_positive':0,'qualified':0,'sum_raw':0.0,'sum_net':0.0,'sum_expected':0.0,
                   'max_raw':None,'max_net':None,'max_expected':None,'sum_cov1':0.0,'sum_cov2':0.0,'sum_traversable':0.0,'max_traversable':None,'last_ts':e.ts,'last_reason':''}; self.pending_profiles[k]=a
            a['samples']+=1; a['data_valid']+=int(e.data_valid); a['timing_valid']+=int(e.timing_valid); a['raw_positive']+=int(e.raw_edge_bps is not None and e.raw_edge_bps>0); a['net_positive']+=int(e.net_edge_bps is not None and e.net_edge_bps>0); a['qualified']+=int(e.accepted)
            for name,val in [('raw',e.raw_edge_bps),('net',e.net_edge_bps),('expected',e.expected_edge_bps)]:
                if val is not None:
                    a['sum_'+name]+=val; a['max_'+name]=val if a['max_'+name] is None else max(a['max_'+name],val)
            a['sum_cov1']+=e.cov1; a['sum_cov2']+=e.cov2; a['sum_traversable']+=e.max_traversable_quote
            a['max_traversable']=e.max_traversable_quote if a['max_traversable'] is None else max(a['max_traversable'],e.max_traversable_quote)
            a['last_ts']=e.ts; a['last_reason']='|'.join(e.reasons) if e.reasons else 'OK'
            for z in e.hard_reasons: self.pending_reasons['HARD:'+z]+=1
            for z in e.timing_reasons: self.pending_reasons['TIMING:'+z]+=1
            if e.data_valid and e.timing_valid and not e.accepted: self.pending_reasons['EDGE:BELOW_EXPECTED']+=1

    def _record_hit(self,e,bbo):
        klass,rank=self._class(e)
        if rank<=0: return
        cooldown=float(self.cfg.get('opportunity_cooldown_s',5.0)); bucket=math.floor(e.ts/cooldown)*cooldown
        score=self._score(e); k=(e.route,bucket)
        hit={'bucket_ts':bucket,'first_ts':e.ts,'last_ts':e.ts,'route':e.route,'token':e.token,'stable_a':e.stable_a,'stable_b':e.stable_b,
             'symbol1':e.symbol1,'symbol2':e.symbol2,'observations':1,'class':klass,'class_rank':rank,'score':score,'size':e.size,'fraction':e.fraction,
             'bbo_raw_bps':bbo,'raw_edge_bps':e.raw_edge_bps,'fee_bps_leg1':e.fee_bps_leg1,'fee_bps_leg2':e.fee_bps_leg2,'net_edge_bps':e.net_edge_bps,
             'expected_edge_bps':e.expected_edge_bps,'potential_pnl_usd':e.size*(e.expected_edge_bps or 0)/1e4 if e.expected_edge_bps is not None else None,
             'cov1':e.cov1,'cov2':e.cov2,'max_traversable_quote':e.max_traversable_quote,'vwap1':e.vwap1,'vwap2':e.vwap2,
             'local_age1_ms':e.local_age1_ms,'local_age2_ms':e.local_age2_ms,'exchange_age1_ms':e.exchange_age1_ms,'exchange_age2_ms':e.exchange_age2_ms,
             'transport_age1_ms':e.transport_age1_ms,'transport_age2_ms':e.transport_age2_ms,'local_skew_ms':e.local_skew_ms,'exchange_skew_ms':e.exchange_skew_ms,
             'timing_valid':int(e.timing_valid),'accepted':int(e.accepted),'reasons':'|'.join(e.reasons) if e.reasons else 'OK'}
        with self.lock:
            old=self.pending_hits.get(k)
            if old:
                old['observations']+=1; old['last_ts']=max(old['last_ts'],e.ts); old['first_ts']=min(old['first_ts'],e.ts)
                if score>old['score']:
                    obs,first,last=old['observations'],old['first_ts'],old['last_ts']; old.update(hit); old['observations']=obs; old['first_ts']=first; old['last_ts']=last
            else: self.pending_hits[k]=hit

    def _evaluate_route_depth(self,r,bbo):
        ev=[]
        for size in self.cfg['test_sizes_usd']:
            for f in self.cfg['depth_fractions']:
                e=self._evaluate(r,size,f)
                if e is not None:
                    ev.append(e); self._record_profile(e)
        best=None
        for e in ev:
            if self._class(e)[1]>0 and (best is None or self._score(e)>self._score(best)): best=e
        if best is not None: self._record_hit(best,bbo)
        self.total_depth_evals+=len(ev); self.qualified_evals+=sum(int(e.accepted) for e in ev)
        return len(ev),best

    def _process_routes(self,routes,fast=False):
        bbo_checks=depth_evals=positive=0; now_ns=time.monotonic_ns(); min_ns=int(float(self.cfg.get('fast_watch_route_cooldown_ms',0))*1e6)
        threshold=float(self.cfg.get('raw_watch_threshold_bps',0.0))
        for r in routes:
            if fast:
                with self.lock:
                    last=self.last_fast_route_ns.get(r.route,0)
                    if now_ns-last<min_ns: continue
                    self.last_fast_route_ns[r.route]=now_ns
            bbo=self._quick_bbo(r); bbo_checks+=1; self._record_activity(r,bbo)
            if bbo is not None and bbo>threshold:
                positive+=1; n,_=self._evaluate_route_depth(r,bbo); depth_evals+=n
        self.total_bbo_checks+=bbo_checks
        return bbo_checks,depth_evals,positive

    def flush(self,force=False):
        if not force and time.monotonic()-self.last_flush<float(self.cfg.get('aggregate_flush_s',2.0)): return
        with self.lock:
            activity=list(self.pending_activity.values()); profiles=list(self.pending_profiles.values()); hits=list(self.pending_hits.values()); reasons=dict(self.pending_reasons)
            self.pending_activity={}; self.pending_profiles={}; self.pending_hits={}; self.pending_reasons=Counter(); self.last_flush=time.monotonic()
        self.db.upsert_route_activity(activity); self.db.upsert_route_profiles(profiles); self.db.upsert_opportunity_hits(hits); self.db.add_reason_counts(reasons)

    def sweep_once(self):
        t=time.monotonic_ns(); b,d,p=self._process_routes(self.universe.routes,fast=False); self.flush()
        with self.lock:
            self.sweeps+=1; self.last_sweep_bbo=b; self.last_sweep_depth=d; self.last_positive_routes=p; self.sweep_ms=(time.monotonic_ns()-t)/1e6
        return b,d

    def fast_once(self,changed_symbols):
        t=time.monotonic_ns(); routes={r.route:r for s in changed_symbols for r in self.routes_by_symbol.get(s,[])}
        b,d,p=self._process_routes(routes.values(),fast=True); self.flush()
        with self.lock:
            self.fast_batches+=1; self.fast_routes=len(routes); self.fast_bbo=b; self.fast_depth=d; self.fast_ms=(time.monotonic_ns()-t)/1e6
        return b,d

    def status(self):
        with self.lock:
            return {'sweeps':self.sweeps,'last_sweep_ms':self.sweep_ms,'last_sweep_bbo_checks':self.last_sweep_bbo,'last_sweep_depth_evals':self.last_sweep_depth,
                    'last_positive_routes':self.last_positive_routes,'fast_batches':self.fast_batches,'fast_last_ms':self.fast_ms,'fast_routes_touched':self.fast_routes,
                    'fast_bbo_checks':self.fast_bbo,'fast_depth_evals':self.fast_depth,'total_bbo_checks':self.total_bbo_checks,'total_depth_evals':self.total_depth_evals,
                    'qualified_evaluations':self.qualified_evals,'pending_hits':len(self.pending_hits)}
