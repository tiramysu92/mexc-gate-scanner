from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, Iterable
import queue
import threading
import time

@dataclass(frozen=True)
class L:
    p: float
    q: float

@dataclass(frozen=True)
class Book:
    symbol: str
    bids: Tuple[L, ...]
    asks: Tuple[L, ...]
    gen: int
    ver: Optional[int]
    exchange_ms: Optional[int]
    recv_wall_ms: Optional[float]
    recv_ns: int
    apply_ns: int
    state: str = "VALID"

    @property
    def age_ms(self) -> float:
        # This is book-inactivity age, not network latency. A depth stream is event driven.
        return (time.monotonic_ns() - self.apply_ns) / 1e6

    def exchange_age_ms(self, clock_offset_ms: float = 0.0) -> Optional[float]:
        if not self.exchange_ms:
            return None
        return (time.time() * 1000.0 + clock_offset_ms) - float(self.exchange_ms)

    def transport_age_ms(self, clock_offset_ms: float = 0.0) -> Optional[float]:
        if not self.exchange_ms or self.recv_wall_ms is None:
            return None
        return (float(self.recv_wall_ms) + clock_offset_ms) - float(self.exchange_ms)

    @property
    def best_bid(self) -> Optional[float]:
        return self.bids[0].p if self.bids else None

    @property
    def best_ask(self) -> Optional[float]:
        return self.asks[0].p if self.asks else None

    @property
    def spread_bps(self) -> Optional[float]:
        if not self.bids or not self.asks or self.bids[0].p <= 0:
            return None
        return (self.asks[0].p / self.bids[0].p - 1.0) * 1e4

class Store:
    """Immutable book store + bounded symbol-update signal queue.

    The queue is only a wake-up hint for the fast opportunity watcher. Book state remains
    authoritative in _books, so dropping a wake-up never corrupts the book; it only reduces
    fast-watch temporal resolution and is therefore counted explicitly.
    """
    def __init__(self, update_queue_max: int = 100000):
        self._lock = threading.RLock()
        self._books: dict[str, Book] = {}
        self._updates = queue.Queue(maxsize=int(update_queue_max))
        self.update_drops = 0

    def put(self, book: Book) -> None:
        with self._lock:
            self._books[book.symbol] = book
        try:
            self._updates.put_nowait(book.symbol)
        except queue.Full:
            self.update_drops += 1

    def invalidate(self, symbol: str, generation: int | None = None) -> None:
        with self._lock:
            old = self._books.get(symbol)
            if old is not None:
                self._books[symbol] = Book(old.symbol, old.bids, old.asks, generation if generation is not None else old.gen, old.ver, old.exchange_ms, old.recv_wall_ms, old.recv_ns, old.apply_ns, "INVALID")
        try:
            self._updates.put_nowait(symbol)
        except queue.Full:
            self.update_drops += 1

    def get(self, symbol: str) -> Optional[Book]:
        with self._lock:
            return self._books.get(symbol)

    def snapshot(self) -> dict[str, Book]:
        with self._lock:
            return dict(self._books)

    def n(self) -> int:
        with self._lock:
            return len(self._books)

    def drain_updates(self, timeout_s: float = 0.1, debounce_s: float = 0.025, max_items: int = 10000) -> set[str]:
        try:
            first = self._updates.get(timeout=max(0.0, timeout_s))
        except queue.Empty:
            return set()
        out = {first}
        deadline = time.monotonic() + max(0.0, debounce_s)
        while len(out) < max_items:
            remain = deadline - time.monotonic()
            if remain <= 0:
                break
            try:
                out.add(self._updates.get(timeout=min(remain, 0.005)))
            except queue.Empty:
                continue
        # Drain immediately available duplicates without waiting.
        while len(out) < max_items:
            try:
                out.add(self._updates.get_nowait())
            except queue.Empty:
                break
        return out

    def update_queue_size(self) -> int:
        try:
            return self._updates.qsize()
        except Exception:
            return 0


def buy(levels: Iterable[L], quote: float, fraction: float = 0.25):
    quote = float(quote)
    if quote <= 0:
        return 0.0, 0.0, 1.0
    f = max(0.0, min(1.0, float(fraction)))
    rem = quote; base = spent = 0.0
    for x in levels:
        if x.p <= 0 or x.q <= 0: continue
        take = min(rem, x.p * x.q * f)
        if take <= 0: continue
        base += take / x.p; spent += take; rem -= take
        if rem <= 1e-10: break
    return base, (spent / base if base else 0.0), spent / quote


def sell(levels: Iterable[L], base: float, fraction: float = 0.25):
    base = float(base)
    if base <= 0:
        return 0.0, 0.0, 1.0
    f = max(0.0, min(1.0, float(fraction)))
    rem = base; sold = out = 0.0
    for x in levels:
        if x.p <= 0 or x.q <= 0: continue
        take = min(rem, x.q * f)
        if take <= 0: continue
        sold += take; out += take * x.p; rem -= take
        if rem <= 1e-10: break
    return out, (out / sold if sold else 0.0), sold / base


def cost_for_base(asks: Iterable[L], base: float, fraction: float = 0.25):
    base = float(base)
    if base <= 0: return 0.0, 0.0, 1.0
    f = max(0.0, min(1.0, float(fraction)))
    rem = base; got = cost = 0.0
    for x in asks:
        if x.p <= 0 or x.q <= 0: continue
        take = min(rem, x.q * f)
        if take <= 0: continue
        got += take; cost += take * x.p; rem -= take
        if rem <= 1e-10: break
    return cost, (cost / got if got else 0.0), got / base


def max_traversable_quote(asks: Iterable[L], bids: Iterable[L], fraction: float = 0.25) -> float:
    f = max(0.0, min(1.0, float(fraction)))
    ask_levels = tuple(asks); bid_levels = tuple(bids)
    ask_base = sum(max(0.0, x.q) * f for x in ask_levels)
    bid_base = sum(max(0.0, x.q) * f for x in bid_levels)
    base = min(ask_base, bid_base)
    cost, _, cov = cost_for_base(ask_levels, base, f)
    return cost if cov >= 0.999999 else 0.0


def pct(values, p: float) -> Optional[float]:
    values = sorted(v for v in values if v is not None)
    if not values: return None
    if len(values) == 1: return float(values[0])
    k = (len(values) - 1) * p; lo = int(k); hi = min(len(values)-1, lo+1); w = k-lo
    return float(values[lo]*(1-w) + values[hi]*w)
