from __future__ import annotations
import json, os, sqlite3, threading, time
from dataclasses import asdict

SCHEMA = '''
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS universe_symbols(
 symbol TEXT PRIMARY KEY,base TEXT,quote TEXT,status TEXT,spot_allowed INT,api_default INT,
 activity_score REAL,quote_volume_24h REAL,trade_count_24h REAL,taker_commission TEXT,trade_side_type TEXT);
CREATE TABLE IF NOT EXISTS market_samples(
 id INTEGER PRIMARY KEY,ts REAL,symbol TEXT,ws_id INT,ready INT,bid REAL,ask REAL,spread_bps REAL,
 local_age_ms REAL,exchange_age_ms REAL,transport_age_ms REAL,msg_rate REAL,version INT,generation INT,gaps INT,resyncs INT,errors INT);
CREATE INDEX IF NOT EXISTS ix_market_ts ON market_samples(ts);
CREATE INDEX IF NOT EXISTS ix_market_symbol_ts ON market_samples(symbol,ts);
CREATE TABLE IF NOT EXISTS health_samples(
 id INTEGER PRIMARY KEY,ts REAL,uptime_s REAL,ready_symbols INT,total_symbols INT,ws_connected INT,ws_total INT,subscriptions INT,
 ws_msg_rate REAL,messages INT,gaps INT,resyncs INT,recovery_resyncs INT,reconnects INT,collector_errors INT,
 sweep_ms REAL,bbo_checks INT,depth_evals INT,fast_ms REAL,fast_routes INT,fast_batches INT,
 cpu_pct REAL,rss_mb REAL,db_mb REAL,update_queue INT,update_drops INT);
CREATE INDEX IF NOT EXISTS ix_health_ts ON health_samples(ts);
CREATE TABLE IF NOT EXISTS collector_errors(id INTEGER PRIMARY KEY,ts REAL,kind TEXT,symbol TEXT,detail TEXT,extra_json TEXT);
CREATE INDEX IF NOT EXISTS ix_err_ts ON collector_errors(ts);
CREATE TABLE IF NOT EXISTS reason_aggregates(reason TEXT PRIMARY KEY,count INT,last_ts REAL);
CREATE TABLE IF NOT EXISTS route_activity(
 route TEXT PRIMARY KEY,token TEXT,stable_a TEXT,stable_b TEXT,quick_scans INT,bbo_positive INT,
 max_bbo_bps REAL,last_bbo_bps REAL,last_ts REAL);
CREATE TABLE IF NOT EXISTS route_profiles(
 route TEXT,token TEXT,stable_a TEXT,stable_b TEXT,size REAL,fraction REAL,
 samples INT,data_valid INT,timing_valid INT,raw_positive INT,net_positive INT,qualified INT,
 sum_raw REAL,sum_net REAL,sum_expected REAL,max_raw REAL,max_net REAL,max_expected REAL,
 sum_cov1 REAL,sum_cov2 REAL,sum_traversable REAL,max_traversable REAL,last_ts REAL,last_reason TEXT,
 PRIMARY KEY(route,size,fraction));
CREATE TABLE IF NOT EXISTS opportunity_hits(
 id INTEGER PRIMARY KEY,bucket_ts REAL,first_ts REAL,last_ts REAL,route TEXT,token TEXT,stable_a TEXT,stable_b TEXT,
 symbol1 TEXT,symbol2 TEXT,observations INT,class TEXT,class_rank INT,score REAL,size REAL,fraction REAL,
 bbo_raw_bps REAL,raw_edge_bps REAL,fee_bps_leg1 REAL,fee_bps_leg2 REAL,net_edge_bps REAL,expected_edge_bps REAL,
 potential_pnl_usd REAL,cov1 REAL,cov2 REAL,max_traversable_quote REAL,vwap1 REAL,vwap2 REAL,
 local_age1_ms REAL,local_age2_ms REAL,exchange_age1_ms REAL,exchange_age2_ms REAL,
 transport_age1_ms REAL,transport_age2_ms REAL,local_skew_ms REAL,exchange_skew_ms REAL,
 timing_valid INT,accepted INT,reasons TEXT,
 UNIQUE(route,bucket_ts));
CREATE INDEX IF NOT EXISTS ix_opp_ts ON opportunity_hits(last_ts DESC);
CREATE INDEX IF NOT EXISTS ix_opp_route_ts ON opportunity_hits(route,last_ts DESC);
CREATE INDEX IF NOT EXISTS ix_opp_class_ts ON opportunity_hits(class_rank,last_ts DESC);
'''

class DB:
    def __init__(self, path):
        self.path = path; self.lock = threading.RLock()
        with self.conn() as c: c.executescript(SCHEMA)

    def conn(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.execute('PRAGMA journal_mode=WAL'); c.execute('PRAGMA synchronous=NORMAL'); c.execute('PRAGMA busy_timeout=30000')
        return c

    def set_meta(self, key, value):
        raw = json.dumps(value, separators=(',', ':'), default=str)
        with self.lock, self.conn() as c:
            c.execute('INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, raw))

    def save_universe(self, symbols):
        rows=[]
        for s in symbols:
            rows.append((s.symbol,s.base,s.quote,s.status,int(bool(s.spot_allowed)),int(bool(s.api_default)),
                         float(getattr(s,'activity_score',1) or 1),getattr(s,'quote_volume_24h',None),getattr(s,'trade_count_24h',None),
                         s.taker_commission,s.trade_side_type))
        with self.lock, self.conn() as c:
            c.executemany('''INSERT OR REPLACE INTO universe_symbols
             (symbol,base,quote,status,spot_allowed,api_default,activity_score,quote_volume_24h,trade_count_24h,taker_commission,trade_side_type)
             VALUES(?,?,?,?,?,?,?,?,?,?,?)''', rows)

    def log_collector_error(self, event):
        known={'ts','kind','symbol','detail'}; extra={k:v for k,v in event.items() if k not in known}
        with self.lock, self.conn() as c:
            c.execute('INSERT INTO collector_errors(ts,kind,symbol,detail,extra_json) VALUES(?,?,?,?,?)',
                      (event.get('ts',time.time()),event.get('kind'),event.get('symbol'),event.get('detail'),json.dumps(extra,default=str)))

    def add_market_samples(self, rows):
        if not rows: return
        ts=time.time(); vals=[]
        for x in rows:
            vals.append((ts,x['symbol'],x.get('ws_id'),int(bool(x.get('ready'))),x.get('bid'),x.get('ask'),x.get('spread_bps'),
                         x.get('local_age_ms'),x.get('exchange_age_ms'),x.get('transport_age_ms'),x.get('msg_rate_10s'),
                         x.get('version'),x.get('generation'),x.get('gaps'),x.get('resyncs'),x.get('errors')))
        with self.lock, self.conn() as c:
            c.executemany('''INSERT INTO market_samples(ts,symbol,ws_id,ready,bid,ask,spread_bps,local_age_ms,exchange_age_ms,transport_age_ms,msg_rate,version,generation,gaps,resyncs,errors)
                             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', vals)

    def add_health(self, x):
        cols=['uptime_s','ready_symbols','total_symbols','ws_connected','ws_total','subscriptions','ws_msg_rate','messages','gaps','resyncs','recovery_resyncs','reconnects','collector_errors',
              'sweep_ms','bbo_checks','depth_evals','fast_ms','fast_routes','fast_batches','cpu_pct','rss_mb','db_mb','update_queue','update_drops']
        vals=[time.time()]+[x.get(k) for k in cols]
        with self.lock, self.conn() as c:
            c.execute('INSERT INTO health_samples VALUES(NULL,'+','.join('?' for _ in vals)+')',vals)

    def upsert_route_activity(self, rows):
        if not rows: return
        vals=[(x['route'],x['token'],x['stable_a'],x['stable_b'],x['quick_scans'],x['bbo_positive'],x.get('max_bbo_bps'),x.get('last_bbo_bps'),x['last_ts']) for x in rows]
        sql='''INSERT INTO route_activity(route,token,stable_a,stable_b,quick_scans,bbo_positive,max_bbo_bps,last_bbo_bps,last_ts)
        VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(route) DO UPDATE SET
        quick_scans=quick_scans+excluded.quick_scans,bbo_positive=bbo_positive+excluded.bbo_positive,
        max_bbo_bps=CASE WHEN max_bbo_bps IS NULL THEN excluded.max_bbo_bps WHEN excluded.max_bbo_bps IS NULL THEN max_bbo_bps ELSE MAX(max_bbo_bps,excluded.max_bbo_bps) END,
        last_bbo_bps=excluded.last_bbo_bps,last_ts=excluded.last_ts'''
        with self.lock,self.conn() as c: c.executemany(sql,vals)

    def upsert_route_profiles(self, rows):
        if not rows: return
        vals=[]
        for r in rows:
            vals.append((r['route'],r['token'],r['stable_a'],r['stable_b'],r['size'],r['fraction'],r['samples'],r['data_valid'],r['timing_valid'],r['raw_positive'],r['net_positive'],r['qualified'],
                         r['sum_raw'],r['sum_net'],r['sum_expected'],r.get('max_raw'),r.get('max_net'),r.get('max_expected'),r['sum_cov1'],r['sum_cov2'],r['sum_traversable'],r.get('max_traversable'),r['last_ts'],r.get('last_reason')))
        sql='''INSERT INTO route_profiles VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(route,size,fraction) DO UPDATE SET
        samples=samples+excluded.samples,data_valid=data_valid+excluded.data_valid,timing_valid=timing_valid+excluded.timing_valid,
        raw_positive=raw_positive+excluded.raw_positive,net_positive=net_positive+excluded.net_positive,qualified=qualified+excluded.qualified,
        sum_raw=sum_raw+excluded.sum_raw,sum_net=sum_net+excluded.sum_net,sum_expected=sum_expected+excluded.sum_expected,
        max_raw=CASE WHEN max_raw IS NULL THEN excluded.max_raw WHEN excluded.max_raw IS NULL THEN max_raw ELSE MAX(max_raw,excluded.max_raw) END,
        max_net=CASE WHEN max_net IS NULL THEN excluded.max_net WHEN excluded.max_net IS NULL THEN max_net ELSE MAX(max_net,excluded.max_net) END,
        max_expected=CASE WHEN max_expected IS NULL THEN excluded.max_expected WHEN excluded.max_expected IS NULL THEN max_expected ELSE MAX(max_expected,excluded.max_expected) END,
        sum_cov1=sum_cov1+excluded.sum_cov1,sum_cov2=sum_cov2+excluded.sum_cov2,sum_traversable=sum_traversable+excluded.sum_traversable,
        max_traversable=CASE WHEN max_traversable IS NULL THEN excluded.max_traversable WHEN excluded.max_traversable IS NULL THEN max_traversable ELSE MAX(max_traversable,excluded.max_traversable) END,
        last_ts=excluded.last_ts,last_reason=excluded.last_reason'''
        with self.lock,self.conn() as c: c.executemany(sql,vals)

    def add_reason_counts(self, counts):
        if not counts:return
        ts=time.time()
        with self.lock,self.conn() as c:
            c.executemany('''INSERT INTO reason_aggregates(reason,count,last_ts) VALUES(?,?,?)
             ON CONFLICT(reason) DO UPDATE SET count=count+excluded.count,last_ts=excluded.last_ts''',[(k,int(v),ts) for k,v in counts.items()])

    def upsert_opportunity_hits(self, hits):
        if not hits:return
        cols=['bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','symbol1','symbol2','observations','class','class_rank','score','size','fraction','bbo_raw_bps','raw_edge_bps','fee_bps_leg1','fee_bps_leg2','net_edge_bps','expected_edge_bps','potential_pnl_usd','cov1','cov2','max_traversable_quote','vwap1','vwap2','local_age1_ms','local_age2_ms','exchange_age1_ms','exchange_age2_ms','transport_age1_ms','transport_age2_ms','local_skew_ms','exchange_skew_ms','timing_valid','accepted','reasons']
        vals=[tuple(h.get(c) for c in cols) for h in hits]
        update_best=','.join([f'''{c}=CASE WHEN excluded.score>score THEN excluded.{c} ELSE {c} END''' for c in cols if c not in {'bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','symbol1','symbol2','observations'}])
        sql=f'''INSERT INTO opportunity_hits({','.join(cols)}) VALUES({','.join('?' for _ in cols)})
        ON CONFLICT(route,bucket_ts) DO UPDATE SET observations=observations+excluded.observations,last_ts=MAX(last_ts,excluded.last_ts),first_ts=MIN(first_ts,excluded.first_ts),{update_best}'''
        with self.lock,self.conn() as c: c.executemany(sql,vals)

    def recent_opportunities(self, limit=150, hours=24, min_class_rank=1):
        since=time.time()-float(hours)*3600
        with self.conn() as c:
            rows=c.execute('''SELECT bucket_ts,first_ts,last_ts,route,token,stable_a,stable_b,observations,class,class_rank,size,fraction,bbo_raw_bps,raw_edge_bps,fee_bps_leg1,fee_bps_leg2,net_edge_bps,expected_edge_bps,potential_pnl_usd,cov1,cov2,max_traversable_quote,vwap1,vwap2,local_age1_ms,local_age2_ms,exchange_age1_ms,exchange_age2_ms,transport_age1_ms,transport_age2_ms,local_skew_ms,exchange_skew_ms,timing_valid,accepted,reasons
            FROM opportunity_hits WHERE last_ts>=? AND class_rank>=? ORDER BY last_ts DESC,class_rank DESC,score DESC LIMIT ?''',(since,int(min_class_rank),int(limit))).fetchall()
        cols=['bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','observations','class','class_rank','size','fraction','bbo_raw_bps','raw_edge_bps','fee_bps_leg1','fee_bps_leg2','net_edge_bps','expected_edge_bps','potential_pnl_usd','cov1','cov2','max_traversable_quote','vwap1','vwap2','local_age1_ms','local_age2_ms','exchange_age1_ms','exchange_age2_ms','transport_age1_ms','transport_age2_ms','local_skew_ms','exchange_skew_ms','timing_valid','accepted','reasons']
        return [dict(zip(cols,r)) for r in rows]

    def route_viability(self, hours=24, limit=150):
        since=time.time()-float(hours)*3600
        with self.conn() as c:
            rows=c.execute('''SELECT route,token,stable_a,stable_b,count(*) windows,sum(observations),
              sum(CASE WHEN class_rank=3 THEN 1 ELSE 0 END),sum(CASE WHEN class_rank>=2 THEN 1 ELSE 0 END),
              max(raw_edge_bps),max(net_edge_bps),max(expected_edge_bps),avg(expected_edge_bps),max(potential_pnl_usd),max(last_ts)
              FROM opportunity_hits WHERE last_ts>=? GROUP BY route ORDER BY
              sum(CASE WHEN class_rank=3 THEN 1 ELSE 0 END) DESC,
              sum(CASE WHEN class_rank>=2 THEN 1 ELSE 0 END) DESC,
              max(expected_edge_bps) DESC,max(raw_edge_bps) DESC LIMIT ?''',(since,int(limit))).fetchall()
            out=[]
            for r in rows:
                best=c.execute('''SELECT class,size,fraction,raw_edge_bps,net_edge_bps,expected_edge_bps,potential_pnl_usd,max_traversable_quote,timing_valid,reasons
                  FROM opportunity_hits WHERE route=? AND last_ts>=? ORDER BY class_rank DESC,score DESC LIMIT 1''',(r[0],since)).fetchone()
                out.append({'route':r[0],'token':r[1],'stable_a':r[2],'stable_b':r[3],'windows_5s':r[4],'observations':r[5] or 0,'qualified_windows':r[6] or 0,'net_positive_windows':r[7] or 0,
                            'max_raw_bps':r[8],'max_net_bps':r[9],'max_expected_bps':r[10],'avg_expected_bps':r[11],'max_potential_pnl_usd':r[12],'last_ts':r[13],
                            'best_class':best[0] if best else None,'best_size':best[1] if best else None,'best_fraction':best[2] if best else None,'best_raw_bps':best[3] if best else None,
                            'best_net_bps':best[4] if best else None,'best_expected_bps':best[5] if best else None,'best_potential_pnl_usd':best[6] if best else None,'best_traversable':best[7] if best else None,
                            'best_timing_valid':best[8] if best else None,'best_reasons':best[9] if best else None})
        return out

    def route_activity(self, limit=200):
        with self.conn() as c:
            rows=c.execute('''SELECT route,token,stable_a,stable_b,quick_scans,bbo_positive,max_bbo_bps,last_bbo_bps,last_ts,
              CASE WHEN quick_scans>0 THEN 100.0*bbo_positive/quick_scans ELSE 0 END
              FROM route_activity ORDER BY bbo_positive DESC,max_bbo_bps DESC LIMIT ?''',(int(limit),)).fetchall()
        cols=['route','token','stable_a','stable_b','quick_scans','bbo_positive','max_bbo_bps','last_bbo_bps','last_ts','bbo_positive_pct']
        return [dict(zip(cols,r)) for r in rows]

    def profile_summary(self, limit=100):
        with self.conn() as c:
            rows=c.execute('''SELECT route,token,stable_a,stable_b,size,fraction,samples,data_valid,timing_valid,raw_positive,net_positive,qualified,
              CASE WHEN samples>0 THEN sum_raw/samples END,CASE WHEN samples>0 THEN sum_net/samples END,CASE WHEN samples>0 THEN sum_expected/samples END,
              max_raw,max_net,max_expected,CASE WHEN samples>0 THEN sum_cov1/samples END,CASE WHEN samples>0 THEN sum_cov2/samples END,
              CASE WHEN samples>0 THEN sum_traversable/samples END,max_traversable,last_ts,last_reason
              FROM route_profiles ORDER BY max_expected DESC,max_net DESC,max_raw DESC LIMIT ?''',(int(limit),)).fetchall()
        cols=['route','token','stable_a','stable_b','size','fraction','samples','data_valid','timing_valid','raw_positive','net_positive','qualified','avg_raw_bps','avg_net_bps','avg_expected_bps','max_raw_bps','max_net_bps','max_expected_bps','avg_cov1','avg_cov2','avg_traversable','max_traversable','last_ts','last_reason']
        return [dict(zip(cols,r)) for r in rows]

    def reasons(self):
        with self.conn() as c: rows=c.execute('SELECT reason,count,last_ts FROM reason_aggregates ORDER BY count DESC').fetchall()
        total=sum(r[1] for r in rows) or 1
        return [{'reason':r[0],'count':r[1],'pct':100*r[1]/total,'last_ts':r[2]} for r in rows]

    def opportunity_stats(self,hours=24):
        since=time.time()-float(hours)*3600
        with self.conn() as c:
            r=c.execute('''SELECT count(*),count(DISTINCT route),sum(CASE WHEN class_rank>=2 THEN 1 ELSE 0 END),sum(CASE WHEN class_rank=3 THEN 1 ELSE 0 END),max(raw_edge_bps),max(net_edge_bps),max(expected_edge_bps),sum(observations)
              FROM opportunity_hits WHERE last_ts>=?''',(since,)).fetchone()
        return {'windows_5s':r[0] or 0,'unique_routes':r[1] or 0,'net_positive_windows':r[2] or 0,'qualified_windows':r[3] or 0,'max_raw_bps':r[4],'max_net_bps':r[5],'max_expected_bps':r[6],'observations':r[7] or 0}

    def health_series(self,minutes=60,limit=1000):
        since=time.time()-float(minutes)*60
        with self.conn() as c:
            rows=c.execute('''SELECT ts,ready_symbols,total_symbols,ws_connected,ws_total,subscriptions,ws_msg_rate,gaps,recovery_resyncs,reconnects,collector_errors,sweep_ms,bbo_checks,depth_evals,fast_ms,fast_routes,fast_batches,cpu_pct,rss_mb,db_mb,update_queue,update_drops
              FROM health_samples WHERE ts>=? ORDER BY ts ASC LIMIT ?''',(since,int(limit))).fetchall()
        cols=['ts','ready_symbols','total_symbols','ws_connected','ws_total','subscriptions','ws_msg_rate','gaps','recovery_resyncs','reconnects','collector_errors','sweep_ms','bbo_checks','depth_evals','fast_ms','fast_routes','fast_batches','cpu_pct','rss_mb','db_mb','update_queue','update_drops']
        return [dict(zip(cols,r)) for r in rows]

    def recent_errors(self,limit=100):
        with self.conn() as c: rows=c.execute('SELECT ts,kind,symbol,detail,extra_json FROM collector_errors ORDER BY id DESC LIMIT ?',(int(limit),)).fetchall()
        return [{'ts':r[0],'kind':r[1],'symbol':r[2],'detail':r[3],'extra':json.loads(r[4] or '{}')} for r in rows]

    def counts(self):
        with self.conn() as c:
            names=['market_samples','health_samples','route_activity','route_profiles','opportunity_hits','collector_errors']
            out={n:c.execute(f'SELECT count(*) FROM {n}').fetchone()[0] for n in names}
        try: out['db_mb']=os.path.getsize(self.path)/1024/1024
        except OSError: out['db_mb']=0
        return out
