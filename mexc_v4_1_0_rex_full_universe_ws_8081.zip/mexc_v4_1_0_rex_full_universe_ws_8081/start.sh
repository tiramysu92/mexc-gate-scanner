#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ss -ltn 2>/dev/null | grep -q ':8081 '; then echo 'ERREUR: port 8081 déjà occupé'; exit 1; fi
if [ ! -x .venv/bin/python ]; then echo 'Lancez ./install.sh d abord'; exit 1; fi
if [ -f v4_rex.pid ] && kill -0 "$(cat v4_rex.pid)" 2>/dev/null; then echo "Déjà actif PID $(cat v4_rex.pid)"; exit 1; fi
nohup ./run.sh > v4_rex.log 2>&1 &
echo $! > v4_rex.pid
echo "V4.1.0 FULL UNIVERSE démarrée PID $(cat v4_rex.pid)"
