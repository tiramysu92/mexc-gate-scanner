# V4.1.0-REX Full Universe

## Changement de périmètre
- Univers automatique : tous les tokens MEXC Spot disposant d'au moins deux marchés parmi USDT/USDC/USD1.
- Toutes les routes dirigées `stablecoin A > token > stablecoin B` valides sont créées automatiquement.
- Plus aucune whitelist SOL/SUI/FET/RAY/TIA/ZEC par défaut.

## WebSockets
- Plan multi-WS calculé à partir de l'activité 24 h MEXC.
- Greedy load-balancing des marchés les plus actifs entre sockets.
- Anti-affinité des marchés d'un même token lorsque l'équilibrage le permet.
- 20 streams/socket par défaut, hard cap 30.
- Télémétrie séparée par WS : connected, READY, msg/s, charge estimée, erreurs, reconnects, dernier message, rotation.
- Snapshot/rebuild via pool borné, au lieu de créer des centaines de threads de snapshot au démarrage.
- Rotation proactive avant 24 h de connexion.

## Scanner
- Préfiltre BBO sur 100 % des routes.
- Profondeur complète (6 tailles × 8 fractions) uniquement lorsque BBO brut > 0.
- Fast watcher événementiel + sweep analytique global toutes les 5 s.
- Cooldown d'affichage/persistance de 5 s **par route**.
- Une fenêtre 5 s contient le meilleur profil taille/profondeur et le nombre d'observations intermédiaires.

## Interface
- Suppression des tableaux OPEN/CLOSE/lifecycles de la vue principale.
- Tableau principal : opportunités 2-leg concrètes, verdict, taille, depth, brut, frais, net, expected, gain théorique, traversable, coverage et timing.
- Tableau de viabilité 24 h par route.
- Tableau des connexions WS équilibrées.
- Couverture de toutes les routes au BBO.
- Books détaillés séparés des WS.
