#!/usr/bin/env python3
import argparse,gzip,hashlib,json,sqlite3,time
from pathlib import Path
from v4rex.db import DB
from v4rex import __version__

p=argparse.ArgumentParser();p.add_argument('--config',default='config.json');p.add_argument('--out',default=None);a=p.parse_args()
cfg=json.load(open(a.config)); src=Path(cfg['db_path']); stamp=time.strftime('%Y%m%d_%H%M%S'); out=Path(a.out or f'export_v410_{stamp}');out.mkdir(parents=True,exist_ok=True)
snap=out/'v4_rex_full_universe_snapshot.db'; s=sqlite3.connect(src); d=sqlite3.connect(snap); s.backup(d); d.close(); s.close()
db=DB(str(snap))
summary={'generated_at':time.time(),'version':__version__,'config':cfg,'counts':db.counts(),'opportunity_stats':db.opportunity_stats(24),
         'opportunities':db.recent_opportunities(100000,24,1),'viability':db.route_viability(24,100000),'route_activity':db.route_activity(100000),
         'profiles':db.profile_summary(100000),'reasons':db.reasons(),'errors':db.recent_errors(10000)}
with gzip.open(out/'analysis_summary.json.gz','wt',encoding='utf-8') as f: json.dump(summary,f,separators=(',',':'),default=str)
universe=Path(cfg.get('universe_snapshot_path','exchange_info_v410_start.json.gz'))
if universe.exists(): (out/universe.name).write_bytes(universe.read_bytes())
lines=[]
for f in sorted(out.iterdir()):
    if f.is_file() and f.name!='SHA256SUMS': lines.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name)
(out/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
print(out.resolve())
