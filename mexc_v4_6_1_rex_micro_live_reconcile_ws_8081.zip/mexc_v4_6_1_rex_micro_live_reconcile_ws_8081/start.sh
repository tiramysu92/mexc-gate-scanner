#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ss -ltn 2>/dev/null | grep -q ':8081 '; then echo 'ERREUR: port 8081 déjà occupé'; exit 1; fi
[ -x .venv/bin/python ] || { echo 'Lancez ./install.sh d abord'; exit 1; }
nohup ./run.sh > v4_rex.log 2>&1 & echo $! > v4_rex.pid
echo "V4.6.1 MICRO-LIVE démarrée PID $(cat v4_rex.pid)"
