from __future__ import annotations
import argparse,json,os,signal,threading,time,traceback
import psutil
from flask import Flask,jsonify,render_template,request
from waitress import serve
from v4rex import __version__
from v4rex.core import Store,pct
from v4rex.db import DB
from v4rex.universe import UniverseBuilder
from v4rex.collector import Collector
from v4rex.engine import Engine
from v4rex.live import MicroLiveExecutor

parser=argparse.ArgumentParser();parser.add_argument('config',nargs='?',default='config.json');args=parser.parse_args();cfg=json.load(open(args.config,encoding='utf-8'))
mode=str(cfg.get('mode','SHADOW')).upper()
if mode not in ('SHADOW','MICRO_LIVE'):raise SystemExit('mode must be SHADOW or MICRO_LIVE')
started=time.time();stop_event=threading.Event();thread_state={};thread_lock=threading.RLock();process=psutil.Process(os.getpid());process.cpu_percent(None)
db=DB(cfg['db_path']);bootstrap_survival=db.bootstrap_survival_from(cfg.get('bootstrap_survival_db')) if cfg.get('bootstrap_survival_db') else {'copied':0,'reason':'DISABLED'};universe=UniverseBuilder(cfg).build()
if not universe.routes or not universe.symbols:raise SystemExit('Universe vide')
UniverseBuilder.save_snapshot(universe,cfg.get('universe_snapshot_path','exchange_info_v461_start.json.gz'));db.save_universe(universe.symbols);db.set_meta('version',__version__);db.set_meta('started_at',started);db.set_meta('config',cfg);db.set_meta('universe',universe.as_dict())
store=Store(cfg.get('update_queue_max',200000))
_by_token={};_loads={}
for _s in universe.symbols:
    _by_token.setdefault(_s.base,[]).append(_s.symbol);_loads[_s.symbol]=float(_s.activity_score or 1.0)
_probe_bundles=[tuple(sorted(v)) for _,v in sorted(_by_token.items())]
collector=Collector(cfg,store,[s.symbol for s in universe.symbols],universe.ws_groups,db.log_collector_error,probe_bundles=_probe_bundles,symbol_loads=_loads)
engine=Engine(cfg,store,db,universe,collector);app=Flask(__name__,template_folder='templates')
live=MicroLiveExecutor(cfg,store,db,universe) if mode=='MICRO_LIVE' else None
if live:engine.set_live_executor(live)
# Start multiprocessing BBO workers before application threads are created.
collector.start()
if live:live.start()

def safe_thread(name,fn):
    def w():
        with thread_lock:thread_state[name]={'alive':True,'started':time.time(),'last_ok':None,'error':None}
        try:fn()
        except Exception as exc:
            with thread_lock:thread_state[name]['alive']=False;thread_state[name]['error']=repr(exc);thread_state[name]['traceback']=traceback.format_exc()
            db.log_collector_error({'ts':time.time(),'kind':'THREAD_FATAL','symbol':None,'detail':f'{name}:{exc}','traceback':traceback.format_exc()})
        finally:
            with thread_lock:
                if name in thread_state:thread_state[name]['alive']=False
    t=threading.Thread(target=w,daemon=True,name=name);t.start();return t

def collector_loop():collector.run()
def sweep_loop():
    inter=float(cfg.get('analytical_sweep_s',5))
    while not stop_event.is_set():
        t=time.monotonic();engine.sweep_once();thread_state['analytical-sweep']['last_ok']=time.time();stop_event.wait(max(0,inter-(time.monotonic()-t)))
def bbo_scan_loop():
    inter=max(.005,float(cfg.get('bbo_scan_interval_ms',20))/1000.0)
    while not stop_event.is_set():
        t=time.monotonic();engine.bbo_scan_once();thread_state['bbo-scanner']['last_ok']=time.time();stop_event.wait(max(0,inter-(time.monotonic()-t)))
def depth_fast_loop():
    deb=float(cfg.get('depth_watch_debounce_ms',15))/1000
    while not stop_event.is_set():
        ch=store.drain_updates(.25,deb,int(cfg.get('fast_watch_max_queue_batch',50000)))
        if ch:engine.depth_fast_once(ch)
        thread_state['depth-opportunity']['last_ok']=time.time()
def survival_loop():
    while not stop_event.is_set():
        engine.survival.tick();thread_state['l2-survivability']['last_ok']=time.time();stop_event.wait(.01)
def sample_loop():
    inter=float(cfg.get('market_sample_interval_s',5))
    while not stop_event.is_set():db.add_market_samples(collector.symbol_status());thread_state['market-sampler']['last_ok']=time.time();stop_event.wait(inter)
def health_loop():
    inter=float(cfg.get('health_interval_s',5))
    while not stop_event.is_set():
        try:
            cs=collector.status();cnt=db.counts()
            try:cpu=process.cpu_percent(None);rss=process.memory_info().rss/1024/1024
            except Exception:cpu=rss=None
            hd=cs['hot_depth'];db.add_health({'uptime_s':time.time()-started,'bbo_ready':cs['ready'],'total_symbols':cs['symbols'],'bbo_ws_connected':cs['ws_connected'],'bbo_ws_total':cs['ws_total'],'bbo_msg_rate':cs['msg_rate_10s'],'bbo_rx_queue':cs['rx_queue_total'],'bbo_rx_age_ms':cs['rx_queue_age_max_ms'],'bbo_decode_p95':cs['decode_lag_p95_max_ms'],'hot_symbols':hd['hot_symbols'],'depth_ws_connected':hd['ws_connected'],'depth_ws_total':hd['ws_total'],'depth_queue':hd['queue'],'cpu_pct':cpu,'rss_mb':rss,'db_mb':cnt['db_mb'],'update_queue':store.update_queue_size(),'update_drops':store.update_drops})
            infra_error=None
            if int(cs.get('bbo_workers_alive') or 0) != int(cs.get('bbo_worker_processes') or 0):infra_error='BASE_BBO_WORKER_DEAD'
            if cs.get('fast_lane') and not cs['fast_lane'].get('worker_alive',False):infra_error='FAST_LANE_WORKER_DEAD'
            with thread_lock:
                thread_state['health']['last_ok']=time.time();thread_state['health']['error']=None;thread_state['health']['traceback']=None
                thread_state['collector']['last_ok']=time.time() if cs['messages'] else None;thread_state['collector']['error']=infra_error
        except Exception as exc:
            tb=traceback.format_exc();db.log_collector_error({'ts':time.time(),'kind':'HEALTH_SAMPLE_ERROR','symbol':None,'detail':repr(exc),'traceback':tb})
            with thread_lock:thread_state['health']['error']=repr(exc);thread_state['health']['traceback']=tb
        stop_event.wait(inter)
for n,f in [('collector',collector_loop),('analytical-sweep',sweep_loop),('bbo-scanner',bbo_scan_loop),('depth-opportunity',depth_fast_loop),('l2-survivability',survival_loop),('market-sampler',sample_loop),('health',health_loop)]:safe_thread(n,f)

def proc_metrics():
    try:
        kids=process.children(recursive=True);rss=(process.memory_info().rss+sum(c.memory_info().rss for c in kids if c.is_running()))/1024/1024
        return {'parent_cpu_pct':process.cpu_percent(None),'system_cpu_pct':psutil.cpu_percent(None),'tree_rss_mb':rss,'worker_children':len(kids)}
    except Exception:return {'parent_cpu_pct':None,'system_cpu_pct':None,'tree_rss_mb':None,'worker_children':None}

def quality(rows):
    return {'ready':sum(1 for x in rows if x['ready']),'total':len(rows),'transport_p50_ms':pct([x['transport_age_ms'] for x in rows],.5),'transport_p95_ms':pct([x['transport_age_ms'] for x in rows],.95),'decode_p50_ms':pct([x['decode_lag_ms'] for x in rows],.5),'decode_p95_ms':pct([x['decode_lag_ms'] for x in rows],.95),'spread_p50_bps':pct([x['spread_bps'] for x in rows],.5),'spread_p95_bps':pct([x['spread_bps'] for x in rows],.95)}
def safe_cfg():return {k:v for k,v in cfg.items() if 'key' not in k.lower() and 'secret' not in k.lower()}
@app.get('/healthz')
def healthz():
    with thread_lock:t={k:dict(v) for k,v in thread_state.items()}
    base_ok=bool(t) and all(v.get('alive') and not v.get('error') for v in t.values())
    ls=live.status() if live else None
    live_ok=True if not live or not live.execution_enabled else bool(ls.get('credentials_present') and ls.get('private_ws',{}).get('connected') and not str(ls.get('state','')).startswith('ENTRY_DISABLED') and ls.get('state')!='PREFLIGHT_ERROR')
    return jsonify(ok=bool(base_ok and live_ok),mode=mode,version=__version__,port=cfg['port'],threads=t,live=ls)
@app.get('/api/status')
def status():
    sy=collector.symbol_status();cs=collector.status();es=engine.status();cnt=db.counts();st=db.opportunity_stats(24)
    try:cpu=process.cpu_percent(None);rss=process.memory_info().rss/1024/1024
    except Exception:cpu=rss=None
    with thread_lock:t={k:dict(v) for k,v in thread_state.items()}
    return jsonify({'version':__version__,'mode':mode,'uptime_s':time.time()-started,'port':cfg['port'],'universe':{'symbols':len(universe.symbols),'routes':len(universe.routes),'tokens':len(set(s.base for s in universe.symbols)),'excluded':len(universe.excluded),'ws_groups':len(universe.ws_groups)},'collector':cs,'quality':quality(sy),'engine':es,'opportunity_stats':st,'qualification_stats':db.qualification_stats(24),'store':{'update_queue':store.update_queue_size(),'update_drops':store.update_drops},'db':cnt,'process':{'cpu_pct':cpu,'rss_mb':rss,**proc_metrics()},'threads':t,'config':safe_cfg(),'bootstrap_survival':bootstrap_survival,'live':live.status() if live else None,'reasons':db.reasons()[:40]})
@app.get('/api/smoke')
def smoke():
    cs=collector.status(); es=engine.status(); cnt=db.counts(); st=db.opportunity_stats(24)
    try: cpu=process.cpu_percent(None); rss=process.memory_info().rss/1024/1024
    except Exception: cpu=rss=None
    ws=collector.ws_status(); worst=sorted(ws,key=lambda x:max(float(x.get('decode_lag_p95_ms') or 0),float(x.get('transport_p95_ms') or 0)),reverse=True)[:8]
    return jsonify({'version':__version__,'uptime_s':time.time()-started,'universe':{'tokens':len(set(s.base for s in universe.symbols)),'symbols':len(universe.symbols),'routes':len(universe.routes)},'bbo':{'ready':cs['ready'],'ws':f"{cs['ws_connected']}/{cs['ws_total']}",'msg_rate_10s':cs['msg_rate_10s'],'rx_queue_total':cs['rx_queue_total'],'rx_queue_age_max_ms':cs['rx_queue_age_max_ms'],'decode_p95_max_ms':cs['decode_lag_p95_max_ms'],'transport_p50_ms':cs['transport_p50_ms'],'transport_p95_ms':cs['transport_p95_ms'],'errors':cs['errors'],'reconnects':cs['reconnects']},'hot_depth':cs['hot_depth'],'fast_lane':cs.get('fast_lane',{}),'engine':es,'opportunity_stats':st,'qualification_stats':db.qualification_stats(24),'db':cnt,'process':{'cpu_pct':cpu,'rss_mb':rss,**proc_metrics()},'store':{'update_queue':store.update_queue_size(),'update_drops':store.update_drops},'worst_bbo_ws':[{k:x.get(k) for k in ('id','worker','pid','msg_rate_10s','decode_lag_p95_ms','transport_p95_ms','transport_gt_500_pct','errors','reconnects')} for x in worst],'survival':engine.survival.status(),'survival_top':db.survival_summary(15),'live':live.status() if live else None,'bootstrap_survival':bootstrap_survival,'recent_errors':db.recent_errors(10)})

@app.get('/api/opportunities')
def opp():return jsonify(db.recent_opportunities(int(request.args.get('limit',150)),float(request.args.get('hours',24)),int(request.args.get('min_rank',1))))
@app.get('/api/candidates')
def cand():return jsonify(db.recent_candidates(int(request.args.get('limit',100)),float(request.args.get('hours',1))))
@app.get('/api/viability')
def via():return jsonify(db.route_viability(float(request.args.get('hours',24)),int(request.args.get('limit',150))))
@app.get('/api/route-activity')
def ra():return jsonify(db.route_activity(int(request.args.get('limit',250))))
@app.get('/api/profiles')
def prof():return jsonify(db.profile_summary(int(request.args.get('limit',150))))
@app.get('/api/survival')
def survival():return jsonify(db.survival_summary(int(request.args.get('limit',150))))
@app.get('/api/survival-trials')
def survival_trials():return jsonify(db.recent_survival_trials(int(request.args.get('limit',100))))
@app.get('/api/ws')
def ws():return jsonify(collector.ws_status())
@app.get('/api/fast-ws')
def fws():return jsonify(collector.fast_ws_status())
@app.get('/api/fast-audit')
def faudit():return jsonify(db.fast_audit(int(request.args.get('limit',100))))
@app.get('/api/depth-ws')
def dws():return jsonify(collector.depth_ws_status())
@app.get('/api/symbols')
def syms():return jsonify(collector.symbol_status())
@app.get('/api/errors')
def errs():return jsonify(db.recent_errors(int(request.args.get('limit',100))))
@app.get('/api/live/status')
def live_status():return jsonify(live.status() if live else {'state':'SHADOW','execution_enabled':False})
@app.get('/api/live/trades')
def live_trades():return jsonify(db.live_cycles(int(request.args.get('limit',200))))
@app.get('/api/live/events')
def live_events():return jsonify(db.live_events(int(request.args.get('limit',300)),request.args.get('cycle_id')))
@app.get('/api/live/dust')
def live_dust():return jsonify({'summary':db.live_dust_summary(),'rows':db.live_dust_rows(int(request.args.get('limit',200)))})
@app.get('/api/live/balances')
def live_balances():return jsonify({'current':(live.status().get('balances') if live else {}),'startup':(live.status().get('startup_balances') if live else {}),'history':db.live_balance_history(['USDC','USDT'],int(request.args.get('limit',300)))})
@app.get('/api/universe')
def uni():return jsonify(universe.as_dict())
@app.get('/')
def index():return render_template('index.html')
def shutdown(*_):
    stop_event.set();collector.stop=True;engine.flush(True);live.close() if live else None;raise SystemExit(0)
for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,shutdown)
if __name__=='__main__':serve(app,host='0.0.0.0',port=int(cfg['port']),threads=int(cfg.get('http_threads',8)))
