# CHANGELOG — V4.6.1 REX MICRO-LIVE RECONCILE

## V4.6.0

- Reprend sans changement le collecteur V4.5.1 : full universe, Base100, Fast10 dynamique et Depth20.
- Ajoute un exécuteur MICRO-LIVE Spot 2-leg limité par défaut à `USDC` et `USDT`, taille fixe 10 USD, une exposition maximum.
- Admission identique au TEST : classe A `NET > 1 bp`, classe B `NET > 2 bp`, classe C interdite, fee floor 5 bp/jambe, L1 >=5x, L2 >=10x.
- Gate LIVE supplémentaire : au moins 1000 trials L2 pour la route et la taille exacte.
- Importe une seule fois les agrégats de survivabilité V4.5.1 dans une DB V4.6 fraîche.
- Validation `POST /api/v3/order/test` des deux jambes avant le premier ordre réel d'une route/taille, puis attente de l'opportunité suivante.
- Ordres normaux FOK. Après fill L1, l'edge d'entrée n'est plus réappliqué : priorité à la finalisation L2.
- Private WebSocket ordres/deals/account + REST de réconciliation. Timeout/5xx = `UNKNOWN`, jamais un rejet implicite.
- Recovery au redémarrage : réconciliation L1/L2 avant toute nouvelle entrée; reprise de la finalisation L2 lorsqu'une exposition est prouvée.
- Protection des bags préexistants : L2 ne vend que la quantité stratégie acquise par le cycle courant.
- Dust : arrondi de quantité conservé comme résidu comptable, journalisé et non bloquant sous le seuil configuré. Aucun auto-convert vers MX.
- Journal LIVE SQLite : cycles, événements, balances, validations FOK, poussières, commissions, PnL réel.
- Dashboard : état LIVE, Private WS, balances USDC/USDT, exposition active, trades passés, PnL cumulé, turnover, fees et dust.
- Export V4.6 inclut toutes les tables LIVE et le snapshot SQLite cohérent.

# V4.6.1 — deterministic L1 reconciliation

- Fix REST order status parsing: string statuses such as `CANCELED` no longer go through `int(...)`.
- Query Order is now the first reconciliation step immediately after L1/L2 submission; Private WS remains parallel fast confirmation.
- Persist pre-L1 token and stable balances. A positive token delta can confirm strategy exposure even if order status is ambiguous.
- Before declaring `L1_NO_FILL`, V4.6.1 checks the token balance delta.
- Startup recovery applies the same rule: if strategy token exposure exists, L2 resumes; otherwise a canceled zero-fill order closes safely.
- Includes the production Private WS fixes discovered in V4.6.0: signed listenKey, string extraction, heartbeat started after on_open.
- UI distinguishes `CYCLE EN RÉCONCILIATION` from a proven `EXPOSITION ACTIVE`.
- New LIVE arm token: `V461_LIVE_10USD`.
