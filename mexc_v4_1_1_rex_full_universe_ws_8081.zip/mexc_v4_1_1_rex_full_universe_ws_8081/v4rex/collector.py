from __future__ import annotations
import heapq
import json
import math
import random
import threading
import time
from collections import deque
from typing import Callable, Optional

import requests
import websocket
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory

from .core import Book, L, Store

REST = "https://api.mexc.com"
WS = "wss://wbs-api.mexc.com/ws"


def _codec():
    """Minimal dynamic codec matching MEXC's official Diff.Depth protobuf fields."""
    fd = descriptor_pb2.FileDescriptorProto(name="mexc_v411.proto", package="v411", syntax="proto3")

    def msg(name):
        m = fd.message_type.add(); m.name = name; return m

    def fld(m, name, num, typ, repeated=False, target=None, oneof=None):
        f = m.field.add(); f.name = name; f.number = num; f.type = typ
        f.label = 3 if repeated else 1
        if target: f.type_name = ".v411." + target
        if oneof is not None: f.oneof_index = oneof
        return f

    level = msg("PublicAggreDepthV3ApiItem")
    fld(level, "price", 1, 9); fld(level, "quantity", 2, 9)
    depth = msg("PublicAggreDepthsV3Api")
    fld(depth, "asks", 1, 11, True, "PublicAggreDepthV3ApiItem")
    fld(depth, "bids", 2, 11, True, "PublicAggreDepthV3ApiItem")
    fld(depth, "eventType", 3, 9); fld(depth, "fromVersion", 4, 9); fld(depth, "toVersion", 5, 9)
    fld(depth, "lastOrderCreateTime", 6, 3)
    env = msg("PushDataV3ApiWrapper")
    fld(env, "channel", 1, 9)
    body = env.oneof_decl.add(); body.name = "body"
    fld(env, "publicAggreDepths", 313, 11, False, "PublicAggreDepthsV3Api", 0)
    fld(env, "symbol", 3, 9); fld(env, "symbolId", 4, 9); fld(env, "createTime", 5, 3); fld(env, "sendTime", 6, 3)
    pool = descriptor_pool.DescriptorPool(); pool.Add(fd)
    return message_factory.GetMessageClass(pool.FindMessageTypeByName("v411.PushDataV3ApiWrapper"))


Envelope = _codec()


def decode(payload: bytes):
    e = Envelope(); e.ParseFromString(payload)
    if not e.symbol or not e.HasField("publicAggreDepths"):
        return None
    d = e.publicAggreDepths
    try:
        fv, tv = int(d.fromVersion), int(d.toVersion)
    except (TypeError, ValueError):
        return None
    return {
        "channel": e.channel, "symbol": e.symbol, "send": int(e.sendTime or 0), "create": int(e.createTime or 0),
        "from": fv, "to": tv, "last_order_create": int(d.lastOrderCreateTime or 0),
        "bids": [(float(z.price), float(z.quantity)) for z in d.bids],
        "asks": [(float(z.price), float(z.quantity)) for z in d.asks],
    }



def decode_control_frame(msg):
    """Return JSON control payload for MEXC ACK/PONG frames, including binary JSON frames."""
    if isinstance(msg, str):
        raw = msg
    elif isinstance(msg, (bytes, bytearray)):
        b = bytes(msg).lstrip()
        if b[:1] not in (b"{", b"["):
            return None
        try:
            raw = bytes(msg).decode("utf-8")
        except UnicodeDecodeError:
            return None
    else:
        return None
    try:
        obj = json.loads(raw)
    except Exception:
        return None
    return obj if isinstance(obj, dict) else None

def bridge_first_ok(snapshot_version: int, first_from: int, first_to: int) -> bool:
    nxt = snapshot_version + 1
    return first_from <= nxt <= first_to


def _percentile(values, p):
    vals = sorted(float(x) for x in values if x is not None and math.isfinite(float(x)))
    if not vals: return None
    if len(vals) == 1: return vals[0]
    k = (len(vals)-1)*p; lo = int(k); hi = min(len(vals)-1, lo+1); w = k-lo
    return vals[lo]*(1-w)+vals[hi]*w


class RateLimiter:
    def __init__(self, per_second: float):
        self.interval = 1.0 / max(0.1, float(per_second)); self.lock = threading.Lock(); self.next_at = 0.0
    def wait(self):
        with self.lock:
            now = time.monotonic(); wait = max(0.0, self.next_at-now); self.next_at = max(now,self.next_at)+self.interval
        if wait: time.sleep(wait)


class ClockSync:
    def __init__(self): self.offset_ms=0.0; self.rtt_ms=None; self.last_sync=None
    def sync(self, session: requests.Session, samples=5, timeout=3):
        best=None
        for _ in range(samples):
            try:
                a=time.time()*1000.0; r=session.get(REST+"/api/v3/time",timeout=timeout); r.raise_for_status(); b=time.time()*1000.0
                server=float(r.json()["serverTime"]); rtt=b-a; offset=server-(a+b)/2.0
                if best is None or rtt<best[0]: best=(rtt,offset)
            except Exception: pass
            time.sleep(.05)
        if best: self.rtt_ms,self.offset_ms=best; self.last_sync=time.time()
        return self.offset_ms


class Collector:
    """Full-universe MEXC collector.

    V4.1.1 deliberately keeps WebSocket callbacks lightweight. Raw binary frames are
    timestamped and placed in bounded per-WS queues. Decoder workers own disjoint WS
    sets, preserving ordering per channel while preventing one busy channel from
    starving the others. Book publication is coalesced in a separate thread.
    """
    def __init__(self,cfg:dict,store:Store,symbols:list[str],ws_groups=None,error_sink:Optional[Callable[[dict],None]]=None):
        from concurrent.futures import ThreadPoolExecutor
        self.cfg=cfg; self.store=store; self.symbols=sorted(set(symbols)); self.error_sink=error_sink
        self.session=requests.Session(); self.clock=ClockSync(); self.clock.sync(self.session)
        self.snapshot_limiter=RateLimiter(cfg.get("snapshot_rate_per_sec",8.0))
        self.snapshot_pool=ThreadPoolExecutor(max_workers=int(cfg.get("snapshot_workers",12)),thread_name_prefix="snapshot")
        self.lock=threading.RLock(); self.stop=False
        self.raw={}; self.buffers={s:deque(maxlen=int(cfg.get("buffer_max_updates",20000))) for s in self.symbols}
        self.ready=set(); self.symbol_gen={}; self._gen_counter=0; self.started=time.time(); self.msg_times=deque(maxlen=500000)
        self.recent_errors=deque(maxlen=300)
        self.per_symbol={s:{"messages":0,"gaps":0,"resyncs":0,"errors":0,"buffer_overflows":0,"last_error":None,
                           "last_error_ts":None,"last_from":None,"last_to":None,"last_send_ms":None,"last_message_ts":None,
                           "msg_times":deque(maxlen=50000)} for s in self.symbols}
        if ws_groups: plans=ws_groups
        else:
            gs=max(1,min(30,int(cfg.get("ws_group_size",20))))
            plans=[{"id":i//gs+1,"symbols":self.symbols[i:i+gs],"load_score":0.0,"quote_volume_24h":0.0,"trade_count_24h":0.0}
                   for i in range(0,len(self.symbols),gs)]
        self.ws_plans=[]; self.channels={}
        for idx,plan in enumerate(plans,start=1):
            syms=[s for s in plan.get("symbols",[]) if s in self.buffers]
            if not syms: continue
            if len(syms)>30: raise ValueError("MEXC supports at most 30 subscriptions per WebSocket")
            wid=int(plan.get("id") or idx); p=dict(plan); p.update(id=wid,symbols=syms,symbol_count=len(syms)); self.ws_plans.append(p)
            self.channels[wid]={"id":wid,"symbols":syms,"symbol_count":len(syms),"estimated_load":float(plan.get("load_score") or 0),
                "quote_volume_24h":float(plan.get("quote_volume_24h") or 0),"trade_count_24h":float(plan.get("trade_count_24h") or 0),
                "connected":False,"generation":None,"messages":0,"msg_times":deque(maxlen=100000),"acks":0,"pongs":0,"controls":0,
                "errors":0,"reconnects":0,"proactive_rotations":0,"opened_ts":None,"last_message_ts":None,"last_frame_ts":None,"last_error":None,
                "rx_queue":deque(),"rx_lock":threading.Lock(),"rx_bytes":0,"rx_drops":0,"decode_lags":deque(maxlen=10000),"queue_lags":deque(maxlen=10000),
                "catchup":False,"app":None}
        self.rx_event=threading.Event(); self.dirty_event=threading.Event(); self.dirty=set(); self.dirty_lock=threading.Lock()
        self.messages=self.requests=self.errors=self.reconnects=self.gaps=self.resyncs=0
        self.bootstraps=self.recovery_resyncs=self.acks=self.pongs=self.decode_errors=self.buffer_overflows=0
        self.proactive_rotations=self.binary_json_controls=self.rx_overflows=self.publish_count=self.publish_coalesced=0

    def _next_gen(self):
        with self.lock: self._gen_counter+=1; return self._gen_counter

    def _error(self,kind,symbol=None,detail="",**extra):
        event={"ts":time.time(),"kind":kind,"symbol":symbol,"detail":str(detail)[:1000],**extra}
        with self.lock:
            self.errors+=1; self.recent_errors.appendleft(event)
            if symbol in self.per_symbol:
                st=self.per_symbol[symbol]; st["errors"]+=1; st["last_error"]=kind+(":"+str(detail)[:160] if detail else ""); st["last_error_ts"]=event["ts"]
            wid=extra.get("wid")
            if wid in self.channels:
                self.channels[wid]["errors"]+=1; self.channels[wid]["last_error"]=kind+(":"+str(detail)[:160] if detail else "")
        if self.error_sink:
            try:self.error_sink(event)
            except Exception:pass

    def _buffer(self,symbol,item):
        q=self.buffers[symbol]
        if len(q)>=q.maxlen:
            self.buffer_overflows+=1; self.per_symbol[symbol]["buffer_overflows"]+=1; self._error("BUFFER_OVERFLOW",symbol,f"maxlen={q.maxlen}")
        q.append(item)

    @staticmethod
    def _apply_levels(state,update):
        for side in ("bids","asks"):
            for p,q in update[side]:
                if q==0: state[side].pop(p,None)
                else: state[side][p]=q

    def _mark_dirty(self,sym):
        with self.dirty_lock:
            if sym in self.dirty: self.publish_coalesced+=1
            self.dirty.add(sym)
        self.dirty_event.set()

    def _publish(self,sym):
        depth=int(self.cfg.get("depth_levels",100))
        with self.lock:
            x=self.raw.get(sym)
            if not x or not x.get("ready"): return
            # Copy metadata and choose only top-N levels. heapq avoids sorting the full 5k snapshot.
            bids_raw=x["bids"]; asks_raw=x["asks"]
            bids_top=heapq.nlargest(depth,bids_raw.items(),key=lambda kv:kv[0])
            asks_top=heapq.nsmallest(depth,asks_raw.items(),key=lambda kv:kv[0])
            meta=(x["gen"],x.get("ver"),x.get("send") or None,x.get("recv_wall_ms"),x.get("recv_ns",time.monotonic_ns()),x.get("apply_ns",time.monotonic_ns()))
        bids=tuple(L(p,q) for p,q in bids_top); asks=tuple(L(p,q) for p,q in asks_top)
        if not bids or not asks:return
        if bids[0].p>=asks[0].p:
            self._error("CROSSED_BOOK",sym,f"bid={bids[0].p} ask={asks[0].p}",version=meta[1]); return
        self.store.put(Book(sym,bids,asks,*meta,"VALID")); self.publish_count+=1

    def _publisher_loop(self):
        interval=max(.005,float(self.cfg.get("book_publish_interval_ms",25))/1000.0)
        while not self.stop:
            self.dirty_event.wait(interval); self.dirty_event.clear()
            with self.dirty_lock:
                dirty=list(self.dirty); self.dirty.clear()
            for sym in dirty:
                try:self._publish(sym)
                except Exception as exc:self._error("PUBLISH",sym,repr(exc))

    def _apply(self,u,gen,recv_ns,recv_wall_ms):
        sym=u["symbol"]
        with self.lock:
            if self.symbol_gen.get(sym)!=gen:return
            st=self.per_symbol[sym]; st["messages"]+=1; st["last_from"]=u["from"]; st["last_to"]=u["to"]; st["last_send_ms"]=u["send"]; st["last_message_ts"]=time.time()
            now=time.monotonic(); st["msg_times"].append(now); self.msg_times.append(now); self.messages+=1
            x=self.raw.get(sym)
            if not x or not x.get("ready"):
                self._buffer(sym,(u,recv_ns,recv_wall_ms)); return
            if u["to"]<=x["ver"]:return
            continuous=bridge_first_ok(x["ver"],u["from"],u["to"]) if x.get("bridge_pending") else (u["from"]==x["ver"]+1)
            if not continuous:
                x["ready"]=False; self.ready.discard(sym); self._buffer(sym,(u,recv_ns,recv_wall_ms)); self.gaps+=1; st["gaps"]+=1; expected=x["ver"]+1
                self._error("LIVE_GAP",sym,f"expected_cover={expected} got={u['from']}..{u['to']}",expected=expected,from_version=u["from"],to_version=u["to"],bridge_pending=bool(x.get("bridge_pending")))
                self.store.invalidate(sym,gen); self.snapshot_pool.submit(self._resync,sym,gen,"LIVE_GAP"); return
            self._apply_levels(x,u); x.update(ver=u["to"],send=u["send"],recv_ns=recv_ns,recv_wall_ms=recv_wall_ms,apply_ns=time.monotonic_ns(),bridge_pending=False)
        self._mark_dirty(sym)

    def _resync(self,sym,gen,trigger="INIT"):
        with self.lock:
            if self.symbol_gen.get(sym)!=gen:return
            x=self.raw.setdefault(sym,{"gen":gen,"ready":False})
            if x.get("resyncing"):return
            x["ready"]=False; x["resyncing"]=True; self.ready.discard(sym)
        tries=int(self.cfg.get("snapshot_retries",12))
        try:
            for attempt in range(tries):
                if self.stop or self.symbol_gen.get(sym)!=gen:return
                try:
                    self.snapshot_limiter.wait(); r=self.session.get(REST+"/api/v3/depth",params={"symbol":sym,"limit":int(self.cfg.get("snapshot_limit",5000))},timeout=float(self.cfg.get("rest_timeout_s",8)))
                    self.requests+=1; r.raise_for_status(); j=r.json(); ver=int(j["lastUpdateId"])
                    bids={float(p):float(q) for p,q in j.get("bids",[]) if float(q)>0}; asks={float(p):float(q) for p,q in j.get("asks",[]) if float(q)>0}
                    snap_recv_ns=time.monotonic_ns(); snap_wall_ms=time.time()*1000.0
                    with self.lock:
                        if self.symbol_gen.get(sym)!=gen:return
                        buffered=list(self.buffers[sym]); self.buffers[sym].clear(); rem=[z for z in buffered if z[0]["to"]>ver]
                        state={"bids":bids,"asks":asks,"ver":ver,"send":0,"recv_ns":snap_recv_ns,"recv_wall_ms":snap_wall_ms,"apply_ns":time.monotonic_ns(),"gen":gen,"ready":True,"resyncing":True,"bridge_pending":not bool(rem)}
                        if rem:
                            first,rns,rwms=rem[0]
                            if not bridge_first_ok(ver,first["from"],first["to"]):
                                self.buffers[sym].extend(rem); raise RuntimeError(f"snapshot bridge gap snapshot={ver} first={first['from']}..{first['to']}")
                            self._apply_levels(state,first); state.update(ver=first["to"],send=first["send"],recv_ns=rns,recv_wall_ms=rwms,apply_ns=time.monotonic_ns(),bridge_pending=False)
                            for idx,(u,rns,rwms) in enumerate(rem[1:],start=1):
                                if u["to"]<=state["ver"]:continue
                                if u["from"]!=state["ver"]+1:
                                    self.buffers[sym].extend(rem[idx:]); raise RuntimeError(f"post-bridge gap expected={state['ver']+1} got={u['from']}..{u['to']}")
                                self._apply_levels(state,u); state.update(ver=u["to"],send=u["send"],recv_ns=rns,recv_wall_ms=rwms,apply_ns=time.monotonic_ns())
                        state["ready"]=True; state["resyncing"]=False; self.raw[sym]=state; self.ready.add(sym); self.resyncs+=1; self.per_symbol[sym]["resyncs"]+=1
                        if trigger=="OPEN":self.bootstraps+=1
                        else:self.recovery_resyncs+=1
                    self._mark_dirty(sym); return
                except Exception as exc:
                    self._error("RESYNC_RETRY",sym,str(exc),attempt=attempt+1,trigger=trigger); time.sleep(min(4.0,.15*(2**min(attempt,5)))+random.random()*.05)
            self._error("RESYNC_EXHAUSTED",sym,f"trigger={trigger} tries={tries}")
        finally:
            with self.lock:
                if sym in self.raw:self.raw[sym]["resyncing"]=False

    def _handle_control(self,msg,wid):
        j=decode_control_frame(msg)
        if j is None:return False
        if isinstance(msg,(bytes,bytearray)):self.binary_json_controls+=1
        with self.lock:
            c=self.channels[wid]; c["controls"]+=1; c["last_frame_ts"]=time.time()
            text=str(j.get("msg","")).upper()
            if text=="PONG": self.pongs+=1; c["pongs"]+=1
            else: self.acks+=1; c["acks"]+=1
        return True

    def _enqueue_binary(self,wid,msg,recv_ns,recv_wall_ms):
        c=self.channels[wid]; max_frames=int(self.cfg.get("rx_queue_max_frames",4096)); max_bytes=int(self.cfg.get("rx_queue_max_bytes",16*1024*1024))
        overflow=False
        with c["rx_lock"]:
            if len(c["rx_queue"])>=max_frames or c["rx_bytes"]+len(msg)>max_bytes: overflow=True; c["rx_drops"]+=1
            else: c["rx_queue"].append((bytes(msg),recv_ns,recv_wall_ms)); c["rx_bytes"]+=len(msg)
        if overflow:
            self.rx_overflows+=1; self._error("RX_QUEUE_OVERFLOW",None,f"frames={len(c['rx_queue'])} bytes={c['rx_bytes']}",wid=wid,generation=c.get("generation"))
            for s in c["symbols"]: self.store.invalidate(s,c.get("generation"))
            try:
                if c.get("app"): c["app"].close()
            except Exception:pass
        else:self.rx_event.set()

    def _process_channel(self,wid,quantum):
        c=self.channels[wid]; done=0
        for _ in range(quantum):
            with c["rx_lock"]:
                if not c["rx_queue"]: break
                payload,recv_ns,recv_wall_ms=c["rx_queue"].popleft(); c["rx_bytes"]-=len(payload)
            lag_ms=max(0.0,(time.monotonic_ns()-recv_ns)/1e6); c["queue_lags"].append(lag_ms)
            c["catchup"]=lag_ms>float(self.cfg.get("decoder_catchup_ms",100))
            try:
                u=decode(payload)
                if u:
                    if u["symbol"] not in c["symbols"]: raise ValueError(f"wrong channel symbol {u['symbol']}")
                    gen=c.get("generation")
                    self._apply(u,gen,recv_ns,recv_wall_ms)
                    now=time.monotonic(); c["messages"]+=1; c["msg_times"].append(now); c["last_message_ts"]=time.time(); done+=1
            except Exception as exc:
                self.decode_errors+=1; self._error("DECODE",None,repr(exc),wid=wid,generation=c.get("generation"))
            finally:
                c["decode_lags"].append(max(0.0,(time.monotonic_ns()-recv_ns)/1e6))
        with c["rx_lock"]:
            if not c["rx_queue"]: c["catchup"]=False
        return done

    def _decoder_loop(self,wids):
        quantum=max(1,int(self.cfg.get("decoder_quantum",32))); pos=0
        while not self.stop:
            work=0
            if wids:
                for i in range(len(wids)):
                    work+=self._process_channel(wids[(pos+i)%len(wids)],quantum)
                pos=(pos+1)%len(wids)
            if not work:
                self.rx_event.clear(); self.rx_event.wait(.005)

    def _socket(self,group,wid):
        backoff=.5; channel=self.channels[wid]
        while not self.stop:
            gen=self._next_gen(); opened=time.monotonic()
            with self.lock:
                channel.update(connected=False,generation=gen,opened_ts=time.time(),last_error=None,last_frame_ts=None,last_message_ts=None)
                with channel["rx_lock"]: channel["rx_queue"].clear(); channel["rx_bytes"]=0
                for s in group:
                    self.symbol_gen[s]=gen; self.ready.discard(s); self.raw[s]={"gen":gen,"ready":False,"resyncing":False}; self.buffers[s].clear(); self.store.invalidate(s,gen)
            def on_open(ws):
                with self.lock: channel["connected"]=True
                params=[f"spot@public.aggre.depth.v3.api.pb@10ms@{s}" for s in group]; ws.send(json.dumps({"method":"SUBSCRIPTION","params":params}))
                for s in group:self.snapshot_pool.submit(self._resync,s,gen,"OPEN")
            def on_message(ws,msg):
                recv_ns=time.monotonic_ns(); recv_wall_ms=time.time()*1000.0
                with self.lock: channel["last_frame_ts"]=time.time()
                try:
                    if self._handle_control(msg,wid): return
                    if isinstance(msg,(bytes,bytearray)): self._enqueue_binary(wid,msg,recv_ns,recv_wall_ms)
                    else: self._error("UNKNOWN_FRAME",None,type(msg).__name__,wid=wid,generation=gen)
                except Exception as exc:self._error("RX_HANDLER",None,repr(exc),wid=wid,generation=gen)
            def on_error(ws,err): self._error("WS_ERROR",None,repr(err),wid=wid,generation=gen)
            def on_close(ws,code,msg):
                with self.lock: channel["connected"]=False
                if not self.stop:self._error("WS_CLOSE",None,f"code={code} msg={msg}",wid=wid,generation=gen)
            app=websocket.WebSocketApp(WS,on_open=on_open,on_message=on_message,on_error=on_error,on_close=on_close); channel["app"]=app
            def ping_loop():
                rotate_s=float(self.cfg.get("ws_rotate_s",82800))
                while not self.stop:
                    time.sleep(float(self.cfg.get("ping_interval_s",15)))
                    if time.monotonic()-opened>=rotate_s:
                        with self.lock:self.proactive_rotations+=1; channel["proactive_rotations"]+=1
                        try:app.close()
                        except Exception:pass
                        return
                    try:app.send(json.dumps({"method":"PING"}))
                    except Exception:return
            threading.Thread(target=ping_loop,daemon=True,name=f"mexc-ping-{wid}").start()
            try:app.run_forever(ping_interval=0,skip_utf8_validation=True)
            except Exception as exc:self._error("WS_RUN",None,repr(exc),wid=wid,generation=gen)
            with self.lock: channel["connected"]=False
            if self.stop:break
            self.reconnects+=1; channel["reconnects"]+=1; lived=time.monotonic()-opened; backoff=.5 if lived>120 else min(30.0,max(.5,backoff*1.8)); time.sleep(backoff+random.random()*.25)

    def run(self):
        threading.Thread(target=self._publisher_loop,daemon=True,name="book-publisher").start()
        workers=max(1,int(self.cfg.get("decoder_workers",4))); ids=sorted(self.channels)
        for w in range(workers):
            assigned=[wid for i,wid in enumerate(ids) if i%workers==w]
            threading.Thread(target=self._decoder_loop,args=(assigned,),daemon=True,name=f"decoder-{w+1}").start()
        for plan in self.ws_plans:
            threading.Thread(target=self._socket,args=(list(plan["symbols"]),int(plan["id"])),daemon=True,name=f"mexc-ws-{plan['id']}").start()
        while not self.stop:
            for _ in range(300):
                if self.stop:break
                time.sleep(1)
            if not self.stop:self.clock.sync(self.session)
        self.rx_event.set(); self.dirty_event.set()
        try:self.snapshot_pool.shutdown(wait=False,cancel_futures=True)
        except Exception:pass

    @staticmethod
    def _rate(dq,window=10.0):
        now=time.monotonic()
        while dq and dq[0]<now-window:dq.popleft()
        return len(dq)/window

    def ws_status(self):
        out=[]
        with self.lock:
            for wid in sorted(self.channels):
                c=self.channels[wid]
                with c["rx_lock"]:
                    qn=len(c["rx_queue"]); qb=c["rx_bytes"]
                    oldest=((time.monotonic_ns()-c["rx_queue"][0][1])/1e6) if c["rx_queue"] else 0.0
                now=time.time(); lm=c["last_message_ts"]; lf=c["last_frame_ts"]
                out.append({"id":wid,"connected":bool(c["connected"]),"generation":c["generation"],"symbols":list(c["symbols"]),"symbol_count":c["symbol_count"],
                    "estimated_load":c["estimated_load"],"quote_volume_24h":c["quote_volume_24h"],"trade_count_24h":c["trade_count_24h"],"messages":c["messages"],
                    "msg_rate_10s":self._rate(c["msg_times"]),"acks":c["acks"],"pongs":c["pongs"],"controls":c["controls"],"errors":c["errors"],
                    "reconnects":c["reconnects"],"proactive_rotations":c["proactive_rotations"],"opened_ts":c["opened_ts"],
                    "last_message_age_s":max(0.0,now-lm) if lm else None,"last_frame_age_s":max(0.0,now-lf) if lf else None,"last_error":c["last_error"],
                    "ready":sum(1 for s in c["symbols"] if s in self.ready),"rx_queue":qn,"rx_bytes":qb,"rx_drops":c["rx_drops"],"rx_queue_age_ms":oldest,
                    "decode_lag_p50_ms":_percentile(c["decode_lags"],.5),"decode_lag_p95_ms":_percentile(c["decode_lags"],.95),"catchup":bool(c["catchup"])})
        return out

    def symbol_status(self):
        books=self.store.snapshot(); out=[]
        with self.lock:
            wid_by_symbol={s:wid for wid,c in self.channels.items() for s in c["symbols"]}
            for sym in self.symbols:
                st=self.per_symbol[sym]; b=books.get(sym)
                out.append({"symbol":sym,"ws_id":wid_by_symbol.get(sym),"ready":sym in self.ready and b is not None,"generation":self.symbol_gen.get(sym),
                    "version":b.ver if b else self.raw.get(sym,{}).get("ver"),"messages":st["messages"],"msg_rate_10s":self._rate(st["msg_times"]),"gaps":st["gaps"],
                    "resyncs":st["resyncs"],"errors":st["errors"],"buffer_overflows":st["buffer_overflows"],"last_from":st["last_from"],"last_to":st["last_to"],
                    "last_send_ms":st["last_send_ms"],"last_message_ts":st["last_message_ts"],"last_error":st["last_error"],"last_error_ts":st["last_error_ts"],
                    "bid":b.best_bid if b else None,"ask":b.best_ask if b else None,"spread_bps":b.spread_bps if b else None,"local_age_ms":b.age_ms if b else None,
                    "exchange_age_ms":b.exchange_age_ms(self.clock.offset_ms) if b else None,"transport_age_ms":b.transport_age_ms(self.clock.offset_ms) if b else None,
                    "decode_lag_ms":b.decode_lag_ms if b else None})
        return out

    def status(self):
        ws=self.ws_status(); decode_vals=[x["decode_lag_p95_ms"] for x in ws if x["decode_lag_p95_ms"] is not None]
        with self.lock:
            return {"symbols":len(self.symbols),"ready":len(self.ready),"messages":self.messages,"msg_rate_10s":self._rate(self.msg_times),"requests":self.requests,
                "errors":self.errors,"decode_errors":self.decode_errors,"reconnects":self.reconnects,"gaps":self.gaps,"resyncs":self.resyncs,"bootstraps":self.bootstraps,
                "recovery_resyncs":self.recovery_resyncs,"buffer_overflows":self.buffer_overflows,"acks":self.acks,"pongs":self.pongs,"binary_json_controls":self.binary_json_controls,
                "rx_overflows":self.rx_overflows,"publish_count":self.publish_count,"publish_coalesced":self.publish_coalesced,"generation_counter":self._gen_counter,
                "proactive_rotations":self.proactive_rotations,"clock_offset_ms":self.clock.offset_ms,"clock_sync_rtt_ms":self.clock.rtt_ms,
                "ws_connected":sum(1 for x in ws if x["connected"]),"ws_total":len(ws),"subscriptions":sum(x["symbol_count"] for x in ws),"ws_channels":ws,
                "rx_queue_total":sum(x["rx_queue"] for x in ws),"rx_queue_age_max_ms":max([x["rx_queue_age_ms"] for x in ws] or [0.0]),
                "decode_lag_p95_max_ms":max(decode_vals or [0.0]),"catchup_channels":sum(1 for x in ws if x["catchup"]),"recent_errors":list(self.recent_errors)[:30]}
