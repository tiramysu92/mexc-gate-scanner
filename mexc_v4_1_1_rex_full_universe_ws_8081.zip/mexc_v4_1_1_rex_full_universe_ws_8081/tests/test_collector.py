from v4rex.collector import bridge_first_ok,Envelope,decode,decode_control_frame

def test_bridge_allows_covering_delta():
    assert bridge_first_ok(100,101,101)
    assert bridge_first_ok(100,99,103)
    assert not bridge_first_ok(100,102,103)

def test_official_proto_decode():
    e=Envelope(); e.channel='spot@public.aggre.depth.v3.api.pb@10ms@SOLUSDT'; e.symbol='SOLUSDT'; e.sendTime=123456
    d=e.publicAggreDepths; d.fromVersion='100'; d.toVersion='101'; d.eventType='spot@public.aggre.depth.v3.api.pb@10ms'; d.lastOrderCreateTime=123400
    a=d.asks.add(); a.price='10.5'; a.quantity='2.0'; b=d.bids.add(); b.price='10.4'; b.quantity='3.0'
    x=decode(e.SerializeToString())
    assert x['symbol']=='SOLUSDT'; assert x['from']==100; assert x['to']==101; assert x['send']==123456
    assert x['asks']==[(10.5,2.0)]; assert x['bids']==[(10.4,3.0)]


def test_binary_json_ack_is_not_protobuf():
    x=decode_control_frame(b'{"id":0,"code":0,"msg":"spot@public.aggre.depth.v3.api.pb@10ms@BTCUSDT"}')
    assert x["code"]==0 and "depth" in x["msg"]

def test_binary_json_pong_is_not_protobuf():
    x=decode_control_frame(b'{"id":0,"code":0,"msg":"PONG"}')
    assert x["msg"]=="PONG"

def test_real_protobuf_not_control_json():
    e=Envelope(); e.symbol="BTCUSDT"; e.publicAggreDepths.fromVersion="1"; e.publicAggreDepths.toVersion="2"
    assert decode_control_frame(e.SerializeToString()) is None
