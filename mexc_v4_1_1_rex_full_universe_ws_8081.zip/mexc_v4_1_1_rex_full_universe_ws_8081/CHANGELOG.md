# V4.1.1-REX Full Universe

Correctif de robustesse après le smoke-test V4.1.0 sur 304 tokens / 635 symboles / 716 routes.

## Correctifs critiques
- Les réponses MEXC SUBSCRIPTION/PONG peuvent être livrées comme JSON dans une frame binaire. Elles sont maintenant détectées avant Protobuf : plus de faux `Wire format was corrupt` périodiques.
- Réception WS découplée du décodage : le callback horodate et pousse dans une file bornée par WS.
- 4 workers de décodage équitables par défaut ; chaque WS est affecté à un seul worker pour préserver l'ordre des deltas.
- Files RX bornées en frames et octets, avec overflow explicite et reconnexion sûre.
- Publication des Books découplée/coalescée (25 ms par défaut) et top-N par `heapq`, afin de ne plus trier un snapshot pouvant contenir des milliers de niveaux à chaque delta 10 ms.
- Exposition dans le cockpit : RX queue, queue age, decode lag p50/p95, catchup, ACK/PONG, binary JSON controls, overflow.
- `transport_delay` signifie désormais réellement exchange-send -> local-receive du dernier delta ; le temps depuis la dernière modification du Book reste une métrique descriptive.
- L'inactivité d'un Book et le skew entre dates de dernière modification ne sont plus des rejets timing : Diff.Depth est événementiel.
- Qualification timing basée sur `transport_delay` et `receive->apply decode lag`.
- Correction de `last_message_age_s` négatif dû à une lecture concurrente.

## Invariants conservés
- FULL UNIVERSE dynamique ExchangeInfo/defaultSymbols.
- Toutes les routes dirigées stablecoin A > token > stablecoin B.
- Répartition WS équilibrée avec anti-affinité token et 20 streams max par WS.
- Snapshot + Diff.Depth Protobuf 10 ms + versioning + gap/resync.
- BBO préfiltre toutes les routes puis profondeur multi-tailles/multi-fractions uniquement si raw BBO > 0.
- Cooldown de restitution 5 secondes par route, sans cooldown sur la détection.
- SHADOW ONLY : aucune clé privée et aucun endpoint d'ordre.
