# V4.1.0-REX — Full Universe MEXC Spot 2-Leg

Build **SHADOW ONLY** sur le port **8081**. Aucun endpoint d'ordre, aucune clé API privée.

## Objectif
Scanner automatiquement toutes les routes MEXC Spot de la forme :

`stablecoin A -> token -> stablecoin B`

avec `stablecoins = USDT / USDC / USD1`, pour tous les tokens disposant d'au moins deux marchés Spot/API réellement utilisables.

## Univers dynamique
Au démarrage, la build charge `exchangeInfo`, `defaultSymbols` et un snapshot ticker 24 h. Elle :
1. conserve les marchés Spot/API éligibles cotés dans les stablecoins ciblés ;
2. garde les tokens ayant au moins deux stablecoin markets ;
3. construit toutes les directions 2-leg autorisées par `tradeSideType` ;
4. ne souscrit que les symboles participant à au moins une route valide.

Le nombre de tokens, symboles, routes et WS est donc découvert au démarrage — aucun `700` n'est hardcodé.

## Équilibrage des WebSockets
MEXC limite une connexion publique à 30 subscriptions. V4.1 utilise 20 streams/WS par défaut.
Les symboles sont classés selon l'activité 24 h (`count`, ou volume en fallback) puis répartis heaviest-first entre sockets. Les marchés du même token sont séparés lorsque cela ne dégrade pas sensiblement l'équilibre de charge.

## Détection scalable
Toutes les routes passent par un BBO prefilter. Si le BBO brut est <= 0, une profondeur plus importante ne peut pas rendre l'arbitrage brut positif : le depth walk est donc inutile. Si BBO brut > 0, V4.1 teste :
- tailles : 10 / 20 / 25 / 50 / 100 / 200 $
- fractions profondeur : 10 / 15 / 20 / 25 / 33 / 50 / 75 / 100 %

## Cooldown opportunités
Le moteur peut observer la même route plusieurs fois par seconde, mais la DB/interface ne crée qu'une **fenêtre de 5 secondes par route**. Toutes les observations de cette fenêtre sont agrégées et le meilleur profil est conservé.

Verdicts :
- `RAW_POSITIVE` : brut positif, mais frais/risque mangent l'écart ;
- `NET_POSITIVE` : positif après frais, mais pas forcément qualifié par timing/seuil Expected ;
- `QUALIFIED` : passe données + timing strict + seuil Expected configuré.

## Installation
```bash
./install.sh
./start.sh
sleep 30
./smoke_check.sh
```
Dashboard : `http://IP_SERVEUR:8081`

## Smoke gate avant run long
Attendre la fin du bootstrap puis contrôler :
- WS connected = WS total ;
- Books READY proche de 100 % puis 100 % ;
- gaps = 0 ou expliqués ;
- recovery resync = 0 en régime stable ;
- reconnects/errors = 0 en régime stable ;
- update_drops = 0 ;
- aucun thread DEAD ;
- CPU/RAM et temps du fast watcher stables.

## Export cohérent pendant le run
```bash
python export_run.py
```
Utilise le backup SQLite natif compatible WAL.

## V4.1.1 — correctif full-universe
Le smoke V4.1.0 a validé l'univers complet mais a révélé deux phénomènes : les ACK/PONG JSON reçus comme frames binaires étaient envoyés par erreur au décodeur Protobuf, et le décodage/publication inline pouvait créer du backlog sur 32 WS. V4.1.1 sépare réception, décodage et publication, expose les files/latences par WS et corrige la sémantique timing des flux Diff.Depth événementiels.

Gates recommandées avant run long : `READY == total`, `WS connected == total`, `decode_errors == 0`, `rx_overflows == 0`, `update_drops == 0`, `catchup_channels == 0`, `gaps/recovery_resyncs` stables après bootstrap, puis transport/decode p95 compatibles avec les hypothèses d'exécution.
