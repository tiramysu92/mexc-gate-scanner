#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://127.0.0.1:8081}
echo '=== HEALTH ==='; curl -fsS "$BASE/healthz"; echo
echo '=== STATUS ==='; curl -fsS "$BASE/api/status"; echo
echo '=== WS ==='; curl -fsS "$BASE/api/ws"; echo
echo '=== OPPORTUNITES ==='; curl -fsS "$BASE/api/opportunities?hours=24&limit=20&min_rank=1"; echo
echo '=== DB ==='; ls -lh v4_rex_full_universe_v411.db* 2>/dev/null || true
echo '=== LOG TAIL ==='; tail -100 v4_rex.log 2>/dev/null || true
