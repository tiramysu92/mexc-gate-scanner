#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
exec nice -n 15 .venv/bin/python export_data.py
