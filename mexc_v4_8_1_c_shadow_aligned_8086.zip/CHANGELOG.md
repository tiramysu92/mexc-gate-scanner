# 4.8.1-c-shadow.1

- Budget caps and fee-aware L1-to-L2 quantity alignment; bounded candidate search per cap.
- Protected executable estimate = net cash + limited conservative dust mark - explicit C buffer.
- Cash floor for positive signal; commission quantization explained separately.
- Classification at common reference cap, primary UI C-only.
- Full unchanged-content frames with a newer server timestamp are labeled reobservations, not version changes.
- Same-version conflicting books quarantined; duplicate timestamps/old versions never refreshed.
- Atomic latest pair, event wake/coalescing/bounded pairing wait, per-pair clock sampling, recent best-RTT clock worker.
- Separate negative-edge learning and late/relaxed diagnostics; no leakage into qualified episodes/stages.
- Fixed fatal trial INSERT placeholder mismatch (9/9); deep-copy queued payloads; close read handles.
- Raw paired snapshots stored compressed, shared across cap samples.
- New schema policy signature and new data481 directory; old evidence/old executable retained.
- Responsive cost/synchronisation/evidence interface, no simulated C profits shown as realized.
- No changes to LIVE A/B 8081, dashboard 8085, credentials, balances or order execution.
