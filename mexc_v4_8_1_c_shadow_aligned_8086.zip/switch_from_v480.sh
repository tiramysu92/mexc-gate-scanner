#!/usr/bin/env bash
# Swap only the separately-installed C observer. Never stop port 8081/8085.
set -euo pipefail
cd -- "$(dirname -- "$0")"
HERE="$(pwd -P)"
OLD=/home/ubuntu/mexc-c-shadow-v480
if [[ "$HERE" != /home/ubuntu/mexc-c-shadow-v481 ]]; then
  echo "Procédure restreinte à /home/ubuntu/mexc-c-shadow-v481"; exit 1
fi
.venv/bin/python app.py --check
.venv/bin/python - <<'PY'
from pathlib import Path
from cshadow.config import load_config
c=load_config(Path('config.json').resolve())
if c['port']!=8086:raise SystemExit('Bascule prévue sur le seul port C 8086.')
PY
# An existing systemd unit is managed by its exact C name, never by port or Python pattern.
UNIT=mexc-c-shadow-v480.service
LOAD="$(systemctl show "$UNIT" -p LoadState --value 2>/dev/null || true)"
if [[ "$LOAD" == loaded ]]; then
  sudo systemctl stop "$UNIT"
  sudo systemctl disable "$UNIT"
fi
if [[ -f "$OLD/manage.py" ]]; then
  (cd "$OLD" && python3 ./manage.py stop)
fi
# No broad kill: fail if an unidentified listener still owns 8086.
.venv/bin/python - <<'PY'
import socket
with socket.socket() as s:
    try:s.bind(('0.0.0.0',8086))
    except OSError:raise SystemExit('8086 reste occupé. Aucun autre processus tué. Vérifier le propriétaire.')
print('Ancien C arrêté ; 8081 et 8085 non touchés.')
PY
bash ./start.sh
printf '\n=== HEALTH C 4.8.1 ===\n'
curl -fsS --connect-timeout 2 --max-time 10 http://127.0.0.1:8086/api/health
printf '\nAncien code et anciennes données conservés dans %s\n' "$OLD"
