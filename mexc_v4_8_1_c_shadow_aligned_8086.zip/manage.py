#!/usr/bin/env python3
"""Own-process manager. Never kill processes by a broad port/Python pattern."""
from __future__ import annotations
import json
import os
import signal
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from cshadow.config import load_config
ROOT=Path(__file__).resolve().parent
PIDFILE=ROOT/'.c_shadow_pid.json'

def ident(pid):
    proc=Path('/proc')/str(pid)
    try:
        args=(proc/'cmdline').read_bytes().split(b'\0')
        stat=(proc/'stat').read_text().rsplit(')',1)[1].split()
        return str(ROOT/'app.py').encode() in args,str(stat[19])
    except (FileNotFoundError,PermissionError,ProcessLookupError):return False,None

def read_pid():
    if not PIDFILE.exists():return None
    try:r=json.loads(PIDFILE.read_text())
    except (ValueError,OSError):return None
    ours,ticks=ident(r.get('pid',0))
    return r if ours and ticks==r.get('start_ticks') else None

def start():
    if read_pid():raise SystemExit('C-SHADOW already running; LIVE untouched.')
    cfg=load_config(ROOT/'config.json')
    py=ROOT/'.venv'/'bin'/'python'
    if not py.exists():raise SystemExit('Run ./install.sh first (dedicated venv).')
    with socket.socket() as s:
        s.bind((cfg['bind'],cfg['port']))  # Do not stop whoever owns a used port.
    subprocess.run([str(py),str(ROOT/'app.py'),'--check'],check=True)
    env={k:v for k,v in os.environ.items() if not k.startswith('MEXC_') and k not in ('API_KEY','API_SECRET','PYTHONPATH')}
    env['PYTHONDONTWRITEBYTECODE']='1'
    with (ROOT/'bootstrap.log').open('ab') as log:
        child=subprocess.Popen([str(py),str(ROOT/'app.py')],cwd=ROOT,env=env,
                               stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
    time.sleep(.2)
    ours,ticks=ident(child.pid)
    if not ours:raise SystemExit('C-SHADOW exited. Read bootstrap.log; LIVE untouched.')
    PIDFILE.write_text(json.dumps({'pid':child.pid,'start_ticks':ticks}))
    for _ in range(25):
        if child.poll() is not None:raise SystemExit('C-SHADOW exited. Read bootstrap.log.')
        try:
            with urllib.request.urlopen(f'http://127.0.0.1:{cfg["port"]}/api/health',timeout=.5) as r:
                print('C-SHADOW started:',r.read().decode());return
        except Exception:time.sleep(.4)
    print('Process exists; interface not yet responding. See bootstrap.log.')

def stop():
    r=read_pid()
    if not r:
        print('No matching C-SHADOW PID. No other process touched.');return
    os.kill(r['pid'],signal.SIGTERM)
    for _ in range(80):
        if not ident(r['pid'])[0]:
            PIDFILE.unlink(missing_ok=True);print('C-SHADOW stopped. LIVE unchanged.');return
        time.sleep(.25)
    raise SystemExit('C-SHADOW still shutting down. No force kill used.')

if __name__=='__main__':
    command=sys.argv[1] if len(sys.argv)>1 else 'status'
    if command=='start':start()
    elif command=='stop':stop()
    elif command=='restart':stop();start()
    elif command=='status':print(json.dumps(read_pid() or {'running':False}))
    else:raise SystemExit('Usage: manage.py start|stop|restart|status')
