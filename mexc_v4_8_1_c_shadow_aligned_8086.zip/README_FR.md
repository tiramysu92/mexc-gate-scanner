# MEXC V4.8.1 — C-SHADOW, sizing aligné et observation temporelle

Version logicielle : **4.8.1-c-shadow.1**. Interface : **8086**. Mode unique : **SHADOW_ONLY**. Aucun ordre possible.

## Périmètre et continuité

Cette version remplace uniquement l'observateur C V4.8.0. Le LIVE A/B V4.7 sur 8081 et son dashboard sur 8085 ne sont ni modifiés ni redémarrés. Le compte, les clés, les bags, les apports et les trials A/B ne sont pas modifiés. Le code LIVE n'est pas importé.

L'observateur lit `config.json` du runtime A/B pour trouver sa DB et lit `account_fees` avec SQLite `mode=ro` et `query_only=ON`. Il reçoit le status A/B via un GET localhost. Les seules connexions exchange sont des GET publics autorisés et le WebSocket public de profondeur. Il n'existe pas de client d'ordres, de signature ou d'endpoint d'armement C.

Un panneau A/B rapporte les chiffres fournis par A/B ; il ne les certifie pas. Le delta A/B est masqué pendant une exposition. Cette version ne répare pas la comptabilité du LIVE ni le contrôleur de rebalance A/B.

## Installation et remplacement

Nouveau dossier : `/home/ubuntu/mexc-c-shadow-v481`. Ancien dossier conservé : `/home/ubuntu/mexc-c-shadow-v480`.

1. Décompresser dans le nouveau dossier, sans copier un ancien venv ou une DB.
2. `bash ./install.sh` crée le venv dédié, installe la dépendance épinglée, compile, exécute les tests et vérifie la lecture des frais A/B. Rien n'est démarré et l'ancien C continue pendant les tests.
3. `bash ./switch_from_v480.sh` arrête uniquement le service/PID identifié de l'ancien C et lance le nouveau sur 8086. Si le port reste occupé, le script refuse de tuer un autre processus.
4. Lire `curl -fsS --max-time 10 http://127.0.0.1:8086/api/health`.

Le start détaché continue lorsque la console KVM est fermée. Fermer/reconnecter le KVM n'est pas un reboot du serveur. Les variables d'environnement MEXC héritées ne sont pas transmises au nouveau processus.

Les scripts ne font pas de `rm` du runtime ou des données. Le répertoire **data481/** appartient seulement à C. Le changement de modèle ouvre volontairement une nouvelle campagne C : les preuves issues d'une autre règle de mesure ne sont pas additionnées. Un redémarrage avec la même configuration reprend les compteurs C persistés et marque les essais inachevés comme interrompus.

Accès depuis l'adresse AWS déjà utilisée : `http://52.193.38.213:8086/`. Pas de nouveau port à ouvrir si 8086 était déjà accessible. Cette interface n'intègre pas d'authentification/TLS : limiter l'accès au Security Group à votre IP/VPN ou utiliser un reverse proxy authentifié.

### Service après reboot, facultatif

Après validation du lancement manuel : `bash ./stop.sh`, puis `bash ./install_systemd.sh`. Ce script est restreint à `/home/ubuntu/mexc-c-shadow-v481` et au data_dir par défaut. Il crée seulement `mexc-c-shadow-v481.service`. Le service dispose d'un plafond CPU de 50 %, mémoire de 512 Mo, LIVE en lecture seule, credentials inaccessibles. Ces limites peuvent augmenter les retards d'observation ; ce n'est pas une promesse de latence.

Sous systemd : `sudo systemctl stop mexc-c-shadow-v481.service`. Sans systemd : `bash ./stop.sh`. Ne pas utiliser `pkill python` ou tuer un PID identifié seulement par le numéro 8081.

## 1. La taille est un plafond et la sortie L2 pilote les quantités

Les six plafonds restent **2,50 / 5 / 10 / 15 / 20 / 25 SU**.

Pour chaque plafond, le modèle cherche une quantité de vente valide sur L2, puis déduit la quantité brute L1 nécessaire **après commission L1 en base et arrondi de cette commission**. Il vérifie ensuite budget, ticks, minima/maxima, permissions, prix limites et profondeur des deux jambes. L1 peut donc dépenser moins que le plafond.

Exemple de régression synthétique inspiré du cas SOL : pas L1 0,000001 ; pas L2 0,01 ; plafond 10 SU ; prix voisin de 113,42. Le nouveau plan utilise 0,08 SOL achetés et vendus, pour environ 9,08 SU, au lieu de forcer l'achat de 0,088... SOL et laisser environ 0,008 SOL en dust. Cet exemple n'est pas une reconstitution de fill MEXC.

La recherche teste au maximum **24 quantités candidates par plafond** : limites du budget, niveaux de profondeur, marges de réserve et sous-tailles. Elle maximise le gain protégé en SU à l'instant du signal parmi les candidats positifs valides. Si tous sont négatifs, le diagnostic conserve la plus grande dépense valide, sans présenter une minuscule dépense négative comme une opportunité. C'est une recherche bornée, pas la preuve d'un optimum global continu.

Le budget inutilisé reste en stablecoin : il n'est ni perte ni dust. Le rendement est divisé par la **dépense réellement modélisée**, pas par le plafond non consommé. Une fois l'essai commencé, quantité L2 et dépense L1 restent figées ; le modèle ne redimensionne pas après avoir vu les carnets futurs.

Les six plafonds sont conservés séparément. Si deux plafonds donnent la même quantité réelle, le champ `same_quantity_as_cap_su` le signale ; ce ne sont pas deux profits indépendants cumulables.

## 2. Métriques économiques, sans double soustraction

Tous les calculs restent nominaux : 1 USDC = 1 USDT = 1 SU. Ce n'est pas une affirmation sur leur prix de liquidation instantané.

- **Écart BBO brut** : `bid L2 / ask L1 - 1`, avant profondeur/frais.
- **Cash immédiat net** : `(proceeds L2 nets - dépense L1) / dépense L1`, après prix limites/ticks et commissions modélisées ; le dust n'est pas du cash.
- **Net + dust** : cash et marque prudente du dust résiduel, avec une décote de 5 % et une réserve de frais de liquidation.
- **Edge exécutable protégé estimé** : `net + dust - marge C supplémentaire`.
- Marge C par défaut : **2 bp**, retirés une seule fois. Les cushions L1/L2 de **0,50 / 0,50 bp** sont déjà inclus dans les prix limites, pas soustraits une seconde fois.

Le modèle expose les quantités brutes/nettes, commissions en unités, taux annoncé et **taux effectif après arrondi**, coût de borne L1/L2 et marge C en SU. Un gros minimum/arrondi de commission peut réellement plomber une micro-taille dans le modèle : il n'est pas supprimé pour produire un edge vert.

L'hypothèse de monnaie/arrondi des commissions est conservatrice : L1 en base arrondie vers le haut, L2 en quote arrondie vers le haut. Elle n'est pas une commission effectivement prélevée. La vérité comptable d'un futur LIVE restera celle des fills/commissions réconciliés.

Dust maximal : **0,05 % de la dépense** (5 bp), au lieu de 0,5 % précédemment. Un dust trop important rend le plan non testable. Un signal strict doit réunir **edge protégé ≥2 bp ET cash net ≥0 bp** ; une valorisation de dust ne finance donc pas un cash négatif.

La sensibilité à des marges C de 0/1/2/3/5 bp est affichée séparément. Ce sont des variantes diagnostiques sur le même plan, pas des essais indépendants ni des seuils LIVE.

## 3. Fraîcheur et skew : plus de données utiles, pas de fausse fraîcheur

Les limites strictes restent **250 ms d'âge local, 500 ms d'âge exchange, 100 ms de skew local, 150 ms de skew exchange, 50 ms d'incertitude d'horloge**.

Améliorations :

- Capture atomique des deux **derniers** carnets, jamais recherche rétrospective d'un ancien couple artificiellement compatible.
- Réveil sur réception de données ; coalescence locale de 3 ms et attente bornée jusqu'à 25 ms pour que l'autre jambe se mette à jour. Ce délai peut aussi faire rater un signal très court ; il est mesuré, pas caché.
- Réception horodatée avant décodage, horloge relue par couple et pas une fois pour toute la liste de tokens.
- Abonnements des deux symboles rapprochés sur la même connexion, TCP_NODELAY côté client.
- Synchronisation de l'horloge dans un worker séparé ; fenêtre récente de mesures aller-retour, choix d'une mesure à faible incertitude et marge de dérive. Un pic de RTT ne remplace pas systématiquement une meilleure mesure encore valide. Pas de correction des timestamps exchange pour faire passer le skew.
- Trame complète de même version et contenu identique avec **sendTime strictement plus récent** : `REOBSERVED_UNCHANGED`. L'observation de réception est nouvelle, l'âge du dernier changement de contenu et la version sont conservés. Cela ne constitue pas une preuve statistiquement indépendante.
- Timestamp identique, version ancienne, PING/PONG : aucun rafraîchissement du carnet. Même version/contenu contradictoire : carnet mis en quarantaine jusqu'à une version supérieure. Reconnexion : générations invalidées.

Une réobservation complète peut servir à observer L2, mais ne prouve jamais qu'un ordre aurait été rempli. La documentation du flux partiel ne garantit pas une nouvelle trame dans chaque fenêtre de 50 ms.

### Profil temporel élargi : uniquement diagnostic

Pour comprendre les rejets, le calcul est aussi effectué sous des limites explicites plus larges : âges 750/1 500 ms, skew 300/500 ms. Les lignes portent `RELAXED_DIAGNOSTIC`, `testable=false`, `signal_eligible=false` et gardent les raisons de rejet strictes.

**Elles ne déclenchent aucun épisode qualifié, aucun apprentissage strict et aucune progression de stage.** Ce profil permet de voir si l'obstacle est la synchronisation ou l'économie ; il ne supprime pas cet obstacle.

## 4. Apprentissages L2 et épisodes rentables sont séparés

**LEARNING** : toute route C structurellement testable peut faire un essai de sortie par plafond toutes les 10 s, même si son edge est négatif. Les 1 000 trials A/B ne bloquent pas cet apprentissage. Cela augmente les observations de disponibilité/slippage L2, pas le nombre de signaux rentables.

**SIGNAL** : épisode ouvert seulement si un plan strict remplit les conditions de rentabilité ci-dessus. Les plans positifs des différents plafonds gardent chacun leur essai. La clôture est observée, ou censurée si données manquantes/interruption. Plusieurs observations corrélées d'une même poussée ne deviennent pas plusieurs épisodes.

À 50/100/250/500 ms, l'essai cherche la première nouvelle trame complète dans `[h, h+25 ms]`. Sans observation appropriée : **CENSORED**, jamais succès. Une trame plus tardive, jusqu'à `h+250 ms`, est enregistrée en **LATE_DIAGNOSTIC**, avec son délai réel. Elle ne répare pas rétroactivement le succès d'un horizon manqué.

Les tableaux distinguent couverture L2, positivité de l'edge, mesures manquantes, réobservations inchangées, retards et essais SIGNAL seulement. Le volume de LEARNING ne fait pas avancer les stages.

Les stages `C_DISCOVERY`, `C_PROBE_SHADOW`, `C_VALIDATED_SHADOW`, `C_PROVEN_SHADOW` restent des paliers de recherche. Ils n'arment rien, ne garantissent pas les fills et ne prouvent pas la rentabilité de C. La simulation suppose L1 remplie au signal ; le vrai fill L1 et le risque d'exposition post-L1 restent à valider séparément avant tout LIVE C.

## 5. Couverture et interface

L'écran principal montre C uniquement, avec distinction `C_VOLUME` / `C_DEPTH_REFERENCE`. Le classement par profondeur est fixé à un plafond de référence de 25 SU, pour qu'une réduction de taille ne transforme pas artificiellement l'environnement C en A/B. Cela ne signifie pas qu'un token de gros volume serait intrinsèquement illiquide.

Découverte globale BBO toutes les 5 s, jusqu'à 8 tokens chauds simultanément, carnets de 20 niveaux. Les candidats de plus faible volume ont priorité ; deux emplacements servent à l'exploration. La limite par défaut reste 17 abonnements publics (2×8 + FX). Une découverte REST n'est pas une preuve de simultanéité ; la couverture n'est pas exhaustive et des événements courts peuvent être manqués.

Interface : cards C lisibles sur mobile ; comparateur des six plafonds ; décomposition cash/dust/frais/arrondis ; panneau Sync avec quantiles et retards ; horizon learning/signal ; diagnostic A/B et temporel élargi ; meilleurs signaux historiques clairement séparés du courant.

Il n'existe pas de PnL C réalisé autre que zéro. Les gains hypothétiques de multiples plans alternatifs ne sont pas additionnés comme de l'argent gagné. Les endpoints sont en lecture, les réponses sans cache et les valeurs dynamiques échappées.

## 6. Persistence et correction de l'ancien writer

La V4.8.0 comportait un INSERT d'essai avec 10 placeholders pour 9 colonnes. V4.8.1 corrige ce défaut et les tests vérifient réellement un enregistrement via le worker asynchrone, pas uniquement la compilation ou la mise en queue.

Les payloads sont copiés avant écriture, les connexions de lecture fermées après usage, la santé du stockage et les pertes de queue contrôlées. En cas de problème de stockage, la collecte s'interrompt : pas de faux statut sain pendant une perte d'évidence.

Les nouvelles mesures ont un `snapshot_id` vers **c_book_pairs** : deux carnets bruts capturés ensemble, compressés une seule fois et partagés entre plafonds. Les essais conservent leur plan initial et les carnets de sortie. La clé des mesures inclut route, plafond et profil ; aucune taille ne remplace une autre.

Les CSV V4.8.0 transmis (3 210 lignes) ne contiennent pas les carnets complets. On ne prétend donc pas avoir recomputé un backtest historique V4.8.1 de cet échantillon.

Exports UI : 5 000 dernières mesures / 5 000 derniers essais. Export complet : `bash ./export.sh`, dans **exports/**, uniquement DB C avec quick_check et gzip. Ne pas exporter `v240.env`.

Capacité : pause si DB C dépasse 1 Go, disque libre passe sous 1 Go ou queue perdue. Nettoyage borné des mesures/événements/carnets après 7 jours ; essais et compteurs conservés. Aucune suppression dans la DB A/B. Le processus partage CPU/disque/IP avec A/B, donc charge non nulle à contrôler sur AWS.

## Limites avant LIVE C

Voir **SOURCES.md** et **TEST_REPORT.md**. Les champs `baseSizePrecision` et les arrondis de commission restent des hypothèses conservatrices à confirmer par les règles effectives/fills avant LIVE C : MEXC décrit `baseSizePrecision` comme quantité minimale, pas universellement comme incrément. Un filtre LOT_SIZE explicite prévaut.

Les 124 tests hors ligne et le rendu interface synthétique ne valident ni le flux actuel du serveur AWS, ni ses latences, ni les fills réels, ni les profits futurs. L'objectif immédiat est une collecte C plus informative et vérifiable, pas de forcer un edge positif.
