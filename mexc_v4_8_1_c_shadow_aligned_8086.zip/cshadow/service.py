from __future__ import annotations
import copy
import hashlib
import logging
import threading
import time
import uuid
from collections import Counter,deque
from dataclasses import asdict
from . import VERSION
from .model import evaluate, BPS
from .feed import BookCache, PublicDepthFeed
from .public import ReferenceData
from .episodes import Evidence
from .storage import Store

LOG=logging.getLogger(__name__)

class Service:
    def __init__(self,cfg):
        self.cfg=cfg;self.run_id='C481-'+time.strftime('%Y%m%d-%H%M%S',time.gmtime())+'-'+uuid.uuid4().hex[:6]
        self.started_ts=time.time();self.stop=threading.Event()
        self.store=Store(cfg['data_dir'],cfg,self.run_id)
        self.cache=BookCache(cfg.get('reobserve_same_version',True))
        self.feed=PublicDepthFeed(self.cache,self.stop)
        self.reference=ReferenceData(cfg,self.store,self.stop)
        self.evidence=Evidence(cfg,self.store,self.cache)
        self.lock=threading.RLock();self.latest={};self.diagnostic_latest={};self.decisions=Counter()
        self.watch={};self.last_seen={};self.last_check={};self.pending_pair={};self.last_snap={}
        self.last_watch_rotation=0.;self.last_tick=time.monotonic();self.last_error=None
        self.state='STARTING';self.public_view={};self.discovery=[];self.thread=None;self.sequence=0
        self.timings={k:deque(maxlen=2000) for k in ('local_skew_ms','exchange_skew_ms','model_batch_ms','pair_wait_ms')}
        self.discovery_counts={};self.relaxed_counts=Counter();self.history_best={}

    def start(self):
        self.reference.start();self.feed.start()
        self.thread=threading.Thread(target=self.run,name='c-shadow-engine',daemon=True);self.thread.start()

    def discover(self,ref,mono):
        rules,fees,bbo,vol=ref['rules'],ref['fees'],ref['bbo'],ref['volumes']
        bases={}
        for r in rules.values():bases.setdefault(r.base,{})[r.quote]=r
        allroutes={};candidates=[];wall=time.time()
        for token,pairs in bases.items():
            if set(pairs)!={'USDC','USDT'}:continue
            r1,r2=pairs['USDC'],pairs['USDT'];allroutes[token]=(r1,r2)
            a,b=bbo.get(r1.symbol),bbo.get(r2.symbol)
            if not a or not b:continue
            raw1=float((b[0]/a[1]-1)*BPS);raw2=float((a[0]/b[1]-1)*BPS)
            f1,f2=fees.get(r1.symbol),fees.get(r2.symbol)
            known=bool(f1 and f2 and f1.fresh(wall,self.cfg['fee_max_age_s']) and f2.fresh(wall,self.cfg['fee_max_age_s']))
            totalfee=float(f1.taker_bps+f2.taker_bps) if known else None
            gross=max(raw1,raw2);v1,v2=vol.get(r1.symbol),vol.get(r2.symbol)
            minvol=min(v1,v2) if v1 is not None and v2 is not None else None
            likely_c=minvol is not None and minvol<self.cfg['ab_min_volume_su']
            candidates.append({'token':token,'best_raw_bps':gross,'selection_score':gross-totalfee if known else -1e9,
                'account_fees_known':known,'fee_sum_bps':totalfee,'min_volume_su':minvol,'likely_c_volume':likely_c,
                'bbo_timestamp_known':False,'source':'REST_HINT_NOT_EXECUTABILITY'})
        ranked=sorted(candidates,key=lambda x:(x['account_fees_known'],x['selection_score']),reverse=True)
        self.discovery=ranked[:40]
        self.discovery_counts={'tokens_with_two_pairs':len(allroutes),'with_bbo_hint':len(candidates),
                               'likely_c_volume':sum(x['likely_c_volume'] for x in candidates)}
        if mono-self.last_watch_rotation<self.cfg['rotation_s'] and self.watch:return allroutes
        self.last_watch_rotation=mono;cap=self.cfg['max_hot_tokens'];expl_slots=self.cfg.get('exploration_slots',2)
        active={r.split('>')[1] for r in self.evidence.active}
        retained={t:expiry for t,expiry in self.watch.items() if t in allroutes and (expiry>mono or t in active)}
        # Preserve an episode; rotate the other slots. Lower-volume hints get
        # priority, while two exploration slots may discover C_DEPTH_REFERENCE.
        hint=[x for x in ranked if x['best_raw_bps']>=self.cfg['watch_raw_bps'] and x['account_fees_known']]
        hint.sort(key=lambda x:(x['likely_c_volume'],x['selection_score']),reverse=True)
        priority=[x for x in self.cfg['pinned_tokens'] if x in allroutes]+[x['token'] for x in hint]
        priority_cap=max(0,cap-expl_slots)
        for t in priority:
            if len(retained)>=priority_cap:break
            if t not in retained:retained[t]=mono+self.cfg['watch_hold_s'];self.last_seen[t]=mono
        explore=sorted([x for x in candidates if x['token'] not in retained],
                       key=lambda x:(self.last_seen.get(x['token'],0),not x['likely_c_volume'],-x['selection_score']))
        for x in explore:
            if len(retained)>=cap:break
            t=x['token'];retained[t]=mono+self.cfg['watch_hold_s'];self.last_seen[t]=mono
        self.watch=retained
        syms={'USDCUSDT'}
        for t in self.watch:syms.update(r.symbol for r in allroutes[t])
        self.feed.set_symbols(syms)
        return allroutes

    def _timing_profile(self):
        return {**self.cfg,'max_local_age_ms':self.cfg.get('diagnostic_local_age_ms',750),
            'max_exchange_age_ms':self.cfg.get('diagnostic_exchange_age_ms',1500),
            'max_local_skew_ms':self.cfg.get('diagnostic_local_skew_ms',300),
            'max_exchange_skew_ms':self.cfg.get('diagnostic_exchange_skew_ms',500)}

    def _pair_ready(self,route,b1,b2,ref,mono):
        key=(getattr(b1,'generation',None),getattr(b1,'observation_id',None),getattr(b2,'observation_id',None),
             ref.get('rules_ts'),ref.get('fees_ts'),getattr(ref.get('clock'),'sampled_ts',None))
        prev=self.last_check.get(route)
        if prev and key==prev[0] and mono-prev[1]<1:return False
        if prev and mono-prev[1]<.02:
            self.decisions['coalesced_fast_update']+=1;return False
        first=self.pending_pair.setdefault(route,mono)
        if mono-first<self.cfg.get('pair_coalesce_ms',3)/1000:return False
        skew=bool(b1 and b2 and (abs(b1.recv_mono-b2.recv_mono)*1000>self.cfg['max_local_skew_ms'] or
                                 abs(b1.exchange_ms-b2.exchange_ms)>self.cfg['max_exchange_skew_ms']))
        if skew and mono-first<self.cfg.get('pair_sync_wait_ms',25)/1000:return False
        self.timings['pair_wait_ms'].append((mono-first)*1000)
        self.pending_pair.pop(route,None);self.last_check[route]=(key,mono)
        return True

    def run(self):
        lastview=lastmetric=0.;routes={};lastdiscover=0.
        try:
            while not self.stop.is_set():
                wall,mono=time.time(),time.monotonic();self.last_tick=mono
                ref=self.reference.snapshot()
                if mono-lastdiscover>=1 or not routes:routes=self.discover(ref,mono);lastdiscover=mono
                if self.store.failed:
                    self.state='PAUSED_STORAGE';self.feed.set_symbols(set())
                elif mono-self.reference.heartbeat>30 and self.reference.heartbeat:self.state='PAUSED_REFERENCE_WORKER'
                elif mono<self.reference.client.backoff_until:
                    self.state='PAUSED_PUBLIC_RATE_LIMIT';self.feed.pause_until=self.reference.client.backoff_until
                else:
                    if not ref['rules']:self.state='WAITING_RULES'
                    elif not any(f.fresh(wall,self.cfg['fee_max_age_s']) for f in ref['fees'].values()):self.state='WAITING_ACCOUNT_FEES'
                    elif not ref['clock'] or not ref['clock'].valid(wall,self.cfg):self.state='WAITING_CLOCK'
                    elif not self.feed.connected:self.state='WAITING_PUBLIC_FEED'
                    elif not self.feed.last_depth_rx:self.state='WAITING_DEPTH'
                    else:self.state='SHADOW_COLLECTING'
                    for token in list(self.watch):
                        if token not in routes:continue
                        pair=routes[token]
                        for r1,r2 in (pair,pair[::-1]):
                            route=f'{r1.quote}>{token}>{r2.quote}'
                            b1,b2=self.cache.pair(r1.symbol,r2.symbol)
                            # Sample clocks after the atomic pair capture, not once for
                            # the whole watchlist: a later fresh frame is not 'in the future'.
                            wall,mono=time.time(),time.monotonic()
                            if not self._pair_ready(route,b1,b2,ref,mono):continue
                            begin=time.monotonic()
                            f1,f2=ref['fees'].get(r1.symbol),ref['fees'].get(r2.symbol)
                            v1,v2=ref['volumes'].get(r1.symbol),ref['volumes'].get(r2.symbol)
                            vol=min(v1,v2) if v1 is not None and v2 is not None and wall-ref['volume_ts']<=3600 else None
                            if b1 and b2:
                                self.timings['local_skew_ms'].append(abs(b1.recv_mono-b2.recv_mono)*1000)
                                self.timings['exchange_skew_ms'].append(abs(b1.exchange_ms-b2.exchange_ms))
                            snapshot_id=None
                            if b1 and b2 and self.cfg.get('record_book_pairs',True) and mono-self.last_snap.get(route,-1e20)>=self.cfg['sample_interval_s']:
                                # Same contemporaneous raw books support every cap; compressed once.
                                self.last_snap[route]=mono
                                snapshot_id=hashlib.sha256(f'{self.run_id}|{route}|{b1.observation_id}|{b2.observation_id}'.encode()).hexdigest()[:32]
                                self.store.emit('book_pair',{'snapshot_id':snapshot_id,'ts':wall,'books':[b1.wire(),b2.wire()],
                                                'clock':asdict(ref['clock']) if ref['clock'] else None})
                            plans=[];sameqty={}
                            for size in self.cfg['sizes_su']:
                                try:p=evaluate(r1,r2,b1,b2,f1,f2,size,vol,wall,mono,ref['clock'],self.cfg,ref['refs'])
                                except Exception as exc:
                                    self.last_error=f'MODEL_ERROR {route} {size}: {exc}'
                                    self.decisions['MODEL_ERROR']+=1;self.store.emit('model_error',{'error':self.last_error});continue
                                self.decisions['size_evaluations']+=1
                                for reason in p['reasons']:self.decisions[reason]+=1
                                if p['testable']:self.decisions['C_BOOK_TESTABLE']+=1
                                if p.get('signal_eligible'):self.decisions['C_PROTECTED_EDGE_SIGNAL']+=1
                                if snapshot_id:p['snapshot_id']=snapshot_id
                                qkey=(p.get('q1'),p.get('q2'))
                                if qkey[0]:
                                    p['same_quantity_as_cap_su']=sameqty.get(qkey);sameqty.setdefault(qkey,size)
                                # Looser timing is a separate diagnostic only. It cannot
                                # feed episodes, learning, stage counts, or a live decision.
                                temporal=any('SKEW' in x or 'STALE_LOCAL' in x or 'STALE_EXCHANGE' in x for x in p['reasons'])
                                if temporal and self.cfg.get('diagnostic_timing_enabled',True):
                                    d=evaluate(r1,r2,b1,b2,f1,f2,size,vol,wall,mono,ref['clock'],self._timing_profile(),ref['refs'])
                                    d.update(profile='RELAXED_DIAGNOSTIC',strict_reasons=list(p['reasons']),
                                             testable=False,signal_eligible=False,usable_for_strict_proof=False)
                                    if snapshot_id:d['snapshot_id']=snapshot_id
                                    self.diagnostic_latest[(route,size)]=d
                                    self.relaxed_counts['evaluated']+=1
                                    if d.get('book_valid') and d.get('is_c'):
                                        self.relaxed_counts['c_math_visible']+=1
                                        if d.get('protected_edge_bps',-1e9)>=self.cfg['episode_entry_bps']:self.relaxed_counts['positive_but_not_proven']+=1
                                    if snapshot_id:self.store.emit('sample',{k:v for k,v in d.items() if k!='entry_books'})
                                plans.append(p)
                            if b1 and b1.generation!=self.cache.generation:
                                for p in plans:
                                    p['testable']=False;p['signal_eligible']=False;p['reasons'].append('FEED_GENERATION_CHANGED')
                            self.evidence.observe(route,plans,r2,f2,b2,mono,wall)
                            for p in plans:
                                self.latest[(route,p['size'])]=p
                                if p.get('signal_eligible'):
                                    key=(route,p['size']);prev=self.history_best.get(key)
                                    if not prev or p['protected_edge_bps']>prev['protected_edge_bps']:
                                        self.history_best[key]={k:v for k,v in p.items() if k!='entry_books'}
                            self.timings['model_batch_ms'].append((time.monotonic()-begin)*1000)
                            self.decisions['pair_evaluations']+=1
                wall,mono=time.time(),time.monotonic()
                self.evidence.tick(wall,mono,ref['clock'])
                if mono-lastview>=1:self.make_view(ref,wall,mono);lastview=mono
                if mono-lastmetric>=self.cfg['metrics_interval_s']:
                    self.store.emit('metrics',{'ts':wall,'state':self.state,'decisions':dict(self.decisions),
                                              'timing':self._timing_status(),'feed':self.feed.status(),'evidence':self.evidence.status()})
                    lastmetric=mono
                # New frames wake the observer; .02 also advances horizon timers.
                self.cache.updated.wait(.02);self.cache.updated.clear()
        except Exception as exc:
            self.state='ENGINE_FAILED';self.last_error=f'{type(exc).__name__}: {exc}'
            LOG.exception('C observer stopped');self.store.emit('fatal',{'error':self.last_error})
        finally:self.evidence.close()

    def _timing_status(self):
        out={}
        for k,vals in self.timings.items():
            a=sorted(vals)
            out[k]={'n':len(a),'p50':a[len(a)//2] if a else None,'p95':a[min(len(a)-1,int(.95*len(a)))] if a else None,'max':max(a) if a else None}
        return out

    def make_view(self,ref,wall,mono):
        values=[]
        for p in self.latest.values():
            if wall-p['ts']>1200:continue
            x={k:v for k,v in p.items() if k!='entry_books'};x['age_s']=max(0,wall-p['ts'])
            x['stale']=(x.get('book_generation',self.cache.generation)!=self.cache.generation or x['age_s']*1000+max(x.get('local_age1_ms',0),x.get('local_age2_ms',0))>self.cfg['max_local_age_ms'])
            if x['stale']:
                x['testable']=False;x['signal_eligible']=False;x['reasons']=list(x['reasons'])+['DISPLAY_SIGNAL_STALE']
            x['stage']=self.evidence.stage(x['route'],x['size']);values.append(x)
        score=lambda p:(p.get('testable',False),p.get('protected_edge_bps') if p.get('protected_edge_bps') is not None else -1e12)
        values.sort(key=score,reverse=True)
        cvalues=[p for p in values if p.get('is_c')]
        diagnostics=[p for p in values if not p.get('is_c') or not p.get('testable')]
        relaxed=[]
        for p in self.diagnostic_latest.values():
            if wall-p['ts']>1200:continue
            x={k:v for k,v in p.items() if k!='entry_books'};x['age_s']=wall-p['ts'];relaxed.append(x)
        relaxed.sort(key=score,reverse=True)
        live=ref['live'];flow=live.get('flow_inventory') or {};base=flow.get('session_baseline') or {};balances=live.get('balances') or {}
        settled=live.get('active_cycle') is None and live.get('state') in ('READY','SAFE_NOT_ARMED')
        liveview={'state':live.get('state'),'execution_enabled':live.get('execution_enabled'),'arm_ok':live.get('arm_ok'),
            'active_cycle':live.get('active_cycle'),'last_error':live.get('last_error'),
            'private_ws':{k:(live.get('private_ws') or {}).get(k) for k in ('connected','acks','errors','reconnects','last_event_age_s')},
            'balances':balances,'inventory':flow.get('inventory'),
            'baseline':{k:base.get(k) for k in ('session_id','ts','USDC','USDT','stable_units','strategy_dust_est_usd','stable_units_plus_dust')},
            'reported_delta_su':flow.get('session_delta_stable_units') if settled else None,'reported_delta_reconciled':False,
            'settled':settled,'age_s':wall-ref['live_ts'] if ref['live_ts'] else None,'fx':(live.get('maintenance') or {}).get('stable_fx')}
        view={'version':VERSION,'mode':'SHADOW_ONLY','orders_possible':False,'realized_c_pnl_su':0,'run_id':self.run_id,
            'started_ts':self.started_ts,'now':wall,'state':self.state,'last_error':self.last_error,'feed':self.feed.status(),
            'storage':{'healthy':not self.store.failed and self.store.thread.is_alive(),'error':self.store.last_error,
                       'queue':self.store.queue.qsize(),'dropped':self.store.dropped,'written':self.store.written},
            'references':{'fee_fresh':sum(f.fresh(wall,self.cfg['fee_max_age_s']) for f in ref['fees'].values()),'fee_total':len(ref['fees']),
                'rules':len(ref['rules']),'bbo_age_s':wall-ref['bbo_ts'] if ref['bbo_ts'] else None,
                'clock':asdict(ref['clock']) if ref['clock'] else None,'clock_ok':bool(ref['clock'] and ref['clock'].valid(wall,self.cfg)),
                'clock_selection':ref.get('clock_metrics',{}),'errors':ref['errors'],'last_error':ref['last_error']},
            'coverage':{'hot_tokens':list(self.watch),'hot_limit':self.cfg['max_hot_tokens'],'exploration_slots':self.cfg.get('exploration_slots',2),
                        'depth_levels':20,'discovery_poll_s':self.cfg['discovery_poll_s'],**self.discovery_counts},
            'decisions':dict(self.decisions),'evidence':self.evidence.status(),'timing':self._timing_status(),
            'diagnostic_timing_counts':dict(self.relaxed_counts),'top10':cvalues[:10],
            'latest_sizes':cvalues[:150],'diagnostics':diagnostics[:50],'relaxed_diagnostics':relaxed[:50],
            'best_since_start':sorted(self.history_best.values(),key=score,reverse=True)[:20],
            'discovery':self.discovery,'live':liveview,
            'policy':{k:self.cfg[k] for k in ('sizes_su','episode_entry_bps','thin_buffer_bps','l1_cushion_bps','l2_cushion_bps',
                'participation_fraction','episode_separation_s','horizon_tolerance_ms','stage_episode_counts','stage_edges_bps','stage_size_caps_su',
                'max_local_age_ms','max_exchange_age_ms','max_local_skew_ms','max_exchange_skew_ms','learning_interval_s',
                'late_horizon_window_ms','dust_haircut_bps','max_size_candidates','classification_size_su','signal_cash_floor_bps')},
            'model_revision':self.cfg['model_revision']}
        with self.lock:self.sequence+=1;view['sequence']=self.sequence;self.public_view=view

    def snapshot(self):
        with self.lock:out=copy.deepcopy(self.public_view)
        if not out:out={'version':VERSION,'state':self.state,'mode':'SHADOW_ONLY','orders_possible':False,'now':time.time()}
        out['heartbeat_age_s']=max(0,time.monotonic()-self.last_tick)
        if out['heartbeat_age_s']>3:out['state']='STALE_ENGINE_STATUS'
        out['served_ts']=time.time()
        try:out['recent_episodes']=self.store.recent('episodes',20)
        except Exception as exc:out['read_error']=str(exc)
        return out

    def close(self):
        self.stop.set();self.cache.updated.set();self.feed.close()
        if self.thread:self.thread.join(5)
        if self.reference.thread:self.reference.thread.join(5)
        if self.reference.clock_thread:self.reference.clock_thread.join(5)
        self.store.close()
