from __future__ import annotations
import time
import uuid
from collections import Counter, deque
from .model import timing, horizon_exit


class Evidence:
    """C signal episodes and edge-independent learning are separate evidence sets."""
    def __init__(self,cfg,store,cache):
        self.cfg,self.store,self.cache=cfg,store,cache
        self.active={};self.pending={};self.stages=store.load_stages();self.counts=Counter()
        self.horizon_counts={h:Counter() for h in cfg['horizons_ms']}
        self.signal_horizon_counts={h:Counter() for h in cfg['horizons_ms']}
        self.delays={h:deque(maxlen=1000) for h in cfg['horizons_ms']}
        self.slips={h:deque(maxlen=1000) for h in cfg['horizons_ms']}
        self.remaining_edges={h:deque(maxlen=1000) for h in cfg['horizons_ms']}
        self.last_sample={};self.rearm_after={};self.last_learning={}

    def stage(self,route,size):
        c=self.stages.get((route,float(size)),{});n=c.get('clean',0)
        a,b,d=self.cfg['stage_episode_counts']
        i=2 if n>=d else 1 if n>=b else 0 if n>=a else -1
        return {'label':['C_PROBE_SHADOW','C_VALIDATED_SHADOW','C_PROVEN_SHADOW'][i] if i>=0 else 'C_DISCOVERY',
                'clean_episodes':n,'total_episodes':c.get('total',0),'live_authorized':False,
                'size_cap_su':self.cfg['stage_size_caps_su'][i] if i>=0 else 0,
                'required_edge_bps':self.cfg['stage_edges_bps'][i] if i>=0 else None,
                'qualification_claim':'RESEARCH_STAGE_ONLY_NOT_A_FILL_PROBABILITY'}

    def _start_trial(self,plan,r2,fee2,b2,mono,wall,eid,purpose):
        tid=uuid.uuid4().hex
        record={'trial_id':tid,'episode_id':eid,'route':plan['route'],'size':float(plan['size']),
                'start_ts':wall,'done_ts':None,'clean':False,'status':'PENDING',
                'purpose':purpose,'plan':dict(plan),'horizons':{},'late_horizons':{},'live_authorized':False,
                'hypothesis':'L1_FILLED_AT_SIGNAL_NOT_EXECUTED','actual_spend_su':plan.get('spend_su')}
        self.pending[tid]={'record':record,'rule':r2,'fee':fee2,'book':b2,'mono':mono}
        self.store.emit('trial',record)
        self.counts['trials_started']+=1
        self.counts[purpose.lower()+'_trials_started']+=1
        return record

    def observe(self,route,plans,r2,fee2,b2,mono,wall):
        eligible=[p for p in plans if p.get('signal_eligible',False) and p.get('profile','STRICT')=='STRICT']
        ep=self.active.get(route)
        observable=any(p.get('protected_edge_bps') is not None and not any(
            word in reason for reason in p.get('reasons',[]) for word in ('STALE','CLOCK','SKEW','FEES')) for p in plans)
        if eligible and ep is None and mono>=self.rearm_after.get(route,0):
            ep={'episode_id':uuid.uuid4().hex,'route':route,'start_ts':wall,'last_ts':wall,
                'start_mono':mono,'last_observed_mono':mono,'below_since':None,'status':'OPEN',
                'sizes':{},'positive_observations':0,'model_revision':self.cfg.get('model_revision')}
            self.active[route]=ep;self.counts['episodes_opened']+=1;self._save_episode(ep)
        if ep:
            if observable:ep['last_observed_mono']=mono;ep['last_ts']=wall
            if eligible:
                ep['below_since']=None;ep['positive_observations']+=1
                for p in eligible:
                    size=float(p['size'])
                    if size not in ep['sizes'] and b2 is not None:
                        ep['sizes'][size]=self._start_trial(p,r2,fee2,b2,mono,wall,ep['episode_id'],'SIGNAL')
            elif observable:
                edges=[p['protected_edge_bps'] for p in plans if p.get('testable') and p.get('protected_edge_bps') is not None]
                if not edges or max(edges)<=self.cfg['episode_exit_bps']:
                    if ep['below_since'] is None:ep['below_since']=mono
                    if mono-ep['below_since']>=self.cfg['episode_separation_s']:self.finish(route,'CLOSED_OBSERVED',wall,mono)
                else:ep['below_since']=None
        # Do not require a profitable edge merely to learn the exit-side liquidity.
        # Learning outcomes never promote an episode stage or authorize orders.
        if self.cfg.get('learning_enabled',True) and b2 and fee2:
            for p in plans:
                key=(route,float(p['size']))
                if not p.get('testable') or p.get('profile','STRICT')!='STRICT':continue
                if ep and p['size'] in ep['sizes']:continue
                if mono-self.last_learning.get(key,-1e20)<self.cfg.get('learning_interval_s',10):continue
                if any(v['record']['purpose']=='LEARNING' and (v['record']['route'],v['record']['size'])==key for v in self.pending.values()):continue
                self.last_learning[key]=mono
                self._start_trial(p,r2,fee2,b2,mono,wall,'LEARN-'+uuid.uuid4().hex,'LEARNING')
        for p in plans:
            p['stage']=self.stage(route,p['size'])
            if ep:p['episode_id']=ep['episode_id']
            key=(route,p['size'],p.get('profile','STRICT'))
            if mono-self.last_sample.get(key,-1e20)>=self.cfg['sample_interval_s']:
                if p.get('protected_edge_bps') is not None or (p.get('raw_bps') is not None and p['raw_bps']>=self.cfg['watch_raw_bps']):
                    self.store.emit('sample',{k:v for k,v in p.items() if k!='entry_books'})
                self.last_sample[key]=mono
        return plans

    def _result(self,trial,b,pending,mono,clock,status):
        invalid=[x for x in timing(b,b.recv_ts,b.recv_mono,clock,self.cfg) if x!='EMPTY_BOOK']
        signal=trial['plan'].get('clock_at_signal') or {}
        since_signal=b.exchange_ms-(trial['start_ts']*1000+signal.get('offset_ms',0))
        if since_signal < -signal.get('uncertainty_ms',0)-2:invalid.append('EXCHANGE_FRAME_BEFORE_SIGNAL')
        if invalid:result={'status':'CENSORED','reason':','.join(invalid)}
        elif not pending['fee'].fresh(b.recv_ts,self.cfg['fee_max_age_s']):
            result={'status':'CENSORED','reason':'FEES_STALE_AT_HORIZON'}
        elif b.recv_ts-pending['rule'].fetched_ts>self.cfg['rules_max_age_s']:
            result={'status':'CENSORED','reason':'RULES_STALE_AT_HORIZON'}
        else:
            result=horizon_exit(trial['plan'],b,pending['rule'],pending['fee'],self.cfg)
            result['status']=status
            result['pass']=bool(result['liquidity_ok'] and result.get('cash_positive') and
                                result['protected_edge_bps'] is not None and result['protected_edge_bps']>0)
        result.update(actual_delay_ms=(b.recv_mono-pending['mono'])*1000,
                      scheduler_lag_ms=max(0,(mono-b.recv_mono)*1000),frame_version=b.version,
                      observation_kind=b.observation_kind,observation_id=b.observation_id,
                      exchange_ms=b.exchange_ms,exchange_since_signal_ms=since_signal)
        return result

    def tick(self,wall,mono,clock):
        for tid,pending in list(self.pending.items()):
            tr,initial=pending['record'],pending['book']
            for h in self.cfg['horizons_ms']:
                due=pending['mono']+h/1000;deadline=due+self.cfg['horizon_tolerance_ms']/1000
                late_end=due+self.cfg.get('late_horizon_window_ms',250)/1000
                if mono<due:continue
                b=self.cache.first_after(initial.symbol,due,initial.generation,initial.version,initial.exchange_ms,initial.observation_id)
                if str(h) not in tr['horizons']:
                    if b is not None and b.recv_mono<=deadline:
                        result=self._result(tr,b,pending,mono,clock,'OBSERVED')
                    elif mono>=deadline:
                        reason='DISCONNECTED_OR_ROTATED' if self.cache.generation!=initial.generation else 'NO_NEW_FULL_FRAME_IN_WINDOW'
                        result={'status':'CENSORED','reason':reason,'actual_delay_ms':None}
                    else:continue
                    tr['horizons'][str(h)]=result
                    for stats in [self.horizon_counts[h]]+([self.signal_horizon_counts[h]] if tr['purpose']=='SIGNAL' else []):
                        stats['total']+=1
                        if result['status']=='OBSERVED':
                            stats['observed']+=1
                            stats['liquidity_ok']+=int(result['liquidity_ok']);stats['positive']+=int(result['pass'])
                            stats['negative_or_unfillable']+=int(not result['pass'])
                            stats['unchanged_reobservations']+=int(result['observation_kind']=='REOBSERVED_UNCHANGED')
                        else:stats['censored']+=1
                    if result.get('status')=='OBSERVED':
                        self.delays[h].append(result['actual_delay_ms'])
                        if result.get('l2_slippage_bps') is not None:self.slips[h].append(result['l2_slippage_bps'])
                        if result.get('protected_edge_bps') is not None:self.remaining_edges[h].append(result['protected_edge_bps'])
                if str(h) not in tr['late_horizons']:
                    if tr['horizons'][str(h)]['status']=='OBSERVED':tr['late_horizons'][str(h)]={'status':'NOT_NEEDED'}
                    elif b is not None and deadline<b.recv_mono<=late_end:
                        result=self._result(tr,b,pending,mono,clock,'LATE_DIAGNOSTIC')
                        result['usable_for_strict_proof']=False
                        tr['late_horizons'][str(h)]=result
                        self.horizon_counts[h]['late_diagnostic']+=1
                    elif mono>=late_end:tr['late_horizons'][str(h)]={'status':'UNOBSERVED','usable_for_strict_proof':False}
            if len(tr['horizons'])==len(self.cfg['horizons_ms']) and len(tr['late_horizons'])==len(self.cfg['horizons_ms']):
                outcomes=tr['horizons']
                clean=tr['purpose']=='SIGNAL' and all(outcomes[str(h)].get('pass') is True for h in (250,500)) and not any(
                    x['status']=='OBSERVED' and not x['pass'] for x in outcomes.values())
                tr.update(clean=bool(clean),done_ts=wall,status='COMPLETE')
                self.store.emit('trial',tr);self.pending.pop(tid,None);self.counts['trials_completed']+=1
                self.counts[tr['purpose'].lower()+'_trials_completed']+=1
        for route,ep in list(self.active.items()):
            if mono-ep['last_observed_mono']>self.cfg['episode_data_gap_s']:self.finish(route,'CENSORED_DATA_GAP',wall,mono)
            elif mono-ep['start_mono']>self.cfg['episode_max_s']:self.finish(route,'CENSORED_MAX_DURATION',wall,mono)

    def finish(self,route,status,wall,mono):
        ep=self.active.pop(route,None)
        if not ep:return
        ep.update(status=status,end_ts=wall);clean_sizes=[]
        for size,tr in ep['sizes'].items():
            if tr['status']=='PENDING':
                self._interrupt(tr,status,wall);self.pending.pop(tr['trial_id'],None)
            c=self.stages.setdefault((route,size),{'clean':0,'total':0});c['total']+=1
            if status=='CLOSED_OBSERVED' and tr['clean']:c['clean']+=1;clean_sizes.append(size)
            self.store.emit('stage',{'route':route,'size':size,**c})
        ep['clean_sizes']=clean_sizes;self._save_episode(ep)
        self.counts['episodes_closed_observed' if status=='CLOSED_OBSERVED' else 'episodes_censored']+=1
        self.rearm_after[route]=mono+(0 if status=='CLOSED_OBSERVED' else self.cfg['episode_separation_s'])

    def _interrupt(self,tr,reason,wall):
        for h in self.cfg['horizons_ms']:
            tr['horizons'].setdefault(str(h),{'status':'CENSORED','reason':reason})
        tr.update(status='INTERRUPTED',done_ts=wall,clean=False);self.store.emit('trial',tr)

    def _save_episode(self,ep):
        self.store.emit('episode',{k:v for k,v in ep.items() if k not in ('sizes','start_mono','last_observed_mono','below_since')})

    def status(self):
        horizons={}
        for h,c in self.horizon_counts.items():
            delays=sorted(self.delays[h]);slips=sorted(self.slips[h]);edges=sorted(self.remaining_edges[h])
            horizons[str(h)]={**dict(c),'p95_actual_ms':delays[min(len(delays)-1,int(len(delays)*.95))] if delays else None,
                              'p95_slippage_bps':slips[min(len(slips)-1,int(len(slips)*.95))] if slips else None,
                              'worst_slippage_bps':max(slips) if slips else None,'p50_remaining_bps':edges[len(edges)//2] if edges else None,
                              'signal_only':dict(self.signal_horizon_counts[h])}
        return {**dict(self.counts),'active_episodes':len(self.active),'pending_trials':len(self.pending),'horizons':horizons,
                'stages':[{'route':r,'size':s,**v,**self.stage(r,s)} for (r,s),v in self.stages.items()],
                'learning_promotes_stage':False,'late_promotes_stage':False}

    def close(self):
        for r in list(self.active):self.finish(r,'INTERRUPTED_SHUTDOWN',time.time(),time.monotonic())
        for tid,p in list(self.pending.items()):
            self._interrupt(p['record'],'INTERRUPTED_SHUTDOWN',time.time());self.pending.pop(tid,None)
