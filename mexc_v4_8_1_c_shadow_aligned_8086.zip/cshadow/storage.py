from __future__ import annotations
import json
import copy
import zlib
import hashlib
import logging
import queue
import shutil
import sqlite3
import threading
import time
from pathlib import Path

LOG = logging.getLogger(__name__)
SCHEMA = '''
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS c_meta(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS c_runs(run_id TEXT PRIMARY KEY,started_ts REAL,config_json TEXT);
CREATE TABLE IF NOT EXISTS c_episodes(episode_id TEXT PRIMARY KEY,run_id TEXT,route TEXT,start_ts REAL,last_ts REAL,end_ts REAL,status TEXT,detail_json TEXT);
CREATE INDEX IF NOT EXISTS c_ep_time ON c_episodes(start_ts);
CREATE TABLE IF NOT EXISTS c_size_samples(id INTEGER PRIMARY KEY,run_id TEXT,episode_id TEXT,ts REAL,route TEXT,size REAL,testable INTEGER,protected_bps REAL,detail_json TEXT);
CREATE INDEX IF NOT EXISTS c_sample_time ON c_size_samples(ts);
CREATE INDEX IF NOT EXISTS c_sample_key ON c_size_samples(route,size,ts);
CREATE TABLE IF NOT EXISTS c_size_trials(trial_id TEXT PRIMARY KEY,run_id TEXT,episode_id TEXT,route TEXT,size REAL,start_ts REAL,done_ts REAL,clean INTEGER,detail_json TEXT,UNIQUE(episode_id,route,size));
CREATE INDEX IF NOT EXISTS c_trial_time ON c_size_trials(start_ts);
CREATE TABLE IF NOT EXISTS c_stage_counts(route TEXT,size REAL,clean_episodes INTEGER,total_episodes INTEGER,PRIMARY KEY(route,size));
CREATE TABLE IF NOT EXISTS c_events(id INTEGER PRIMARY KEY,ts REAL,kind TEXT,detail_json TEXT);
CREATE TABLE IF NOT EXISTS c_rule_snapshots(id INTEGER PRIMARY KEY,ts REAL,detail_json TEXT);
CREATE TABLE IF NOT EXISTS c_fee_snapshots(id INTEGER PRIMARY KEY,ts REAL,detail_json TEXT);
CREATE TABLE IF NOT EXISTS c_metrics(ts REAL PRIMARY KEY,detail_json TEXT);
CREATE TABLE IF NOT EXISTS c_book_pairs(snapshot_id TEXT PRIMARY KEY,ts REAL,symbol1 TEXT,symbol2 TEXT,body_zlib BLOB);
CREATE INDEX IF NOT EXISTS c_pair_ts ON c_book_pairs(ts);

'''

class ClosingConnection(sqlite3.Connection):
    def __exit__(self,typ,value,traceback):
        try:return super().__exit__(typ,value,traceback)
        finally:self.close()


def encode(x):
    return json.dumps(x, ensure_ascii=False, separators=(',', ':'), allow_nan=False, default=str)

class Store:
    def __init__(self, data_dir: str, cfg: dict, run_id: str):
        self.directory = Path(data_dir)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.path = self.directory/'c_shadow.sqlite'
        self.cfg, self.run_id = cfg, run_id
        self.queue = queue.Queue(maxsize=cfg['writer_queue_size'])
        self.stop_event = threading.Event()
        self.failed = False
        self.last_error = None
        self.dropped = 0
        self.written = 0
        self.writer_heartbeat = time.monotonic()
        with sqlite3.connect(self.path,factory=ClosingConnection) as db:
            db.executescript(SCHEMA)
            # Never pool episode evidence across changed measurement rules.
            ignored={'bind','port','data_dir','live_runtime','live_status_url','max_db_mb','min_disk_free_mb','retention_days','pinned_tokens'}
            signature=hashlib.sha256(json.dumps({k:v for k,v in cfg.items() if k not in ignored},sort_keys=True).encode()).hexdigest()
            previous=db.execute("SELECT value FROM c_meta WHERE key='policy_signature'").fetchone()
            if previous and previous[0]!=signature:
                raise ValueError('Measurement policy changed. Use a NEW C data_dir; old evidence preserved.')
            db.execute("INSERT OR IGNORE INTO c_meta VALUES('policy_signature',?)",(signature,))
            interrupted=db.execute("SELECT episode_id,detail_json FROM c_episodes WHERE status='OPEN'").fetchall()
            for eid,detail in interrupted:
                payload=json.loads(detail);payload['status']='INTERRUPTED_RESTART'
                db.execute('UPDATE c_episodes SET status=?,detail_json=? WHERE episode_id=?',('INTERRUPTED_RESTART',encode(payload),eid))
            for tid,detail in db.execute('SELECT trial_id,detail_json FROM c_size_trials WHERE done_ts IS NULL').fetchall():
                payload=json.loads(detail)
                payload.update(status='INTERRUPTED_RESTART',clean=False,done_ts=time.time())
                db.execute('UPDATE c_size_trials SET done_ts=?,clean=0,detail_json=? WHERE trial_id=?',
                           (payload['done_ts'],encode(payload),tid))
            db.execute('INSERT INTO c_runs VALUES(?,?,?)', (run_id,time.time(),encode(cfg)))
        self.thread = threading.Thread(target=self._writer, name='c-db-writer', daemon=True)
        self.thread.start()

    def emit(self, kind: str, x: dict):
        if self.failed: return False
        try:
            self.queue.put_nowait((kind,copy.deepcopy(x))); return True
        except queue.Full:
            self.dropped += 1
            self.failed = True
            self.last_error = 'WRITER_QUEUE_FULL: collection paused; evidence may be incomplete'
            return False

    def ro(self):
        db = sqlite3.connect(self.path.resolve().as_uri()+'?mode=ro', uri=True, timeout=.5,factory=ClosingConnection)
        db.execute('PRAGMA query_only=ON')
        return db

    def load_stages(self):
        with self.ro() as db:
            return {(r,s): {'clean':int(n), 'total':int(t)} for r,s,n,t in db.execute('SELECT * FROM c_stage_counts')}

    def _write(self, db, kind, x):
        if kind == 'sample':
            db.execute('INSERT INTO c_size_samples(run_id,episode_id,ts,route,size,testable,protected_bps,detail_json) VALUES(?,?,?,?,?,?,?,?)',
                       (self.run_id,x.get('episode_id'),x['ts'],x['route'],x['size'],int(x['testable']),x.get('protected_edge_bps'),encode(x)))
        elif kind == 'episode':
            db.execute('INSERT INTO c_episodes VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(episode_id) DO UPDATE SET last_ts=excluded.last_ts,end_ts=excluded.end_ts,status=excluded.status,detail_json=excluded.detail_json',
                       (x['episode_id'],self.run_id,x['route'],x['start_ts'],x['last_ts'],x.get('end_ts'),x['status'],encode(x)))
        elif kind == 'trial':
            db.execute('INSERT OR REPLACE INTO c_size_trials VALUES(?,?,?,?,?,?,?,?,?)',
                       (x['trial_id'],self.run_id,x['episode_id'],x['route'],x['size'],x['start_ts'],x['done_ts'],int(x['clean']),encode(x)))
        elif kind == 'stage':
            db.execute('INSERT INTO c_stage_counts VALUES(?,?,?,?) ON CONFLICT(route,size) DO UPDATE SET clean_episodes=excluded.clean_episodes,total_episodes=excluded.total_episodes',
                       (x['route'],x['size'],x['clean'],x['total']))
        elif kind == 'book_pair':
            db.execute('INSERT OR IGNORE INTO c_book_pairs VALUES(?,?,?,?,?)',
                       (x['snapshot_id'],x['ts'],x['books'][0]['symbol'],x['books'][1]['symbol'],
                        sqlite3.Binary(zlib.compress(encode(x).encode('utf-8'),3))))
        elif kind == 'metrics':
            db.execute('INSERT OR REPLACE INTO c_metrics VALUES(?,?)',(x['ts'],encode(x)))
        elif kind in ('rules','fees'):
            table = 'c_rule_snapshots' if kind=='rules' else 'c_fee_snapshots'
            db.execute(f'INSERT INTO {table}(ts,detail_json) VALUES(?,?)',(time.time(),encode(x)))
        else:
            db.execute('INSERT INTO c_events(ts,kind,detail_json) VALUES(?,?,?)',(time.time(),kind,encode(x)))
        self.written += 1

    def _writer(self):
        db = sqlite3.connect(self.path, timeout=1)
        db.execute('PRAGMA busy_timeout=1000')
        last_guard, last_prune = 0.0, 0.0
        try:
            while not self.stop_event.is_set() or not self.queue.empty():
                self.writer_heartbeat = time.monotonic()
                if time.monotonic()-last_guard > 5:
                    self.check_capacity()
                    last_guard = time.monotonic()
                if self.failed:
                    self.stop_event.wait(.2)
                    if self.stop_event.is_set(): break
                    continue
                batch = []
                try: batch.append(self.queue.get(timeout=.25))
                except queue.Empty: continue
                for _ in range(99):
                    try: batch.append(self.queue.get_nowait())
                    except queue.Empty: break
                with db:
                    for kind,x in batch: self._write(db,kind,x)
                if time.monotonic()-last_prune > 600:
                    # Bounded cleanup in the C-only DB, never in the LIVE DB.
                    cutoff = time.time()-86400*self.cfg['retention_days']
                    with db:
                        for table in ('c_size_samples','c_events','c_metrics','c_rule_snapshots','c_fee_snapshots','c_book_pairs'):
                            db.execute(f'DELETE FROM {table} WHERE rowid IN (SELECT rowid FROM {table} WHERE ts<? LIMIT 1000)',(cutoff,))
                    last_prune = time.monotonic()
        except Exception as exc:
            self.failed=True; self.last_error=f'DB_WRITE_FAILED: {exc}'
            LOG.exception('C storage stopped')
        finally:
            db.close()

    def check_capacity(self):
        free = shutil.disk_usage(self.directory).free/1024**2
        used = sum(p.stat().st_size for p in self.directory.glob('c_shadow.sqlite*') if p.is_file())/1024**2
        if free < self.cfg['min_disk_free_mb'] or used > self.cfg['max_db_mb']:
            self.failed = True
            self.last_error = f'C_STORAGE_LIMIT: free={free:.0f}MB C_db={used:.0f}MB; collection paused'
        return {'free_mb':round(free,1),'c_db_mb':round(used,1)}

    def recent(self, kind='episodes', limit=50):
        queries = {
            'episodes': 'SELECT detail_json FROM c_episodes ORDER BY start_ts DESC LIMIT ?',
            'trials': 'SELECT detail_json FROM c_size_trials ORDER BY start_ts DESC LIMIT ?',
            'events': 'SELECT kind,ts,detail_json FROM c_events ORDER BY id DESC LIMIT ?',
        }
        with self.ro() as db:
            rows = db.execute(queries[kind],(limit,)).fetchall()
        return [{'kind':r[0],'ts':r[1],'detail':json.loads(r[2])} for r in rows] if kind=='events' else [json.loads(r[0]) for r in rows]

    def close(self):
        self.stop_event.set()
        self.thread.join(4)
