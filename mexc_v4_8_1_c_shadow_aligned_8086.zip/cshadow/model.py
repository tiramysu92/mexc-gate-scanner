from __future__ import annotations
from dataclasses import dataclass, asdict
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_UP
import math
from typing import Any

D = Decimal
BPS = D(10000)
ZERO = D(0)

def dec(value: Any) -> Decimal:
    try:
        x = D(str(value))
    except (InvalidOperation, ValueError, TypeError) as e:
        raise ValueError('Invalid decimal') from e
    if not x.is_finite():
        raise ValueError('Non-finite decimal')
    return x

def floor_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError('Missing or invalid step')
    return (value / step).to_integral_value(rounding=ROUND_DOWN) * step

def ceil_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError('Missing or invalid tick')
    return (value / step).to_integral_value(rounding=ROUND_UP) * step

@dataclass(frozen=True)
class Rule:
    symbol: str
    base: str
    quote: str
    step: Decimal
    tick: Decimal
    min_qty: Decimal
    min_notional: Decimal
    max_notional: Decimal | None
    base_fee_tick: Decimal
    quote_fee_tick: Decimal
    side_type: str
    spot: bool
    online: bool
    percent_filters: tuple
    fetched_ts: float
    quantity_source: str

    @classmethod
    def from_exchange(cls, x: dict, now: float) -> 'Rule':
        filters = {f.get('filterType'): f for f in x.get('filters', [])}
        # MEXC fallback: baseSizePrecision is treated conservatively as the size increment
        # (legacy executor convention); a dedicated LOT_SIZE step overrides it.
        lot = filters.get('LOT_SIZE', {})
        step = dec(lot.get('stepSize', x.get('baseSizePrecision')))
        min_qty = dec(lot.get('minQty', x.get('baseSizePrecision')))
        pf = filters.get('PRICE_FILTER', {})
        precision = int(x['quotePrecision'])
        tick = dec(pf['tickSize']) if 'tickSize' in pf else D(1).scaleb(-precision)
        notional = filters.get('NOTIONAL', filters.get('MIN_NOTIONAL', {}))
        min_n = dec(notional.get('minNotional', x.get('quoteAmountPrecision')))
        maxima = [dec(v) for v in (x.get('maxQuoteAmount'), notional.get('maxNotional')) if v is not None and dec(v) > 0]
        max_n = min(maxima) if maxima else None
        if min(step, tick, min_qty, min_n) <= 0:
            raise ValueError('Symbol rules missing positive tick/step/minimum')
        base_fp = int(x.get('baseCommissionPrecision', x.get('baseAssetPrecision', 8)))
        quote_fp = int(x.get('quoteCommissionPrecision', precision))
        if not 0 <= base_fp <= 18 or not 0 <= quote_fp <= 18:
            raise ValueError('Invalid commission precision')
        return cls(str(x['symbol']), str(x['baseAsset']), str(x['quoteAsset']), step, tick,
                   min_qty, min_n, max_n, D(1).scaleb(-base_fp), D(1).scaleb(-quote_fp),
                   str(x.get('tradeSideType', 'UNKNOWN')), x.get('isSpotTradingAllowed') is True,
                   str(x.get('status')) == '1', tuple(x.get('filters', [])), now,
                   'LOT_SIZE' if lot else 'baseSizePrecision_legacy_convention')

    def permits(self, side: str) -> bool:
        return self.spot and self.online and self.side_type in ('1', '2' if side == 'BUY' else '3')

@dataclass(frozen=True)
class Fee:
    symbol: str
    taker_bps: Decimal
    fetched_ts: float
    source: str

    def fresh(self, now: float, max_age: float) -> bool:
        return (ZERO <= self.taker_bps < BPS and -2 <= now - self.fetched_ts <= max_age
                and self.source in ('MEXC_ACCOUNT_API', 'DIRECT_ACCOUNT_API'))

@dataclass(frozen=True)
class Book:
    symbol: str
    bids: tuple[tuple[Decimal, Decimal], ...]
    asks: tuple[tuple[Decimal, Decimal], ...]
    version: int
    exchange_ms: int
    recv_ts: float
    recv_mono: float
    generation: int = 0
    observation_id: int = 0
    observation_kind: str = 'VERSION_CHANGE'
    content_mono: float | None = None
    last_order_create_ms: int = 0

    @classmethod
    def build(cls, symbol, bids, asks, version, exchange_ms, recv_ts, recv_mono, generation=0, observation_id=0, observation_kind="VERSION_CHANGE", content_mono=None, last_order_create_ms=0):
        def levels(data, reverse):
            parsed=tuple((dec(p),dec(q)) for p,q in data)
            if any(q<0 for _,q in parsed):raise ValueError('Negative displayed quantity')
            out=tuple(sorted(((p,q) for p,q in parsed if q>0),reverse=reverse))
            if len(out) > 20 or any(p <= 0 or q <= 0 for p, q in out):
                raise ValueError('Invalid partial depth')
            if len({p for p, _ in out}) != len(out):
                raise ValueError('Duplicate price level')
            return out
        bb, aa = levels(bids, True), levels(asks, False)
        if bb and aa and bb[0][0] >= aa[0][0]:
            raise ValueError('Crossed order book')
        return cls(symbol, bb, aa, int(version), int(exchange_ms), recv_ts, recv_mono, generation,
                   observation_id, observation_kind, recv_mono if content_mono is None else content_mono,
                   last_order_create_ms)

    def wire(self):
        return {'symbol': self.symbol, 'version': self.version, 'exchange_ms': self.exchange_ms,
                'recv_ts': self.recv_ts, 'generation': self.generation,
                'observation_id': self.observation_id, 'observation_kind': self.observation_kind,
                'last_order_create_ms': self.last_order_create_ms,
                'bids': [[str(p), str(q)] for p, q in self.bids],
                'asks': [[str(p), str(q)] for p, q in self.asks]}

@dataclass(frozen=True)
class Clock:
    offset_ms: float
    uncertainty_ms: float
    sampled_ts: float

    def valid(self, now: float, cfg: dict) -> bool:
        return (math.isfinite(self.offset_ms) and math.isfinite(self.uncertainty_ms) and
                0 <= now - self.sampled_ts <= cfg['clock_max_age_s'] and
                0 <= self.uncertainty_ms <= cfg['max_clock_uncertainty_ms'])

def timing(book: Book | None, now: float, mono: float, clock: Clock | None, cfg: dict) -> list[str]:
    if book is None:
        return ['NO_DEPTH']
    reasons = []
    if not book.bids or not book.asks:
        reasons.append('EMPTY_BOOK')
    age = (mono - book.recv_mono) * 1000
    if not -1 <= age <= cfg['max_local_age_ms']:
        reasons.append('STALE_LOCAL')
    if not clock or not clock.valid(now, cfg):
        reasons.append('CLOCK_UNCERTAIN')
    elif book.exchange_ms <= 0:
        reasons.append('NO_EXCHANGE_TIME')
    else:
        age_ex = now * 1000 + clock.offset_ms - book.exchange_ms
        if age_ex < -clock.uncertainty_ms - 2 or age_ex + clock.uncertainty_ms > cfg['max_exchange_age_ms']:
            reasons.append('STALE_EXCHANGE')
    return reasons

def walk(levels, qty: Decimal, fraction: Decimal, limit=None, side='SELL'):
    """Return actual notional, filled base, terminal price. Never extrapolate missing depth."""
    rem, value, terminal = qty, ZERO, None
    for p, q in levels:
        if limit is not None and ((side == 'BUY' and p > limit) or (side == 'SELL' and p < limit)):
            break
        take = min(rem, q * fraction)
        if take > 0:
            rem -= take
            value += take * p
            terminal = p
        if rem <= 0:
            break
    return value, qty - rem, terminal

def buy_base(levels, budget: Decimal, fraction: Decimal):
    rem, qty = budget, ZERO
    for p, q in levels:
        cost = min(rem, p * q * fraction)
        qty += cost / p
        rem -= cost
        if rem <= 0:
            break
    return qty, rem

def price_filter_reasons(rule: Rule, side: str, price: Decimal, ref: dict | None, now: float):
    reasons = []
    for f in rule.percent_filters:
        typ = f.get('filterType')
        if typ == 'PRICE_FILTER':
            lower,upper=dec(f.get('minPrice',0)),dec(f.get('maxPrice',0))
            if (lower>0 and price<lower) or (upper>0 and price>upper): reasons.append('PRICE_FILTER_RANGE')
            continue
        if typ in ('LOT_SIZE','MIN_NOTIONAL','NOTIONAL'):
            continue
        if typ == 'PERCENT_PRICE_BY_SIDE':
            if not ref or now - ref.get('ts', 0) > 10:
                reasons.append('PRICE_FILTER_REFERENCE_UNKNOWN')
                continue
            last = dec(ref['price'])
            if side == 'BUY' and price > last * (1 + dec(f['bidMultiplierUp'])):
                reasons.append('PRICE_FILTER_BUY')
            if side == 'SELL' and price < last * (1 - dec(f['askMultiplierDown'])):
                reasons.append('PRICE_FILTER_SELL')
        else:
            reasons.append('UNSUPPORTED_EXCHANGE_FILTER')
    return reasons


def pair_timing(b1, b2, now, mono, clock, cfg):
    reasons = ['L1_' + x for x in timing(b1, now, mono, clock, cfg)]
    reasons += ['L2_' + x for x in timing(b2, now, mono, clock, cfg)]
    if b1 and b2:
        if b1.generation != b2.generation:
            reasons.append('GENERATION_MISMATCH')
        if abs(b1.recv_mono-b2.recv_mono)*1000 > cfg['max_local_skew_ms']:
            reasons.append('LOCAL_SKEW')
        if abs(b1.exchange_ms-b2.exchange_ms) > cfg['max_exchange_skew_ms']:
            reasons.append('EXCHANGE_SKEW')
    return reasons


def route_classification(r1, r2, b1, b2, volume_min, cfg):
    """Environment is classified at a REFERENCE cap, not the selected smaller order.

    Reducing size must not erase the reason why a route was being researched as C.
    C_DEPTH_REFERENCE is NOT a claim that a high-volume token is intrinsically illiquid.
    """
    why=[]; band=dec(cfg['reserve_price_band_bps'])/BPS
    ref=dec(cfg.get('classification_size_su',25))
    if volume_min is not None and volume_min < cfg['ab_min_volume_su']:
        why.append('C_VOLUME')
    ref_rx1=ref_rx2=None
    if b1 and b2 and b1.asks and b2.bids:
        near1=sum((p*q for p,q in b1.asks if p<=b1.asks[0][0]*(1+band)),ZERO)
        near2=sum((q for p,q in b2.bids if p>=b2.bids[0][0]*(1-band)),ZERO)
        reference_qty=ref/b1.asks[0][0]
        ref_rx1=float(near1/ref);ref_rx2=float(near2/reference_qty)
        if ref_rx1 < cfg['ab_l1_reserve_x'] or ref_rx2 < cfg['ab_l2_reserve_x']:
            why.append('C_DEPTH_REFERENCE')
    return {'is_c':bool(why), 'c_reasons':why, 'classification_cap_su':float(ref),
            'class_ref_l1_reserve_x':ref_rx1,'class_ref_l2_reserve_x':ref_rx2}


def base_fee_for(qty, rule, fee):
    return ceil_step(qty*fee.taker_bps/BPS, rule.base_fee_tick) if fee.taker_bps else ZERO


def align_buy_to_sell_target(target, r1, fee1):
    """Least gross L1 step found by monotone fixed point that funds target after fee.

    Start at the continuous fee solution, then include fee quantum. Bounded loop;
    no zero-fee assumption and no oversell. A coarse L1 step can leave residual dust.
    """
    if target<=0 or fee1.taker_bps>=BPS:
        return None
    qty=ceil_step(target/(1-fee1.taker_bps/BPS),r1.step)
    for _ in range(32):
        fee=base_fee_for(qty,r1,fee1)
        if qty-fee>=target:
            return qty,fee
        new=ceil_step(target+fee,r1.step)
        if new<=qty: return None
        qty=new
    return None


def _quantity_max(rule):
    for f in rule.percent_filters:
        if f.get('filterType')=='LOT_SIZE':
            mx=dec(f.get('maxQty',0))
            if mx>0:return mx
    return None


def _plan(target, budget, r1, r2, b1, b2, f1, f2, cfg, refs, now):
    aligned=align_buy_to_sell_target(target,r1,f1)
    if aligned is None: return {'valid':False,'reasons':['QUANTITY_ALIGNMENT_FAILED']}
    q1,fee_base=aligned
    q2=floor_step(q1-fee_base,r2.step)
    if q2<=0:return {'valid':False,'reasons':['L2_QUANTITY_ZERO']}
    part=dec(cfg['participation_fraction'])
    cost1,filled1,t1=walk(b1.asks,q1,part,side='BUY')
    if t1 is None or filled1<q1:return {'valid':False,'reasons':['L1_INSUFFICIENT_TOP20']}
    px1=ceil_step(t1*(1+dec(cfg['l1_cushion_bps'])/BPS),r1.tick)
    spend=q1*px1
    if spend>budget: return {'valid':False,'reasons':['BUDGET_CAP']}
    if spend<budget*dec(cfg.get('min_budget_use_fraction',.1)):
        return {'valid':False,'reasons':['BELOW_MIN_CAP_USAGE']}
    if q1<r1.min_qty or spend<r1.min_notional or (r1.max_notional and spend>r1.max_notional):
        return {'valid':False,'reasons':['L1_MINIMUM_OR_MAXIMUM']}
    maxq1,maxq2=_quantity_max(r1),_quantity_max(r2)
    if (maxq1 and q1>maxq1) or (maxq2 and q2>maxq2):
        return {'valid':False,'reasons':['LOT_MAX_QUANTITY']}
    value2,filled2,t2=walk(b2.bids,q2,part)
    if t2 is None or filled2<q2:return {'valid':False,'reasons':['L2_INSUFFICIENT_TOP20']}
    px2=floor_step(t2*(1-dec(cfg['l2_cushion_bps'])/BPS),r2.tick)
    gross=q2*px2
    if px2<=0 or q2<r2.min_qty or gross<r2.min_notional or (r2.max_notional and gross>r2.max_notional):
        return {'valid':False,'reasons':['L2_MINIMUM_OR_MAXIMUM']}
    fee_quote=ceil_step(gross*f2.taker_bps/BPS,r2.quote_fee_tick) if f2.taker_bps else ZERO
    proceeds=gross-fee_quote
    dust=q1-fee_base-q2
    # Nominal SU convention; dust is a MARK, not recovered stable cash.
    dust_bid=min(b1.bids[0][0],b2.bids[0][0])
    dust_mark=dust*dust_bid*(1-dec(cfg.get('dust_haircut_bps',500))/BPS)
    dust_mark*=1-max(f1.taker_bps,f2.taker_bps)/BPS
    netcash=(proceeds/spend-1)*BPS
    netmark=((proceeds+dust_mark)/spend-1)*BPS
    protected=netmark-dec(cfg['thin_buffer_bps'])
    band=dec(cfg['reserve_price_band_bps'])/BPS
    near1=sum((p*q for p,q in b1.asks if p<=b1.asks[0][0]*(1+band)),ZERO)
    near2=sum((q for p,q in b2.bids if p>=b2.bids[0][0]*(1-band)),ZERO)
    rx1,rx2=float(near1/spend),float(near2/q2)
    reasons=[]
    if rx1<cfg['c_min_l1_reserve_x']: reasons.append('C_L1_RESERVE')
    if rx2<cfg['c_min_l2_reserve_x']: reasons.append('C_L2_RESERVE')
    if dust_mark/spend>dec(cfg['max_dust_fraction']): reasons.append('DUST_TOO_LARGE')
    reasons+=price_filter_reasons(r1,'BUY',px1,refs.get(r1.symbol),now)
    reasons+=price_filter_reasons(r2,'SELL',px2,refs.get(r2.symbol),now)
    # Actual depth outcome under hypothetical immediate fills, not the limit-price bound.
    depthfee=ceil_step(value2*f2.taker_bps/BPS,r2.quote_fee_tick) if f2.taker_bps else ZERO
    return {'valid':not reasons,'reasons':reasons,
            'q1':str(q1),'q2':str(q2),'sell_target':str(target),
            'l1_limit':str(px1),'l2_limit':str(px2),'spend_su':float(spend),
            'unspent_su':float(budget-spend),'utilization_pct':float(spend/budget*100),
            'proceeds_su':float(proceeds),'cash_pnl_su':float(proceeds-spend),
            'dust_qty':str(dust),'dust_mark_su':float(dust_mark),'dust_mark_bps':float(dust_mark/spend*BPS),
            'net_cash_bps':float(netcash),'net_mark_bps':float(netmark),
            'protected_cash_bps':float(netcash-dec(cfg['thin_buffer_bps'])), # legacy alias, secondary only
            'protected_edge_bps':float(protected),'protected_pnl_su':float(protected/BPS*spend),
            'l1_reserve_x':rx1,'l2_reserve_x':rx2,'fee_base_units':str(fee_base),'fee_quote_units':str(fee_quote),
            'effective_fee1_bps':float(fee_base/q1*BPS),'effective_fee2_bps':float(fee_quote/gross*BPS),
            'fee1_rounding_extra_base':str(fee_base-q1*f1.taker_bps/BPS),
            'fee2_rounding_extra_quote':str(fee_quote-gross*f2.taker_bps/BPS),
            'bound_cost_su':float(spend),'observed_depth_cost_su':float(cost1),
            'observed_depth_proceeds_gross_su':float(value2),
            'l1_price_bound_cost_su':float(spend-cost1),'l2_price_bound_cost_su':float(value2-gross),
            'thin_buffer_su':float(spend*dec(cfg['thin_buffer_bps'])/BPS),
            'depth_cash_bps':float(((value2-depthfee)/cost1-1)*BPS),
            'cash_positive':netcash>=dec(cfg.get('signal_cash_floor_bps',0))}


def _targets(budget,r1,r2,b1,b2,f1,cfg):
    part=dec(cfg['participation_fraction'])
    qmax,_=buy_base(b1.asks,budget,part)
    qmax=floor_step(qmax,r1.step)
    for _ in range(8):
        _,filled,t=walk(b1.asks,qmax,part,side='BUY')
        if t is None or filled<qmax or qmax<=0:return []
        limit=ceil_step(t*(1+dec(cfg['l1_cushion_bps'])/BPS),r1.tick)
        capped=floor_step(min(qmax,budget/limit),r1.step)
        if capped==qmax:break
        qmax=capped
    maxnet=max(ZERO,qmax-base_fee_for(qmax,r1,f1))
    maxsell=floor_step(min(maxnet,sum((q*part for _,q in b2.bids),ZERO)),r2.step)
    if maxsell<=0:return []
    possible=set()
    def add(v):
        q=floor_step(min(v,maxsell),r2.step)
        if q>0:possible.add(q)
    # Candidate budgets are contemporaneous choices, not retroactive horizon resizing.
    for frac in ('1','.95','.9','.8','.75','.6','.5','.4','.25'):
        add(maxsell*dec(frac))
    add(maxsell-r2.step); add(maxsell-2*r2.step)
    cumulative=ZERO
    for _,q in b2.bids:
        cumulative+=q*part;add(cumulative)
    cumulative=ZERO
    for _,q in b1.asks:
        cumulative+=q*part
        add(max(ZERO,cumulative-base_fee_for(cumulative,r1,f1)))
    band=dec(cfg['reserve_price_band_bps'])/BPS
    near1=sum((p*q for p,q in b1.asks if p<=b1.asks[0][0]*(1+band)),ZERO)
    near2=sum((q for p,q in b2.bids if p>=b2.bids[0][0]*(1-band)),ZERO)
    add(near2/dec(cfg['c_min_l2_reserve_x']))
    add(near1/dec(cfg['c_min_l1_reserve_x'])/b1.asks[0][0]*(1-f1.taker_bps/BPS))
    # Smallest economically permitted exit (can be larger than cap, then it won't fit).
    add(max(r2.min_qty,ceil_step(r2.min_notional/b2.bids[0][0],r2.step)))
    ranked=sorted(possible,reverse=True)
    cap=int(cfg.get('max_size_candidates',24))
    if len(ranked)>cap:
        # Preserve both high use and smaller boundaries; deterministic bounded search.
        idx={round(i*(len(ranked)-1)/(cap-1)) for i in range(cap)}
        ranked=[ranked[i] for i in sorted(idx)]
    return ranked


def evaluate(r1: Rule,r2: Rule,b1: Book | None,b2: Book | None,
             fee1: Fee | None,fee2: Fee | None,size,volume_min,now,mono,clock,cfg,refs=None):
    refs=refs or {};route=f'{r1.quote}>{r1.base}>{r2.quote}'
    out={'route':route,'token':r1.base,'size':float(size),'budget_cap_su':float(size),'ts':now,
         'symbol1':r1.symbol,'symbol2':r2.symbol,'stable_a':r1.quote,'stable_b':r2.quote,
         'model':'CAP_ALIGNED_L2_LIMIT_BOUND_L1_BASE_FEE_L2_QUOTE_FEE',
         'model_revision':cfg.get('model_revision','4.8.1-aligned-exit-v1'),
         'reasons':[],'testable':False,'book_valid':False,'live_authorized':False,
         'raw_bps':None,'protected_edge_bps':None,'protected_cash_bps':None,'net_mark_bps':None,
         'fee1_bps':None,'fee2_bps':None,'volume_min_su_24h':volume_min,
         'rule_steps':{'l1':str(r1.step),'l2':str(r2.step)},
         'rule_ticks':{'l1':str(r1.tick),'l2':str(r2.tick)},
         'rule_quantity_sources':{'l1':r1.quantity_source,'l2':r2.quantity_source},
         'minimum_notionals':{'l1':str(r1.min_notional),'l2':str(r2.min_notional)},
         'clock_at_signal':asdict(clock) if clock else None,'profile':'STRICT'}
    out.update(route_classification(r1,r2,b1,b2,volume_min,cfg))
    reasons=out['reasons']
    if r1.base!=r2.base or {r1.quote,r2.quote}!={'USDC','USDT'}:reasons.append('UNSUPPORTED_ROUTE')
    if not r1.permits('BUY') or not r2.permits('SELL'):reasons.append('SYMBOL_TRADE_DISABLED')
    if any(not -2<=now-r.fetched_ts<=cfg['rules_max_age_s'] for r in (r1,r2)):reasons.append('STALE_RULES')
    if not fee1 or not fee2 or not fee1.fresh(now,cfg['fee_max_age_s']) or not fee2.fresh(now,cfg['fee_max_age_s']):
        reasons.append('ACCOUNT_FEES_UNKNOWN_OR_STALE')
    else:
        out.update(fee1_bps=float(fee1.taker_bps),fee2_bps=float(fee2.taker_bps),fee1_ts=fee1.fetched_ts,
                   fee2_ts=fee2.fetched_ts,fee1_source=fee1.source,fee2_source=fee2.source)
    reasons+=pair_timing(b1,b2,now,mono,clock,cfg)
    if b1 and b2:
        if b1.asks and b2.bids:out['raw_bps']=float((b2.bids[0][0]/b1.asks[0][0]-1)*BPS)
        out.update(local_age1_ms=max(0,(mono-b1.recv_mono)*1000),local_age2_ms=max(0,(mono-b2.recv_mono)*1000),
                   local_skew_ms=abs(b1.recv_mono-b2.recv_mono)*1000,
                   exchange_skew_ms=abs(b1.exchange_ms-b2.exchange_ms),
                   book_generation=b1.generation,
                   observations=[b1.observation_id,b2.observation_id],
                   observation_kinds=[b1.observation_kind,b2.observation_kind],
                   versions=[b1.version,b2.version])
    if (b1 and b1.symbol!=r1.symbol) or (b2 and b2.symbol!=r2.symbol):reasons.append('BOOK_SYMBOL_MISMATCH')
    if (fee1 and fee1.symbol!=r1.symbol) or (fee2 and fee2.symbol!=r2.symbol):reasons.append('FEE_SYMBOL_MISMATCH')
    if volume_min is None:reasons.append('VOLUME_CLASS_UNKNOWN')
    if reasons:return out
    assert b1 and b2 and fee1 and fee2
    if out['raw_bps'] is None or abs(out['raw_bps'])>cfg['max_raw_bps']:
        reasons.append('OUTLIER_CROSS');return out
    for b in (b1,b2):
        if float((b.asks[0][0]/b.bids[0][0]-1)*BPS)>cfg['max_spread_bps']:reasons.append('SPREAD_TOO_WIDE')
    if reasons:return out
    budget=dec(size)
    if budget<=0:reasons.append('BUDGET_INVALID');return out
    targets=_targets(budget,r1,r2,b1,b2,fee1,cfg)
    plans=[_plan(t,budget,r1,r2,b1,b2,fee1,fee2,cfg,refs,now) for t in targets]
    valued=[p for p in plans if p.get('protected_edge_bps') is not None]
    feasible=[p for p in valued if p['valid']]
    if not valued:
        reasons.extend(sorted({x for p in plans for x in p['reasons']}) or ['NO_ALIGNED_SIZE_UNDER_CAP'])
        return out
    # Max protected gain at signal; smaller negative allocations are not trades.
    pool=feasible or valued
    positives=[p for p in pool if p['protected_pnl_su']>0 and p['cash_positive']]
    chosen=max(positives,key=lambda p:(p['protected_pnl_su'],p['spend_su'])) if positives else max(pool,key=lambda p:p['spend_su'])
    out.update(chosen);out['reasons']=list(chosen['reasons']);out.pop('valid',None)
    out['book_valid']=bool(feasible)
    if not out['is_c']:out['reasons'].append('AB_NOT_C')
    out['testable']=out['book_valid'] and out['is_c']
    out['signal_eligible']=bool(out['testable'] and chosen['cash_positive'] and chosen['protected_edge_bps']>=cfg['episode_entry_bps'])
    if out['testable'] and not chosen['cash_positive']:out['signal_note']='CASH_NEGATIVE_DUST_NOT_SPENDABLE'
    out.update(thin_buffer_bps=cfg['thin_buffer_bps'],l1_cushion_bps=cfg['l1_cushion_bps'],l2_cushion_bps=cfg['l2_cushion_bps'],
               dust_haircut_bps=cfg.get('dust_haircut_bps',500),sizing_candidates_tested=len(plans),sizing_candidates_valid=len(feasible),
               sizing_method='BOUNDED_SIGNAL_TIME_PROTECTED_SU_SEARCH',entry_books=[b1.wire(),b2.wire()])
    out['size_alternatives']=[{k:p.get(k) for k in ('q1','q2','spend_su','protected_edge_bps','protected_pnl_su','dust_mark_su','reasons')}
                              for p in valued]
    # Sensitivity is a diagnostic surface, never extra independent episode proof.
    out['buffer_sensitivity_bps']={str(v):out['net_mark_bps']-v for v in (0,1,2,3,5)}
    return out


def horizon_exit(plan,book,rule,fee,cfg):
    """Freeze both hypothetical L1 outlay and L2 quantity for the entire trial."""
    qty,part,spend=dec(plan['q2']),dec(cfg['participation_fraction']),dec(plan['spend_su'])
    _,filled,terminal=walk(book.bids,qty,part)
    out={'coverage':float(filled/qty) if qty>0 else 0,'liquidity_ok':False,
         'protected_edge_bps':None,'protected_cash_bps':None,'l2_slippage_bps':None,
         'limit_still_coverable':False,'dust_qty':plan['dust_qty']}
    if terminal is None or filled<qty or qty<=0:return out
    limit=floor_step(terminal*(1-dec(cfg['l2_cushion_bps'])/BPS),rule.tick)
    gross=qty*limit
    feeq=ceil_step(gross*fee.taker_bps/BPS,rule.quote_fee_tick) if fee.taker_bps else ZERO
    proceeds=gross-feeq
    # Never mark dust higher than its entry conservative value; no speculative credit.
    dustmark=min(dec(plan.get('dust_mark_su',0)),dec(plan['dust_qty'])*book.bids[0][0]*(1-dec(cfg.get('dust_haircut_bps',500))/BPS))
    netcash=(proceeds/spend-1)*BPS
    protected=((proceeds+dustmark)/spend-1)*BPS-dec(cfg['thin_buffer_bps'])
    _,limit_fill,_=walk(book.bids,qty,part,limit=dec(plan['l2_limit']))
    out.update(liquidity_ok=bool(qty>=rule.min_qty and gross>=rule.min_notional and (not rule.max_notional or gross<=rule.max_notional)),
               protected_edge_bps=float(protected),protected_cash_bps=float(netcash-dec(cfg['thin_buffer_bps'])),
               net_cash_bps=float(netcash),net_mark_bps=float((proceeds+dustmark-spend)/spend*BPS),
               cash_positive=netcash>=dec(cfg.get('signal_cash_floor_bps',0)),
               l2_slippage_bps=float((dec(plan['l2_limit'])-limit)/dec(plan['l2_limit'])*BPS),
               limit_still_coverable=limit_fill>=qty,limit_price=str(limit),
               cash_pnl_su=float(proceeds-spend),exit_book=book.wire())
    return out
