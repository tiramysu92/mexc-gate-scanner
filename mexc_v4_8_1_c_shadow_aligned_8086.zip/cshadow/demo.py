"""Synthetic UI/regression demonstration. NEVER used by the live public collector."""
import time
from . import VERSION
from .config import DEFAULTS
from .model import Rule,Book,Fee,Clock,dec,evaluate

class DemoService:
    def __init__(self):self.sequence=0
    def snapshot(self):
        self.sequence+=1;now=time.time();mono=time.monotonic();rows=[]
        for token,bid2 in [('DEMO_AMBRE','1.0026'),('DEMO_JADE','1.0018'),('DEMO_CUIVRE','1.0004')]:
            rr=[]
            for quote in ('USDC','USDT'):
                rr.append(Rule.from_exchange({'symbol':token+quote,'baseAsset':token,'quoteAsset':quote,
                    'quotePrecision':5,'baseAssetPrecision':6,'baseSizePrecision':'.001','quoteAmountPrecision':'1',
                    'baseCommissionPrecision':6,'quoteCommissionPrecision':6,'status':'1','isSpotTradingAllowed':True,
                    'tradeSideType':'1','filters':[]},now))
            r1,r2=rr
            b1=Book.build(r1.symbol,[('.9999','1000')],[('1','1000')],1,int(now*1000),now-.01,mono-.01)
            b2=Book.build(r2.symbol,[(bid2,'1000')],[(str(dec(bid2)+dec('.0001')),'1000')],1,int(now*1000),now-.005,mono-.005)
            for cap in DEFAULTS['sizes_su']:
                p=evaluate(r1,r2,b1,b2,Fee(r1.symbol,dec(0),now,'MEXC_ACCOUNT_API'),Fee(r2.symbol,dec(5),now,'MEXC_ACCOUNT_API'),cap,25000,now,mono,Clock(0,2,now),DEFAULTS)
                p.pop('entry_books',None);p.update(age_s=.01,stale=False,stage={'label':'C_DISCOVERY','clean_episodes':1})
                rows.append(p)
        rows.sort(key=lambda p:p.get('protected_edge_bps') or -1e9,reverse=True)
        selected=[next(p for p in rows if p['token']==token and p['size']==10) for token in ('DEMO_AMBRE','DEMO_JADE','DEMO_CUIVRE')]
        h={str(x):{'total':60,'observed':50,'liquidity_ok':48,'positive':37,'negative_or_unfillable':13,'censored':10,
                  'unchanged_reobservations':20,'late_diagnostic':7,'p95_actual_ms':x+18.,'p50_remaining_bps':7.2,
                  'signal_only':{'observed':12,'total':14}} for x in DEFAULTS['horizons_ms']}
        return {'demo':True,'version':VERSION,'mode':'SHADOW_ONLY','orders_possible':False,'state':'SHADOW_COLLECTING',
            'run_id':'DEMO_DONNEES_FICTIVES','sequence':self.sequence,'now':now,'served_ts':now,'heartbeat_age_s':.01,
            'realized_c_pnl_su':0,'model_revision':DEFAULTS['model_revision'],
            'top10':selected,'latest_sizes':rows,'diagnostics':[],'relaxed_diagnostics':[],'best_since_start':[],
            'coverage':{'hot_tokens':['DEMO_AMBRE','DEMO_JADE','DEMO_CUIVRE'],'hot_limit':8,'exploration_slots':2,
                        'depth_levels':20,'tokens_with_two_pairs':180},
            'feed':{'connected':True,'depth_frames':18240,'channels':17,'desired':17,'reobserved_unchanged':6130,
                    'old_version':2,'duplicate_same_timestamp_or_disabled':125,'same_version_content_conflict':0,'last_frame_age_s':.05},
            'storage':{'healthy':True,'queue':0,'dropped':0,'written':4680},
            'references':{'fee_fresh':642,'fee_total':649,'rules':360,'clock_ok':True,'clock':{'offset_ms':17,'uncertainty_ms':8.4},
                          'clock_selection':{'window_samples':6,'latest_rtt_ms':16.8}},
            'evidence':{'episodes_opened':6,'active_episodes':1,'episodes_closed_observed':4,'episodes_censored':1,
                        'trials_completed':60,'learning_trials_completed':46,'learning_trials_started':52,
                        'signal_trials_completed':14,'pending_trials':6,'horizons':h,'stages':[]},
            'timing':{k:{'p50':a,'p95':b,'n':1500} for k,a,b in [('local_skew_ms',12,48),('exchange_skew_ms',18,64),
                      ('pair_wait_ms',3.1,24.8),('model_batch_ms',4.3,14.6)]},
            'policy':dict(DEFAULTS),'diagnostic_timing_counts':{'evaluated':150,'c_math_visible':40,'positive_but_not_proven':3},
            'decisions':{'size_evaluations':8420,'pair_evaluations':1403,'C_BOOK_TESTABLE':1430,'LOCAL_SKEW':125,
                         'L2_STALE_LOCAL':77,'C_L2_RESERVE':62,'ACCOUNT_FEES_UNKNOWN_OR_STALE':20},
            'recent_episodes':[{'route':'USDC>DEMO_AMBRE>USDT','start_ts':now-250,'end_ts':now-160,'status':'CLOSED_OBSERVED','clean_sizes':[5,10,15]}],
            'live':{'state':'READY','settled':True,'balances':{'USDC':{'free':150.0},'USDT':{'free':150.0}},
                    'inventory':{'zone':'CENTER','usdc_share':.5},'reported_delta_su':None,'fx':{'mid':1.0002},
                    'age_s':2,'baseline':{'session_id':'DEMO_ONLY'}},'discovery':[]}
    def close(self):pass
