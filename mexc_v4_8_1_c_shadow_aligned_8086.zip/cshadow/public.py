from __future__ import annotations
import json
import logging
import re
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, deque
from dataclasses import asdict
from pathlib import Path
from .model import Rule, Fee, Clock, dec

LOG = logging.getLogger(__name__)
ALLOWED = {'/api/v3/exchangeInfo','/api/v3/ticker/24hr','/api/v3/ticker/bookTicker','/api/v3/time','/api/v3/ticker/price'}

class GetOnlyClient:
    def __init__(self):
        self.backoff_until = 0.0
        self.errors = Counter()
    def get(self, path, params=None, timeout=4):
        if path not in ALLOWED:
            raise ValueError('Non-public endpoint is not implemented in C-SHADOW')
        if time.monotonic() < self.backoff_until:
            raise RuntimeError('RATE_LIMIT_BACKOFF')
        url = 'https://api.mexc.com'+path
        if params: url += '?'+urllib.parse.urlencode(params)
        req = urllib.request.Request(url,headers={'User-Agent':'mexc-c-shadow/4.8.1'},method='GET')
        try:
            with urllib.request.urlopen(req,timeout=timeout) as r:
                raw = r.read(8_000_001)
                if len(raw)>8_000_000: raise ValueError('Oversize REST payload')
                return json.loads(raw)
        except urllib.error.HTTPError as exc:
            self.errors[str(exc.code)] += 1
            if exc.code in (403,418,429):
                try: delay=float(exc.headers.get('Retry-After',120))
                except (ValueError,TypeError): delay=120
                self.backoff_until=time.monotonic()+max(120,delay)
            raise

def local_live_status(url):
    p = urllib.parse.urlparse(url)
    if p.hostname != '127.0.0.1' or p.port != 8081 or p.path != '/api/live/status':
        raise ValueError('Only the local LIVE status GET endpoint is permitted')
    with urllib.request.urlopen(urllib.request.Request(url,method='GET'),timeout=2) as r:
        return json.loads(r.read(2_000_000))

class ReferenceData:
    def __init__(self, cfg, store, stop):
        self.cfg,self.store,self.stop=cfg,store,stop
        self.lock=threading.RLock()
        self.client=GetOnlyClient()
        self.rules={}; self.fees={}; self.volumes={}; self.refs={}; self.bbo={}
        self.clock=None; self.live={}; self.live_ts=0.0
        self.last_error=None; self.errors=Counter(); self.heartbeat=0.0
        self.bbo_ts=0.0; self.rules_ts=0.0; self.fees_ts=0.0; self.volume_ts=0.0
        self.live_config={}; self.live_db_path=None
        self.thread=None
        self.clock_samples=deque(maxlen=20)
        self.clock_metrics={}
        self.clock_thread=None

    def read_live_fees(self):
        # Do not import LIVE code (imports could start threads/load credentials).
        # Read only the harmless fee table; never open or copy v240.env.
        runtime=Path(self.cfg['live_runtime'])
        cfg=json.loads((runtime/'config.json').read_text())
        path=Path(cfg['db_path'])
        if not path.is_absolute(): path=runtime/path
        path=path.resolve()
        if not path.is_file(): raise FileNotFoundError('LIVE DB absent; no empty DB created')
        conn=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=.5)
        try:
            conn.execute('PRAGMA query_only=ON')
            rows=conn.execute('SELECT symbol,taker_bps,fetched_ts,source FROM account_fees').fetchall()
        finally: conn.close()
        fees={}
        for sym,bps,ts,source in rows:
            try: fees[sym]=Fee(sym,dec(bps),float(ts),str(source))
            except (ValueError,TypeError): pass
        safe={k:cfg[k] for k in ('live_account_fee_max_age_s','liquidity_b_min_quote_volume_24h',
             'liquidity_l1_reserve_multiple','liquidity_l2_reserve_multiple') if k in cfg}
        with self.lock:
            self.fees=fees; self.fees_ts=time.time(); self.live_db_path=str(path); self.live_config=safe
        self.store.emit('fees',{'source':'READ_ONLY_LIVE_ACCOUNT_FEES','ts':self.fees_ts,
                              'rows':[asdict(x) for x in fees.values()]})

    def update_rules(self):
        now=time.time(); data=self.client.get('/api/v3/exchangeInfo'); rules={}; rejected=Counter()
        for x in data.get('symbols',[]):
            if x.get('quoteAsset') not in ('USDC','USDT'): continue
            base=str(x.get('baseAsset',''))
            if base in self.cfg['excluded_bases'] or re.search(r'[235][LS]$',base): continue
            try:
                r=Rule.from_exchange(x,now)
                if r.spot and r.online: rules[r.symbol]=r
            except (ValueError,KeyError,TypeError): rejected['INCOMPLETE_RULES']+=1
        with self.lock: self.rules=rules;self.rules_ts=now
        self.store.emit('rules',{'ts':now,'rows':data.get('symbols',[]),'rejected':dict(rejected)})

    def update_volumes(self):
        now=time.time(); data=self.client.get('/api/v3/ticker/24hr')
        if not isinstance(data,list): raise ValueError('Invalid bulk 24h response')
        vols={}; refs={}
        for x in data:
            try:
                vols[x['symbol']]=float(dec(x['quoteVolume']))
                refs[x['symbol']]={'price':str(dec(x['lastPrice'])),'ts':now}
            except (KeyError,ValueError,TypeError): continue
        with self.lock: self.volumes=vols;self.refs=refs;self.volume_ts=now

    def update_bbo(self):
        data=self.client.get('/api/v3/ticker/bookTicker');now=time.time()
        if not isinstance(data,list): raise ValueError('Invalid bulk BBO response')
        bb={}
        for x in data:
            try:
                bid,ask=dec(x['bidPrice']),dec(x['askPrice'])
                if bid>0 and ask>bid: bb[x['symbol']]=(bid,ask)
            except (KeyError,ValueError,TypeError): continue
        with self.lock: self.bbo=bb;self.bbo_ts=now

    def update_prices(self):
        data=self.client.get('/api/v3/ticker/price');now=time.time()
        if not isinstance(data,list):raise ValueError('Invalid price ticker response')
        refs={}
        for x in data:
            try:
                px=dec(x['price'])
                if px>0:refs[x['symbol']]={'price':str(px),'ts':now}
            except (KeyError,ValueError,TypeError):continue
        with self.lock:self.refs=refs

    def update_clock(self):
        a=time.time();m=time.monotonic();x=self.client.get('/api/v3/time');b=time.time()
        elapsed=time.monotonic()-m;rtt=elapsed*1000
        if abs((b-a)-elapsed)*1000>20:
            with self.lock:self.clock=None;self.clock_samples.clear()
            raise RuntimeError('LOCAL_WALL_CLOCK_CHANGED_DURING_SYNC')
        c=Clock(float(x['serverTime'])-(a+b)*500,rtt/2+1,b)
        with self.lock:
            # A very delayed time request must not replace a good recent estimate.
            # Intervals incompatible with the new sample trigger a reset, not an
            # arbitrary correction of the market timestamps.
            if self.clock_samples:
                prior=min(self.clock_samples,key=lambda t:t.uncertainty_ms)
                if abs(prior.offset_ms-c.offset_ms)>prior.uncertainty_ms+c.uncertainty_ms+10:
                    self.clock_samples.clear()
            self.clock_samples.append(c)
            recent=[q for q in self.clock_samples if b-q.sampled_ts<=self.cfg.get('clock_window_s',120)]
            drift=self.cfg.get('clock_drift_allowance_ms_per_s',.05)
            best=min(recent,key=lambda q:q.uncertainty_ms+max(0,b-q.sampled_ts)*drift)
            self.clock=Clock(best.offset_ms,best.uncertainty_ms+max(0,b-best.sampled_ts)*drift,best.sampled_ts)
            self.clock_metrics={'window_samples':len(recent),'latest_rtt_ms':rtt,
                                'chosen_base_uncertainty_ms':best.uncertainty_ms,
                                'chosen_sample_age_s':b-best.sampled_ts,
                                'drift_allowance_ms_per_s':drift}

    def clock_loop(self):
        # Separate thread: a slow metadata request cannot stall clock sampling.
        warm=0
        while not self.stop.is_set():
            try:self.update_clock()
            except Exception as exc:
                with self.lock:self.errors['clock']+=1
                LOG.warning('Clock sample unavailable: %s',exc)
            warm+=1
            self.stop.wait(.25 if warm<3 else self.cfg.get('clock_sync_interval_s',20))

    def update_live(self):
        data=local_live_status(self.cfg['live_status_url'])
        with self.lock: self.live=data;self.live_ts=time.time()

    def run(self):
        due={}
        methods=[('fees',self.read_live_fees,30),('live',self.update_live,10),
                 ('rules',self.update_rules,1800),
                 ('volumes',self.update_volumes,300),('prices',self.update_prices,8),('bbo',self.update_bbo,self.cfg['discovery_poll_s'])]
        while not self.stop.is_set():
            self.heartbeat=time.monotonic()
            for key,fn,interval in methods:
                if self.stop.is_set():break
                now=time.monotonic()
                if now<due.get(key,0):continue
                due[key]=now+interval
                try:fn()
                except Exception as exc:
                    self.errors[key]+=1;self.last_error=f'{key}: {type(exc).__name__}: {exc}'
                    LOG.warning(self.last_error)
                    self.store.emit('reference_error',{'source':key,'error':self.last_error})
                    due[key]=now+max(15,interval if key not in ('rules','clock') else 30)
            self.stop.wait(.2)

    def start(self):
        self.clock_thread=threading.Thread(target=self.clock_loop,name='c-clock-sync',daemon=True)
        self.clock_thread.start()
        self.thread=threading.Thread(target=self.run,name='c-reference-data',daemon=True)
        self.thread.start()

    def snapshot(self):
        with self.lock:
            return {'rules':self.rules.copy(),'fees':self.fees.copy(),'volumes':self.volumes.copy(),
                    'refs':self.refs.copy(),'bbo':self.bbo.copy(),'clock':self.clock,
                    'live':self.live.copy(),'live_ts':self.live_ts,'bbo_ts':self.bbo_ts,
                    'rules_ts':self.rules_ts,'volume_ts':self.volume_ts,'fees_ts':self.fees_ts,
                    'errors':dict(self.errors),'last_error':self.last_error,'clock_metrics':dict(self.clock_metrics)}
