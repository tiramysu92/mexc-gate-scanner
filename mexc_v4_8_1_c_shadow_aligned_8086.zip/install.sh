#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
umask 077
if [[ ! -x .venv/bin/python ]]; then
  python3 -m venv .venv
fi
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m compileall -q app.py manage.py cshadow
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python app.py --check
printf '\nInstallation OK. Nothing started, no LIVE file changed.\n'
