#!/usr/bin/env python3
from __future__ import annotations
import argparse
import csv
import fcntl
import io
import json
import logging
import logging.handlers
import signal
import sqlite3
import threading
import urllib.parse
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from cshadow import VERSION
from cshadow.config import load_config
from cshadow.storage import encode

ROOT=Path(__file__).resolve().parent

class Server(ThreadingHTTPServer):
    daemon_threads=True
    request_queue_size=16
    def __init__(self,address,backend):
        self.backend=backend
        self.slots=threading.BoundedSemaphore(16)
        super().__init__(address,Handler)
    def process_request(self,request,address):
        if not self.slots.acquire(blocking=False):
            self.shutdown_request(request);return
        try:super().process_request(request,address)
        except Exception:
            self.slots.release();raise
    def process_request_thread(self,request,address):
        try:super().process_request_thread(request,address)
        finally:self.slots.release()

class Handler(BaseHTTPRequestHandler):
    server_version='MEXC-C-Observer'
    def setup(self):
        super().setup();self.connection.settimeout(8)
    def log_message(self,format,*args):
        if args and str(args[1:2]) not in ("('200',)",):
            logging.getLogger('http').debug(format,*args)
    def reply(self,data:bytes,mime='application/json; charset=utf-8',code=200,name=None):
        self.send_response(code)
        self.send_header('Content-Type',mime)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if name:self.send_header('Content-Disposition',f'attachment; filename="{name}"')
        self.end_headers()
        try:self.wfile.write(data)
        except (BrokenPipeError,ConnectionResetError):pass
    def do_POST(self):self.reply(b'{"error":"READ_ONLY_INTERFACE_NO_ORDERS"}',code=405)
    do_PUT=do_POST
    do_DELETE=do_POST
    do_PATCH=do_POST
    def do_GET(self):
        path=self.path.split('?',1)[0]
        try:
            if path in ('/api/data','/api/health'):
                view=self.server.backend.snapshot()
                if path=='/api/health':
                    view={k:view.get(k) for k in ('version','mode','orders_possible','state','run_id','heartbeat_age_s','storage','demo')}
                self.reply(encode(view).encode('utf-8'));return
            if path=='/api/trials':
                backend=self.server.backend
                rows=backend.store.recent('trials',100) if hasattr(backend,'store') else []
                self.reply(encode(rows).encode('utf-8'));return
            if path=='/api/export/samples.csv':
                backend=self.server.backend
                if not hasattr(backend,'store'):
                    self.reply(b'DEMO: no real data\n','text/plain');return
                with backend.store.ro() as db:
                    rows=db.execute('SELECT ts,route,size,testable,protected_bps,detail_json FROM c_size_samples ORDER BY id DESC LIMIT 5000').fetchall()
                text=io.StringIO();writer=csv.writer(text)
                writer.writerow(['ts','route','budget_cap_su','strict_book_testable','executable_protected_bps','detail_json'])
                writer.writerows(rows)
                self.reply(text.getvalue().encode('utf-8-sig'),'text/csv; charset=utf-8',name='c481_last5000_samples.csv');return
            if path=='/api/export/trials.csv':
                backend=self.server.backend
                if not hasattr(backend,'store'):
                    self.reply(b'DEMO: no real data\n','text/plain');return
                with backend.store.ro() as db:
                    rows=db.execute('SELECT start_ts,route,size,clean,detail_json FROM c_size_trials ORDER BY start_ts DESC LIMIT 5000').fetchall()
                text=io.StringIO();writer=csv.writer(text)
                writer.writerow(['start_ts','route','budget_cap_su','signal_trial_clean','detail_json'])
                writer.writerows(rows)
                self.reply(text.getvalue().encode('utf-8-sig'),'text/csv; charset=utf-8',name='c481_last5000_trials.csv');return
            assets={'/':('index.html','text/html; charset=utf-8'),
                    '/static/style.css':('style.css','text/css; charset=utf-8'),
                    '/static/app.js':('app.js','text/javascript; charset=utf-8')}
            if path in assets:
                file,mime=assets[path]
                self.reply((ROOT/'static'/file).read_bytes(),mime);return
            self.reply(b'{"error":"NOT_FOUND"}',code=404)
        except Exception as exc:
            logging.exception('Observer request failed')
            self.reply(encode({'error':type(exc).__name__,'detail':str(exc)}).encode(),code=503)

def check(cfg):
    runtime=Path(cfg['live_runtime'])
    x=json.loads((runtime/'config.json').read_text())
    path=Path(x['db_path']);path=(runtime/path).resolve() if not path.is_absolute() else path.resolve()
    if not path.is_file():raise ValueError('LIVE DB missing; no empty file will be created')
    with sqlite3.connect(path.as_uri()+'?mode=ro',uri=True,timeout=.5) as db:
        db.execute('PRAGMA query_only=ON')
        db.execute('SELECT symbol,taker_bps,fetched_ts,source FROM account_fees LIMIT 1').fetchall()
    import websocket
    print('CHECK OK — C-SHADOW only. Source DB opened read-only.')
    print('LIVE runtime:',runtime)
    print('C data only :',cfg['data_dir'])
    print('UI port     :',cfg['port'])
    print('WebSocket client:',websocket.__version__)

def main():
    ap=argparse.ArgumentParser(description='C-SHADOW observer. No execution implementation.')
    ap.add_argument('--config',default=str(ROOT/'config.json'))
    ap.add_argument('--check',action='store_true')
    ap.add_argument('--demo',action='store_true')
    ap.add_argument('--port',type=int)
    args=ap.parse_args()
    cfg=load_config(Path(args.config).resolve())
    if args.port is not None:
        if args.port in (8081,8082,8085) or not 1024<=args.port<=65535:
            raise ValueError('Reserved/invalid port')
        cfg['port']=args.port
    if args.check:
        check(cfg);return
    if args.demo:
        from cshadow.demo import DemoService
        backend=DemoService()
        print('DEMO ONLY: no market/account access',flush=True)
    else:
        check(cfg)
        data=Path(cfg['data_dir']);data.mkdir(parents=True,exist_ok=True)
        process_lock=(data/'process.lock').open('a')
        fcntl.flock(process_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        logging.basicConfig(level=logging.INFO,handlers=[logging.handlers.RotatingFileHandler(
            data/'observer.log',maxBytes=3*1024*1024,backupCount=2,encoding='utf-8')],
            format='%(asctime)s %(levelname)s %(name)s %(message)s')
        from cshadow.service import Service
        backend=Service(cfg)
    # Bind before starting network workers: a port conflict cannot leave an orphan collector.
    try:server=Server((cfg['bind'],cfg['port']),backend)
    except Exception:
        backend.close();raise
    if not args.demo:backend.start()
    def stop(signum,frame):
        threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    print(f'C-SHADOW {VERSION} listening on {cfg["bind"]}:{cfg["port"]}; no order endpoints.',flush=True)
    try:server.serve_forever(poll_interval=.25)
    finally:server.server_close();backend.close()

if __name__=='__main__':main()
