# Sources et hypothèses — V4.8.1

Vérification documentaire : 19 septembre 2026. Les documents officiels sont utilisés pour le format des messages et règles, pas pour présumer une rentabilité.

1. MEXC — Partial Book Depth Streams
   https://www.mexc.com/api-docs/spot-v3/websocket-market-streams/partial-book-depth-streams
   Flux public partiel 5/10/20 niveaux. Champs version, sendTime (temps événement), lastOrderCreateTime (création dernier ordre). La version utilise 20 niveaux. Aucun taux garanti de rafraîchissement 50 ms n'est supposé. La réobservation de version inchangée est une politique explicite : trame complète identique et sendTime strictement croissant ; elle reste signalée comme inchangée.

2. MEXC — Exchange Information
   https://www.mexc.com/api-docs/spot-v3/market-data-endpoints/exchange-information
   Précisions d'actif et de commission, minimum de montant quoteAmountPrecision, quantité minimale baseSizePrecision, tradeSideType et limites de prix. En l'absence de LOT_SIZE, la convention du moteur historique utilise baseSizePrecision comme pas conservateur ; ce choix peut sous-estimer la taille admissible. Ce n'est pas une certification du pas effectif de chaque symbole. Les commissions en base/quote et leur arrondi supérieur sont des hypothèses du modèle.

3. MEXC — How to Properly Maintain a Local Copy of the Order Book
   https://www.mexc.com/api-docs/spot-v3/websocket-market-streams/how-to-properly-maintain-a-local-copy-of-the-order-book
   Le flux incrémental demande un snapshot et des contrôles de continuité. V4.8.1 NE migre PAS vers ce flux ; elle garde les snapshots partiels complets pour éviter d'ajouter une reconstruction différentielle non validée.

4. MEXC — schémas protobuf officiels
   https://github.com/mexcdevelop/websocket-proto
   PushDataV3ApiWrapper.proto / PublicLimitDepthsV3Api.proto. Décodage limité aux champs publics utiles ; aucune implémentation de canal privé/ordre.

5. Python — sqlite3
   https://docs.python.org/3/library/sqlite3.html
   Ouverture URI en lecture seule, API backup, transactions. La DB de frais A/B n'est jamais initialisée/migrée par C. L'usage de `with connection` ne ferme pas à lui seul une connexion ; les handles C sont explicitement fermés.

# Sources de données utilisateur

- ZIP C-SHADOW V4.8.0 transmis : code de départ inspecté, archive inchangée conservée hors du package.
- c_shadow_last5000_samples.csv : 3 210 mesures issues de l'ancien modèle, sans les livres complets. Source du constat de dust/arrondis, pas source d'un replay intégral 4.8.1.
- Règles futures : GET public exchangeInfo ; frais compte : lecture de account_fees gérée par V4.7.

# Ce qui n'est PAS une source de vérité

Les captures d'interface démo et les tests utilisent des carnets fabriqués. Le compteur de plans, les stages C et les marks de dust ne sont pas des profits, des fills, ni une probabilité de succès indépendante. Les marges et seuils de recherche sont des paramètres explicites, non des valeurs optimales démontrées.
