# Rapport de validation — 4.8.1-c-shadow.1

## Résultat

**124 tests unittest passent**, à partir de la suite incluse dans le package. Les entrées réseau sont fictives ou simulées. Les tests ne contactent pas le compte MEXC et n'envoient aucun ordre.

Le rapport complet est fourni sous `validation/unittest.log`. Il inclut les 81 tests hérités (adaptés lorsque la spécification de sizing change) et 43 tests supplémentaires. Un de ces tests parcourt 150 combinaisons pseudo-aléatoires reproductibles de pas/frais/plafonds ; ce ne sont pas 150 tests d'exécution exchange.

## Ce qui a réellement été testé

- Budget plafonné ; achat aligné à la quantité revendable ; commissions en base/quote et quantification ; minimums, maximums, pas, ticks, profondeur et résidu ; invariant aucun dépassement de budget ni survente.
- Régression inspirée SOL : cap10, pas L1 0,000001 / pas L2 0,01 ; q1=q2=0,08, dust nul. Carnets synthétiques, pas reconstruction historique d'un fill.
- Frais absents/périmés bloqués ; frais zéro acceptés quand connus ; arrondi de commission élevé rendu visible.
- Réobservation complète à contenu identique / version inchangée seulement si sendTime croît ; vieux paquet/timestamp identique/PING interdits ; conflit de contenu mis en quarantaine ; nouvelle génération séparée.
- Couples des derniers carnets, non sélection rétrospective ; horloge incertaine ou skew excessif restent bloquants en strict.
- LEARNING indépendant du signe de l'edge, plafonné en fréquence et sans promotion ; profil temporel élargi jamais pris pour une preuve.
- Quantité figée entre signal et horizons ; horizon absent censuré ; observation tardive séparée ; carnet vide observé = échec de liquidité, pas succès ; interruption conservée.
- Écriture asynchrone effective d'un trial dans SQLite, correction 9 colonnes/9 placeholders ; copie des payloads ; carnet partagé compressé/relu ; pas d'altération du fichier source de frais ; fermeture des handles de lecture.
- Endpoints HTTP / JSON / fichiers statiques / méthodes d'écriture refusées, configuration validée, lifecycle du service avec références et flux simulés.

## Interface

Contrôles JavaScript (`node --check`) et rendu Chromium local effectués avec un JSON de démo injecté :

| Vue | Dimensions | Erreurs JS | Cartes C | Plafonds comparés | Débordement du document |
|---|---|---:|---:|---:|---:|
| Ordinateur | 1440 × 1100 | 0 | 3 | 6 | 0 px |
| Mobile | 430 × 932 | 0 | 3 | 6 | 0 px |

La sélection d'une route met à jour le comparateur. Les données indiquent explicitement DEMO. Le rendu a été fait depuis les fichiers locaux avec `fetch` simulé ; les endpoints HTTP sont testés séparément par unittest. Aucune prétention de validation du réseau mobile de l'utilisateur ou d'un accès externe AWS.

## Calcul local, pas latence MEXC

Benchmark indicatif de 80 lots synthétiques, 6 plafonds/lot, 20 niveaux par côté et limite de 24 quantités candidates/plafond : médiane environ 8,00 ms, p95 environ 8,85 ms, maximum environ 11,76 ms dans cet environnement de construction. Résultats exacts dans `validation/benchmark_results.json`.

Ces mesures NE sont PAS la latence sur AWS ni L1→L2. Sous charge, la collecte peut avoir des horizons censurés/tardifs ; l'interface les montre. La charge partagée avec A/B doit être contrôlée après installation.

## Limites de la validation

Le flux MEXC de l'instance AWS, ses codes/permissions effectifs, le remplissage d'ordres, la précision réellement appliquée aux commissions, les pertes en scénario de marché discontinu et la rentabilité C ne sont pas validés par ces tests. L'absence d'ordres implémentés est volontaire.

Le CSV V4.8.0 transmis ne comporte pas les livres complets. Aucun résultat de replay ou rendement historique V4.8.1 n'est inventé à partir de ses seules 3 210 lignes. Le nouveau format conserve des snapshots bruts pour permettre des analyses ultérieures mieux fondées.

Les stages par nombre d'épisodes sont des indicateurs de recherche, pas des probabilités de fill, et ne donnent jamais une autorisation LIVE.
