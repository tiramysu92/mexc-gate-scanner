#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
HERE="$(pwd -P)"
if [[ "$HERE" != /home/ubuntu/mexc-c-shadow-v481 ]]; then
  echo "Service template is restricted to /home/ubuntu/mexc-c-shadow-v481"
  exit 1
fi
.venv/bin/python app.py --check
# Refuse to steal an occupied port; a running manual C instance must be stopped first.
.venv/bin/python - <<'PY'
import socket
from pathlib import Path
from cshadow.config import load_config
c=load_config(Path('config.json').resolve())
if Path(c['data_dir']) != Path('data481').resolve():raise SystemExit('Service restricted to default data481 directory')
with socket.socket() as s:s.bind((c['bind'],c['port']))
PY
sudo tee /etc/systemd/system/mexc-c-shadow-v481.service >/dev/null <<EOF
[Unit]
Description=MEXC 4.8.1 C-SHADOW only - no order execution
After=network-online.target
Wants=network-online.target
[Service]
User=ubuntu
WorkingDirectory=$HERE
ExecStart=$HERE/.venv/bin/python $HERE/app.py
Environment=PYTHONDONTWRITEBYTECODE=1
Restart=on-failure
RestartSec=10
TimeoutStopSec=20
Nice=10
CPUQuota=50%
MemoryMax=512M
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=$HERE/data481
ReadOnlyPaths=/home/ubuntu/mexc-spot-2leg-v4
InaccessiblePaths=-/home/ubuntu/.config/mexc-bot
[Install]
WantedBy=multi-user.target
EOF
mkdir -p "$HERE/data481"
sudo systemctl daemon-reload
sudo systemctl enable --now mexc-c-shadow-v481.service
sudo systemctl status --no-pager mexc-c-shadow-v481.service
