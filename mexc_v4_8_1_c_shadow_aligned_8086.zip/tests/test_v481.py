"""4.8.1 regression/integration tests. All network input is synthetic/mocked."""
import copy
import json
import random
import sqlite3
import tempfile
import threading
import time
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
from cshadow.config import DEFAULTS,load_config
from cshadow.model import *
from cshadow.feed import BookCache,decode_partial
from cshadow.episodes import Evidence
from cshadow.public import ReferenceData
from cshadow.storage import Store
from test_core import fixture,rule,calc,WALL,MONO,MemoryStore,frame,pb


class AlignedSizing(unittest.TestCase):
    def test_sol_style_residual_removed(self):
        r1=rule('SOLUSDC','USDC',baseAsset='SOL',baseSizePrecision='.000001',quotePrecision=2)
        r2=rule('SOLUSDT','USDT',baseAsset='SOL',baseSizePrecision='.01',quotePrecision=2)
        b1=Book.build(r1.symbol,[('113.40','100')],[('113.42','100')],1,1000000,WALL,MONO)
        b2=Book.build(r2.symbol,[('113.43','100')],[('113.44','100')],1,1000000,WALL,MONO)
        p=evaluate(r1,r2,b1,b2,Fee(r1.symbol,D(0),WALL,'MEXC_ACCOUNT_API'),Fee(r2.symbol,D(5),WALL,'MEXC_ACCOUNT_API'),10,500000,WALL,MONO,Clock(0,1,WALL),DEFAULTS)
        self.assertEqual(D(p['q1']),D('.08'));self.assertEqual(D(p['q2']),D('.08'))
        self.assertEqual(p['dust_mark_su'],0);self.assertLess(p['spend_su'],10)
        self.assertFalse(p['is_c']);self.assertIn('AB_NOT_C',p['reasons'])
        self.assertGreater(p['protected_edge_bps'],-100) # not the artificial ~-940bp

    def test_fee_compensated_before_l2_rounding(self):
        x=list(fixture());x[0]=replace(x[0],step=D('.000001'));x[1]=replace(x[1],step=D('.01'))
        x[4]=replace(x[4],taker_bps=D(5));p=calc(x)
        self.assertLessEqual(D(p['dust_qty']),D('.000002'))
        self.assertGreaterEqual(D(p['q1'])-D(p['fee_base_units']),D(p['q2']))

    def test_coarse_l1_dust_is_not_assumed_zero(self):
        x=list(fixture());x[0]=replace(x[0],step=D('.013'));x[1]=replace(x[1],step=D('.017'))
        p=calc(x,cfg={**DEFAULTS,'max_dust_fraction':.005})
        self.assertGreaterEqual(D(p.get('dust_qty','0')),0)
        if p.get('q1'):
            self.assertEqual(D(p['q1'])-D(p['fee_base_units'])-D(p['q2']),D(p['dust_qty']))

    def test_high_commission_quantum_visible(self):
        x=list(fixture());x[0]=replace(x[0],base_fee_tick=D('.01'));x[4]=replace(x[4],taker_bps=D(5));p=calc(x)
        self.assertGreater(p['effective_fee1_bps'],5)
        self.assertGreater(D(p['fee1_rounding_extra_base']),0)

    def test_zero_notional_stays_invalid(self):
        p=calc(size=0);self.assertFalse(p['testable']);self.assertIn('BUDGET_INVALID',p['reasons'])

    def test_max_quote_amount(self):
        x=list(fixture());x[0]=replace(x[0],max_notional=D(3));p=calc(x)
        self.assertLessEqual(p['spend_su'],3)

    def test_search_is_bounded(self):
        p=calc(cfg={**DEFAULTS,'max_size_candidates':8});self.assertLessEqual(p['sizing_candidates_tested'],8)

    def test_not_remainder_divided_by_cap(self):
        p=calc()
        expected=(p['proceeds_su']+p['dust_mark_su']-p['spend_su'])/p['spend_su']*10000-DEFAULTS['thin_buffer_bps']
        self.assertAlmostEqual(p['protected_edge_bps'],expected,places=8)

    def test_dust_and_buffer_are_applied_once(self):
        p=calc()
        self.assertAlmostEqual(p['protected_edge_bps'],p['net_cash_bps']+p['dust_mark_bps']-DEFAULTS['thin_buffer_bps'],places=9)

    def test_rounding_never_oversells_random_grid(self):
        rng=random.Random(1701)
        for _ in range(150):
            x=list(fixture());x[0]=replace(x[0],step=D(rng.choice(['.0001','.001','.01'])))
            x[1]=replace(x[1],step=D(rng.choice(['.001','.01','.1'])))
            x[4]=replace(x[4],taker_bps=D(rng.choice([0,1,5,10])))
            cap=rng.choice([2.5,5,10,15,20,25]);p=calc(x,size=cap)
            if p.get('spend_su') is None:continue
            with self.subTest(cap=cap,q=p['q1']):
                self.assertLessEqual(p['spend_su'],cap+1e-12)
                self.assertEqual(D(p['q1'])%x[0].step,0);self.assertEqual(D(p['q2'])%x[1].step,0)
                self.assertGreaterEqual(D(p['dust_qty']),0)
                self.assertEqual(D(p['q1'])-D(p['fee_base_units'])-D(p['q2']),D(p['dust_qty']))

    def test_classification_does_not_disappear_when_sizing_down(self):
        x=list(fixture());x[3]=replace(x[3],bids=((D('1.0015'),D(40)),))
        p=calc(x,size=2.5,volume_min=1000000)
        self.assertTrue(p['is_c']);self.assertIn('C_DEPTH_REFERENCE',p['c_reasons'])
        self.assertGreater(p['l2_reserve_x'],10)

    def test_late_reprice_does_not_resize_initial_plan(self):
        x=fixture();p=calc(x);q=p['q2'];cash=p['spend_su']
        b=replace(x[3],bids=((D('.9'),D(2)),))
        z=horizon_exit(p,b,x[1],x[5],DEFAULTS)
        self.assertFalse(z['liquidity_ok']);self.assertEqual(p['q2'],q);self.assertEqual(p['spend_su'],cash)

    def test_unknown_fee_blocks_all_sizes(self):
        for cap in DEFAULTS['sizes_su']:
            x=list(fixture());x[4]=None
            self.assertFalse(calc(x,size=cap)['testable'])

    def test_bad_generation_is_not_synced(self):
        x=list(fixture());x[3]=replace(x[3],generation=4)
        self.assertIn('GENERATION_MISMATCH',calc(x)['reasons'])


class ReobservationTests(unittest.TestCase):
    def message(self,version=1,send=1000000):
        x=decode_partial(frame(version));x['send_ms']=send;return x
    def test_identical_full_frame_new_server_time(self):
        c=BookCache();c.add(self.message(),WALL,MONO)
        self.assertTrue(c.add(self.message(send=1000050),WALL+.05,MONO+.05))
        b=c.latest('TESTUSDT');self.assertEqual(b.version,1);self.assertEqual(b.content_mono,MONO)
        self.assertEqual(b.observation_kind,'REOBSERVED_UNCHANGED');self.assertEqual(b.recv_mono,MONO+.05)
    def test_reobservation_can_be_disabled(self):
        c=BookCache(False);c.add(self.message(),WALL,MONO)
        self.assertFalse(c.add(self.message(send=1000050),WALL+.05,MONO+.05))
    def test_reobs_can_measure_horizon_but_is_tagged(self):
        c=BookCache();c.add(self.message(),WALL,MONO);first=c.latest('TESTUSDT')
        c.add(self.message(send=1000060),WALL+.06,MONO+.06)
        b=c.first_after('TESTUSDT',MONO+.05,0,1,1000000,first.observation_id)
        self.assertIsNotNone(b);self.assertEqual(b.observation_kind,'REOBSERVED_UNCHANGED')
    def test_same_time_never_refreshes(self):
        c=BookCache();c.add(self.message(),WALL,MONO)
        c.add(self.message(),WALL+1,MONO+1);self.assertEqual(c.latest('TESTUSDT').recv_mono,MONO)
    def test_lower_version_with_new_time_not_refresh(self):
        c=BookCache();c.add(self.message(2),WALL,MONO)
        self.assertFalse(c.add(self.message(1,1000100),WALL+.1,MONO+.1))
        self.assertEqual(c.latest('TESTUSDT').version,2)
    def test_same_version_conflict_quarantined(self):
        c=BookCache();c.add(self.message(),WALL,MONO)
        bad=self.message(send=1000100);bad['bids']=[('0.9','30')]
        self.assertFalse(c.add(bad,WALL+.1,MONO+.1));self.assertIsNone(c.latest('TESTUSDT'))
        self.assertFalse(c.add(bad,WALL+.2,MONO+.2))
        self.assertTrue(c.add(self.message(2,1000300),WALL+.3,MONO+.3))
    def test_atomically_latest_pair_not_best_historical_pair(self):
        c=BookCache();a=self.message();b=self.message();b['symbol']='OTHER'
        c.add(a,WALL,MONO);c.add(b,WALL,MONO)
        a=self.message(2,1000200);c.add(a,WALL+.2,MONO+.2)
        x,y=c.pair('TESTUSDT','OTHER');self.assertEqual(x.version,2);self.assertEqual(y.version,1)
    def test_last_order_time_not_freshness(self):
        c=BookCache();x=self.message();x['last_order_create_ms']=123
        c.add(x,WALL,MONO);self.assertEqual(c.latest('TESTUSDT').exchange_ms,1000000)
    def test_ping_cannot_decode_depth(self):self.assertIsNone(decode_partial(pb(1,'PING')))


class LearningAndLateTests(unittest.TestCase):
    def setup_case(self):
        self.cfg={**DEFAULTS,'learning_enabled':True};self.store=MemoryStore();self.cache=BookCache()
        self.e=Evidence(self.cfg,self.store,self.cache);self.x=fixture();self.p=calc();self.clock=Clock(0,1,WALL)
    def observe(self,p=None):
        p=p or self.p;self.e.observe(p['route'],[p],self.x[1],self.x[5],self.x[3],MONO,WALL)
    def test_negative_edges_start_learning_without_signal(self):
        self.setup_case();p={**self.p,'signal_eligible':False,'protected_edge_bps':-4,'net_cash_bps':-2}
        self.observe(p);self.assertFalse(self.e.active);self.assertEqual(len(self.e.pending),1)
        self.assertEqual(next(iter(self.e.pending.values()))['record']['purpose'],'LEARNING')
    def test_learning_has_no_stage_credit(self):
        self.setup_case();p={**self.p,'signal_eligible':False,'protected_edge_bps':-4};self.observe(p)
        for i,h in enumerate((50,100,250,500)):
            d=h/1000+.01;self.cache.add({'symbol':self.x[3].symbol,'bids':self.x[3].bids,'asks':self.x[3].asks,'version':i+2,'send_ms':int((WALL+d)*1000)},WALL+d,MONO+d)
            self.e.tick(WALL+d,MONO+d,self.clock)
        self.assertEqual(self.e.stage(p['route'],5)['clean_episodes'],0)
        self.assertFalse([x for k,x in self.store.rows if k=='trial'][-1]['clean'])
    def test_learning_is_rate_limited(self):
        self.setup_case();p={**self.p,'signal_eligible':False};self.observe(p);self.observe(p)
        self.assertEqual(len(self.e.pending),1)
    def test_late_frame_not_retroactive_strict_success(self):
        self.setup_case();self.observe();self.e.tick(WALL+.08,MONO+.08,self.clock)
        d=.12;self.cache.add({'symbol':self.x[3].symbol,'bids':self.x[3].bids,'asks':self.x[3].asks,'version':2,'send_ms':int((WALL+d)*1000)},WALL+d,MONO+d)
        self.e.tick(WALL+d,MONO+d,self.clock)
        tr=next(iter(self.e.pending.values()))['record']
        self.assertEqual(tr['horizons']['50']['status'],'CENSORED')
        self.assertEqual(tr['late_horizons']['50']['status'],'LATE_DIAGNOSTIC')
        self.assertFalse(tr['late_horizons']['50']['usable_for_strict_proof'])
    def test_missed_all_horizons_not_success(self):
        self.setup_case();self.observe();self.e.tick(WALL+1,MONO+1,self.clock)
        self.assertFalse(self.e.pending)
        tr=[x for k,x in self.store.rows if k=='trial'][-1]
        self.assertFalse(tr['clean']);self.assertTrue(all(z['status']=='CENSORED' for z in tr['horizons'].values()))
    def test_relaxed_profile_cannot_start_signal_or_learning(self):
        self.setup_case();p={**self.p,'profile':'RELAXED_DIAGNOSTIC'};self.observe(p)
        self.assertFalse(self.e.active);self.assertFalse(self.e.pending)
    def test_no_liquidity_not_success(self):
        self.setup_case();self.observe()
        self.cache.add({'symbol':self.x[3].symbol,'bids':[],'asks':self.x[3].asks,'version':2,'send_ms':1000060},WALL+.06,MONO+.06)
        self.e.tick(WALL+.06,MONO+.06,self.clock)
        tr=next(iter(self.e.pending.values()))['record']
        self.assertEqual(tr['horizons']['50']['status'],'OBSERVED');self.assertFalse(tr['horizons']['50']['pass'])
    def test_close_interrupts_learning(self):
        self.setup_case();self.observe({**self.p,'signal_eligible':False});self.e.close();self.assertFalse(self.e.pending)
        self.assertEqual([x for k,x in self.store.rows if k=='trial'][-1]['status'],'INTERRUPTED')


class Storage481Tests(unittest.TestCase):
    def test_real_writer_stores_trial_not_just_queue(self):
        with tempfile.TemporaryDirectory() as td:
            st=Store(td,{**DEFAULTS,'min_disk_free_mb':0},'T')
            trial={'trial_id':'t','episode_id':'e','route':'R','size':5,'start_ts':time.time(),'done_ts':None,'clean':False,'status':'PENDING'}
            st.emit('trial',trial)
            until=time.monotonic()+2
            while st.written<1 and not st.failed and time.monotonic()<until:time.sleep(.01)
            self.assertFalse(st.failed,st.last_error)
            with st.ro() as db:self.assertEqual(db.execute('SELECT COUNT(*) FROM c_size_trials').fetchone()[0],1)
            st.close()
    def test_queued_payload_does_not_mutate(self):
        st=Store.__new__(Store);st.failed=False;st.queue=__import__('queue').Queue(maxsize=4)
        x={'horizons':{}};st.emit('x',x);x['horizons']['50']='changed'
        self.assertEqual(st.queue.get_nowait()[1]['horizons'],{})
    def test_raw_pair_compressed_and_recoverable(self):
        import zlib
        with tempfile.TemporaryDirectory() as td:
            st=Store(td,{**DEFAULTS,'min_disk_free_mb':0},'T')
            x={'snapshot_id':'s','ts':time.time(),'books':[{'symbol':'A'},{'symbol':'B'}]};st.emit('book_pair',x)
            until=time.monotonic()+2
            while st.written<1 and time.monotonic()<until:time.sleep(.01)
            with st.ro() as db:raw=db.execute('SELECT body_zlib FROM c_book_pairs').fetchone()[0]
            self.assertEqual(json.loads(zlib.decompress(raw)),x);st.close()
    def test_source_live_db_cannot_be_written(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'config.json').write_text(json.dumps({'db_path':'live.sqlite'}))
            db=sqlite3.connect(p/'live.sqlite');db.execute('CREATE TABLE account_fees(symbol,taker_bps,fetched_ts,source)');db.commit();db.close()
            before=(p/'live.sqlite').read_bytes();ref=ReferenceData({**DEFAULTS,'live_runtime':td},MemoryStore(),threading.Event());ref.read_live_fees()
            self.assertEqual(before,(p/'live.sqlite').read_bytes())
    def test_sql_read_context_closes_handle(self):
        with tempfile.TemporaryDirectory() as td:
            st=Store(td,{**DEFAULTS,'min_disk_free_mb':0},'T')
            with st.ro() as db:db.execute('SELECT 1')
            with self.assertRaises(sqlite3.ProgrammingError):db.execute('SELECT 1')
            st.close()


class Clock481Tests(unittest.TestCase):
    def ref(self):return ReferenceData(DEFAULTS,MemoryStore(),threading.Event())
    def test_low_rtt_sample_kept_over_delayed_sample(self):
        r=self.ref();r.client.get=lambda _: {'serverTime':1000005}
        with patch('cshadow.public.time.time',side_effect=[1000.,1000.01]),patch('cshadow.public.time.monotonic',side_effect=[10.,10.01]):r.update_clock()
        r.client.get=lambda _: {'serverTime':1020100}
        with patch('cshadow.public.time.time',side_effect=[1020.,1020.2]),patch('cshadow.public.time.monotonic',side_effect=[30.,30.2]):r.update_clock()
        self.assertLess(r.clock.uncertainty_ms,20);self.assertEqual(r.clock.sampled_ts,1000.01)
    def test_wall_jump_invalidates_clock(self):
        r=self.ref();r.client.get=lambda _: {'serverTime':1000005}
        with patch('cshadow.public.time.time',side_effect=[1000.,1001.]),patch('cshadow.public.time.monotonic',side_effect=[10.,10.01]):
            with self.assertRaises(RuntimeError):r.update_clock()
        self.assertIsNone(r.clock)
    def test_boolean_config_works(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'config.json';p.write_text('{}');self.assertTrue(load_config(p)['learning_enabled'])
    def test_bad_boolean_config_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'config.json';p.write_text('{"learning_enabled":1}')
            with self.assertRaises(ValueError):load_config(p)

if __name__=='__main__':unittest.main()


class AdditionalRuleGuards(unittest.TestCase):
    def test_notional_max_filter_is_not_ignored(self):
        r=rule('TESTUSDC','USDC',maxQuoteAmount='100',filters=[{'filterType':'NOTIONAL','minNotional':'1','maxNotional':'3'}])
        self.assertEqual(r.max_notional,D(3))
    def test_integer_settings_cannot_be_fractional(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'config.json';p.write_text(json.dumps({'port':8086.5}))
            with self.assertRaises(ValueError):load_config(p)


class DisplayGeneration(unittest.TestCase):
    def test_evaluation_persists_book_generation(self):
        p=calc();self.assertEqual(p['book_generation'],0)
