import copy
import json
import math
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from cshadow.config import DEFAULTS, load_config
from cshadow.model import *
from cshadow.feed import fields, decode_partial, BookCache
from cshadow.episodes import Evidence

WALL=1000.0
MONO=10.0

def rule(symbol='TESTUSDC',quote='USDC',**kw):
    d={'symbol':symbol,'baseAsset':'TEST','quoteAsset':quote,'quotePrecision':5,'baseAssetPrecision':6,
       'baseSizePrecision':'.001','quoteAmountPrecision':'1','baseCommissionPrecision':6,'quoteCommissionPrecision':6,
       'tradeSideType':'1','status':'1','isSpotTradingAllowed':True,'filters':[]}
    d.update(kw)
    return Rule.from_exchange(d,WALL)

def fixture():
    r1,r2=rule(),rule('TESTUSDT','USDT')
    b1=Book.build('TESTUSDC',[['.9999','1000']],[['1','1000']],1,1000000,WALL,MONO)
    b2=Book.build('TESTUSDT',[['1.0015','1000']],[['1.0016','1000']],1,1000000,WALL,MONO)
    f1=Fee('TESTUSDC',D(0),WALL,'MEXC_ACCOUNT_API')
    f2=Fee('TESTUSDT',D(0),WALL,'MEXC_ACCOUNT_API')
    return r1,r2,b1,b2,f1,f2

def calc(items=None,cfg=None,**kw):
    x=fixture() if items is None else items
    args={'size':5,'volume_min':10000,'now':WALL,'mono':MONO,'clock':Clock(0,1,WALL),'cfg':cfg or dict(DEFAULTS)}
    args.update(kw)
    return evaluate(*x,**args)

class MathTests(unittest.TestCase):
    def test_testable_c(self):
        p=calc();self.assertTrue(p['testable']);self.assertGreater(p['protected_cash_bps'],2);self.assertEqual(p['c_reasons'],['C_VOLUME'])
    def test_no_live(self):self.assertIs(calc()['live_authorized'],False)
    def test_fees_never_default_zero(self):
        x=list(fixture());x[4]=None;self.assertIn('ACCOUNT_FEES_UNKNOWN_OR_STALE',calc(x)['reasons'])
    def test_zero_fee_is_valid(self):self.assertEqual(calc()['fee1_bps'],0)
    def test_stale_fee(self):
        x=list(fixture());x[4]=replace(x[4],fetched_ts=-5000);self.assertFalse(calc(x)['testable'])
    def test_fee_currency_rounding(self):
        x=list(fixture());x[4]=replace(x[4],taker_bps=D(5));p=calc(x)
        self.assertGreater(D(p['fee_base_units']),0);self.assertLessEqual(D(p['q2']),D(p['q1'])-D(p['fee_base_units']))
    def test_second_fee_subtracted_once(self):
        x=list(fixture());p0=calc(x);x[5]=replace(x[5],taker_bps=D(5));p=calc(x)
        self.assertAlmostEqual(p0['net_cash_bps']-p['net_cash_bps'],5.01,delta=.03)
    def test_limit_rounding(self):
        p=calc();self.assertGreaterEqual(D(p['l1_limit']),D('1.00005'));self.assertLessEqual(D(p['l2_limit']),D('1.0015')*(1-D('.5')/BPS))
    def test_budget_not_exceeded(self):
        for size in DEFAULTS['sizes_su']:
            self.assertLessEqual(calc(size=size)['spend_su'],size)
    def test_cap_can_use_less_than_budget_for_thin_book(self):
        x=list(fixture());x[2]=replace(x[2],asks=((D(1),D(4)),));p=calc(x)
        self.assertTrue(p['testable']);self.assertLess(p['spend_su'],5)
        self.assertLessEqual(D(p['q1']),D(1))
    def test_empty_depth(self):
        x=list(fixture());x[3]=replace(x[3],bids=());self.assertIn('L2_EMPTY_BOOK',calc(x)['reasons'])
    def test_l2_qty_coverage(self):
        x=list(fixture());x[3]=replace(x[3],bids=((D('1.0015'),D('.5')),));self.assertFalse(calc(x)['testable'])
    def test_min_notional(self):self.assertIn('L1_MINIMUM_OR_MAXIMUM',calc(size=.5)['reasons'])
    def test_sell_min_notional(self):
        x=list(fixture());x[1]=replace(x[1],min_notional=D(100));self.assertIn('L2_MINIMUM_OR_MAXIMUM',calc(x)['reasons'])
    def test_wrong_book_symbol(self):
        x=list(fixture());x[3]=replace(x[3],symbol='OTHER');self.assertIn('BOOK_SYMBOL_MISMATCH',calc(x)['reasons'])
    def test_wrong_fee_symbol(self):
        x=list(fixture());x[5]=replace(x[5],symbol='OTHER');self.assertIn('FEE_SYMBOL_MISMATCH',calc(x)['reasons'])
    def test_cash_excludes_dust(self):
        x=list(fixture());x[1]=replace(x[1],step=D('.1'));p=calc(x)
        self.assertEqual(p['dust_mark_su'],0);self.assertEqual(p['net_mark_bps'],p['net_cash_bps'])
    def test_excess_dust_blocks(self):
        x=list(fixture());x[1]=replace(x[1],step=D('1'));p=calc(x)
        self.assertTrue(p['testable']);self.assertEqual(D(p['dust_qty']),0)
    def test_fresh_clock_required(self):self.assertIn('L1_CLOCK_UNCERTAIN',calc(clock=None)['reasons'])
    def test_uncertain_clock(self):self.assertIn('L1_CLOCK_UNCERTAIN',calc(clock=Clock(0,500,WALL))['reasons'])
    def test_local_age(self):self.assertIn('L1_STALE_LOCAL',calc(now=WALL+.3,mono=MONO+.3)['reasons'])
    def test_exchange_age(self):
        x=list(fixture());x[3]=replace(x[3],exchange_ms=999000);self.assertIn('L2_STALE_EXCHANGE',calc(x)['reasons'])
    def test_exchange_skew(self):
        x=list(fixture());x[3]=replace(x[3],exchange_ms=999800);self.assertIn('EXCHANGE_SKEW',calc(x)['reasons'])
    def test_large_raw_outlier(self):
        x=list(fixture());x[3]=replace(x[3],bids=((D(2),D(1000)),),asks=((D('2.001'),D(1000)),));self.assertIn('OUTLIER_CROSS',calc(x)['reasons'])
    def test_not_all_markets_are_c(self):self.assertIn('AB_NOT_C',calc(volume_min=1000000)['reasons'])
    def test_c_depth_not_daily_volume_only(self):
        x=list(fixture());x[3]=replace(x[3],bids=((D('1.0015'),D(40)),));p=calc(x,volume_min=1000000)
        self.assertIn('C_DEPTH_REFERENCE',p['c_reasons']);self.assertTrue(p['testable'])
    def test_distant_reserves_not_counted(self):
        x=list(fixture());x[3]=replace(x[3],bids=((D('1.0015'),D(1)),(D('.99'),D(1000000))));p=calc(x)
        self.assertIn('C_L2_RESERVE',p['reasons'])
    def test_trade_side(self):
        x=list(fixture());x[0]=replace(x[0],side_type='3');self.assertIn('SYMBOL_TRADE_DISABLED',calc(x)['reasons'])
    def test_price_filter_missing_reference(self):
        x=list(fixture());x[0]=replace(x[0],percent_filters=({'filterType':'PERCENT_PRICE_BY_SIDE','bidMultiplierUp':'.1','askMultiplierDown':'.1'},))
        self.assertIn('PRICE_FILTER_REFERENCE_UNKNOWN',calc(x)['reasons'])
    def test_price_filter_violation(self):
        x=list(fixture());x[0]=replace(x[0],percent_filters=({'filterType':'PERCENT_PRICE_BY_SIDE','bidMultiplierUp':'.1','askMultiplierDown':'.1'},))
        p=calc(x,refs={'TESTUSDC':{'price':'.5','ts':WALL}});self.assertIn('PRICE_FILTER_BUY',p['reasons'])
    def test_nan_rejected(self):
        with self.assertRaises(ValueError):dec('NaN')
    def test_future_reprice_not_resized(self):
        x=fixture();p=calc(x);b=replace(x[3],bids=((D('.9'),D(1000)),),asks=((D('.9001'),D(1000)),))
        outcome=horizon_exit(p,b,x[1],x[5],dict(DEFAULTS));self.assertLess(outcome['protected_cash_bps'],0)
        self.assertFalse(outcome['limit_still_coverable'])
    def test_source_rules_missing(self):
        with self.assertRaises((ValueError,TypeError)):rule(baseSizePrecision=None)
    def test_crossed_book(self):
        with self.assertRaises(ValueError):Book.build('X',[['1','1']],[['.9','1']],1,1,WALL,MONO)

# Binary fixtures generated from documented protobuf field numbers.
def vi(n):
    a=bytearray()
    while n>127:a.append((n&127)|128);n>>=7
    a.append(n);return bytes(a)
def pb(n,s):
    if isinstance(s,int):return vi(n<<3)+vi(s)
    b=s.encode() if isinstance(s,str) else s
    return vi((n<<3)|2)+vi(len(b))+b

def frame(version=1):
    ask=pb(1,'1.01')+pb(2,'20');bid=pb(1,'1')+pb(2,'30')
    body=pb(1,ask)+pb(2,bid)+pb(4,str(version))
    return pb(1,'spot@public.limit.depth.v3.api.pb@TESTUSDT@20')+pb(3,'TESTUSDT')+pb(6,1000000)+pb(303,body)

class FeedTests(unittest.TestCase):
    def test_decode(self):
        x=decode_partial(frame());self.assertEqual(x['bids'],[('1','30')]);self.assertEqual(x['asks'],[('1.01','20')])
    def test_no_private_decode(self):self.assertIsNone(decode_partial(pb(304,b'')))
    def test_truncated(self):
        with self.assertRaises(ValueError):decode_partial(frame()[:-1])
    def test_mismatch(self):
        with self.assertRaises(ValueError):decode_partial(frame()+pb(3,'OTHER'))
    def test_missing_timestamp(self):
        with self.assertRaises(ValueError):decode_partial(frame()+pb(6,0))
    def test_duplicate_not_refresh(self):
        c=BookCache();self.assertTrue(c.add(decode_partial(frame()),WALL,MONO));self.assertFalse(c.add(decode_partial(frame()),WALL+10,MONO+10))
        self.assertEqual(c.latest('TESTUSDT').recv_mono,MONO)
    def test_clear_generation(self):
        c=BookCache();c.add(decode_partial(frame()),WALL,MONO);c.clear();self.assertIsNone(c.latest('TESTUSDT'));self.assertEqual(c.generation,1)
    def test_needs_new_frame(self):
        c=BookCache();c.add(decode_partial(frame()),WALL,MONO)
        self.assertIsNone(c.first_after('TESTUSDT',MONO+.05,0,1,1000000))
    def test_unknown_field_skip(self):self.assertEqual(decode_partial(frame()+pb(99,'extra'))['version'],1)
    def test_wire0_invalid(self):
        with self.assertRaises(ValueError):list(fields(b'\x00\x01'))

class MemoryStore:
    def __init__(self):self.rows=[]
    def emit(self,k,x):self.rows.append((k,copy.deepcopy(x)));return True
    def load_stages(self):return {}

class EvidenceTests(unittest.TestCase):
    def setup_evidence(self):
        self.s=MemoryStore();self.c=BookCache();self.e=Evidence(dict(DEFAULTS),self.s,self.c)
        self.x=fixture();self.p=calc(self.x);self.clock=Clock(0,1,WALL)
        return self.e
    def open_trial(self):
        self.e.observe(self.p['route'],[copy.deepcopy(self.p)],self.x[1],self.x[5],self.x[3],MONO,WALL)
    def test_one_trial_per_size_episode(self):
        self.setup_evidence();self.open_trial();self.open_trial();self.assertEqual(len(self.e.pending),1)
    def test_no_data_censored_not_success(self):
        self.setup_evidence();self.open_trial();self.e.tick(WALL+1,MONO+1,self.clock)
        trial=[x for k,x in self.s.rows if k=='trial'][-1]
        self.assertFalse(trial['clean']);self.assertTrue(all(x['status']=='CENSORED' for x in trial['horizons'].values()))
    def test_post_horizon_fresh_frames(self):
        self.setup_evidence();self.open_trial()
        for i,h in enumerate([50,100,250,500]):
            delay=h/1000+.010
            self.c.add({'symbol':'TESTUSDT','bids':[['1.0015','1000']],'asks':[['1.0016','1000']],
                        'version':i+2,'send_ms':int((WALL+delay)*1000)},WALL+delay,MONO+delay)
            self.e.tick(WALL+delay,MONO+delay,self.clock)
        trial=[x for k,x in self.s.rows if k=='trial'][-1]
        self.assertTrue(trial['clean']);self.assertEqual(self.e.stage(self.p['route'],5)['clean_episodes'],0)
    def test_negative_exit_is_failure(self):
        self.setup_evidence();self.open_trial()
        self.c.add({'symbol':'TESTUSDT','bids':[['.99','1000']],'asks':[['.991','1000']],
                    'version':2,'send_ms':1000060},WALL+.06,MONO+.06)
        self.e.tick(WALL+.06,MONO+.06,self.clock)
        self.assertEqual(self.e.horizon_counts[50]['negative_or_unfillable'],1)
    def test_reconnect_censor(self):
        self.setup_evidence();self.open_trial();self.c.clear();self.e.tick(WALL+1,MONO+1,self.clock)
        trial=[x for k,x in self.s.rows if k=='trial'][-1]
        self.assertEqual(trial['horizons']['50']['reason'],'DISCONNECTED_OR_ROTATED')
    def test_late_frame_not_success(self):
        self.setup_evidence();self.open_trial()
        self.c.add({'symbol':'TESTUSDT','bids':[['1.0015','1000']],'asks':[['1.0016','1000']],
                    'version':2,'send_ms':1000090},WALL+.09,MONO+.09)
        self.e.tick(WALL+.09,MONO+.09,self.clock)
        self.assertEqual(self.e.horizon_counts[50]['censored'],1)
    def test_data_gap_not_clean_episode(self):
        self.setup_evidence();self.open_trial();self.e.tick(WALL+11,MONO+11,self.clock)
        self.assertFalse(self.e.active);self.assertEqual(self.e.stage(self.p['route'],5)['clean_episodes'],0)
    def test_stage_never_live(self):
        self.setup_evidence();self.e.stages[('R',5)]={'clean':100,'total':101}
        stage=self.e.stage('R',5);self.assertEqual(stage['label'],'C_PROVEN_SHADOW');self.assertFalse(stage['live_authorized'])
    def test_all_sizes_preserved(self):
        self.setup_evidence();plans=[calc(size=q) for q in (2.5,5,10)]
        self.e.observe(self.p['route'],plans,self.x[1],self.x[5],self.x[3],MONO,WALL)
        self.assertEqual(len(self.e.pending),3)
    def test_same_censored_episode_not_immediate_rearm(self):
        self.setup_evidence();self.open_trial();self.e.finish(self.p['route'],'CENSORED_DATA_GAP',WALL+1,MONO+1)
        self.open_trial();self.assertFalse(self.e.active)

class ConfigTests(unittest.TestCase):
    def check_dict(self,cfg):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'config.json';p.write_text(json.dumps(cfg));return load_config(p)
    def test_no_execution_config(self):
        with self.assertRaises(ValueError):self.check_dict({'execution_enabled':True})
    def test_dedicated_port(self):
        with self.assertRaises(ValueError):self.check_dict({'port':8081})
    def test_live_dir_never_destination(self):
        with self.assertRaises(ValueError):self.check_dict({'data_dir':'/same','live_runtime':'/same'})
    def test_no_high_load(self):
        with self.assertRaises(ValueError):self.check_dict({'discovery_poll_s':.1})
    def test_bad_number(self):
        with self.assertRaises(ValueError):self.check_dict({'max_db_mb':float('nan')})
    def test_defaults(self):self.assertEqual(self.check_dict({})['port'],8086)

if __name__=='__main__':unittest.main()
