#!/usr/bin/env python3
"""Export the independent C database, never the LIVE database."""
import gzip
import hashlib
import json
import shutil
import sqlite3
import time
from pathlib import Path
from cshadow.config import load_config

ROOT=Path(__file__).resolve().parent

def main():
    cfg=load_config(ROOT/'config.json')
    source=Path(cfg['data_dir'])/'c_shadow.sqlite'
    if not source.is_file():raise SystemExit('No C database yet.')
    outdir=ROOT/'exports';outdir.mkdir(exist_ok=True)
    if shutil.disk_usage(outdir).free < max(1024**3,3*source.stat().st_size):
        raise SystemExit('Insufficient export space. No file copied.')
    stamp=time.strftime('%Y%m%d_%H%M%S',time.gmtime())
    tmp=outdir/f'c481_{stamp}.sqlite.partial';out=outdir/f'c481_{stamp}.sqlite.gz'
    if tmp.exists() or out.exists():raise SystemExit('Export already exists; no overwrite.')
    print('Online backup of C-only database...',flush=True)
    src=sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True,timeout=3)
    dst=sqlite3.connect(tmp)
    try:src.backup(dst,pages=-1)
    finally:dst.close();src.close()
    with sqlite3.connect(tmp.resolve().as_uri()+'?mode=ro',uri=True) as db:
        check=db.execute('PRAGMA quick_check').fetchall()
    if check != [('ok',)]:raise SystemExit('Export integrity failed; partial file retained for inspection.')
    gztemp=out.with_suffix('.gz.partial')
    with tmp.open('rb') as f,gzip.open(gztemp,'wb',compresslevel=1) as g:
        shutil.copyfileobj(f,g,1024*1024)
    gztemp.replace(out);tmp.unlink()
    (outdir/f'c481_{stamp}_config.json').write_text(json.dumps(cfg,indent=2)+'\n')
    h=hashlib.sha256()
    with out.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    print('Integrity: ok')
    print('File:',out)
    print('SHA256:',h.hexdigest())

if __name__=='__main__':main()
