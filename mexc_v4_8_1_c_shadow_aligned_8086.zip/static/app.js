'use strict';
const $ = id => document.getElementById(id);
const esc = x => String(x ?? '—').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const number = (x,n=2) => x==null || !Number.isFinite(Number(x)) ? '—' : (Math.abs(Number(x)) < .5 * 10**(-n) ? 0 : Number(x)).toLocaleString('fr-FR',{minimumFractionDigits:n,maximumFractionDigits:n});
const bp = x => x==null ? '—' : number(x,2)+' bp';
const su = x => x==null ? '—' : number(x,5)+' SU';
const age = x => x==null?'—':x<1?number(x*1000,0)+' ms':x<60?number(x,1)+' s':number(x/60,1)+' min';
const clock = x => x ? new Date(x*1000).toLocaleTimeString('fr-FR') : '—';
const pct = (a,b) => b>0 ? number(100*a/b,1)+' %' : '—';
const tag = (x,cls='') => `<span class="tag ${esc(cls)}">${esc(x)}</span>`;
let data = null;
function text(id,x,cls){$(id).textContent=x??'—';if(cls!==undefined)$(id).className=cls;}
function simpleRows(rows,render,empty='Aucune donnée observée.'){
  return rows?.length ? rows.map(render).join('') : `<div class="empty">${esc(empty)}</div>`;
}
function signalCard(p){
  const valid=p.testable && !p.stale, signal=p.signal_eligible && valid;
  const tone=signal?'good':p.protected_edge_bps==null?'muted':p.protected_edge_bps>=0?'warn':'muted';
  const label=p.stale?'PÉRIMÉ':signal?'SIGNAL SHADOW':valid?'TESTABLE · SANS SIGNAL':'NON TESTABLE';
  return `<article class="signal ${signal?'signal-positive':''}">
    <div class="signalhead"><div class="route mono">${esc(p.route)}<small>Plafond ${su(p.size)} · engagé ${su(p.spend_su)}</small></div><span class="badge ${tone}">${label}</span></div>
    <div class="edge ${tone}">${bp(p.protected_edge_bps)}<small>exécutable protégé estimé</small></div>
    <div class="signalmetrics"><div><label>Brut BBO</label><span>${bp(p.raw_bps)}</span></div><div><label>Cash hors dust</label><span>${bp(p.net_cash_bps)}</span></div><div><label>Dust décoté</label><span>${su(p.dust_mark_su)}</span></div></div>
    <small>Frais taux : ${number(p.fee1_bps,2)} / ${number(p.fee2_bps,2)} bp · réserves ${number(p.l1_reserve_x,1)}× / ${number(p.l2_reserve_x,1)}× · observé il y a ${age(p.age_s)}</small>
    <div class="tags">${(p.c_reasons||[]).map(x=>tag(x)).join('')}${(p.reasons||[]).map(x=>tag(x,'warn')).join('')}${p.signal_note?tag(p.signal_note,'warn'):''}</div></article>`;
}
function renderSizes(){
  if(!data)return;
  const rows=(data.latest_sizes||[]).filter(x=>x.route===$('route').value).sort((a,b)=>a.size-b.size);
  $('sizes').innerHTML=rows.length?rows.map(x=>`<tr><td>${su(x.size)}${x.same_quantity_as_cap_su!=null?`<small>Même quantité que cap ${number(x.same_quantity_as_cap_su,2)}</small>`:''}</td>
    <td>${su(x.spend_su)}<small>inutilisé ${su(x.unspent_su)}</small></td><td class="${x.signal_eligible?'good':''}"><b>${bp(x.protected_edge_bps)}</b></td><td>${bp(x.net_cash_bps)}<small>${su(x.cash_pnl_su)}</small></td><td>${su(x.dust_mark_su)}</td>
    <td class="mono">${esc(x.q1)}<br>→ ${esc(x.q2)}</td><td>${number(x.fee1_bps,2)} / ${number(x.fee2_bps,2)} bp<small>effectives ${number(x.effective_fee1_bps,2)} / ${number(x.effective_fee2_bps,2)} bp</small></td>
    <td>${(x.reasons||[]).map(r=>tag(r,'warn')).join('')||tag(x.testable?'C testable':'non testable')}<small>${number(x.sizing_candidates_valid,0)} / ${number(x.sizing_candidates_tested,0)} quantités retenues</small></td></tr>`).join(''):'<tr><td colspan="8">Aucun C mesuré pour cette route.</td></tr>';
  const p=rows.find(x=>x.size===10 && x.spend_su!=null)||rows.find(x=>x.spend_su!=null);
  $('waterfall').innerHTML=p?`<p>Décomposition du plafond ${su(p.size)} — ${esc(p.route)}</p><div class="waterfall">
    <div>Coût aux niveaux affichés<strong>${su(p.observed_depth_cost_su)}</strong></div><div>Surcoût limite L1<strong>${su(p.l1_price_bound_cost_su)}</strong></div>
    <div>Manque à gagner limite L2<strong>${su(p.l2_price_bound_cost_su)}</strong></div><div>Commission L1 en base<strong>${esc(p.fee_base_units)}</strong></div>
    <div>Commission L2 en quote<strong>${esc(p.fee_quote_units)}</strong></div><div>Cash après limites/frais<strong>${su(p.cash_pnl_su)}</strong></div>
    <div>Dust après décote<strong>${su(p.dust_mark_su)}</strong></div><div>Réserve C supplémentaire<strong>${su(p.thin_buffer_su)}</strong></div></div>
    <p class="note">Effet des arrondis de commissions : taux L1 ${bp(p.fee1_bps)} → effectif ${bp(p.effective_fee1_bps)}. Taux L2 ${bp(p.fee2_bps)} → effectif ${bp(p.effective_fee2_bps)}. Ce sont des hypothèses conservatrices, pas des commissions réalisées.</p>
    <p class="note">Sensibilité à la réserve C (diagnostic sur le même plan) : ${Object.entries(p.buffer_sensitivity_bps||{}).map(([k,v])=>esc(k)+' bp → '+bp(v)).join(' · ')}</p>`:'<p class="note">Décomposition indisponible : carnet, rules, frais ou timing non validés.</p>';
}
function miniDiagnostics(rows){
  return simpleRows(rows?.slice(0,12),p=>`<div class="minirow"><b class="mono">${esc(p.route)} · cap ${su(p.size)}</b><span>Brut ${bp(p.raw_bps)} · protégé ${bp(p.protected_edge_bps)} · âge ${age(p.age_s)}</span><div class="tags">${(p.strict_reasons||p.reasons||[]).map(x=>tag(x,'warn')).join('')}</div></div>`);
}
function render(d){
  data=d;const ev=d.evidence||{},ref=d.references||{},feed=d.feed||{},st=d.storage||{},cov=d.coverage||{},policy=d.policy||{},t=d.timing||{};
  $('demo').classList.toggle('hide',!d.demo);
  text('state',d.state,d.state==='SHADOW_COLLECTING'?'badge good':'badge warn');text('clock',clock(d.served_ts||d.now));
  const alerts=[];
  if(d.orders_possible!==false)alerts.push('Statut de sécurité incohérent : ne pas utiliser ce processus.');
  if(st.healthy===false)alerts.push('Stockage arrêté : '+(st.error||'cause inconnue'));
  if(d.last_error)alerts.push(d.last_error);if(d.heartbeat_age_s>3)alerts.push('Données de service périmées');
  $('alert').textContent=alerts.join(' · ');$('alert').classList.toggle('hide',!alerts.length);
  text('validC',number((d.latest_sizes||[]).filter(p=>p.testable && !p.stale).length,0));
  text('validCNote',`${cov.hot_tokens?.length||0}/${cov.hot_limit||0} tokens suivis · ${cov.tokens_with_two_pairs??'—'} à deux paires`);
  text('episodes',number(ev.episodes_opened||0,0));text('episodesNote',`${ev.active_episodes||0} ouverts · ${ev.episodes_closed_observed||0} clos observés · ${ev.episodes_censored||0} censurés`);
  text('learning',number(ev.learning_trials_completed||0,0));text('learningNote',`${ev.learning_trials_started||0} démarrés · ${ev.signal_trials_completed||0} essais signal terminés`);
  text('fees',`${ref.fee_fresh??'—'} / ${ref.fee_total??'—'}`);text('feesNote',`${ref.rules??'—'} règles · aucune clé API chargée`);
  // One headline card per route, not ten almost identical budget caps.
  const seen=new Set();const main=(d.top10||[]).filter(p=>!seen.has(p.route)&&seen.add(p.route));
  $('signals').innerHTML=simpleRows(main,signalCard,'Aucun signal C chiffrable actuellement. Voir les raisons et la synchronisation ci-dessous ; les A/B sont exclus ici.');
  text('policy',`Participation ${number(100*policy.participation_fraction,0)} % · coussins L1/L2 ${number(policy.l1_cushion_bps,2)}/${number(policy.l2_cushion_bps,2)} bp · réserve C ${number(policy.thin_buffer_bps,2)} bp · épisode dès ${number(policy.episode_entry_bps,2)} bp protégés avec cash ≥ ${number(policy.signal_cash_floor_bps,2)} bp. Paramètres SHADOW, pas seuils LIVE validés.`);
  const routes=[...new Set((d.latest_sizes||[]).map(x=>x.route))].sort(),selected=$('route').value;
  $('route').innerHTML=routes.length?routes.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join(''):'<option value="">Aucune route C</option>';
  if(routes.includes(selected))$('route').value=selected;renderSizes();
  text('localSkew',`${number(t.local_skew_ms?.p50,1)} / ${number(t.local_skew_ms?.p95,1)} ms`);text('localSkewNote',`seuil strict ${number(policy.max_local_skew_ms,0)} ms · ${t.local_skew_ms?.n||0} dernières paires`);
  text('exchangeSkew',`${number(t.exchange_skew_ms?.p50,1)} / ${number(t.exchange_skew_ms?.p95,1)} ms`);text('exchangeSkewNote',`seuil strict ${number(policy.max_exchange_skew_ms,0)} ms`);
  text('clockError',number(ref.clock?.uncertainty_ms,2)+' ms');text('clockErrorNote',`offset ${number(ref.clock?.offset_ms,2)} ms · ${ref.clock_selection?.window_samples??'—'} échantillons récents`);
  $('syncDetails').innerHTML=`<div><b>Trames reçues utilisables</b>${number(feed.depth_frames,0)} · dont ${number(feed.reobserved_unchanged||0,0)} réobservations identiques</div>
    <div><b>Messages ignorés</b>${number(feed.old_version||0,0)} versions anciennes · ${number(feed.duplicate_same_timestamp_or_disabled||0,0)} doublons sans nouveau temps</div>
    <div><b>Contradictions de version</b>${number(feed.same_version_content_conflict||0,0)} · mise à l'écart jusqu'à nouvelle version</div>
    <div><b>Attente courte P95</b>${number(t.pair_wait_ms?.p95,2)} ms · avant de simuler L1</div><div><b>Calcul des 6 plafonds P95</b>${number(t.model_batch_ms?.p95,2)} ms</div>
    <div><b>Dernière trame / abonnements</b>${age(feed.last_frame_age_s)} · ${feed.channels??'—'}/${feed.desired??'—'}</div>`;
  $('survival').innerHTML=[50,100,250,500].map(h=>{const x=ev.horizons?.[String(h)]||{};return `<tr><td>${h} ms</td><td>${x.observed||0} / ${x.total||0}</td><td>${pct(x.liquidity_ok,x.observed)}</td><td>${pct(x.positive,x.observed)}</td><td>${x.censored||0}</td><td>${x.unchanged_reobservations||0}</td><td>${x.late_diagnostic||0}</td><td>${number(x.p95_actual_ms,1)} ms</td><td>${bp(x.p50_remaining_bps)}</td><td>${x.signal_only?.observed||0} / ${x.signal_only?.total||0}</td></tr>`;}).join('');
  $('episodeRows').innerHTML=simpleRows(d.recent_episodes,p=>`<div class="minirow"><b class="mono">${esc(p.route)}</b>${clock(p.start_ts)} → ${clock(p.end_ts)} · ${esc(p.status)}<small>Plafonds propres : ${esc(p.clean_sizes?.join(' / ')||'aucun')}</small></div>`,'Aucun épisode de signal. Les essais de liquidité peuvent néanmoins progresser.');
  $('stages').innerHTML=simpleRows(ev.stages?.slice(0,15),p=>`<div class="minirow"><b class="mono">${esc(p.route)} · cap ${su(p.size)}</b>${esc(p.label)}<small>${p.clean_episodes||0} épisodes propres / ${p.total_episodes||0} · aucun LIVE autorisé</small></div>`);
  const reasons=Object.entries(d.decisions||{}).filter(([k])=>!['size_evaluations','pair_evaluations'].includes(k)).sort((a,b)=>b[1]-a[1]);
  $('reasons').innerHTML=reasons.slice(0,16).map(([k,v])=>`<div class="reason"><span>${esc(k)}</span><b>${number(v,0)}</b></div>`).join('');
  text('relaxedNote',`${d.diagnostic_timing_counts?.evaluated||0} simulations exploratoires · ${d.diagnostic_timing_counts?.c_math_visible||0} C chiffrables · ${d.diagnostic_timing_counts?.positive_but_not_proven||0} positives mais NON prouvées. Aucune ne compte comme signal strict.`);
  $('relaxed').innerHTML=miniDiagnostics(d.relaxed_diagnostics?.filter(p=>p.is_c).slice(0,3));
  $('diagnostics').innerHTML=miniDiagnostics(d.diagnostics);
  $('historical').innerHTML=miniDiagnostics(d.best_since_start?.map(p=>({...p,age_s:(d.now||0)-p.ts})));
  $('discovery').innerHTML=simpleRows(d.discovery?.slice(0,20),p=>`<div class="minirow"><b>${esc(p.token)}</b>Indice brut ${bp(p.best_raw_bps)} · fees ${bp(p.fee_sum_bps)}<small>Volume minimal ${number(p.min_volume_su,0)} SU · ${p.likely_c_volume?'priorité C volume':'exploration profondeur'} · indice REST non synchronisé</small></div>`);
  const l=d.live||{},b=l.balances||{};text('liveState',l.state||'Indisponible','badge muted');text('liveBalances',`${number(b.USDC?.free,4)} / ${number(b.USDT?.free,4)}`);text('liveInventory',`${l.inventory?.zone||'—'} · ${number(100*l.inventory?.usdc_share,2)} % USDC`);text('liveDelta',l.settled?su(l.reported_delta_su):'Exposition / non disponible');text('liveFX',number(l.fx?.mid,6));text('liveNote',`Source ${age(l.age_s)} · session ${l.baseline?.session_id||'—'}`);
  $('health').innerHTML=`<div><b>WebSocket public</b>${feed.connected?'Connecté':'Non connecté'} · ${esc(feed.last_error||'aucune erreur')}</div>
    <div><b>Stockage C</b>${st.healthy?'Actif':'À contrôler'} · file ${st.queue??'—'} · perdus ${st.dropped??'—'} · écrits ${st.written??'—'}<small>${esc(st.error||'')}</small></div>
    <div><b>Horloge</b>${ref.clock_ok?'Valide':'Non validée'} · RTT récent ${number(ref.clock_selection?.latest_rtt_ms,1)} ms</div>
    <div><b>Couverture</b>${esc(cov.hot_tokens?.join(', ')||'aucun')}<small>${cov.depth_levels??20} niveaux · ${cov.exploration_slots??2} slots exploratoires</small></div>
    <div><b>Évaluations</b>${number(d.decisions?.pair_evaluations,0)} paires · ${number(d.decisions?.size_evaluations,0)} plafonds</div>
    <div><b>Version / processus</b>${esc(d.version)}<small>heartbeat ${age(d.heartbeat_age_s)} · ${esc(d.model_revision)}</small></div>`;
  text('runid',d.run_id);
}
$('route').addEventListener('change',renderSizes);
async function refresh(){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{const r=await fetch('/api/data',{cache:'no-store',signal:controller.signal});if(!r.ok)throw new Error('HTTP '+r.status);render(await r.json());}
  catch(err){text('state','INTERFACE / DONNÉES INDISPONIBLES','badge warn');text('clock',new Date().toLocaleTimeString('fr-FR'));$('alert').textContent='Dernier rafraîchissement échoué : '+String(err)+'. Les chiffres restants peuvent être anciens.';$('alert').classList.remove('hide');}
  finally{clearTimeout(timer);setTimeout(refresh,2000);}
}
refresh();
