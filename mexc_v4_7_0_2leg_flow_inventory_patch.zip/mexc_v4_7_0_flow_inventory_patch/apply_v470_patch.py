#!/usr/bin/env python3
from __future__ import annotations
import argparse, ast, json, os, py_compile, shutil, tempfile, re
from pathlib import Path

FLOW_IMPORT="from .flow_policy import inventory_state, inventory_role, threshold_bps, size_allowed, qualification_mode, effective_threshold"
HELPERS='    def _inventory_recovery_active(self):\n        return False\n\n    def _flow_inventory(self):\n        return inventory_state(self._available("USDC"),self._available("USDT"),self.cfg)\n\n    def _flow_structure_ok(self,e):\n        if getattr(e,"liquidity_class",None) not in ("A","B"):return False\n        if not bool(getattr(e,"data_valid",True)) or not bool(getattr(e,"timing_valid",True)) or not bool(getattr(e,"depth_synced",True)):return False\n        if float(getattr(e,"l1_reserve_x",0) or 0)<float(self.cfg.get("liquidity_l1_reserve_multiple",5.0)):return False\n        if float(getattr(e,"l2_reserve_x",0) or 0)<float(self.cfg.get("liquidity_l2_reserve_multiple",10.0)):return False\n        return getattr(e,"stable_a",None) in self.allowed and getattr(e,"stable_b",None) in self.allowed\n\n    def _flow_survival(self,e):\n        size=float(getattr(e,"size",self.size));ss=self.db.survival_stat(e.route,size)\n        mode=qualification_mode(int(ss.get("trials") or 0),size,self.size,\n            float(ss.get("l2_survival_100") or 0),float(ss.get("l2_survival_250") or 0),float(ss.get("l2_survival_500") or 0),\n            e.liquidity_class,self.cfg)\n        return mode,ss\n\n    def _flow_nominal_guaranteed(self,e):\n        fi1=self._fee_info(e.symbol1);fi2=self._fee_info(e.symbol2)\n        if bool(self.cfg.get("live_require_account_fees",True)) and (not fi1.get("usable_live") or not fi2.get("usable_live")):\n            return None,{"reason":"ACCOUNT_FEE_UNKNOWN","fee1":fi1,"fee2":fi2}\n        f1=float(fi1.get("taker_bps") or 0);f2=float(fi2.get("taker_bps") or 0);raw=getattr(e,"raw_edge_bps",None)\n        if raw is None:return None,{"reason":"RAW_EDGE_MISSING","fee1":fi1,"fee2":fi2}\n        nominal=((1+float(raw)/1e4)*(1-f1/1e4)*(1-f2/1e4)-1)*1e4\n        reserve=float(self.cfg.get("execution_price_reserve_bps",.5))\n        return nominal-reserve,{"fee1_bps":f1,"fee2_bps":f2,"fee1_source":fi1.get("source"),"fee2_source":fi2.get("source"),\n                                "nominal_net_bps":nominal,"execution_reserve_bps":reserve}\n\n    def _flow_candidate_info(self,e):\n        qf=float(self.cfg.get("qualification_depth_fraction",.25))\n        if abs(float(getattr(e,"fraction",qf))-qf)>1e-12 or not self._flow_structure_ok(e):return None\n        state=self._flow_inventory();role=inventory_role(e.stable_a,e.stable_b,state)\n        if role=="OTHER" or not size_allowed(float(e.size),e.stable_a,e.stable_b,state,role,self.cfg,self._available(e.stable_a)):return None\n        qmode,ss=self._flow_survival(e)\n        if qmode is None:return None\n        guaranteed,meta=self._flow_nominal_guaranteed(e)\n        if guaranteed is None:return None\n        base=threshold_bps(e.liquidity_class,role,state["zone"],self.cfg)\n        if base is None:return None\n        threshold=effective_threshold(base,qmode,e.liquidity_class,self.cfg)\n        if float(guaranteed)<=float(threshold):return None\n        return {"role":role,"zone":state["zone"],"inventory":state,"qualification":qmode,"threshold_bps":float(threshold),\n                "guaranteed_edge_bps":float(guaranteed),"survival":ss,**meta}\n\n    def _event_submission_mode(self,e):\n        info=self._flow_candidate_info(e)\n        return None if info is None else "FLOW_"+str(info["qualification"])+"_"+str(info["role"])\n\n    def select_live_candidate(self,ev,qf):\n        qf=float(qf);candidates=[]\n        for e in ev:\n            if abs(float(getattr(e,"fraction",qf))-qf)>1e-12:continue\n            info=self._flow_candidate_info(e)\n            if info is not None:candidates.append((e,info))\n        if not candidates:return None\n        corrective=[x for x in candidates if x[1]["role"]=="CORRECTIVE"]\n        if corrective:return max(corrective,key=lambda x:(float(x[0].size),float(x[1]["guaranteed_edge_bps"])))[0]\n        return max(candidates,key=lambda x:float(x[1]["guaranteed_edge_bps"]))[0]\n\n    def _capture_flow_session_baseline(self):\n        ts=time.time();session_id="V470-"+time.strftime("%Y%m%d-%H%M%S");nz={}\n        for asset,b in (self._balances or {}).items():\n            free=float((b or {}).get("free",0) or 0);locked=float((b or {}).get("locked",0) or 0)\n            if abs(free)+abs(locked)>1e-18:nz[str(asset)]={"free":free,"locked":locked,"total":free+locked}\n        usdc=float(nz.get("USDC",{}).get("total",0) or 0);usdt=float(nz.get("USDT",{}).get("total",0) or 0)\n        try:dust=float((self.db.live_dust_summary() or {}).get("est_usd") or 0)\n        except Exception:dust=0.0\n        snap={"session_id":session_id,"ts":ts,"USDC":usdc,"USDT":usdt,"stable_units":usdc+usdt,\n              "strategy_dust_est_usd":dust,"stable_units_plus_dust":usdc+usdt+dust,"nonzero_assets":nz}\n        with self.db.lock,self.db.conn() as c:\n            c.execute("CREATE TABLE IF NOT EXISTS flow_session_baselines(session_id TEXT PRIMARY KEY,ts REAL,usdc REAL,usdt REAL,stable_units REAL,dust_est_usd REAL,stable_units_plus_dust REAL,balances_json TEXT)")\n            c.execute("INSERT OR REPLACE INTO flow_session_baselines VALUES(?,?,?,?,?,?,?,?)",\n                      (session_id,ts,usdc,usdt,usdc+usdt,dust,usdc+usdt+dust,json.dumps(nz,separators=(\',\',\':\'))))\n        self._flow_session_baseline=snap\n        self.db.add_live_event(None,"FLOW_SESSION_BASELINE",{"session_id":session_id,"USDC":usdc,"USDT":usdt,"stable_units":usdc+usdt,\n            "strategy_dust_est_usd":dust,"stable_units_plus_dust":usdc+usdt+dust,"nonzero_asset_count":len(nz)})\n\n    def _flow_status(self):\n        state=self._flow_inventory();base=getattr(self,"_flow_session_baseline",{}) or {}\n        try:dust=float((self.db.live_dust_summary() or {}).get("est_usd") or 0)\n        except Exception:dust=0.0\n        current=state["total"]+dust;baseline=float(base.get("stable_units_plus_dust",current) or current)\n        return {"mode":"2LEG_FLOW_INVENTORY","inventory":state,"session_baseline":base,\n                "current_stable_units_plus_dust":current,"session_delta_stable_units":current-baseline,\n                "base_size_usd":self.size,"corrective_sizes_usd":self.cfg.get("flow_corrective_sizes_usd",[25,20,10]),\n                "max_trade_pct":float(self.cfg.get("flow_max_trade_pct",.10)),\n                "full_trials":int(self.cfg.get("live_min_survival_trials",1000)),\n                "probation_trials":int(self.cfg.get("flow_probation_min_trials",500)),\n                "route_cooldown_s":float(self.cfg.get("flow_route_cooldown_s",5.0))}\n'
SUBMIT='    def submit(self,e):\n        if self.stop or not self.client:return False\n        if self._flow_candidate_info(e) is None or not self.execution_enabled:return False\n        if bool(self.cfg.get("live_require_private_ws",True)) and (not self.private or not self.private.connected):self.skipped+=1;return False\n        now=time.time()\n        with self.lock:\n            if self.state!="READY" or self.active_cycle is not None:return False\n            if not hasattr(self,"_flow_route_last_ts"):self._flow_route_last_ts={}\n            if now-float(self._flow_route_last_ts.get(e.route,0) or 0)<float(self.cfg.get("flow_route_cooldown_s",5.0)):return False\n            if not self.q.empty():return False\n            self._flow_route_last_ts[e.route]=now\n        try:self.q.put_nowait((e,time.perf_counter_ns()));self.submitted+=1;return True\n        except queue.Full:return False\n'
LIVE_GATE='    def _live_gate(self,e):\n        info=self._flow_candidate_info(e)\n        if info is None:return False,"FLOW_EVENT_NO_LONGER_ELIGIBLE"\n        trade_size=float(getattr(e,"size",self.size));reserve=float(self.cfg.get("live_min_stable_reserve_usd",20))\n        bal_age=max(0.0,time.time()-float(self._balances_ts or 0)) if self._balances_ts else math.inf\n        if bal_age>float(self.cfg.get("live_balance_cache_max_age_s",5.0)):return False,"BALANCE_CACHE_STALE"\n        if self._available(e.stable_a)<trade_size+reserve:return False,"BALANCE_RESERVE"\n        qmode,ss=self._flow_survival(e)\n        if qmode is None:return False,"SURVIVAL_NOT_QUALIFIED"\n        guaranteed,meta=self._flow_nominal_guaranteed(e)\n        if guaranteed is None:return False,meta.get("reason","ACCOUNT_FEE_UNKNOWN")\n        inv=self._flow_inventory();role=inventory_role(e.stable_a,e.stable_b,inv)\n        if not size_allowed(trade_size,e.stable_a,e.stable_b,inv,role,self.cfg,self._available(e.stable_a)):return False,"FLOW_SIZE_OR_INVENTORY"\n        base=threshold_bps(e.liquidity_class,role,inv["zone"],self.cfg)\n        if base is None:return False,"FLOW_HARD_AGGRAVATING_BLOCK"\n        threshold=effective_threshold(base,qmode,e.liquidity_class,self.cfg)\n        if float(guaranteed)<=float(threshold):return False,"FLOW_EDGE"\n        return True,{**meta,"live_net_bps":float(meta["nominal_net_bps"]),"guaranteed_edge_bps":float(guaranteed),\n            "threshold_bps":float(threshold),"balance_age_s":bal_age,"survival":ss,"trade_size":trade_size,\n            "inventory_mode":"FLOW","inventory_role":role,"inventory_zone":inv["zone"],\n            "inventory_usdc_share":inv["usdc_share"],"qualification_mode":qmode,"accounting":"STABLE_UNITS_1TO1"}\n'
START_OLD='            self._balances=self.balance_client.balances();self._balances_ts=time.time();self._startup_balances=dict(self._balances)\n            self.db.save_live_inventory_baseline(self._balances)\n'
START_NEW='            _b1=self.balance_client.balances()\n            time.sleep(float(self.cfg.get("flow_startup_balance_check_delay_s",0.35)))\n            _b2=self.balance_client.balances()\n            _tol=float(self.cfg.get("flow_startup_balance_tolerance_usd",0.001))\n            for _asset in ("USDC","USDT"):\n                _v1=float((_b1.get(_asset,{}) or {}).get("free",0) or 0)+float((_b1.get(_asset,{}) or {}).get("locked",0) or 0)\n                _v2=float((_b2.get(_asset,{}) or {}).get("free",0) or 0)+float((_b2.get(_asset,{}) or {}).get("locked",0) or 0)\n                if abs(_v2-_v1)>_tol:raise RuntimeError(f"START_BALANCE_UNSTABLE {_asset}: first={_v1} second={_v2}")\n            self._balances=_b2;self._balances_ts=time.time();self._startup_balances=dict(self._balances)\n            self.db.save_live_inventory_baseline(self._balances)\n            self._capture_flow_session_baseline()\n'

def class_methods(src,class_name):
    tree=ast.parse(src)
    for node in tree.body:
        if isinstance(node,ast.ClassDef) and node.name==class_name:
            return {n.name:n for n in node.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    raise RuntimeError("class not found: "+class_name)

def replace_methods(src,class_name,replacements):
    lines=src.splitlines(True);methods=class_methods(src,class_name);edits=[]
    for name,repl in replacements.items():
        n=methods.get(name)
        if n is None:raise RuntimeError(f"method not found: {class_name}.{name}")
        edits.append((n.lineno-1,n.end_lineno,repl.rstrip()+"\n\n" if repl else ""))
    for a,b,repl in sorted(edits,reverse=True):lines[a:b]=[repl] if repl else []
    out="".join(lines);ast.parse(out);return out

def patch_start(src):
    n=class_methods(src,"MicroLiveExecutor").get("start")
    if n is None:raise RuntimeError("start method missing")
    lines=src.splitlines(True);a=n.lineno-1;b=n.end_lineno;block="".join(lines[a:b])
    if "_capture_flow_session_baseline()" in block:return src
    pat=re.compile(r'(?m)^(?P<ind>[ \t]+)self\._balances=self\.balance_client\.balances\(\);self\._balances_ts=time\.time\(\);self\._startup_balances=dict\(self\._balances\)\n(?P=ind)self\.db\.save_live_inventory_baseline\(self\._balances\)\n')
    m=pat.search(block)
    if not m:raise RuntimeError("start balance anchor not found")
    ind=m.group("ind")
    repl="".join((ind+ln[12:] if ln.startswith("            ") else ln) for ln in START_NEW.splitlines(True))
    block=block[:m.start()]+repl+block[m.end():];lines[a:b]=[block]
    out="".join(lines);ast.parse(out);return out

def patch_status(src):
    n=class_methods(src,"MicroLiveExecutor").get("status")
    if n is None:raise RuntimeError("status method missing")
    lines=src.splitlines(True);a=n.lineno-1;b=n.end_lineno;block="".join(lines[a:b])
    if 'out["flow_inventory"]' in block:return src
    anchor="        return out\n"
    if block.count(anchor)!=1:raise RuntimeError("status return-out anchor not unique")
    block=block.replace(anchor,'        out["flow_inventory"]=self._flow_status()\n        return out\n',1)
    lines[a:b]=[block];out="".join(lines);ast.parse(out);return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument("runtime");ap.add_argument("--flow-policy-file",required=True);args=ap.parse_args()
    root=Path(args.runtime).resolve();live=root/"v4rex"/"live.py";cfgp=root/"config.json";cfgexp=root/"config.example.json";start=root/"start.sh"
    if not live.exists() or not cfgp.exists():raise SystemExit("Target runtime missing live.py/config.json")
    original=live.read_text();required=["def select_live_candidate","def _live_gate","def submit","V4661_LIVE_10USD","MaintenanceCoordinator"]
    missing=[x for x in required if x not in original]
    if missing:raise SystemExit("Not expected V4.6.6.1 runtime; missing: "+", ".join(missing))
    s=original
    if FLOW_IMPORT not in s:
        anchor="from .maintenance import MaintenanceCoordinator"
        if anchor not in s:raise RuntimeError("maintenance import anchor missing")
        s=s.replace(anchor,anchor+"\n"+FLOW_IMPORT,1)
    methods=class_methods(s,"MicroLiveExecutor")
    replacements={"_inventory_recovery_active":HELPERS,"submit":SUBMIT,"_live_gate":LIVE_GATE}
    for x in ["_stable_fx_mid","_economic_net_bps","_economic_expected_from_eval","_recovery_structure_ok","_is_reverse_recovery_event","_event_submission_mode","_record_recovery_shadow","select_live_candidate"]:
        if x in methods:replacements[x]=""
    s=replace_methods(s,"MicroLiveExecutor",replacements);s=patch_start(s);s=patch_status(s)
    s=s.replace("V4661_LIVE_10USD","V470_FLOW_10USD")
    ast.parse(s)
    cfg=json.loads(cfgp.read_text())
    cfg.update({
      "execution_enabled":False,"live_arm_token":"V470_FLOW_10USD","inventory_recovery_enabled":False,
      "flow_mode":"2LEG_FLOW_INVENTORY","flow_corrective_sizes_usd":[25,20,10],"flow_max_trade_pct":0.10,
      "flow_soft_deviation":0.05,"flow_warning_deviation":0.10,"flow_strong_deviation":0.15,"flow_hard_deviation":0.20,
      "flow_post_corrective_min_usdc_share":0.45,"flow_post_corrective_max_usdc_share":0.55,
      "flow_probation_min_trials":500,"flow_probation_survival_min":1.0,"flow_probation_a_min_bps":3.0,"flow_probation_b_min_bps":4.0,
      "flow_route_cooldown_s":5.0,"flow_startup_balance_check_delay_s":0.35,"flow_startup_balance_tolerance_usd":0.001,
      "flow_mild_corrective_a_bps":0.5,"flow_mild_corrective_b_bps":1.0,"flow_mild_aggravating_a_bps":2.0,"flow_mild_aggravating_b_bps":3.0,
      "flow_strong_corrective_a_bps":0.25,"flow_strong_corrective_b_bps":0.5,"flow_strong_aggravating_a_bps":4.0,"flow_strong_aggravating_b_bps":5.0,
      "flow_severe_corrective_a_bps":0.10,"flow_severe_corrective_b_bps":0.25,"flow_severe_aggravating_a_bps":7.0,"flow_severe_aggravating_b_bps":8.0,
      "flow_hard_corrective_a_bps":0.0,"flow_hard_corrective_b_bps":0.10,"rebalance_mode":"EMERGENCY_ONLY","rebalance_target_usdc_ratio":0.50
    })
    with tempfile.TemporaryDirectory() as td:
        td=Path(td);(td/"v4rex").mkdir();(td/"v4rex"/"live.py").write_text(s);(td/"v4rex"/"flow_policy.py").write_text(Path(args.flow_policy_file).read_text())
        py_compile.compile(str(td/"v4rex"/"live.py"),doraise=True);py_compile.compile(str(td/"v4rex"/"flow_policy.py"),doraise=True)
    for p in (live,cfgp,cfgexp,start):
        if p.exists():
            b=p.with_suffix(p.suffix+".PRE_V470")
            if not b.exists():shutil.copy2(p,b)
    (root/"v4rex"/"flow_policy.py").write_text(Path(args.flow_policy_file).read_text())
    tmp=live.with_suffix(".py.V470.tmp");tmp.write_text(s);os.replace(tmp,live)
    tmpcfg=cfgp.with_suffix(".json.V470.tmp");tmpcfg.write_text(json.dumps(cfg,indent=2)+"\n");os.replace(tmpcfg,cfgp)
    if start.exists():
        x=start.read_text().replace("V4.6.6.1 FX-NORMALIZED LIVE","V4.7.0 2LEG FLOW INVENTORY")
        start.write_text(x)
    print("PATCHED V4.7.0 FLOW:",root);print("ARM TOKEN: V470_FLOW_10USD");print("execution_enabled reset to false")
    print("Stable Units 1:1 admission; strict startup account baseline enabled.")
    print("FORCE-L2 / reconciliation / tradeFee / protected bags / dust ownership unchanged.")

if __name__=="__main__":main()
