import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from v4rex.flow_policy import inventory_state,inventory_role,threshold_bps,size_allowed,qualification_mode,effective_threshold
CFG={"live_trade_size_usd":10,"live_min_stable_reserve_usd":20,"liquidity_a_min_net_edge_bps":1,"liquidity_b_min_net_edge_bps":2,
"flow_corrective_sizes_usd":[25,20,10],"flow_max_trade_pct":.10,"flow_soft_deviation":.05,"flow_warning_deviation":.10,"flow_strong_deviation":.15,"flow_hard_deviation":.20,
"flow_post_corrective_min_usdc_share":.45,"flow_post_corrective_max_usdc_share":.55,"live_min_survival_trials":1000,
"flow_probation_min_trials":500,"flow_probation_survival_min":1.0,"flow_probation_a_min_bps":3,"flow_probation_b_min_bps":4}
def test_center():
    s=inventory_state(141.827843,150.92,CFG);assert s["zone"]=="CENTER";assert inventory_role("USDC","USDT",s)=="NEUTRAL"
def test_mild():
    s=inventory_state(120,180,CFG);assert s["zone"]=="MILD";assert inventory_role("USDT","USDC",s)=="CORRECTIVE"
    assert threshold_bps("A","CORRECTIVE","MILD",CFG)==.5;assert threshold_bps("B","AGGRAVATING","MILD",CFG)==3
def test_hard():
    s=inventory_state(60,240,CFG);assert s["zone"]=="HARD";assert threshold_bps("A","AGGRAVATING","HARD",CFG) is None
def test_size_cap():
    s=inventory_state(100,193,CFG);assert size_allowed(25,"USDT","USDC",s,"CORRECTIVE",CFG,193);assert not size_allowed(50,"USDT","USDC",s,"CORRECTIVE",CFG,193)
def test_neutral_base():
    s=inventory_state(145,148,CFG);assert size_allowed(10,"USDC","USDT",s,"NEUTRAL",CFG,145);assert not size_allowed(25,"USDC","USDT",s,"NEUTRAL",CFG,145)
def test_full():assert qualification_mode(1000,25,10,1,1,1,"A",CFG)=="FULL"
def test_probation():assert qualification_mode(500,10,10,1,1,1,"A",CFG)=="PROBATION"
def test_no_big_probation():assert qualification_mode(500,25,10,1,1,1,"A",CFG) is None
def test_perfect_probation():assert qualification_mode(900,10,10,.999,1,1,"A",CFG) is None
def test_probation_edge():assert effective_threshold(.5,"PROBATION","A",CFG)==3
