# V4.7.0 — 2LEG FLOW INVENTORY

- Stable Units 1:1 drive 2-leg admission.
- $10 normal trades; $20/$25 only in the corrective inventory direction and only with FULL exact route×size qualification.
- Corrective max size is capped at 10% of total USDC+USDT.
- Continuous inventory zones change thresholds instead of blocking after one trade.
- 500–999 trials: $10 probation only, perfect S100/S250/S500, ≥3bp A / ≥4bp B.
- >=1000 trials: FULL qualification.
- Cooldown is per route (5s), not a global pause across all routes.
- One token exposure maximum remains.
- FORCE-L2, UNKNOWN reconciliation, account tradeFee, bag protection and dust attribution are untouched.
- Direct stable rebalance remains EMERGENCY_ONLY, target 50/50.
- Startup account check reads signed balances twice 350ms apart and persists the complete non-zero snapshot. External capital already present before restart becomes baseline capital, not PnL.
