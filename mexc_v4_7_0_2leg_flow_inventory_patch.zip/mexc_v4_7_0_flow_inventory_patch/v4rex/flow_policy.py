from __future__ import annotations

def _f(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return float(default)

def inventory_state(usdc, usdt, cfg):
    usdc=max(0.0,_f(usdc));usdt=max(0.0,_f(usdt));total=usdc+usdt
    share=usdc/total if total>0 else 0.5
    d=abs(share-0.5)
    soft=_f(cfg.get("flow_soft_deviation",0.05))
    warning=_f(cfg.get("flow_warning_deviation",0.10))
    strong=_f(cfg.get("flow_strong_deviation",0.15))
    hard=_f(cfg.get("flow_hard_deviation",0.20))
    if d<=soft:zone="CENTER"
    elif d<=warning:zone="MILD"
    elif d<=strong:zone="STRONG"
    elif d<=hard:zone="SEVERE"
    else:zone="HARD"
    if share<0.5-soft:needed="USDT_TO_USDC"
    elif share>0.5+soft:needed="USDC_TO_USDT"
    else:needed="NONE"
    return {"USDC":usdc,"USDT":usdt,"total":total,"usdc_share":share,
            "deviation":d,"zone":zone,"needed_direction":needed}

def route_direction(stable_a, stable_b):
    if stable_a=="USDT" and stable_b=="USDC":return "USDT_TO_USDC"
    if stable_a=="USDC" and stable_b=="USDT":return "USDC_TO_USDT"
    return "OTHER"

def inventory_role(stable_a, stable_b, state):
    rd=route_direction(stable_a,stable_b);need=state.get("needed_direction","NONE")
    if need=="NONE":return "NEUTRAL"
    if rd==need:return "CORRECTIVE"
    if rd in ("USDT_TO_USDC","USDC_TO_USDT"):return "AGGRAVATING"
    return "OTHER"

def threshold_bps(liquidity_class, role, zone, cfg):
    klass=str(liquidity_class or "")
    standard=_f(cfg.get("liquidity_a_min_net_edge_bps",1.0) if klass=="A"
                else cfg.get("liquidity_b_min_net_edge_bps",2.0))
    if zone=="CENTER" or role in ("NEUTRAL","OTHER"):return standard
    table={
      "MILD":{"CORRECTIVE":("flow_mild_corrective_a_bps","flow_mild_corrective_b_bps",0.5,1.0),
              "AGGRAVATING":("flow_mild_aggravating_a_bps","flow_mild_aggravating_b_bps",2.0,3.0)},
      "STRONG":{"CORRECTIVE":("flow_strong_corrective_a_bps","flow_strong_corrective_b_bps",0.25,0.5),
                "AGGRAVATING":("flow_strong_aggravating_a_bps","flow_strong_aggravating_b_bps",4.0,5.0)},
      "SEVERE":{"CORRECTIVE":("flow_severe_corrective_a_bps","flow_severe_corrective_b_bps",0.10,0.25),
                "AGGRAVATING":("flow_severe_aggravating_a_bps","flow_severe_aggravating_b_bps",7.0,8.0)},
      "HARD":{"CORRECTIVE":("flow_hard_corrective_a_bps","flow_hard_corrective_b_bps",0.0,0.10),
              "AGGRAVATING":(None,None,None,None)}
    }
    spec=table.get(zone,{}).get(role)
    if not spec:return standard
    ka,kb,da,db=spec
    if role=="AGGRAVATING" and zone=="HARD":return None
    return _f(cfg.get(ka,da) if klass=="A" else cfg.get(kb,db))

def size_allowed(size, stable_a, stable_b, state, role, cfg, available_source):
    size=_f(size);base=_f(cfg.get("live_trade_size_usd",10.0));reserve=_f(cfg.get("live_min_stable_reserve_usd",20.0))
    if size<=0 or _f(available_source)<size+reserve:return False
    if role!="CORRECTIVE" or state.get("zone")=="CENTER":return abs(size-base)<=1e-9
    allowed={_f(x) for x in cfg.get("flow_corrective_sizes_usd",[25,20,10])}
    if size not in allowed:return False
    total=_f(state.get("total"));cap=total*_f(cfg.get("flow_max_trade_pct",0.10))
    if size>cap+1e-9 or total<=0:return False
    usdc=_f(state.get("USDC"));low=_f(cfg.get("flow_post_corrective_min_usdc_share",0.45));high=_f(cfg.get("flow_post_corrective_max_usdc_share",0.55))
    rd=route_direction(stable_a,stable_b);post=(usdc+size)/total if rd=="USDT_TO_USDC" else (usdc-size)/total
    return low-1e-12 <= post <= high+1e-12 or ((rd=="USDT_TO_USDC" and post<0.5) or (rd=="USDC_TO_USDT" and post>0.5))

def qualification_mode(trials, size, base_size, s100, s250, s500, liquidity_class, cfg):
    n=int(trials or 0);size=_f(size);base=_f(base_size);full=int(cfg.get("live_min_survival_trials",1000));probation=int(cfg.get("flow_probation_min_trials",500))
    klass=str(liquidity_class or "")
    if klass not in ("A","B"):return None
    req100=_f(cfg.get("class_a_l2_survival_100_min",.99) if klass=="A" else cfg.get("class_b_l2_survival_100_min",.98))
    req250=_f(cfg.get("class_a_l2_survival_250_min",.98) if klass=="A" else cfg.get("class_b_l2_survival_250_min",.95))
    req500=_f(cfg.get("class_a_l2_survival_500_min",.95) if klass=="A" else cfg.get("class_b_l2_survival_500_min",.90))
    s100=_f(s100);s250=_f(s250);s500=_f(s500)
    if n>=full and s100>=req100 and s250>=req250 and s500>=req500:return "FULL"
    if abs(size-base)<=1e-9 and n>=probation:
        p=_f(cfg.get("flow_probation_survival_min",1.0))
        if s100>=p and s250>=p and s500>=p:return "PROBATION"
    return None

def effective_threshold(base_threshold, qualification, liquidity_class, cfg):
    if qualification!="PROBATION":return base_threshold
    klass=str(liquidity_class or "")
    probation=_f(cfg.get("flow_probation_a_min_bps",3.0) if klass=="A" else cfg.get("flow_probation_b_min_bps",4.0))
    return max(_f(base_threshold),probation)
