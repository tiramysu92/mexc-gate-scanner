# V4.5.1-REX — L2 Learning → Robust Qualification — SHADOW ONLY

V4.5.1 conserve le socle réseau validé en V4.4/V4.5.0 : univers complet MEXC Spot 2-leg, Base100 sur tout l'univers, Fast Lane 10 ms dynamique et Depth20 adaptatif.

Le changement est volontairement ciblé : **on apprend la capacité à terminer la jambe 2 avant que l'edge économique n'apparaisse**.

## Doctrine

Ancienne séquence V4.5.0 :

`edge rentable → candidat → commencer les trials L2`

Nouvelle séquence V4.5.1 :

`route liquide/profonde + RAW positif → apprendre L2 en continu → l'edge devient rentable → utiliser immédiatement la preuve L2 déjà accumulée`

Le RETURN/unwind reste mesuré mais ne pilote jamais l'admission. La priorité est la finalisation de L2.

## Frais et seuils TEST = futur Micro-Live

Qualification conservative :
- L1 : minimum 5 bp = 0,05 % ;
- L2 : minimum 5 bp = 0,05 %.

Classe A :
- volume quote 24 h de la jambe la moins liquide >= 1 000 000 $ ;
- trade candidate seulement si NET > **1 bp** ;
- L1 reserve >=5x ;
- L2 reserve >=10x.

Classe B :
- volume quote 24 h >=100 000 $ ;
- trade candidate seulement si NET > **2 bp** ;
- L1 reserve >=5x ;
- L2 reserve >=10x.

Classe C :
- volume <100 000 $ ;
- jamais qualifiée LIVE/TEST, même avec un edge énorme ;
- visible uniquement comme `RISKY_HIGH_EDGE` pour analyse.

## Learning gate — indépendant de l'edge NET

Un trial de survivabilité peut démarrer si :
1. la route est A ou B ;
2. on évalue la fraction de qualification 25 % ;
3. BBO/Depth sont synchronisés et le timing est valide ;
4. le RAW edge Depth est strictement >0 bp ;
5. L1 reserve >=5x ;
6. L2 reserve >=10x.

Aucun NET minimum n'est demandé pour apprendre.

Le cooldown est de **1 000 ms par route × taille**. Les tailles 10/20/25/50/100/200 $ ont donc leurs propres statistiques.

## L2 survivability

Pour exactement la quantité de token qu'aurait créée L1, L2 est re-testée à :
- T+50 ms
- T+100 ms
- T+150 ms
- T+250 ms
- T+500 ms

Mesures :
- quantité entièrement vendable ou non ;
- slippage L2 ;
- RETURN disponible et coût du RETURN, uniquement informatifs.

Après au moins 20 trials route+taille :

Classe A :
- L2 survival 100 ms >=99 % ;
- 250 ms >=98 % ;
- 500 ms >=95 %.

Classe B :
- 100 ms >=98 % ;
- 250 ms >=95 % ;
- 500 ms >=90 %.

## États

- `LEARNING_A/B` : la route apprend déjà L2 mais l'edge est encore sous le seuil économique ou la preuve n'est pas encore suffisante.
- `L2_PROVEN_A/B_WAIT_EDGE` : la survivabilité est déjà démontrée, mais l'edge actuel est trop faible.
- `A_CANDIDATE/B_CANDIDATE` : l'edge est >1/>2 bp, mais la preuve L2 n'est pas encore suffisante.
- `ROBUST_A/B` : edge + liquidité + profondeur + survivabilité L2 validés.
- `RISKY_HIGH_EDGE` : classe C, jamais qualifiable.

## Installation

```bash
./install.sh
./start.sh
sleep 120
./smoke_check.sh
```

## Export

```bash
source .venv/bin/activate
python export_run.py
```

L'export V4.5.1 inclut la DB cohérente, les opportunités, agrégats/trials L2, profils de route, audit Fast Lane et snapshot d'univers.
