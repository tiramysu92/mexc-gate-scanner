# CHANGELOG — V4.5.1 L2 Learning

- Base technique V4.5.0 conservée : full universe Base100 + Fast10 + Depth20 adaptatif.
- Correction structurante : **l'apprentissage de la survivabilité L2 est désormais indépendant du seuil économique**.
- `LEARNING_ELIGIBLE` si : classe A/B, fraction de qualification 25 %, données/timing valides, RAW edge > 0 bp, réserve L1 >=5x et réserve L2 >=10x.
- Un trial Shadow démarre même si le NET après frais 5+5 bp est négatif ou sous le seuil A/B.
- Cooldown : **1 trial maximum par route × taille toutes les 1 000 ms**.
- Les tailles 10/20/25/50/100/200 $ restent apprises séparément.
- `TRADE_CANDIDATE` reste strictement : classe A NET >1 bp ; classe B NET >2 bp.
- `ROBUST_A/B` exige à la fois le seuil économique et la preuve L2 déjà acquise.
- Nouveaux états visibles : `LEARNING_A`, `LEARNING_B`, `L2_PROVEN_A_WAIT_EDGE`, `L2_PROVEN_B_WAIT_EDGE`.
- Classe C reste non qualifiable, quel que soit l'edge.
- RETURN continue d'être mesuré uniquement comme filet de sécurité ; il ne fait pas passer le gate.
- Dashboard : filtres Learning / L2 prouvé / Candidates / Robust et compteurs dédiés.
- DB/export séparés V4.5.1 pour ne pas mélanger les données V4.5.0.
