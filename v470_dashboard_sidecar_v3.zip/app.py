from __future__ import annotations
import argparse, json, sqlite3, time, urllib.request
from pathlib import Path
from flask import Flask, jsonify, render_template
from waitress import serve

ap=argparse.ArgumentParser()
ap.add_argument("--runtime",default="/home/ubuntu/mexc-spot-2leg-v4/runtime_v470/mexc_v4_7_0_2leg_flow_inventory_ws_8081")
ap.add_argument("--scanner-url",default="http://127.0.0.1:8081")
ap.add_argument("--port",type=int,default=8085)
args=ap.parse_args()

RUNTIME=Path(args.runtime).resolve()
CFG=json.loads((RUNTIME/"config.json").read_text())
DB=Path(CFG["db_path"])
if not DB.is_absolute(): DB=(RUNTIME/DB).resolve()
SCANNER=args.scanner_url.rstrip("/")
PORT=args.port
app=Flask(__name__,template_folder="templates")

def f(x,d=0.0):
    try:return float(x)
    except Exception:return float(d)

def getj(path,default=None,timeout=2):
    try:
        with urllib.request.urlopen(SCANNER+path,timeout=timeout) as r:
            return json.loads(r.read().decode())
    except Exception:return default

def rodb():
    return sqlite3.connect(f"file:{DB}?mode=ro",uri=True,timeout=2)

def inv_role(a,b,inv):
    need=inv.get("needed_direction","NONE")
    rd="USDC_TO_USDT" if a=="USDC" and b=="USDT" else "USDT_TO_USDC" if a=="USDT" and b=="USDC" else "OTHER"
    if need=="NONE":return "NEUTRAL"
    if rd==need:return "CORRECTIVE"
    if rd!="OTHER":return "AGGRAVATING"
    return "OTHER"

def threshold(klass,role,zone):
    std=f(CFG.get("liquidity_a_min_net_edge_bps",1) if klass=="A" else CFG.get("liquidity_b_min_net_edge_bps",2))
    if zone=="CENTER" or role in ("NEUTRAL","OTHER"):return std
    vals={
      ("MILD","CORRECTIVE","A"):("flow_mild_corrective_a_bps",.5),("MILD","CORRECTIVE","B"):("flow_mild_corrective_b_bps",1),
      ("MILD","AGGRAVATING","A"):("flow_mild_aggravating_a_bps",2),("MILD","AGGRAVATING","B"):("flow_mild_aggravating_b_bps",3),
      ("STRONG","CORRECTIVE","A"):("flow_strong_corrective_a_bps",.25),("STRONG","CORRECTIVE","B"):("flow_strong_corrective_b_bps",.5),
      ("STRONG","AGGRAVATING","A"):("flow_strong_aggravating_a_bps",4),("STRONG","AGGRAVATING","B"):("flow_strong_aggravating_b_bps",5),
      ("SEVERE","CORRECTIVE","A"):("flow_severe_corrective_a_bps",.10),("SEVERE","CORRECTIVE","B"):("flow_severe_corrective_b_bps",.25),
      ("SEVERE","AGGRAVATING","A"):("flow_severe_aggravating_a_bps",7),("SEVERE","AGGRAVATING","B"):("flow_severe_aggravating_b_bps",8),
      ("HARD","CORRECTIVE","A"):("flow_hard_corrective_a_bps",0),("HARD","CORRECTIVE","B"):("flow_hard_corrective_b_bps",.10)
    }
    if zone=="HARD" and role=="AGGRAVATING":return None
    key,default=vals.get((zone,role,klass),(None,std))
    return f(CFG.get(key,default)) if key else std

def fee_api():
    x=getj("/api/fees?limit=1500",{}) or {}
    return {r.get("symbol"):r for r in x.get("rows",[]) if r.get("symbol")},x.get("summary") or {}

def direct_recent_candidates(minutes=20):
    # Source of truth for Top 10:
    # opportunity_hits gives exact symbols/raw edge; survival_aggregates gives exact
    # route×size proof used by the LIVE gate. Do not rely on the API opportunity
    # snapshot's embedded survival counters.
    since=time.time()-minutes*60
    db=rodb()
    try:
        rows=db.execute("""
        SELECT
          h.last_ts,h.route,h.token,h.stable_a,h.stable_b,h.symbol1,h.symbol2,
          h.size,h.liquidity_class,h.raw_edge_bps,h.net_edge_bps,h.expected_edge_bps,
          h.l1_reserve_x,h.l2_reserve_x,h.depth_synced,h.timing_valid,h.reasons,
          COALESCE(s.trials,0),
          CASE WHEN COALESCE(s.trials,0)>0 THEN 1.0*s.l2_ok_100/s.trials END,
          CASE WHEN COALESCE(s.trials,0)>0 THEN 1.0*s.l2_ok_250/s.trials END,
          CASE WHEN COALESCE(s.trials,0)>0 THEN 1.0*s.l2_ok_500/s.trials END
        FROM opportunity_hits h
        LEFT JOIN survival_aggregates s
          ON s.route=h.route AND ABS(s.size-h.size)<1e-9
        WHERE h.last_ts>=?
          AND h.stable_a IN ('USDC','USDT')
          AND h.stable_b IN ('USDC','USDT')
          AND h.stable_a<>h.stable_b
          AND h.liquidity_class IN ('A','B')
          AND h.size IN (10,20,25)
        ORDER BY h.last_ts DESC
        LIMIT 2500
        """,(since,)).fetchall()
    finally:
        db.close()

    cols=["last_ts","route","token","stable_a","stable_b","symbol1","symbol2","size",
          "liquidity_class","raw_edge_bps","net_edge_bps","expected_edge_bps",
          "l1_reserve_x","l2_reserve_x","depth_synced","timing_valid","engine_reasons",
          "survival_trials","l2_survival_100","l2_survival_250","l2_survival_500"]
    return [dict(zip(cols,r)) for r in rows]

def qualification(r):
    klass=r["liquidity_class"];n=int(r["survival_trials"] or 0);size=f(r["size"])
    s100,s250,s500=f(r["l2_survival_100"]),f(r["l2_survival_250"]),f(r["l2_survival_500"])
    full=int(CFG.get("live_min_survival_trials",1000))
    if klass=="A":
        req=(f(CFG.get("class_a_l2_survival_100_min",.99)),f(CFG.get("class_a_l2_survival_250_min",.98)),f(CFG.get("class_a_l2_survival_500_min",.95)))
    else:
        req=(f(CFG.get("class_b_l2_survival_100_min",.98)),f(CFG.get("class_b_l2_survival_250_min",.95)),f(CFG.get("class_b_l2_survival_500_min",.90)))
    if n>=full and s100>=req[0] and s250>=req[1] and s500>=req[2]:return "FULL"
    if abs(size-f(CFG.get("live_trade_size_usd",10)))<1e-9 and n>=int(CFG.get("flow_probation_min_trials",500)):
        p=f(CFG.get("flow_probation_survival_min",1.0))
        if s100>=p and s250>=p and s500>=p:return "PROBATION"
    return None

def guaranteed(r,fm):
    a,b=fm.get(r["symbol1"],{}),fm.get(r["symbol2"],{})
    if not a.get("usable_live") or not b.get("usable_live"):return None
    b1,b2=f(a.get("taker_bps")),f(b.get("taker_bps"))
    net=((1+f(r["raw_edge_bps"])/1e4)*(1-b1/1e4)*(1-b2/1e4)-1)*1e4
    return net-f(CFG.get("execution_price_reserve_bps",.5))

def top10(live,inv,fm):
    candidates=direct_recent_candidates(20)
    now=time.time();best={}
    for r in candidates:
        role=inv_role(r["stable_a"],r["stable_b"],inv)
        q=qualification(r);th=threshold(r["liquidity_class"],role,inv.get("zone","CENTER"));g=guaranteed(r,fm)
        if q=="PROBATION":
            p=f(CFG.get("flow_probation_a_min_bps",3) if r["liquidity_class"]=="A" else CFG.get("flow_probation_b_min_bps",4))
            th=max(th if th is not None else p,p)
        reasons=[]
        if role=="AGGRAVATING" and inv.get("zone")=="HARD":reasons.append("HARD: aggravant bloqué")
        if q is None:reasons.append(f"trials/survival {int(r['survival_trials'] or 0)}")
        if th is None:reasons.append("seuil BLOCK")
        elif g is None:reasons.append("tradeFee indisponible")
        elif g<=th:reasons.append(f"edge {g:.2f} ≤ seuil {th:.2f}")
        bal=f(((live.get("balances") or {}).get(r["stable_a"]) or {}).get("free"));size=f(r["size"]);reserve=f(CFG.get("live_min_stable_reserve_usd",20))
        if bal<size+reserve:reasons.append(f"{r['stable_a']} {bal:.2f} < {size+reserve:.2f}")
        if role!="CORRECTIVE" and abs(size-f(CFG.get("live_trade_size_usd",10)))>1e-9:reasons.append("taille non corrective")
        if role=="CORRECTIVE" and size>f(inv.get("total"))*f(CFG.get("flow_max_trade_pct",.1))+1e-9:reasons.append(">10% bag")
        if not reasons:reasons=["ÉLIGIBLE"]
        x=dict(r);x.update({"role":role,"qual":q,"threshold":th,"guaranteed_v470":g,"reasons_v470":reasons,"age_s":now-f(r["last_ts"])})
        key=(r["route"],f(r["size"]))
        old=best.get(key)
        # Keep the strongest recent candidate for each exact route×size.
        if old is None or (g if g is not None else -1e12)>(old["guaranteed_v470"] if old["guaranteed_v470"] is not None else -1e12):
            best[key]=x
    out=list(best.values())
    out.sort(key=lambda x:-1e12 if x["guaranteed_v470"] is None else x["guaranteed_v470"],reverse=True)
    return out[:10]

def session(live):
    fl=live.get("flow_inventory") or {};base=fl.get("session_baseline") or {};start=f(base.get("ts"))
    db=rodb()
    try:
        if not start:return {"closed":0,"turnover":0,"cash":0,"dust":0,"dirs":{},"recent":[]}
        rows=db.execute("""SELECT started_ts,route,requested_size,state,guaranteed_edge_bps,realized_pnl_nominal,dust_est_usd,l1_latency_ms,l2_latency_ms FROM live_cycles WHERE started_ts>=? ORDER BY started_ts DESC LIMIT 30""",(start,)).fetchall()
        recent=[{"ts":r[0],"route":r[1],"size":r[2],"state":r[3],"edge":r[4],"cash":r[5],"dust":r[6],"l1":r[7],"l2":r[8]} for r in rows]
        q="SELECT COUNT(*),COALESCE(SUM(l1_quote_spent),0),COALESCE(SUM(realized_pnl_nominal),0),COALESCE(SUM(dust_est_usd),0) FROM live_cycles WHERE started_ts>=? AND state IN ('CLOSED','CLOSED_WITH_RESIDUAL')"
        a=db.execute(q,(start,)).fetchone();dirs={}
        for pat,name in [("USDC>%>USDT","USDC→USDT"),("USDT>%>USDC","USDT→USDC")]:
            rr=db.execute(q.replace("WHERE started_ts>=?","WHERE started_ts>=? AND route LIKE ?"),(start,pat)).fetchone()
            dirs[name]={"cycles":int(rr[0] or 0),"turnover":f(rr[1]),"cash":f(rr[2]),"dust":f(rr[3])}
        return {"closed":int(a[0] or 0),"turnover":f(a[1]),"cash":f(a[2]),"dust":f(a[3]),"dirs":dirs,"recent":recent}
    finally:db.close()

@app.get("/api/data")
def data():
    live=getj("/api/live/status",{}) or {};fl=live.get("flow_inventory") or {};inv=fl.get("inventory") or {}
    fm,fs=fee_api()
    return jsonify({"live":live,"flow":fl,"inv":inv,"baseline":fl.get("session_baseline") or {},
                    "session":session(live),"top10":top10(live,inv,fm),"fees":fs,
                    "fx":(live.get("maintenance") or {}).get("stable_fx") or {}})

@app.get("/")
def index():return render_template("index.html")

if __name__=="__main__":serve(app,host="0.0.0.0",port=PORT,threads=4)
