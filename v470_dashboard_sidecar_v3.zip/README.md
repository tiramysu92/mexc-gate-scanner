# V4.7 sidecar V3 READ-ONLY

Fixes:
- Trials read directly from survival_aggregates (same source used by the LIVE gate).
- Exact symbol1/symbol2 read from opportunity_hits, so account tradeFee can be mapped correctly.
- Top 10 filters to USDC<->USDT routes only; USD1/OTHER routes are excluded.
- SQLite remains mode=ro; scanner 8081 is GET-only.
