from v4rex.maintenance import _floor_step, _ceil_price, _floor_price

def test_v465_rounding():
    assert _floor_step(10.129, 0.01) == 10.12
    assert _ceil_price(1.00001, 4) == 1.0001
    assert _floor_price(1.00009, 4) == 1.0
