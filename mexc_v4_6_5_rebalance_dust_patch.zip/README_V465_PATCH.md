# V4.6.5 patch — automatic stablecoin rebalance + strategy dust → MX → USDC

Target: `mexc_v4_6_4_rex_force_l2_dust_accounting_ws_8081`

## Automatic rebalance
The existing LIVE gate remains unchanged:
`free(stable_a) >= live_trade_size_usd + live_min_stable_reserve_usd`.

With 10 USD trades + 20 USD reserve, hard minimum = 30 USD.
V4.6.5 adds a 5 USD operating buffer => maintenance floor = 35 USD.

Defaults:
- target 60% USDC / 40% USDT
- ±10 point deadband
- direct `USDCUSDT`
- FOK only
- 10 USD minimum, 100 USD maximum per rebalance
- 5 minute cooldown
- impossible while `active_cycle != None`
- maintenance state removes executor from READY, blocking new entries

## Dust
Every 3 hours:
- inspect MEXC convertible balances;
- select only recorded strategy dust;
- never select USDC/USDT/USD1/MX;
- reject assets with any material protected/pre-existing bag;
- batch <=15 assets and <=50 USD;
- require >=0.50 USD total strategy dust;
- convert selected dust to MX;
- attribute only resulting MX to `strategy_MX`;
- sell only `strategy_MX` on `MXUSDC` by FOK;
- never sell the account's full MX balance.

Scheduler cap: 8 successful dust conversions / rolling 24h.

Successful dust is removed/decremented from `live_dust`, preventing double-counting
in the existing strategy-PnL dust valuation. Maintenance audit is stored in:
`maintenance_events` and `maintenance_inventory`.

## Safety / arming
New token: `V465_LIVE_10USD`.
The patch deliberately sets `execution_enabled=false`.

## Apply
```bash
unzip mexc_v4_6_5_rebalance_dust_patch.zip -d /tmp/v465_patch
cd /home/ubuntu/mexc-spot-2leg-v4/runtime_v464/mexc_v4_6_4_rex_force_l2_dust_accounting_ws_8081

python3 /tmp/v465_patch/apply_v465_patch.py . \
  --maintenance-file /tmp/v465_patch/maintenance.py

python3 -m py_compile v4rex/maintenance.py v4rex/live.py
pytest -q
```

Do not arm until the tests pass and the status is clean.
