from __future__ import annotations

import json
import threading
import time
import uuid
from decimal import Decimal, ROUND_DOWN, ROUND_UP

from .mexc_api import MexcAPIError, MexcUnknown

REST = "https://api.mexc.com"


def _f(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return float(default)


def _floor_step(value, step):
    step = _f(step)
    if step <= 0:
        return float(value)
    v = Decimal(str(value))
    s = Decimal(str(step))
    return float((v / s).to_integral_value(rounding=ROUND_DOWN) * s)


def _ceil_price(value, decimals):
    q = Decimal(1).scaleb(-int(decimals))
    return float(Decimal(str(value)).quantize(q, rounding=ROUND_UP))


def _floor_price(value, decimals):
    q = Decimal(1).scaleb(-int(decimals))
    return float(Decimal(str(value)).quantize(q, rounding=ROUND_DOWN))


def _status(o):
    return str((o or {}).get("status") or "").upper()


def _executed_qty(o):
    return _f((o or {}).get("executedQty") or (o or {}).get("cumulativeQuantity") or 0)


class MaintenanceCoordinator:
    """V4.6.5 maintenance plane.

    Safety invariants:
      * never runs while a LIVE cycle/exposure is active;
      * maintenance moves executor state away from READY, blocking submit();
      * stablecoin rebalance uses FOK only;
      * dust assets are selected only when the free account balance is explainable
        by recorded strategy dust;
      * only strategy-attributed MX is sold, never the full account MX balance.
    """

    def __init__(self, executor):
        self.ex = executor
        self.cfg = executor.cfg
        self.db = executor.db
        self.stop_evt = threading.Event()
        self.thread = None
        self.last_error = None
        self.last_action = None
        self.last_rebalance_ts = 0.0
        self.last_dust_ts = 0.0
        self._init_schema()

    def _init_schema(self):
        with self.db.lock, self.db.conn() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS maintenance_events(
                id INTEGER PRIMARY KEY,
                ts REAL,
                kind TEXT,
                status TEXT,
                asset TEXT,
                qty REAL,
                value_usd REAL,
                detail_json TEXT
            );
            CREATE INDEX IF NOT EXISTS ix_maintenance_events_ts
                ON maintenance_events(ts DESC);
            CREATE TABLE IF NOT EXISTS maintenance_inventory(
                asset TEXT PRIMARY KEY,
                qty REAL NOT NULL DEFAULT 0,
                updated_ts REAL
            );
            """)

    def _event(self, kind, status="INFO", asset=None, qty=None, value_usd=None, detail=None):
        payload = dict(detail or {})
        with self.db.lock, self.db.conn() as c:
            c.execute(
                "INSERT INTO maintenance_events(ts,kind,status,asset,qty,value_usd,detail_json) "
                "VALUES(?,?,?,?,?,?,?)",
                (time.time(), str(kind), str(status), asset,
                 None if qty is None else float(qty),
                 None if value_usd is None else float(value_usd),
                 json.dumps(payload, separators=(",", ":"), default=str)),
            )
        try:
            self.db.add_live_event(None, "MAINT_" + str(kind), {
                "status": status, "asset": asset, "qty": qty,
                "value_usd": value_usd, **payload
            })
        except Exception:
            pass

    def _get_inventory(self, asset):
        with self.db.conn() as c:
            r = c.execute("SELECT qty FROM maintenance_inventory WHERE asset=?", (asset,)).fetchone()
        return _f(r[0] if r else 0)

    def _set_inventory(self, asset, qty):
        qty = max(0.0, float(qty))
        with self.db.lock, self.db.conn() as c:
            c.execute(
                "INSERT INTO maintenance_inventory(asset,qty,updated_ts) VALUES(?,?,?) "
                "ON CONFLICT(asset) DO UPDATE SET qty=excluded.qty,updated_ts=excluded.updated_ts",
                (asset, qty, time.time()),
            )

    def _add_inventory(self, asset, qty):
        self._set_inventory(asset, self._get_inventory(asset) + float(qty))

    def _claim(self, kind):
        with self.ex.lock:
            if self.ex.stop or not self.ex.execution_enabled:
                return False
            if self.ex.state != "READY" or self.ex.active_cycle is not None:
                return False
            self.ex.state = "MAINTENANCE_" + kind
            return True

    def _release(self):
        with self.ex.lock:
            if self.ex.active_cycle is None and str(self.ex.state).startswith("MAINTENANCE_"):
                self.ex.state = "READY" if self.ex.execution_enabled else "SAFE_NOT_ARMED"

    def start(self):
        if not bool(self.cfg.get("maintenance_enabled", True)):
            return
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._loop, daemon=True, name="v465-maintenance")
        self.thread.start()
        self._event("START", detail={"version": "V4.6.5"})

    def close(self):
        self.stop_evt.set()

    def status(self):
        return {
            "enabled": bool(self.cfg.get("maintenance_enabled", True)),
            "last_error": self.last_error,
            "last_action": self.last_action,
            "last_rebalance_ts": self.last_rebalance_ts or None,
            "last_dust_ts": self.last_dust_ts or None,
            "strategy_mx_pending": self._get_inventory("MX"),
            "rebalance_floor_usd": self._runway_floor(),
            "rebalance_target_usdc_ratio": float(self.cfg.get("rebalance_target_usdc_ratio", 0.60)),
        }

    def _loop(self):
        self.stop_evt.wait(float(self.cfg.get("maintenance_start_delay_s", 10.0)))
        while not self.stop_evt.is_set() and not self.ex.stop:
            try:
                self._maybe_rebalance()
                self._maybe_dust()
            except Exception as exc:
                self.last_error = repr(exc)
                self._event("LOOP_ERROR", "ERROR", detail={"error": repr(exc)})
            self.stop_evt.wait(float(self.cfg.get("maintenance_check_s", 10.0)))

    def _refresh_balances(self):
        b = (self.ex.balance_client or self.ex.client).balances()
        self.ex._balances = b
        self.ex._balances_ts = time.time()
        try:
            self.db.add_live_balance_snapshot(b)
        except Exception:
            pass
        return b

    def _runway_floor(self):
        return (
            float(self.cfg.get("live_trade_size_usd", 10.0))
            + float(self.cfg.get("live_min_stable_reserve_usd", 20.0))
            + float(self.cfg.get("rebalance_runway_buffer_usd", 5.0))
        )

    def _symbol_info(self, symbol):
        r = self.ex.client.session.get(
            REST + "/api/v3/exchangeInfo",
            params={"symbol": symbol},
            timeout=float(self.cfg.get("live_rest_timeout_s", 3.0)),
        )
        r.raise_for_status()
        arr = (r.json() or {}).get("symbols") or []
        if not arr:
            raise RuntimeError("symbol info unavailable: " + symbol)
        s = arr[0]
        return {
            "step": _f(s.get("baseSizePrecision")),
            "quote_precision": int(s.get("quotePrecision") or 8),
        }

    def _depth(self, symbol, limit=50):
        r = self.ex.client.session.get(
            REST + "/api/v3/depth",
            params={"symbol": symbol, "limit": int(limit)},
            timeout=float(self.cfg.get("live_rest_timeout_s", 3.0)),
        )
        r.raise_for_status()
        x = r.json() or {}
        return {
            "bids": [(_f(p), _f(q)) for p, q, *_ in (x.get("bids") or [])],
            "asks": [(_f(p), _f(q)) for p, q, *_ in (x.get("asks") or [])],
        }

    @staticmethod
    def _worst_for_qty(levels, qty):
        left = float(qty)
        worst = None
        for p, q in levels:
            if p <= 0 or q <= 0:
                continue
            take = min(left, q)
            if take > 0:
                worst = p
                left -= take
            if left <= 1e-12:
                return worst
        return None

    def _maintenance_fok(self, symbol, side, qty, price, kind):
        cid = ("v465" + kind[:4] + str(int(time.time()*1000))[-9:] + uuid.uuid4().hex[:6])[:32]
        mid = "M465-" + time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:5]
        return self.ex._place_fok(
            symbol, side, qty, price, cid,
            cycle_id=mid, leg=kind, attempt=1,
            plan_meta={"execution_reserve_bps": float(self.cfg.get("rebalance_price_cushion_bps", 1.0))}
        )

    def _maybe_rebalance(self):
        if not bool(self.cfg.get("rebalance_enabled", True)):
            return
        now = time.time()
        cooldown = float(self.cfg.get("rebalance_cooldown_s", 300.0))
        if now - self.last_rebalance_ts < cooldown:
            return

        usdc = _f(self.ex._balances.get("USDC", {}).get("free"))
        usdt = _f(self.ex._balances.get("USDT", {}).get("free"))
        total = usdc + usdt
        floor = self._runway_floor()
        if total < 2 * floor:
            self._event("REBALANCE_SKIPPED", "WARN", detail={
                "reason": "TOTAL_STABLE_BELOW_TWO_RUNWAYS",
                "USDC": usdc, "USDT": usdt, "floor": floor
            })
            self.last_rebalance_ts = now
            return

        target_ratio = float(self.cfg.get("rebalance_target_usdc_ratio", 0.60))
        deadband = float(self.cfg.get("rebalance_ratio_deadband", 0.10))
        ratio = usdc / total if total > 0 else 0.0
        target_usdc = total * target_ratio
        direction = None
        amount = 0.0

        if usdc < floor or ratio < target_ratio - deadband:
            direction = "USDT_TO_USDC"
            amount = min(
                max(0.0, target_usdc - usdc),
                max(0.0, usdt - floor),
                float(self.cfg.get("rebalance_max_trade_usd", 100.0)),
            )
        elif usdt < floor or ratio > target_ratio + deadband:
            direction = "USDC_TO_USDT"
            amount = min(
                max(0.0, usdc - target_usdc),
                max(0.0, usdc - floor),
                float(self.cfg.get("rebalance_max_trade_usd", 100.0)),
            )
        else:
            return

        if amount < float(self.cfg.get("rebalance_min_trade_usd", 10.0)):
            return
        if not self._claim("REBALANCE"):
            return

        self.last_rebalance_ts = now
        try:
            pair = str(self.cfg.get("rebalance_pair", "USDCUSDT"))
            info = self._symbol_info(pair)
            depth = self._depth(pair)
            cushion = float(self.cfg.get("rebalance_price_cushion_bps", 1.0)) / 1e4

            if direction == "USDT_TO_USDC":
                if not depth["asks"]:
                    raise RuntimeError("rebalance asks unavailable")
                rough = amount / max(depth["asks"][0][0], 1e-18)
                terminal = self._worst_for_qty(depth["asks"], rough)
                if not terminal:
                    raise RuntimeError("rebalance BUY depth insufficient")
                price = _ceil_price(terminal * (1.0 + cushion), info["quote_precision"])
                qty = _floor_step(amount / price, info["step"])
                side = "BUY"
            else:
                qty = _floor_step(amount, info["step"])
                terminal = self._worst_for_qty(depth["bids"], qty)
                if not terminal:
                    raise RuntimeError("rebalance SELL depth insufficient")
                price = _floor_price(terminal * (1.0 - cushion), info["quote_precision"])
                side = "SELL"

            if qty <= 0 or price <= 0:
                raise RuntimeError("rebalance rounded to zero")

            before = {"USDC": usdc, "USDT": usdt}
            o = self._maintenance_fok(pair, side, qty, price, "REBAL")
            after = self._refresh_balances()
            self.last_action = "REBALANCE " + direction
            self._event("REBALANCE", _status(o) or "UNKNOWN", qty=qty, value_usd=amount, detail={
                "direction": direction, "pair": pair, "side": side,
                "price": price, "executed_qty": _executed_qty(o),
                "before": before,
                "after": {
                    "USDC": _f(after.get("USDC", {}).get("free")),
                    "USDT": _f(after.get("USDT", {}).get("free")),
                },
                "floor": floor, "target_ratio": target_ratio,
            })
        except Exception as exc:
            self.last_error = repr(exc)
            try:
                self._refresh_balances()
            except Exception:
                pass
            self._event("REBALANCE_ERROR", "ERROR", detail={"error": repr(exc)})
        finally:
            self._release()

    def _outstanding_dust(self):
        with self.db.conn() as c:
            rows = c.execute(
                "SELECT asset,sum(qty),sum(est_usd) FROM live_dust "
                "GROUP BY asset HAVING sum(qty)>0"
            ).fetchall()
        return {str(a): {"qty": _f(q), "est_usd": _f(u)} for a, q, u in rows}

    def _dust_calls_24h(self):
        cutoff = time.time() - 86400.0
        with self.db.conn() as c:
            r = c.execute(
                "SELECT count(*) FROM maintenance_events "
                "WHERE kind='DUST_CONVERT' AND status='SUCCESS' AND ts>=?",
                (cutoff,),
            ).fetchone()
        return int((r or [0])[0] or 0)

    def _convert_list(self):
        x = self.ex.client._signed("GET", "/api/v3/capital/convert/list")
        return x if isinstance(x, list) else []

    def _settle_live_dust(self, asset, qty):
        remaining = max(0.0, float(qty))
        if remaining <= 0:
            return 0.0
        settled = 0.0
        with self.db.lock, self.db.conn() as c:
            rows = c.execute(
                "SELECT id,qty,est_usd FROM live_dust WHERE asset=? ORDER BY id",
                (asset,),
            ).fetchall()
            for rid, q, usd in rows:
                if remaining <= 1e-18:
                    break
                q = _f(q)
                usd = _f(usd)
                take = min(q, remaining)
                left = q - take
                settled += take
                remaining -= take
                if left <= max(1e-18, q * 1e-12):
                    c.execute("DELETE FROM live_dust WHERE id=?", (rid,))
                else:
                    ratio = left / q if q > 0 else 0.0
                    c.execute("UPDATE live_dust SET qty=?,est_usd=? WHERE id=?",
                              (left, usd * ratio, rid))
        return settled

    def _sell_strategy_mx(self):
        pending = self._get_inventory("MX")
        if pending <= 0:
            return
        pair = str(self.cfg.get("dust_mx_pair", "MXUSDC"))
        info = self._symbol_info(pair)
        depth = self._depth(pair)
        if not depth["bids"]:
            return
        fee_reserve = float(self.cfg.get("dust_mx_base_reserve_bps", 10.0)) / 1e4
        qty = _floor_step(pending * (1.0 - fee_reserve), info["step"])
        if qty <= 0:
            return
        terminal = self._worst_for_qty(depth["bids"], qty)
        if not terminal:
            return
        if qty * terminal < float(self.cfg.get("dust_mx_sell_min_usdc", 0.50)):
            return
        cushion = float(self.cfg.get("dust_mx_sell_cushion_bps", 2.0)) / 1e4
        price = _floor_price(terminal * (1.0 - cushion), info["quote_precision"])
        before_usdc = _f(self.ex._balances.get("USDC", {}).get("free"))
        o = self._maintenance_fok(pair, "SELL", qty, price, "DUSTMX")
        executed = _executed_qty(o)
        after = self._refresh_balances()
        if executed > 0:
            self._set_inventory("MX", max(0.0, pending - executed))
        after_usdc = _f(after.get("USDC", {}).get("free"))
        self._event("DUST_MX_SELL", _status(o) or "UNKNOWN", asset="MX",
                    qty=executed, value_usd=max(0.0, after_usdc - before_usdc),
                    detail={"pair": pair, "price": price, "requested_qty": qty,
                            "pending_before": pending,
                            "pending_after": self._get_inventory("MX")})

    def _maybe_dust(self):
        if not bool(self.cfg.get("dust_enabled", True)):
            return
        now = time.time()
        if now - self.last_dust_ts < float(self.cfg.get("dust_interval_s", 10800.0)):
            return
        if self._dust_calls_24h() >= int(self.cfg.get("dust_max_calls_24h", 8)):
            return
        if not self._claim("DUST"):
            return

        self.last_dust_ts = now
        try:
            self._sell_strategy_mx()
            outstanding = self._outstanding_dust()
            if not outstanding:
                return

            conv = {str(x.get("asset")): x for x in self._convert_list() if x.get("asset")}
            candidates = []
            total_est = 0.0
            rel_tol = float(self.cfg.get("dust_bag_guard_rel_tolerance", 0.02))
            abs_tol = float(self.cfg.get("dust_bag_guard_abs_tolerance", 1e-10))
            skip_assets = set(self.cfg.get("live_allowed_stablecoins", ["USDC", "USDT"])) | {"MX", "USD1"}

            for asset, d in sorted(outstanding.items(), key=lambda kv: kv[1]["est_usd"], reverse=True):
                if asset in skip_assets:
                    continue
                x = conv.get(asset)
                if not x:
                    continue

                account_free = _f(self.ex._balances.get(asset, {}).get("free"))
                strategy_qty = _f(d["qty"])
                convertible_balance = _f(x.get("balance"))
                est = _f(x.get("convertUsdt"), d["est_usd"])
                mx = _f(x.get("convertMx"))
                startup_free = _f(self.ex._startup_balances.get(asset, {}).get("free"))
                protected_at_start = max(0.0, startup_free - strategy_qty)

                # MEXC dust conversion chooses assets, not quantities. If any material amount
                # cannot be attributed to strategy dust, skip the entire asset.
                if protected_at_start > max(abs_tol, strategy_qty * rel_tol):
                    self._event("DUST_SKIP_BAG", "SKIP", asset=asset, qty=strategy_qty,
                                value_usd=est, detail={"startup_free": startup_free,
                                "protected_at_start": protected_at_start})
                    continue
                if account_free > strategy_qty * (1.0 + rel_tol) + abs_tol:
                    self._event("DUST_SKIP_BAG", "SKIP", asset=asset, qty=strategy_qty,
                                value_usd=est, detail={"account_free": account_free,
                                "strategy_qty": strategy_qty})
                    continue
                if convertible_balance <= 0 or mx <= 0:
                    continue
                if est <= 0 or est >= float(self.cfg.get("dust_per_asset_max_usd", 5.0)):
                    continue
                if len(candidates) >= int(self.cfg.get("dust_api_max_assets", 15)):
                    break
                if total_est + est > float(self.cfg.get("dust_batch_max_usd", 50.0)):
                    continue

                candidates.append((asset, x, min(strategy_qty, convertible_balance)))
                total_est += est

            if total_est < float(self.cfg.get("dust_batch_min_usd", 0.50)) or not candidates:
                return

            mx_before = _f(self.ex._balances.get("MX", {}).get("free"))
            assets = [a for a, _, _ in candidates]

            try:
                res = self.ex.client._signed(
                    "POST", "/api/v3/capital/convert",
                    {"asset": ",".join(assets)},
                    order_mutation=True,
                    client_order_id="v465dust" + uuid.uuid4().hex[:12],
                    symbol="DUST",
                ) or {}
            except MexcUnknown as exc:
                self._refresh_balances()
                self.last_error = repr(exc)
                self._event("DUST_CONVERT_UNKNOWN", "UNKNOWN",
                            detail={"assets": assets, "error": repr(exc)})
                return

            after = self._refresh_balances()
            mx_after = _f(after.get("MX", {}).get("free"))
            mx_delta_balance = max(0.0, mx_after - mx_before)
            mx_reported = _f(res.get("totalConvert"))
            strategy_mx = mx_reported if mx_reported > 0 else mx_delta_balance
            if mx_delta_balance > 0 and strategy_mx > 0:
                strategy_mx = min(strategy_mx, mx_delta_balance * 1.001)

            success = set(res.get("successList") or [])
            failed = res.get("failedList") or []
            settled = {}
            for asset, x, qty in candidates:
                if asset in success:
                    settled[asset] = self._settle_live_dust(asset, qty)

            if strategy_mx > 0:
                self._add_inventory("MX", strategy_mx)

            self.last_action = "DUST_TO_MX"
            self._event("DUST_CONVERT", "SUCCESS" if success else "FAILED",
                        asset=",".join(sorted(success)) if success else None,
                        qty=strategy_mx, value_usd=total_est,
                        detail={"requested_assets": assets,
                                "success": sorted(success),
                                "failed": failed,
                                "settled_strategy_dust": settled,
                                "mx_before": mx_before,
                                "mx_after": mx_after,
                                "mx_reported": mx_reported,
                                "strategy_mx_added": strategy_mx})

            self._sell_strategy_mx()

        except MexcAPIError as exc:
            self.last_error = repr(exc)
            self._event("DUST_ERROR", "ERROR", detail={"error": repr(exc)})
        except Exception as exc:
            self.last_error = repr(exc)
            self._event("DUST_ERROR", "ERROR", detail={"error": repr(exc)})
        finally:
            self._release()
