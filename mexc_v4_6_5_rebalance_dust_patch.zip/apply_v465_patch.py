#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

MAINTENANCE_IMPORT = "from .maintenance import MaintenanceCoordinator"
OLD_IMPORT = "from .mexc_api import MexcAPIError, MexcUnknown, MexcClient, PrivateStream, load_existing_mexc_env, mexc_credentials"

START_ANCHOR = '''            threading.Thread(target=self._balance_loop,daemon=True,name="micro-live-balances").start()
            if open_cycles:
'''
START_REPL = '''            threading.Thread(target=self._balance_loop,daemon=True,name="micro-live-balances").start()
            self.maintenance=MaintenanceCoordinator(self)
            self.maintenance.start()
            if open_cycles:
'''

CLOSE_ANCHOR = '''    def close(self):
        self.stop=True
        if self.private:self.private.close()
'''
CLOSE_REPL = '''    def close(self):
        self.stop=True
        if getattr(self,"maintenance",None):self.maintenance.close()
        if self.private:self.private.close()
'''

STATUS_ANCHOR = '''        return {"state":self.state,"execution_enabled":self.execution_enabled,"arm_ok":self.arm_ok,"credentials_present":self.credentials_present,"allowed_stablecoins":sorted(self.allowed),"trade_size_usd":self.size,"execution_reserve_bps":float(self.cfg.get("execution_price_reserve_bps",.5)),"active_cycle":self.active_cycle,"balances":{k:self._balances.get(k,{"free":0,"locked":0}) for k in sorted(self.allowed)},"startup_balances":{k:self._startup_balances.get(k,{"free":0,"locked":0}) for k in sorted(self.allowed)},"balance_age_s":bal_age,"submitted":self.submitted,"skipped":self.skipped,"executed":self.executed,"pnl":pnl,"dust":dust,"execution":execution,"private_ws":priv,"last_error":self.last_error}
'''
STATUS_REPL = '''        out={"state":self.state,"execution_enabled":self.execution_enabled,"arm_ok":self.arm_ok,"credentials_present":self.credentials_present,"allowed_stablecoins":sorted(self.allowed),"trade_size_usd":self.size,"execution_reserve_bps":float(self.cfg.get("execution_price_reserve_bps",.5)),"active_cycle":self.active_cycle,"balances":{k:self._balances.get(k,{"free":0,"locked":0}) for k in sorted(self.allowed)},"startup_balances":{k:self._startup_balances.get(k,{"free":0,"locked":0}) for k in sorted(self.allowed)},"balance_age_s":bal_age,"submitted":self.submitted,"skipped":self.skipped,"executed":self.executed,"pnl":pnl,"dust":dust,"execution":execution,"private_ws":priv,"last_error":self.last_error}
        out["maintenance"]=self.maintenance.status() if getattr(self,"maintenance",None) else {"enabled":False}
        return out
'''


def replace_once(text, old, new, label):
    if new in text:
        return text
    if text.count(old) != 1:
        raise RuntimeError(f"{label}: expected exactly one anchor, found {text.count(old)}")
    return text.replace(old, new, 1)


def main():
    ap = argparse.ArgumentParser(description="Apply V4.6.5 rebalance+dust patch to an unpacked V4.6.4 runtime")
    ap.add_argument("runtime", nargs="?", default=".", help="V4.6.4 package directory")
    ap.add_argument("--maintenance-file", required=True, help="maintenance.py from patch bundle")
    args = ap.parse_args()

    root = Path(args.runtime).resolve()
    live = root / "v4rex" / "live.py"
    cfgp = root / "config.json"
    cfgexp = root / "config.example.json"
    if not live.exists() or not cfgp.exists():
        raise SystemExit(f"Not a V4.6.4 runtime: {root}")

    for p in (live, cfgp, cfgexp):
        if p.exists():
            b = p.with_suffix(p.suffix + ".v464.bak")
            if not b.exists():
                shutil.copy2(p, b)

    (root / "v4rex" / "maintenance.py").write_text(Path(args.maintenance_file).read_text())

    s = live.read_text()
    if MAINTENANCE_IMPORT not in s:
        s = replace_once(s, OLD_IMPORT, OLD_IMPORT + "\n" + MAINTENANCE_IMPORT, "import")
    s = replace_once(s, START_ANCHOR, START_REPL, "start hook")
    s = replace_once(s, CLOSE_ANCHOR, CLOSE_REPL, "close hook")
    s = replace_once(s, STATUS_ANCHOR, STATUS_REPL, "status hook")
    s = s.replace(
        'self.arm_ok=(os.getenv("MEXC_LIVE_ARM") == str(cfg.get("live_arm_token","V464_LIVE_10USD")))',
        'self.arm_ok=(os.getenv("MEXC_LIVE_ARM") == str(cfg.get("live_arm_token","V465_LIVE_10USD")))'
    )
    live.write_text(s)

    additions = {
        "execution_enabled": False,
        "live_arm_token": "V465_LIVE_10USD",
        "maintenance_enabled": True,
        "maintenance_start_delay_s": 10.0,
        "maintenance_check_s": 10.0,
        "rebalance_enabled": True,
        "rebalance_pair": "USDCUSDT",
        "rebalance_target_usdc_ratio": 0.60,
        "rebalance_ratio_deadband": 0.10,
        "rebalance_runway_buffer_usd": 5.0,
        "rebalance_min_trade_usd": 10.0,
        "rebalance_max_trade_usd": 100.0,
        "rebalance_cooldown_s": 300.0,
        "rebalance_price_cushion_bps": 1.0,
        "dust_enabled": True,
        "dust_interval_s": 10800.0,
        "dust_max_calls_24h": 8,
        "dust_api_max_assets": 15,
        "dust_batch_min_usd": 0.50,
        "dust_per_asset_max_usd": 5.0,
        "dust_batch_max_usd": 50.0,
        "dust_bag_guard_rel_tolerance": 0.02,
        "dust_bag_guard_abs_tolerance": 1e-10,
        "dust_mx_pair": "MXUSDC",
        "dust_mx_sell_min_usdc": 0.50,
        "dust_mx_sell_cushion_bps": 2.0,
        "dust_mx_base_reserve_bps": 10.0,
    }

    for p in (cfgp, cfgexp):
        if not p.exists():
            continue
        cfg = json.loads(p.read_text())
        cfg.update(additions)
        p.write_text(json.dumps(cfg, indent=2) + "\n")

    print("PATCHED:", root)
    print("NEW ARM TOKEN: V465_LIVE_10USD")
    print("execution_enabled reset to false by design")
    print("Run: python3 -m py_compile v4rex/maintenance.py v4rex/live.py")
    print("Then run pytest before arming.")


if __name__ == "__main__":
    main()
