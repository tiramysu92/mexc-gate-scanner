#!/usr/bin/env python3
from __future__ import annotations

import argparse, json, re, shutil, py_compile
from pathlib import Path


def replace_method(text: str, name: str, new_body: str) -> str:
    pat = re.compile(rf'^    def {re.escape(name)}\(.*?(?=^    def |^class |\Z)', re.M | re.S)
    m = pat.search(text)
    if not m:
        raise RuntimeError(f'method not found: {name}')
    return text[:m.start()] + new_body.rstrip() + '\n\n' + text[m.end():]


def insert_before_method(text: str, name: str, block: str) -> str:
    marker = f'    def {name}('
    i = text.find(marker)
    if i < 0:
        raise RuntimeError(f'insert marker not found: {name}')
    if block.strip() in text:
        return text
    return text[:i] + block.rstrip() + '\n\n' + text[i:]


HELPERS = r'''    def _inventory_recovery_active(self):
        if not bool(self.cfg.get("inventory_recovery_enabled", True)):
            return False
        usdc=self._available("USDC");usdt=self._available("USDT")
        trigger=float(self.cfg.get("inventory_recovery_trigger_usdc",60.0))
        reserve=float(self.cfg.get("live_min_stable_reserve_usd",20.0))
        return usdc < trigger and usdt > reserve + self.size

    def _survival_metrics_ok(self,e):
        if e.liquidity_class not in ("A","B"):return False
        if not bool(e.data_valid) or not bool(e.timing_valid) or not bool(e.depth_synced):return False
        if float(e.l1_reserve_x or 0)<float(self.cfg.get("liquidity_l1_reserve_multiple",5.0)):return False
        if float(e.l2_reserve_x or 0)<float(self.cfg.get("liquidity_l2_reserve_multiple",10.0)):return False
        if int(e.survival_trials or 0)<int(self.cfg.get("live_min_survival_trials",1000)):return False
        k=e.liquidity_class
        req100=float(self.cfg.get("class_a_l2_survival_100_min",.99) if k=="A" else self.cfg.get("class_b_l2_survival_100_min",.98))
        req250=float(self.cfg.get("class_a_l2_survival_250_min",.98) if k=="A" else self.cfg.get("class_b_l2_survival_250_min",.95))
        req500=float(self.cfg.get("class_a_l2_survival_500_min",.95) if k=="A" else self.cfg.get("class_b_l2_survival_500_min",.90))
        return float(e.l2_survival_100 or 0)>=req100 and float(e.l2_survival_250 or 0)>=req250 and float(e.l2_survival_500 or 0)>=req500

    def _is_reverse_recovery_event(self,e):
        sizes={float(x) for x in self.cfg.get("inventory_recovery_sizes_usd",[40,25,20,10])}
        return (self._inventory_recovery_active() and getattr(e,"stable_a",None)=="USDT" and getattr(e,"stable_b",None)=="USDC" and
                float(getattr(e,"size",self.size)) in sizes and self._survival_metrics_ok(e))

    def _event_submission_mode(self,e):
        qf=float(self.cfg.get("qualification_depth_fraction",.25))
        if abs(float(getattr(e,"fraction",qf))-qf)>1e-12:return None
        if self._is_reverse_recovery_event(e):return "RECOVERY"
        # getattr defaults preserve legacy/unit-test calls that predate Eval.size/accepted.
        if bool(getattr(e,"accepted",True)) and abs(float(getattr(e,"size",self.size))-self.size)<1e-9:return "STANDARD"
        return None

    def _record_recovery_shadow(self,e):
        now=time.time();key=(e.route,float(e.size));ttl=float(self.cfg.get("inventory_recovery_shadow_log_s",30.0))
        if now-float(self._recovery_shadow_last.get(key,0) or 0)<ttl:return
        self._recovery_shadow_last[key]=now
        self.db.add_live_event(None,"RECOVERY_SHADOW_CANDIDATE",{
            "route":e.route,"size":e.size,"expected_edge_bps":e.expected_edge_bps,
            "net_edge_bps":e.net_edge_bps,"survival_trials":e.survival_trials,
            "l2_survival_100":e.l2_survival_100,"l2_survival_250":e.l2_survival_250,
            "l2_survival_500":e.l2_survival_500,"liquidity_class":e.liquidity_class})

    def select_live_candidate(self,ev,qf):
        qf=float(qf);same=[e for e in ev if abs(float(e.fraction)-qf)<1e-12]
        normal=[e for e in same if bool(e.accepted) and abs(float(e.size)-self.size)<1e-9]
        if self._inventory_recovery_active():
            sizes={float(x) for x in self.cfg.get("inventory_recovery_sizes_usd",[40,25,20,10])}
            structural=[e for e in same if e.stable_a=="USDT" and e.stable_b=="USDC" and float(e.size) in sizes and self._survival_metrics_ok(e)]
            shadow_min=float(self.cfg.get("inventory_recovery_shadow_min_edge_bps",-1.0))
            shadow=[e for e in structural if e.expected_edge_bps is not None and float(e.expected_edge_bps)>shadow_min]
            if shadow:self._record_recovery_shadow(max(shadow,key=lambda x:(float(x.size),float(x.expected_edge_bps or -1e9))))
            live_min=float(self.cfg.get("inventory_recovery_live_min_edge_bps",0.0))
            recovery=[e for e in structural if e.expected_edge_bps is not None and float(e.expected_edge_bps)>live_min]
            if recovery:
                # Restore inventory as fast as safely proven: largest exact qualified size wins.
                return max(recovery,key=lambda x:(float(x.size),float(x.expected_edge_bps or -1e9)))
        if normal:return max(normal,key=lambda x:float(x.expected_edge_bps or -1e9))
        return None'''

SUBMIT = r'''    def submit(self,e):
        if self.stop or not self.client:return False
        mode=self._event_submission_mode(e)
        if mode is None:return False
        if e.stable_a not in self.allowed or e.stable_b not in self.allowed:return False
        if e.liquidity_class not in ("A","B"):return False
        if int(e.survival_trials or 0)<int(self.cfg.get("live_min_survival_trials",1000)):self.skipped+=1;return False
        if not self.execution_enabled:return False
        if bool(self.cfg.get("live_require_private_ws",True)) and (not self.private or not self.private.connected):self.skipped+=1;return False
        with self.lock:
            if self.state!="READY" or self.active_cycle is not None:return False
            if time.time()-self.last_cycle_ts<float(self.cfg.get("live_route_cooldown_s",5)):return False
            if not self.q.empty():return False
        try:self.q.put_nowait((e,time.perf_counter_ns()));self.submitted+=1;return True
        except queue.Full:return False'''

LIVE_GATE = r'''    def _live_gate(self,e):
        mode=self._event_submission_mode(e)
        if mode is None:return False,"EVENT_NO_LONGER_ELIGIBLE"
        trade_size=float(getattr(e,"size",self.size));reserve=float(self.cfg.get("live_min_stable_reserve_usd",20))
        bal_age=max(0.0,time.time()-float(self._balances_ts or 0)) if self._balances_ts else math.inf
        if bal_age>float(self.cfg.get("live_balance_cache_max_age_s",5.0)):return False,"BALANCE_CACHE_STALE"
        if self._available(e.stable_a) < trade_size+reserve:return False,"BALANCE_RESERVE"
        ss=self.db.survival_stat(e.route,trade_size);n=int(ss.get("trials") or 0)
        if n<int(self.cfg.get("live_min_survival_trials",1000)):return False,"SURVIVAL_SAMPLES"
        klass=e.liquidity_class
        req100=float(self.cfg.get("class_a_l2_survival_100_min",.99) if klass=="A" else self.cfg.get("class_b_l2_survival_100_min",.98))
        req250=float(self.cfg.get("class_a_l2_survival_250_min",.98) if klass=="A" else self.cfg.get("class_b_l2_survival_250_min",.95))
        req500=float(self.cfg.get("class_a_l2_survival_500_min",.95) if klass=="A" else self.cfg.get("class_b_l2_survival_500_min",.90))
        if float(ss.get("l2_survival_100") or 0)<req100 or float(ss.get("l2_survival_250") or 0)<req250 or float(ss.get("l2_survival_500") or 0)<req500:return False,"SURVIVAL_RATIO"
        fi1=self._fee_info(e.symbol1);fi2=self._fee_info(e.symbol2)
        if bool(self.cfg.get("live_require_account_fees",True)) and (not fi1.get("usable_live") or not fi2.get("usable_live")):
            return False,"ACCOUNT_FEE_UNKNOWN"
        f1=float(fi1.get("taker_bps") or 0);f2=float(fi2.get("taker_bps") or 0)
        raw=float(e.raw_edge_bps or -1e9);net=((1+raw/1e4)*(1-f1/1e4)*(1-f2/1e4)-1)*1e4
        execution_reserve=float(self.cfg.get("execution_price_reserve_bps",.5));guaranteed=net-execution_reserve
        standard=float(self.cfg.get("liquidity_a_min_net_edge_bps",1) if klass=="A" else self.cfg.get("liquidity_b_min_net_edge_bps",2))
        if mode=="RECOVERY":
            threshold=float(self.cfg.get("inventory_recovery_live_min_edge_bps",0.0))
        elif self._inventory_recovery_active() and e.stable_a=="USDC" and e.stable_b=="USDT":
            threshold=max(standard,float(self.cfg.get("inventory_forward_min_edge_bps",5.0)))
        else:threshold=standard
        if guaranteed<=threshold:return False,"EXECUTION_RESERVE_EDGE"
        return True,{"fee1_bps":f1,"fee2_bps":f2,"fee1_source":fi1.get("source"),"fee2_source":fi2.get("source"),"live_net_bps":net,"execution_reserve_bps":execution_reserve,"guaranteed_edge_bps":guaranteed,"threshold_bps":threshold,"balance_age_s":bal_age,"survival":ss,"trade_size":trade_size,"inventory_mode":mode}'''

ENTRY_PLAN = r'''    def _entry_plan(self,e):
        d1=self.store.get_depth(e.symbol1);d2=self.store.get_depth(e.symbol2)
        if not d1 or not d2:return None
        trade_size=float(e.size);frac=float(self.cfg.get("qualification_depth_fraction",.25));base,_,cov=buy(d1.asks,trade_size,frac)
        if cov<.999 or base<=0:return None
        r1=self._symbol_rule(e.symbol1);r2=self._symbol_rule(e.symbol2)
        step1=float(r1.base_size_precision or 0);step2=float(r2.base_size_precision or 0)
        qty=floor_step(base,step1 if step1>0 else None)
        cushion=float(self.cfg.get("execution_price_reserve_bps",.5))
        terminal=None;raw_limit=None;limit_px=None
        for _ in range(3):
            terminal=worst_ask_for_base(d1.asks,qty,frac)
            if not terminal or qty<=0:return None
            raw_limit,limit_px=buy_limit_with_cushion(terminal,cushion,r1.quote_precision)
            capped=floor_step(min(qty,trade_size/max(limit_px,1e-18)),step1 if step1>0 else None)
            if capped<=0:return None
            if abs(capped-qty)<=1e-18:break
            qty=capped
        l2_trusted=sum(max(0,float(x.q))*frac for x in d2.bids)
        if l2_trusted/max(qty,1e-18)<float(self.cfg.get("liquidity_l2_reserve_multiple",10)):return None
        best=float(getattr(d1,'best_ask',0) or (d1.asks[0].p if d1.asks else 0))
        return {"qty":qty,"price":limit_px,"qty_s":decstr(qty),"price_s":decstr(limit_px,max(2,(r1.quote_precision or 8)+2)),"step2":r2.base_size_precision,"quote_precision2":r2.quote_precision,"best_price_signal":best,"terminal_depth_price":float(terminal),"limit_price_unrounded":float(raw_limit),"tick_size":price_tick(r1.quote_precision),"execution_reserve_bps":cushion,"trade_size":trade_size}'''

ROUTE_VALIDATED = r'''    def _route_validated(self,e,plan):
        trade_size=float(e.size);key=(e.route,trade_size)
        old=self._validated.get(key) or self.db.live_route_validation(e.route,trade_size)
        ttl=float(self.cfg.get("live_order_test_ttl_s",21600))
        if old and old.get("ok") and time.time()-float(old.get("ts") or 0)<ttl:
            self._validated[key]=old;return True,False
        try:
            c1="v466t1"+uuid.uuid4().hex[:17];self.client.order_test(symbol=e.symbol1,side="BUY",quantity=plan["qty_s"],price=plan["price_s"],client_order_id=c1)
            q2=floor_step(plan["qty"],plan["step2"])
            d2=self.store.get_depth(e.symbol2);px2=worst_bid_for_base(d2.bids,q2,float(self.cfg.get("qualification_depth_fraction",.25))) if d2 else None
            if not px2 or q2<=0:raise MexcAPIError("L2 test plan unavailable")
            px2=floor_price(px2,plan["quote_precision2"]);c2="v466t2"+uuid.uuid4().hex[:17]
            self.client.order_test(symbol=e.symbol2,side="SELL",quantity=decstr(q2),price=decstr(px2,max(2,(plan["quote_precision2"] or 8)+2)),client_order_id=c2)
            val={"route":e.route,"size":trade_size,"ok":True,"ts":time.time(),"detail":"L1+L2 FOK /order/test OK"};self._validated[key]=val;self.db.save_live_route_validation(val);return True,True
        except Exception as exc:
            val={"route":e.route,"size":trade_size,"ok":False,"ts":time.time(),"detail":repr(exc)};self._validated[key]=val;self.db.save_live_route_validation(val);return False,False'''

EXECUTE = r'''    def _execute(self,e,signal_ns=None):
        signal_ns=signal_ns or time.perf_counter_ns();trade_size=float(e.size)
        with self.lock:
            if self.state!="READY" or self.active_cycle is not None:return
            self.state="ENTRY_CHECK"
        ok,gate=self._live_gate(e)
        if not ok:self.skipped+=1;self.state="READY";return
        plan=self._entry_plan(e)
        if not plan:self.skipped+=1;self.state="READY";return
        valid,just_validated=self._route_validated(e,plan)
        if not valid:self.skipped+=1;self.state="READY";return
        if just_validated and bool(self.cfg.get("live_skip_trade_on_first_validation",True)):
            self.db.add_live_event(None,"ROUTE_FOK_VALIDATED_WAIT_NEXT",{"route":e.route,"size":trade_size,"l1_limit":plan["price"],"execution_reserve_bps":gate["execution_reserve_bps"],"inventory_mode":gate.get("inventory_mode")});self.state="READY";return
        token_before,stable_before,balance_age=self._snapshot_l1_balances(e)
        if balance_age>float(self.cfg.get("live_balance_cache_max_age_s",5.0)):
            self.skipped+=1;self.state="READY";return
        decision_done_ns=time.perf_counter_ns()
        cycle={"cycle_id":self._cycle_id(),"started_ts":time.time(),"updated_ts":time.time(),"closed_ts":None,"route":e.route,"token":e.token,"stable_a":e.stable_a,"stable_b":e.stable_b,"liquidity_class":e.liquidity_class,"requested_size":trade_size,"expected_net_bps":gate["live_net_bps"],"execution_reserve_bps":gate["execution_reserve_bps"],"guaranteed_edge_bps":gate["guaranteed_edge_bps"],"state":"L1_SUBMIT","l1_symbol":e.symbol1,"l2_symbol":e.symbol2,"l1_token_before":token_before,"l1_stable_a_before":stable_before,"l1_terminal_price":plan["terminal_depth_price"],"l1_limit_price":plan["price"],"error":None}
        with self.lock:self.active_cycle=cycle;self.state="EXPOSURE_PENDING_L1"
        self.db.upsert_live_cycle(cycle);self.db.add_live_event(cycle["cycle_id"],"CYCLE_START",{"route":e.route,"size":trade_size,"net_bps":gate["live_net_bps"],"execution_reserve_bps":gate["execution_reserve_bps"],"guaranteed_edge_bps":gate["guaranteed_edge_bps"],"threshold_bps":gate["threshold_bps"],"inventory_mode":gate.get("inventory_mode"),"survival_trials":e.survival_trials,"balance_age_s":balance_age,"terminal_ask":plan["terminal_depth_price"],"limit_price":plan["price"]})
        cid=self._client_id("L1");cycle["l1_client_id"]=cid;cycle["state"]="L1_RECONCILING";self.db.upsert_live_cycle(cycle)
        o1=None;l1=None
        try:
            meta={k:plan.get(k) for k in ("best_price_signal","terminal_depth_price","tick_size","limit_price_unrounded","execution_reserve_bps")}
            o1=self._place_fok(e.symbol1,"BUY",plan["qty"],plan["price"],cid,cycle_id=cycle["cycle_id"],leg="L1",attempt=1,signal_ns=signal_ns,decision_done_ns=decision_done_ns,plan_meta=meta)
        except MexcUnknown as exc:
            cycle["error"]=repr(exc);self.db.upsert_live_cycle(cycle);l1=self._balance_reconcile_l1(e,cycle)
            if l1 is None:
                cycle["state"]="UNKNOWN_L1";self.db.upsert_live_cycle(cycle);self.state="ENTRY_DISABLED_UNKNOWN_L1";return
        st=order_status_name(o1) if o1 else "UNKNOWN";executed=order_executed_qty(o1) if o1 else 0.0
        if o1:
            cycle.update({"l1_order_id":o1.get("orderId"),"l1_confirm_source":o1.get("_confirm_source"),"l1_latency_ms":o1.get("_latency_ms"),"updated_ts":time.time()});self.db.upsert_live_cycle(cycle)
        if l1 is None and o1 and order_has_exposure(o1):l1=self._l1_accounting(e,o1)
        if l1 is None and o1 and st=="REJECTED" and executed<=1e-18:
            cycle.update({"state":"L1_NO_FILL","closed_ts":time.time(),"updated_ts":time.time()});self.db.upsert_live_cycle(cycle);self.db.add_live_event(cycle["cycle_id"],"L1_REJECTED_NO_FILL",{"status":st,"source":o1.get("_confirm_source"),"latency_ms":o1.get("_latency_ms"),"error":o1.get("_error")})
            with self.lock:self.active_cycle=None;self.state="READY" if self.execution_enabled else "SAFE_NOT_ARMED";self.last_cycle_ts=time.time();return
        if l1 is None and o1 and order_is_terminal_no_fill(o1):
            l1=self._balance_reconcile_l1(e,cycle)
            if l1 is None:
                cycle.update({"state":"L1_NO_FILL","closed_ts":time.time(),"updated_ts":time.time()});self.db.upsert_live_cycle(cycle);self.db.add_live_event(cycle["cycle_id"],"L1_NO_FILL",{"status":st,"source":o1.get("_confirm_source"),"latency_ms":o1.get("_latency_ms")})
                with self.lock:self.active_cycle=None;self.state="READY" if self.execution_enabled else "SAFE_NOT_ARMED";self.last_cycle_ts=time.time();return
        if l1 is None:l1=self._balance_reconcile_l1(e,cycle)
        if l1 is None:
            cycle.update({"state":"UNKNOWN_L1","error":f"unresolved L1 status={st}","updated_ts":time.time()});self.db.upsert_live_cycle(cycle);self.state="ENTRY_DISABLED_UNKNOWN_L1";return
        cycle.update({"state":"EXPOSURE_ACTIVE","l1_quote_spent":l1["quote_cost"],"l1_base_gross":l1["gross_base"],"l1_base_net":l1["net_base"],"l1_fees_json":json.dumps(l1["fees"],separators=(",",":")),"updated_ts":time.time()});self.db.upsert_live_cycle(cycle)
        if not order_is_filled(o1 or {}) and executed>0:self.db.add_live_event(cycle["cycle_id"],"L1_PARTIAL_UNEXPECTED_COMPLETE_L2",{"status":st,"executed_qty":executed})
        self.state="EXPOSURE_ACTIVE";self.db.add_live_event(cycle["cycle_id"],"L1_EXPOSURE_CONFIRMED",{"status":st,"source":cycle.get("l1_confirm_source"),"latency_ms":cycle.get("l1_latency_ms"),"quote_spent":l1["quote_cost"],"base_net":l1["net_base"],"balance_fallback":bool(l1.get("balance_reconciled"))})
        try:o2,sell_qty,attempts=self._attempt_l2(e,cycle,l1,gate)
        except MexcUnknown as exc:
            cycle["state"]="UNKNOWN_L2";cycle["error"]=repr(exc);self.db.upsert_live_cycle(cycle);self.state="ENTRY_DISABLED_UNKNOWN_L2";return
        self._close_cycle_from_l2(e,cycle,l1,o2,sell_qty,attempts)'''


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('runtime',nargs='?',default='.')
    ap.add_argument('--maintenance-file',required=True)
    args=ap.parse_args();root=Path(args.runtime).resolve()
    live=root/'v4rex'/'live.py';engine=root/'v4rex'/'engine.py';maint=root/'v4rex'/'maintenance.py';startsh=root/'start.sh';cfgp=root/'config.json';cfgexp=root/'config.example.json'
    for p in (live,engine,maint,startsh,cfgp,cfgexp):
        if p.exists():
            b=p.with_suffix(p.suffix+'.PRE_V466')
            if not b.exists():shutil.copy2(p,b)
    if 'MaintenanceCoordinator' not in live.read_text():raise SystemExit('V4.6.5 maintenance hook not found; apply V4.6.5 first')
    maint.write_text(Path(args.maintenance_file).read_text())

    s=live.read_text()
    s=s.replace('V465_LIVE_10USD','V466_LIVE_10USD')
    s=s.replace('self._validated={};self._fee_cache={};self._balances={};self._startup_balances={};self._balances_ts=0.0;self._worker=None;self.private=None;self.client=None;self.query_client=None;self.balance_client=None',
                'self._validated={};self._fee_cache={};self._balances={};self._startup_balances={};self._balances_ts=0.0;self._worker=None;self.private=None;self.client=None;self.query_client=None;self.balance_client=None;self._recovery_shadow_last={}')
    s=insert_before_method(s,'submit',HELPERS)
    s=replace_method(s,'submit',SUBMIT)
    s=replace_method(s,'_live_gate',LIVE_GATE)
    s=replace_method(s,'_entry_plan',ENTRY_PLAN)
    s=replace_method(s,'_route_validated',ROUTE_VALIDATED)
    s=replace_method(s,'_execute',EXECUTE)
    s=s.replace('def _cycle_id(self):return "V464-"+time.strftime("%Y%m%d-%H%M%S")+"-"+uuid.uuid4().hex[:6]', 'def _cycle_id(self):return "V466-"+time.strftime("%Y%m%d-%H%M%S")+"-"+uuid.uuid4().hex[:6]')
    s=s.replace('def _client_id(self,leg):return ("v464"+leg+str(int(time.time()*1000))[-9:]+uuid.uuid4().hex[:7])[:32]', 'def _client_id(self,leg):return ("v466"+leg+str(int(time.time()*1000))[-9:]+uuid.uuid4().hex[:7])[:32]')
    s=s.replace('"quote_cost":cost if cost>0 else float(self.size)', '"quote_cost":cost if cost>0 else float(getattr(e,"size",self.size))')
    # Status: expose recovery state and maintenance-inclusive nominal strategy PnL.
    old='''        out["maintenance"]=self.maintenance.status() if getattr(self,"maintenance",None) else {"enabled":False}\n        return out'''
    new='''        out["maintenance"]=self.maintenance.status() if getattr(self,"maintenance",None) else {"enabled":False}\n        out["inventory_recovery"]={"active":self._inventory_recovery_active(),"trigger_usdc":float(self.cfg.get("inventory_recovery_trigger_usdc",60.0)),"live_sizes":self.cfg.get("inventory_recovery_sizes_usd",[40,25,20,10]),"reverse_live_min_edge_bps":float(self.cfg.get("inventory_recovery_live_min_edge_bps",0.0)),"reverse_shadow_min_edge_bps":float(self.cfg.get("inventory_recovery_shadow_min_edge_bps",-1.0)),"forward_min_edge_bps_when_active":float(self.cfg.get("inventory_forward_min_edge_bps",5.0))}\n        m=out["maintenance"];cash=float((pnl or {}).get("realized_pnl_nominal") or 0);dust_now=float((dust or {}).get("est_usd") or 0);recovered=float(m.get("dust_recovered_usdc") or 0);reb_nom=float(m.get("rebalance_nominal_pnl_1to1") or 0)\n        out["strategy_pnl_nominal"]={"cash_cycles":cash,"outstanding_dust":dust_now,"recovered_dust_usdc":recovered,"rebalance_nominal_pnl_1to1":reb_nom,"total":cash+dust_now+recovered+reb_nom}\n        return out'''
    if old not in s:raise RuntimeError('V4.6.5 status hook not found')
    s=s.replace(old,new,1)
    live.write_text(s)

    es=engine.read_text()
    oldblock='''        if self.live_executor is not None:\n            live_size=float(self.cfg.get('live_trade_size_usd',10));qf=float(self.cfg.get('qualification_depth_fraction',0.25))\n            live=[e for e in ev if e.accepted and abs(e.size-live_size)<1e-9 and abs(e.fraction-qf)<1e-12]\n            if live:\n                try:self.live_executor.submit(max(live,key=self._score))\n                except Exception as exc:self.db.add_live_event(None,'LIVE_SUBMIT_ERROR',{'route':r.route,'error':repr(exc)})'''
    newblock='''        if self.live_executor is not None:\n            qf=float(self.cfg.get('qualification_depth_fraction',0.25))\n            try:\n                candidate=self.live_executor.select_live_candidate(ev,qf)\n                if candidate:self.live_executor.submit(candidate)\n            except Exception as exc:self.db.add_live_event(None,'LIVE_SUBMIT_ERROR',{'route':r.route,'error':repr(exc)})'''
    if oldblock not in es:raise RuntimeError('engine live-dispatch anchor not found')
    engine.write_text(es.replace(oldblock,newblock,1))
    if startsh.exists():
        st=startsh.read_text().replace('V4.6.4 MICRO-LIVE','V4.6.6 INVENTORY-LIVE')
        startsh.write_text(st)

    add={
      'execution_enabled':False,'live_arm_token':'V466_LIVE_10USD',
      'inventory_recovery_enabled':True,'inventory_recovery_trigger_usdc':60.0,
      'inventory_recovery_sizes_usd':[40,25,20,10],
      'inventory_recovery_live_min_edge_bps':0.0,'inventory_recovery_shadow_min_edge_bps':-1.0,
      'inventory_forward_min_edge_bps':5.0,'inventory_recovery_shadow_log_s':30.0,
      'rebalance_mode':'EMERGENCY_ONLY','rebalance_cooldown_s':300.0,
      'dust_direct_enabled':True,'dust_direct_check_s':30.0,'dust_direct_min_est_usd':0.50,
      'dust_direct_max_assets_per_pass':3,'dust_direct_price_cushion_bps':2.0,
    }
    for cp in (cfgp,cfgexp):
        if not cp.exists():continue
        c=json.loads(cp.read_text());sizes=[float(x) for x in c.get('test_sizes_usd',[])]
        if 40.0 not in sizes:sizes.append(40.0)
        c['test_sizes_usd']=sorted(sizes);c.update(add);cp.write_text(json.dumps(c,indent=2)+'\n')
    try:
        for p in (live,engine,maint):py_compile.compile(str(p),doraise=True)
    except Exception:
        # Automatic rollback on syntax failure.
        for p in (live,engine,maint,startsh,cfgp,cfgexp):
            b=p.with_suffix(p.suffix+'.PRE_V466')
            if b.exists():shutil.copy2(b,p)
        raise
    print('PATCHED V4.6.6:',root)
    print('SYNTAX CHECK: PASS')
    print('NEW ARM TOKEN: V466_LIVE_10USD')
    print('execution_enabled reset to false by design')
    print('engine.py change is limited to LIVE candidate dispatch; evaluation/qualification untouched')

if __name__=='__main__':main()
