from v4rex.maintenance import _floor_step,_ceil_price,_floor_price

def test_rounding_v466():
    assert _floor_step(40.019,0.01)==40.01
    assert _ceil_price(1.00001,4)==1.0001
    assert _floor_price(1.00009,4)==1.0
