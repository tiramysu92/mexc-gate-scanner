# V4.6.6 — Inventory Recovery + Direct Dust to USDC

This is a narrow patch on top of the already-installed V4.6.5 runtime.

## What stays unchanged

The REX core remains intact: FORCE-L2 after L1 exposure, Private WS/REST/Query reconciliation, real account fees, one exposure maximum, L1/L2 reserves, survivability gates, bag protection, and L2 completion logic.

`engine.py` receives only a small LIVE-dispatch hook: it asks the existing LIVE executor which already-evaluated candidate to submit. `_evaluate`, qualification, depth math and survivability logic are not changed.

## V4.6.6 changes

### Natural inventory recovery

When free USDC falls below 60 USD:

- reverse routes `USDT -> token -> USDC` are preferred;
- LIVE reverse threshold is strictly above **0 bp guaranteed**;
- reverse sizes are attempted in order **40 / 25 / 20 / 10 USD**;
- every size still needs its own exact >=1000 survivability trials and A/B ratios;
- therefore 40 USD does **not** become LIVE merely because the config says 40;
- 40 USD is added to the learning grid and becomes usable only after exact qualification;
- candidates down to **-1 bp** are recorded in shadow as `RECOVERY_SHADOW_CANDIDATE` but are not executed.

While recovery is active, inventory-draining `USDC -> token -> USDT` routes require at least **+5 bp guaranteed**.

### Direct stablecoin rebalance

Direct `USDT <-> USDC` rebalance becomes `EMERGENCY_ONLY`: it only fires after a stable can no longer fund a normal 10 USD entry + 20 USD reserve. Natural reverse routes and dust recovery have priority.

### Dust

Every ~30 s, when no LIVE exposure exists, strategy dust is checked for a direct `TOKENUSDC` spot sale. The bot sells exactly the strategy quantity, so a pre-existing bag is not touched. `/order/test` must pass first. Residual non-tradable dust keeps the existing 3-hour `dust -> MX -> strategy_MX -> USDC` fallback.

### PnL accounting

V4.6.6 exposes:

- cycle cash PnL;
- outstanding dust;
- recovered dust proceeds;
- nominal rebalance PnL at 1:1 stable valuation;
- rebalance execution friction versus the signal mid;
- a maintenance-inclusive nominal strategy total.

Use `pnl_v466.py` for the detailed console view.

## Safety

New arm token: `V466_LIVE_10USD`.

The patch resets `execution_enabled=false` by design.
