#!/usr/bin/env python3
from __future__ import annotations
import json, sqlite3

try:
    import requests
except Exception:
    requests=None

cfg=json.load(open('config.json'))
db=sqlite3.connect(cfg['db_path'])
db.row_factory=sqlite3.Row

p=db.execute("""
SELECT COUNT(*) n,COALESCE(SUM(realized_pnl_nominal),0) cash,
       COALESCE(SUM(l1_quote_spent),0) turnover
FROM live_cycles WHERE state IN ('CLOSED','CLOSED_WITH_RESIDUAL')
""").fetchone()

dust=float(db.execute("SELECT COALESCE(SUM(est_usd),0) FROM live_dust").fetchone()[0] or 0)

recovered=0.0;reb_nom=0.0;reb_mid_cost=0.0;rebs=0
for r in db.execute("SELECT kind,status,value_usd,detail_json FROM maintenance_events ORDER BY id"):
    kind,status,value,detail=r
    try:d=json.loads(detail or '{}')
    except Exception:d={}
    if kind in ('DUST_DIRECT_SELL','DUST_MX_SELL') and status=='FILLED':recovered+=float(value or 0)
    if kind=='REBALANCE' and status=='FILLED':
        rebs+=1;reb_nom+=float(d.get('nominal_pnl_1to1') or 0);reb_mid_cost+=float(d.get('execution_cost_mid_quote') or 0)

mxrow=db.execute("SELECT qty FROM maintenance_inventory WHERE asset='MX'").fetchone()
mx=float(mxrow[0] if mxrow else 0)
mx_value=0.0
if mx>0 and requests:
    try:
        x=requests.get('https://api.mexc.com/api/v3/depth',params={'symbol':'MXUSDC','limit':5},timeout=4).json()
        bid=float((x.get('bids') or [[0]])[0][0]);mx_value=mx*bid
    except Exception:pass

cash=float(p['cash'] or 0);turn=float(p['turnover'] or 0)
total=cash+dust+recovered+mx_value+reb_nom
print('\n================ V4.6.6 STRATEGY PNL ================')
print('Closed cycles                 :',p['n'])
print(f'Turnover                      : {turn:.6f} $')
print(f'Cycle cash PnL                : {cash:+.9f} $')
print(f'Outstanding strategy dust     : {dust:+.9f} $')
print(f'Recovered dust -> USDC        : {recovered:+.9f} $')
print(f'Pending strategy MX mark      : {mx_value:+.9f} $  (qty={mx:.9f})')
print(f'Rebalance nominal PnL 1:1     : {reb_nom:+.9f} $  ({rebs} fills)')
print('------------------------------------------------------')
print(f'STRATEGY PNL NOMINAL          : {total:+.9f} $')
if turn:print(f'STRATEGY PNL / turnover       : {total/turn*10000:+.3f} bps')
print(f'Rebalance execution friction  : {reb_mid_cost:+.9f} quote-units vs signal mid')
print('======================================================\n')
