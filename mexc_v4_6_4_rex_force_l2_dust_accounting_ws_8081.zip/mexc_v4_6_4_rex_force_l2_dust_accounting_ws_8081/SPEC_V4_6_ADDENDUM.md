# SPEC V4.6 ADDENDUM — MICRO-LIVE / L2 COMPLETION

## Invariants

1. `REPLAY/SHADOW/MICRO-LIVE` conservent les mêmes seuils de qualification économiques : A >1 bp NET, B >2 bp NET.
2. C n'est jamais exécutable dans cette phase.
3. Fee admission par jambe = `max(fee authentifié MEXC, 5 bp)`.
4. LIVE n'accepte que la taille 10 USD et une seule exposition.
5. La preuve de survivabilité est route × taille, >=1000 trials avant exécution.
6. Après fill L1, aucun re-gate d'edge : L2 Completion Coordinator possède l'exposition.
7. FOK est le primitive d'ordre normal.
8. Timeout/5xx => UNKNOWN. Réconciliation obligatoire avant tout ordre contradictoire.
9. Private WS = chemin rapide de confirmation; REST = autorité de réconciliation/crash recovery.
10. Un bag préexistant n'est jamais vendable par la stratégie.
11. Dust de rounding est journalisée et non bloquante; un gros résidu devient une exposition et désactive les entrées.
12. Aucun rebalance stablecoin automatique dans cette version.
13. Aucun auto-convert de dust vers MX.

## L2 Completion

Tentatives FOK planifiées autour des horizons mesurés : immédiat, ~100 ms, ~250 ms, ~500 ms. Si aucune ne remplit, l'exposition reste active et L2 est retentée à cadence bornée. Le plafond de perte acceptable peut s'élargir après le délai primaire, mais la stratégie ne repasse jamais en mode "nouvelle entrée" tant que l'exposition n'est pas clôturée/réconciliée.

## Dashboard / Audit

Chaque cycle conserve : route, classe, size, edge prévu, order/client IDs, quantités réelles, quote dépensée/reçue, commissions par asset, tentatives L2, PnL réalisé, dust, état et événements horodatés.
