"""Free-tier hybrid BBO transport.

Tier 1 keeps the complete universe on MEXC BookTicker @100ms.
Tier 2 is a bounded dynamic 10ms fast lane used for:
  * routes that become BBO-positive on Tier 1;
  * optional static symbols/tokens;
  * a rotating audit probe over complete token bundles.

The two tiers publish into separate SharedBBO arrays. HybridSharedBBO chooses the
newest exchange event for active fast-lane symbols, otherwise the 100ms baseline.
"""
from __future__ import annotations
import json, math, multiprocessing as mp, os, random, threading, time
from collections import deque
import websocket
from .core import BBO
from .mp_bbo import SharedBBO, MultiprocessBBOCollector, _write, _decode, _control, _pct, WS


def _fast_worker(symbols, sym_index, shared, stats_q, ctrl_q, stop_ev, cfg, clock_offset_ms):
    n_ws=max(1,int(cfg.get('fast_lane_ws',3)))
    channels={i:{'id':1000+i,'slot':i,'symbols':set(),'connected':False,'messages':0,'acks':0,'pongs':0,'errors':0,'reconnects':0,'decode':deque(maxlen=5000),'transport':deque(maxlen=5000),'times':deque(maxlen=30000),'last':0.0,'app':None} for i in range(1,n_ws+1)}
    lock=threading.RLock()

    def stream(s): return f'spot@public.aggre.bookTicker.v3.api.pb@10ms@{s}'

    def apply_plan(plan):
        for slot,c in channels.items():
            desired=set(plan.get(slot,()))
            with lock:
                old=set(c['symbols']); c['symbols']=desired; app=c.get('app'); connected=c['connected']
            if not connected or not app: continue
            rem=sorted(old-desired); add=sorted(desired-old)
            try:
                if rem: app.send(json.dumps({'method':'UNSUBSCRIPTION','params':[stream(s) for s in rem]}))
                if add: app.send(json.dumps({'method':'SUBSCRIPTION','params':[stream(s) for s in add]}))
            except Exception:
                with lock:c['errors']+=1

    def socket_loop(slot):
        c=channels[slot]; back=.5; wid=c['id']
        while not stop_ev.is_set():
            def on_open(ws):
                with lock:c['connected']=True; syms=sorted(c['symbols'])
                if syms: ws.send(json.dumps({'method':'SUBSCRIPTION','params':[stream(s) for s in syms]}))
            def on_msg(ws,msg):
                rn=time.monotonic_ns(); rw=time.time()*1000
                ctrl=_control(msg)
                if ctrl is not None:
                    with lock:
                        if str(ctrl.get('msg','')).upper()=='PONG':c['pongs']+=1
                        else:c['acks']+=1
                    return
                if not isinstance(msg,(bytes,bytearray)): return
                try:
                    x=_decode(bytes(msg))
                    if not x:return
                    sym,bid,bq,ask,aq,ver,ex=x
                    with lock:active=sym in c['symbols']
                    if not active:return
                    idx=sym_index.get(sym)
                    if idx is None:return
                    an=time.monotonic_ns();_write(shared,idx,bid,bq,ask,aq,ver,ex,rw,rn,an,wid)
                    lag=(an-rn)/1e6;td=(rw+clock_offset_ms-ex) if ex else None
                    with lock:
                        c['messages']+=1;c['decode'].append(lag);c['times'].append(time.monotonic());c['last']=time.time()
                        if td is not None and math.isfinite(td):c['transport'].append(td)
                except Exception:
                    with lock:c['errors']+=1
            def on_err(ws,exc):
                with lock:c['errors']+=1
            def on_close(ws,code,msg):
                with lock:c['connected']=False
            app=websocket.WebSocketApp(WS,on_open=on_open,on_message=on_msg,on_error=on_err,on_close=on_close)
            with lock:c['app']=app
            def ping():
                while not stop_ev.is_set():
                    time.sleep(float(cfg.get('ping_interval_s',15)))
                    with lock:ok=c['connected']
                    if not ok:return
                    try:app.send(json.dumps({'method':'PING'}))
                    except Exception:return
            threading.Thread(target=ping,daemon=True).start()
            try:app.run_forever(ping_interval=0,skip_utf8_validation=True)
            except Exception:
                with lock:c['errors']+=1
            with lock:c['connected']=False;c['reconnects']+=1
            if stop_ev.is_set():break
            time.sleep(back+random.random()*.2);back=min(10,back*1.5)

    for slot in channels:
        threading.Thread(target=socket_loop,args=(slot,),daemon=True,name=f'fast-ws-{slot}').start()

    last_stats=0.0
    while not stop_ev.is_set():
        try:
            while True:
                plan=ctrl_q.get_nowait()
                if isinstance(plan,dict):apply_plan(plan)
        except Exception:pass
        now=time.monotonic()
        if now-last_stats>=1.0:
            rows=[]
            with lock:
                for slot,c in channels.items():
                    times=tuple(c['times']);dec=tuple(c['decode']);tr=tuple(c['transport'])
                    rows.append({'id':c['id'],'tier':'FAST10','interval_ms':10,'worker':1,'pid':os.getpid(),'connected':c['connected'],'symbol_count':len(c['symbols']),'messages':c['messages'],'msg_rate_10s':sum(1 for t in times if now-t<=10)/10,'decode_lag_p50_ms':_pct(dec,.5),'decode_lag_p95_ms':_pct(dec,.95),'transport_p50_ms':_pct(tr,.5),'transport_p95_ms':_pct(tr,.95),'transport_gt_500_pct':(100.0*sum(1 for x in tr if x>500)/len(tr) if tr else 0.0),'acks':c['acks'],'pongs':c['pongs'],'errors':c['errors'],'reconnects':c['reconnects'],'last_message_age_s':max(0,time.time()-c['last']) if c['last'] else None,'symbols':tuple(sorted(c['symbols']))})
            try:stats_q.put_nowait({'ts':time.time(),'channels':rows})
            except Exception:pass
            last_stats=now
        stop_ev.wait(.05)
    with lock:apps=[c.get('app') for c in channels.values()]
    for app in apps:
        try:
            if app:app.close()
        except Exception:pass


class DynamicFastLane:
    def __init__(self,cfg,symbols,shared,clock_offset_ms=0.0,probe_bundles=None,symbol_loads=None,active_mask=None):
        self.cfg=cfg;self.symbols=tuple(symbols);self.shared=shared;self.ctx=mp.get_context('fork');self.active_mask=active_mask;self.stop_ev=self.ctx.Event();self.ctrl_q=self.ctx.Queue(maxsize=8);self.stats_q=self.ctx.Queue(maxsize=20);self.process=None;self.stop=False
        self.lock=threading.RLock();self.candidate_bundles={};self.current=set();self.current_probe=set();self.stats=[];self.promotions=0;self.rotations=0;self.last_rotation=0.0;self.probe_cursor=0
        self.probe_bundles=[tuple(x) for x in (probe_bundles or []) if x];self.loads=dict(symbol_loads or {})
        self.static=set(s for s in cfg.get('fast_lane_static_symbols',[]) if s in shared.index)
        cap=max(1,int(cfg.get('fast_lane_ws',3))*min(30,max(1,int(cfg.get('fast_lane_group_size',20)))))
        self.capacity=cap;self.probe_budget=max(0,min(cap,int(cfg.get('fast_probe_symbol_budget',20))))
    def start(self):
        self.process=self.ctx.Process(target=_fast_worker,args=(self.symbols,self.shared.index,self.shared.args(),self.stats_q,self.ctrl_q,self.stop_ev,self.cfg,float(self.cfg.get('_clock_offset_ms',0.0))),daemon=True,name='fast-lane-bbo');self.process.start()
        threading.Thread(target=self._manager,daemon=True,name='fast-lane-manager').start();threading.Thread(target=self._listen,daemon=True,name='fast-lane-stats').start()
    def touch(self,symbols,ttl=None):
        exp=time.time()+float(ttl or self.cfg.get('fast_lane_ttl_s',60));bundle=tuple(sorted({s for s in symbols if s in self.shared.index}))
        if not bundle:return
        with self.lock:
            if bundle not in self.candidate_bundles:self.promotions+=1
            self.candidate_bundles[bundle]=max(self.candidate_bundles.get(bundle,0),exp)
    def _next_probe(self,budget):
        if budget<=0 or not self.probe_bundles:return set()
        out=set();seen=0;n=len(self.probe_bundles)
        while seen<n and len(out)<budget:
            b=self.probe_bundles[self.probe_cursor%n];self.probe_cursor=(self.probe_cursor+1)%n;seen+=1
            if len(out)+len(b)>budget and out:continue
            out.update(b)
        self.rotations+=1;return out
    def _desired(self):
        now=time.time()
        with self.lock:
            dead=[b for b,t in self.candidate_bundles.items() if t<=now]
            for b in dead:self.candidate_bundles.pop(b,None)
            bundles=sorted(self.candidate_bundles,key=lambda b:(-self.candidate_bundles[b],-sum(float(self.loads.get(s,1)) for s in b),b))
            desired=set(self.static);candidate_symbols=set()
            for b in bundles:
                add=set(b)-desired
                if len(desired)+len(add)>self.capacity:continue
                desired.update(add);candidate_symbols.update(b)
            remain=self.capacity-len(desired);probe_budget=min(self.probe_budget,remain)
            rotate_s=float(self.cfg.get('fast_probe_rotate_s',30))
            if now-self.last_rotation>=rotate_s or not self.current_probe:
                self.current_probe=self._next_probe(probe_budget);self.last_rotation=now
            probe=set(list(self.current_probe)[:probe_budget]);desired.update(probe)
            return desired,probe,len(candidate_symbols)
    def _plan(self,desired):
        n=max(1,int(self.cfg.get('fast_lane_ws',3)));g=max(1,min(30,int(self.cfg.get('fast_lane_group_size',20))));slots={i:[] for i in range(1,n+1)};loads=[0.0]*n
        for s in sorted(desired,key=lambda x:(-float(self.loads.get(x,1)),x)):
            choices=[i for i in range(n) if len(slots[i+1])<g]
            if not choices:break
            i=min(choices,key=lambda j:loads[j]);slots[i+1].append(s);loads[i]+=float(self.loads.get(s,1))
        return {i:tuple(v) for i,v in slots.items()}
    def _manager(self):
        last=None
        while not self.stop:
            desired,probe,_=self._desired()
            plan=self._plan(desired)
            key=tuple((i,plan[i]) for i in sorted(plan))
            if key!=last:
                try:
                    while True:self.ctrl_q.get_nowait()
                except Exception:pass
                try:self.ctrl_q.put_nowait(plan)
                except Exception:pass
                with self.lock:self.current=set(desired)
                if self.active_mask is not None:
                    for i,s in enumerate(self.symbols):self.active_mask[i]=1 if s in desired else 0
                last=key
            time.sleep(.25)
    def _listen(self):
        while not self.stop:
            try:x=self.stats_q.get(timeout=.5)
            except Exception:continue
            with self.lock:self.stats=list(x.get('channels',[]))
    def is_active(self,symbol):
        with self.lock:return symbol in self.current
    def active_snapshot(self):
        with self.lock:return set(self.current),set(self.current_probe),set().union(*self.candidate_bundles.keys()) if self.candidate_bundles else set()
    def status(self):
        with self.lock:
            rows=[dict(x) for x in self.stats];active=set(self.current);probe=set(self.current_probe);cands=len(set().union(*(b for b,t in self.candidate_bundles.items() if t>time.time()))) if self.candidate_bundles else 0
        return {'active_symbols':len(active),'candidate_symbols':cands,'probe_symbols':len(active&probe),'static_symbols':len(active&self.static),'capacity':self.capacity,'promotions':self.promotions,'probe_rotations':self.rotations,'ws_connected':sum(bool(x.get('connected')) for x in rows),'ws_total':max(1,int(self.cfg.get('fast_lane_ws',3))),'msg_rate_10s':sum(float(x.get('msg_rate_10s') or 0) for x in rows),'errors':sum(int(x.get('errors') or 0) for x in rows),'reconnects':sum(int(x.get('reconnects') or 0) for x in rows),'channels':rows,'worker_alive':bool(self.process and self.process.is_alive())}
    def close(self):
        self.stop=True;self.stop_ev.set()
        if self.process:
            self.process.join(timeout=3)
            if self.process.is_alive():self.process.terminate()


class HybridSharedBBO:
    def __init__(self,base,fast,active_mask):
        self.base=base;self.fast=fast;self.index=base.index;self.symbols=base.symbols;self.active_mask=active_mask
    def read_idx(self,i):
        b=self.base.read_idx(i);s=self.symbols[i]
        if not self.active_mask[i]:return b
        f=self.fast.read_idx(i)
        if not f:return b
        if not b:return f
        # exchange sendTime first; receive monotonic breaks ties/missing timestamps
        bex, fex = int(b[5] or 0), int(f[5] or 0)
        if fex>bex:return f
        if bex>fex:return b
        return f if int(f[7] or 0)>=int(b[7] or 0) else b
    def get_bbo(self,symbol):
        i=self.index.get(symbol)
        if i is None:return None
        z=self.read_idx(i)
        if not z:return None
        bid,bq,ask,aq,ver,ex,rw,rn,an,wid=z
        return BBO(symbol,bid,bq,ask,aq,ver or None,ex or None,rw or None,rn,an,wid,'VALID')
    def snapshot_bbo(self):
        out={}
        for i,s in enumerate(self.symbols):
            z=self.read_idx(i)
            if not z:continue
            bid,bq,ask,aq,ver,ex,rw,rn,an,wid=z;out[s]=BBO(s,bid,bq,ask,aq,ver or None,ex or None,rw or None,rn,an,wid,'VALID')
        return out


class HybridBBOCollector:
    def __init__(self,cfg,symbols,groups,error,clock_offset_ms=0.0,probe_bundles=None,symbol_loads=None):
        self.cfg=cfg;self.error=error;self.ctx=mp.get_context('fork');self.base_shared=SharedBBO(symbols,self.ctx);self.fast_shared=SharedBBO(symbols,self.ctx);self.active_mask=self.ctx.RawArray('B',len(symbols))
        base_workers=int(cfg.get('bbo_worker_processes',0) or 0)
        # Free-tier default: two baseline workers on two vCPU. The 100ms stream is light.
        if base_workers<=0:cfg=dict(cfg);cfg['bbo_worker_processes']=max(1,min(2,os.cpu_count() or 2))
        self.base=MultiprocessBBOCollector(cfg,symbols,groups,error,clock_offset_ms,self.base_shared,int(cfg.get('bbo_base_interval_ms',100)),'BASE100')
        fcfg=dict(cfg);fcfg['_clock_offset_ms']=float(clock_offset_ms or 0.0)
        self.fast=DynamicFastLane(fcfg,symbols,self.fast_shared,clock_offset_ms,probe_bundles,symbol_loads,self.active_mask)
        self.shared=HybridSharedBBO(self.base_shared,self.fast_shared,self.active_mask)
    def start(self):self.base.start();self.fast.start()
    def touch_fast(self,symbols,ttl=None):self.fast.touch(symbols,ttl)
    def get_bbo(self,s):return self.shared.get_bbo(s)
    def snapshot_bbo(self):return self.shared.snapshot_bbo()
    def ws_status(self):return self.base.ws_status()
    def fast_ws_status(self):return self.fast.status().get('channels',[])
    def status(self):
        b=self.base.status();f=self.fast.status();return {**b,'fast_lane':f,'base_interval_ms':int(self.cfg.get('bbo_base_interval_ms',100))}
    def close(self):self.fast.close();self.base.close()
