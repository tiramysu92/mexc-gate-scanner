from __future__ import annotations
from dataclasses import dataclass, asdict, replace
from typing import Any
import gzip, json, math, time, requests

REST = 'https://api.mexc.com'

@dataclass(frozen=True)
class SymbolRule:
    symbol: str
    base: str
    quote: str
    status: str
    spot_allowed: bool
    api_default: bool
    base_precision: int | None
    quote_precision: int | None
    base_size_precision: str | None
    quote_amount_precision: str | None
    max_quote_amount: str | None
    maker_commission: str | None
    taker_commission: str | None
    trade_side_type: str | None
    activity_score: float = 1.0
    quote_volume_24h: float | None = None
    trade_count_24h: float | None = None

@dataclass(frozen=True)
class Route:
    route: str
    token: str
    stable_a: str
    stable_b: str
    symbol1: str
    symbol2: str

class Universe:
    def __init__(self, symbols, routes, excluded, raw_exchange_info, default_symbols,
                 route_excluded=None, ws_groups=None, ticker_snapshot=None):
        self.symbols = symbols
        self.routes = routes
        self.excluded = excluded
        self.raw_exchange_info = raw_exchange_info
        self.default_symbols = default_symbols
        self.route_excluded = route_excluded or []
        self.ws_groups = ws_groups or []
        self.ticker_snapshot = ticker_snapshot or []
        self.by_symbol = {s.symbol: s for s in symbols}
        self.route_by_name = {r.route: r for r in routes}

    def as_dict(self):
        by_token = {}
        for s in self.symbols:
            by_token.setdefault(s.base, []).append(s.quote)
        return {
            'symbol_count': len(self.symbols),
            'route_count': len(self.routes),
            'token_count': len(by_token),
            'symbols': [asdict(x) for x in self.symbols],
            'routes': [asdict(x) for x in self.routes],
            'quotes_by_token': {k: sorted(v) for k, v in sorted(by_token.items())},
            'excluded': self.excluded,
            'route_excluded': self.route_excluded,
            'ws_groups': self.ws_groups,
        }

def _status_ok(status: Any) -> bool:
    return str(status).upper() in {'1', 'ENABLED', 'ONLINE', 'TRADING'}

def _can_buy(t):
    # MEXC: 1=all, 2=buy only, 3=sell only. Missing => do not over-filter in Shadow.
    return t in (None, 'None', '', '1', '2')

def _can_sell(t):
    return t in (None, 'None', '', '1', '3')

def _f(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None

def _activity_map(tickers):
    out = {}
    if isinstance(tickers, dict):
        tickers = [tickers]
    for x in tickers or []:
        sym = str(x.get('symbol') or '')
        if not sym:
            continue
        count = _f(x.get('count'))
        qv = _f(x.get('quoteVolume'))
        if not qv or qv <= 0:
            vol, last = _f(x.get('volume')), _f(x.get('lastPrice'))
            if vol and last and vol > 0 and last > 0:
                qv = vol * last
        # Message pressure is closer to trade activity than to nominal volume.
        # Count is preferred; sqrt(quote volume) is a robust fallback when MEXC returns count=null.
        if count and count > 0:
            score = count
        elif qv and qv > 0:
            score = math.sqrt(qv)
        else:
            score = 1.0
        out[sym] = {'score': max(1.0, float(score)), 'quote_volume': qv, 'count': count}
    return out

def balanced_ws_groups(symbols: list[SymbolRule], group_size: int = 20):
    """Greedy load-balanced WS plan with soft same-token anti-affinity.

    MEXC currently allows at most 30 subscriptions per connection. We default to 20,
    leaving headroom and spreading the most active markets across independent sockets.
    """
    group_size = max(1, min(30, int(group_size)))
    if not symbols:
        return []
    n_groups = max(1, math.ceil(len(symbols) / group_size))
    groups = [{'id': i + 1, 'symbols': [], 'bases': set(), 'load_score': 0.0,
               'quote_volume_24h': 0.0, 'trade_count_24h': 0.0} for i in range(n_groups)]
    ranked = sorted(symbols, key=lambda s: (-float(s.activity_score or 1), s.symbol))
    for s in ranked:
        available = [g for g in groups if len(g['symbols']) < group_size]
        min_load = min(g['load_score'] for g in available)
        # Prefer a socket without another market of the same token when that does not
        # materially unbalance load. Correlated bursts are therefore spread where possible.
        headroom = max(1.0, min_load * 0.15)
        preferred = [g for g in available if s.base not in g['bases'] and g['load_score'] <= min_load + headroom]
        pool = preferred or available
        g = min(pool, key=lambda z: (z['load_score'], len(z['symbols']), z['id']))
        g['symbols'].append(s.symbol)
        g['bases'].add(s.base)
        g['load_score'] += float(s.activity_score or 1)
        g['quote_volume_24h'] += float(s.quote_volume_24h or 0)
        g['trade_count_24h'] += float(s.trade_count_24h or 0)
    result = []
    for g in groups:
        result.append({
            'id': g['id'], 'symbols': sorted(g['symbols']), 'symbol_count': len(g['symbols']),
            'load_score': g['load_score'], 'quote_volume_24h': g['quote_volume_24h'],
            'trade_count_24h': g['trade_count_24h'],
        })
    return result

def parse_exchange_info(payload: dict, cfg: dict, default_symbols: set[str] | None = None, tickers=None) -> Universe:
    default_symbols = default_symbols or set()
    stablecoins = set(cfg.get('stablecoins', ['USDT', 'USDC', 'USD1']))
    full_mode = str(cfg.get('universe_mode', 'FULL_STABLECOIN_2LEG')).upper() == 'FULL_STABLECOIN_2LEG'
    allowlist = set(cfg.get('token_allowlist') or cfg.get('tokens') or [])
    require_default = bool(cfg.get('require_default_symbols', True))
    activity = _activity_map(tickers)
    valid = []
    excluded = []

    for x in payload.get('symbols') or []:
        symbol = str(x.get('symbol') or '')
        base = str(x.get('baseAsset') or '')
        quote = str(x.get('quoteAsset') or '')
        if quote not in stablecoins or base in stablecoins:
            continue
        if (not full_mode) and allowlist and base not in allowlist:
            continue
        if full_mode and allowlist and base not in allowlist:
            # Optional allowlist can deliberately narrow FULL mode for a diagnostic run.
            continue
        reasons = []
        status = x.get('status')
        if not _status_ok(status): reasons.append('STATUS')
        spot = bool(x.get('isSpotTradingAllowed', False))
        if not spot: reasons.append('SPOT_API_DISABLED')
        api_default = (symbol in default_symbols) if default_symbols else True
        if require_default and default_symbols and not api_default: reasons.append('NOT_DEFAULT_API_SYMBOL')
        if reasons:
            excluded.append({'symbol': symbol, 'base': base, 'quote': quote, 'reasons': reasons})
            continue
        a = activity.get(symbol, {'score': 1.0, 'quote_volume': None, 'count': None})
        valid.append(SymbolRule(
            symbol, base, quote, str(status), spot, api_default,
            x.get('baseAssetPrecision'), x.get('quotePrecision'), x.get('baseSizePrecision'),
            x.get('quoteAmountPrecision'), x.get('maxQuoteAmount'), x.get('makerCommission'),
            x.get('takerCommission'), str(x.get('tradeSideType')) if x.get('tradeSideType') is not None else None,
            float(a['score']), a['quote_volume'], a['count']))

    by_base = {}
    for s in valid:
        by_base.setdefault(s.base, []).append(s)
    eligible_bases = {b for b, ss in by_base.items() if len({s.quote for s in ss}) >= 2}
    for base, ss in by_base.items():
        if base not in eligible_bases:
            for s in ss:
                excluded.append({'symbol': s.symbol, 'base': s.base, 'quote': s.quote, 'reasons': ['TOKEN_LT2_STABLE_QUOTES']})
    selected = [s for s in valid if s.base in eligible_bases]
    market = {(s.base, s.quote): s for s in selected}

    routes = []
    route_excluded = []
    for token in sorted(eligible_bases):
        quotes = sorted(q for q in stablecoins if (token, q) in market)
        for a in quotes:
            for b in quotes:
                if a == b:
                    continue
                s1, s2 = market[(token, a)], market[(token, b)]
                rr = f'{a}>{token}>{b}'
                reasons = []
                if not _can_buy(s1.trade_side_type): reasons.append('LEG1_BUY_NOT_ALLOWED')
                if not _can_sell(s2.trade_side_type): reasons.append('LEG2_SELL_NOT_ALLOWED')
                if reasons:
                    route_excluded.append({'route': rr, 'symbol1': s1.symbol, 'symbol2': s2.symbol, 'reasons': reasons})
                else:
                    routes.append(Route(rr, token, a, b, s1.symbol, s2.symbol))

    # Subscribe only symbols that participate in at least one valid directed route.
    used = {r.symbol1 for r in routes} | {r.symbol2 for r in routes}
    for s in selected:
        if s.symbol not in used:
            excluded.append({'symbol': s.symbol, 'base': s.base, 'quote': s.quote, 'reasons': ['NO_VALID_2LEG_DIRECTION']})
    selected = [s for s in selected if s.symbol in used]
    ws_groups = balanced_ws_groups(selected, int(cfg.get('ws_group_size', 20)))
    return Universe(selected, routes, excluded, payload, default_symbols, route_excluded, ws_groups, tickers or [])

class UniverseBuilder:
    def __init__(self, cfg):
        self.cfg = cfg
        self.session = requests.Session()

    def build(self):
        timeout = float(self.cfg.get('rest_timeout_s', 8))
        r = self.session.get(REST + '/api/v3/exchangeInfo', timeout=timeout)
        r.raise_for_status(); exchange = r.json()
        defaults = set()
        try:
            x = self.session.get(REST + '/api/v3/defaultSymbols', timeout=timeout)
            x.raise_for_status(); defaults = set(x.json().get('data') or [])
        except Exception:
            defaults = set()
        tickers = []
        try:
            # One startup call only. MEXC documents weight 40 when all symbols are requested.
            x = self.session.get(REST + '/api/v3/ticker/24hr', timeout=max(timeout, 12))
            x.raise_for_status(); tickers = x.json() or []
        except Exception:
            tickers = []
        return parse_exchange_info(exchange, self.cfg, defaults, tickers)

    @staticmethod
    def save_snapshot(universe, path):
        with gzip.open(path, 'wt', encoding='utf-8') as f:
            json.dump({
                'saved_at': time.time(), 'universe': universe.as_dict(),
                'exchange_info': universe.raw_exchange_info,
                'default_symbols': sorted(universe.default_symbols),
                'ticker_24h': universe.ticker_snapshot,
            }, f, separators=(',', ':'))
