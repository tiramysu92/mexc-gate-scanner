from __future__ import annotations
from dataclasses import dataclass, field
from collections import defaultdict
import math, threading, time, uuid
from .core import sell


@dataclass
class Trial:
    trial_id: str
    route: str
    token: str
    stable_a: str
    stable_b: str
    symbol1: str
    symbol2: str
    liquidity_class: str
    size: float
    fraction: float
    base_qty: float
    l1_cost_quote: float
    planned_l2_vwap: float
    initial_net_bps: float
    min_quote_volume_24h: float
    l1_reserve_x: float
    l2_reserve_x: float
    return_reserve_x: float
    start_wall: float
    start_ns: int
    next_idx: int = 0
    results: dict = field(default_factory=dict)


class L2SurvivalTracker:
    """Shadow-only forward survivability measurement.

    V4.5.1 learns L2 behaviour independently of the current economic edge: once a
    route/size is A/B, data-valid and deep enough, RAW-positive observations can start
    trials. The stored proof is then available immediately when the NET edge later
    crosses its A/B trade threshold. RETURN is measured only as a safety fallback.
    """
    def __init__(self,cfg,store,db):
        self.cfg=cfg; self.store=store; self.db=db
        self.horizons=tuple(int(x) for x in cfg.get('survival_horizons_ms',[50,100,150,250,500]))
        self.cooldown_ms=float(cfg.get('survival_trial_cooldown_ms',5000))
        self.lock=threading.RLock(); self.active={}; self.last_start={}; self.pending_agg=defaultdict(self._empty_agg); self.total_agg=defaultdict(self._empty_agg)
        self.started=0; self.completed=0; self.dropped=0
        try:
            for row in self.db.load_survival_aggregates():
                key=(row['route'],float(row['size']));a=self.total_agg[key]
                for k,v in row.items():
                    if k not in ('route','size') and k in a:a[k]=v
        except Exception:
            pass

    def _empty_agg(self):
        d={'trials':0,'last_ts':0.0}
        for h in self.horizons:
            d[f'l2_ok_{h}']=0; d[f'return_ok_{h}']=0
            d[f'l2_slip_sum_{h}']=0.0; d[f'l2_slip_max_{h}']=None
            d[f'return_loss_sum_{h}']=0.0; d[f'return_loss_max_{h}']=None
        return d

    def maybe_start(self,e):
        if not getattr(e,'survival_eligible',False): return False
        key=(e.route,float(e.size)); now_ns=time.monotonic_ns()
        with self.lock:
            last=self.last_start.get(key,0)
            if last and (now_ns-last)/1e6 < self.cooldown_ms:return False
            self.last_start[key]=now_ns
            tid=uuid.uuid4().hex[:20]
            self.active[tid]=Trial(
                tid,e.route,e.token,e.stable_a,e.stable_b,e.symbol1,e.symbol2,e.liquidity_class,
                float(e.size),float(e.fraction),float(e.base_qty),float(e.l1_cost_quote),float(e.vwap2),
                float(e.net_edge_bps),float(e.min_quote_volume_24h or 0),float(e.l1_reserve_x),
                float(e.l2_reserve_x),float(e.return_reserve_x),time.time(),now_ns)
            self.started+=1
        return True

    def tick(self):
        now_ns=time.monotonic_ns(); done=[]
        with self.lock: trials=list(self.active.values())
        for tr in trials:
            while tr.next_idx < len(self.horizons):
                h=self.horizons[tr.next_idx]
                if (now_ns-tr.start_ns)/1e6 < h: break
                d2=self.store.get_depth(tr.symbol2); d1=self.store.get_depth(tr.symbol1)
                l2_ok=ret_ok=False; l2_slip=None; ret_loss=None
                if d2:
                    out,vwap,cov=sell(d2.bids,tr.base_qty,tr.fraction); l2_ok=cov>=.999
                    if l2_ok and tr.planned_l2_vwap>0:
                        l2_slip=max(0.0,(tr.planned_l2_vwap-vwap)/tr.planned_l2_vwap*1e4)
                if d1:
                    retq,rvwap,rcov=sell(d1.bids,tr.base_qty,tr.fraction); ret_ok=rcov>=.999
                    if ret_ok and tr.l1_cost_quote>0:
                        ret_loss=max(0.0,(tr.l1_cost_quote-retq)/tr.l1_cost_quote*1e4)
                tr.results[h]={'l2_ok':int(l2_ok),'return_ok':int(ret_ok),'l2_slippage_bps':l2_slip,'return_loss_bps':ret_loss}
                tr.next_idx+=1
            if tr.next_idx>=len(self.horizons):done.append(tr)
        if done:
            rows=[]
            with self.lock:
                for tr in done:
                    self.active.pop(tr.trial_id,None);self.completed+=1
                    for a in (self.pending_agg[(tr.route,tr.size)], self.total_agg[(tr.route,tr.size)]):
                        a['trials']+=1;a['last_ts']=time.time()
                        for h,r in tr.results.items():
                            a[f'l2_ok_{h}']+=r['l2_ok'];a[f'return_ok_{h}']+=r['return_ok']
                            if r['l2_slippage_bps'] is not None:
                                a[f'l2_slip_sum_{h}']+=r['l2_slippage_bps'];m=a[f'l2_slip_max_{h}'];a[f'l2_slip_max_{h}']=r['l2_slippage_bps'] if m is None else max(m,r['l2_slippage_bps'])
                            if r['return_loss_bps'] is not None:
                                a[f'return_loss_sum_{h}']+=r['return_loss_bps'];m=a[f'return_loss_max_{h}'];a[f'return_loss_max_{h}']=r['return_loss_bps'] if m is None else max(m,r['return_loss_bps'])
                    rows.append(self._row(tr))
            self.db.add_survival_trials(rows);self.db.upsert_survival_aggregates(self._aggregate_rows(done))
        return len(done)

    def _row(self,tr):
        x={'trial_id':tr.trial_id,'start_ts':tr.start_wall,'done_ts':time.time(),'route':tr.route,'token':tr.token,'stable_a':tr.stable_a,'stable_b':tr.stable_b,
           'liquidity_class':tr.liquidity_class,'size':tr.size,'fraction':tr.fraction,'base_qty':tr.base_qty,'l1_cost_quote':tr.l1_cost_quote,'planned_l2_vwap':tr.planned_l2_vwap,
           'initial_net_bps':tr.initial_net_bps,'min_quote_volume_24h':tr.min_quote_volume_24h,'l1_reserve_x':tr.l1_reserve_x,'l2_reserve_x':tr.l2_reserve_x,'return_reserve_x':tr.return_reserve_x}
        for h in self.horizons:
            r=tr.results.get(h,{})
            x[f'l2_ok_{h}']=r.get('l2_ok',0);x[f'return_ok_{h}']=r.get('return_ok',0);x[f'l2_slippage_bps_{h}']=r.get('l2_slippage_bps');x[f'return_loss_bps_{h}']=r.get('return_loss_bps')
        return x

    def _aggregate_rows(self,done):
        keys={(tr.route,tr.size) for tr in done}; out=[]
        with self.lock:
            for key in keys:
                a=self.pending_agg[key];route,size=key
                out.append({'route':route,'size':size,**a})
                # Reset pending aggregate after flush to DB: DB upsert is cumulative.
                self.pending_agg[key]=self._empty_agg()
        return out

    def stats(self,route,size):
        with self.lock:
            a=dict(self.total_agg.get((route,float(size))) or self._empty_agg())
        n=int(a.get('trials') or 0);a['route']=route;a['size']=float(size)
        if n:
            for h in self.horizons:
                a[f'l2_survival_{h}']=(a.get(f'l2_ok_{h}') or 0)/n
                a[f'return_survival_{h}']=(a.get(f'return_ok_{h}') or 0)/n
                a[f'avg_l2_slippage_bps_{h}']=(a.get(f'l2_slip_sum_{h}') or 0.0)/max(1,int(a.get(f'l2_ok_{h}') or 0))
                a[f'avg_return_loss_bps_{h}']=(a.get(f'return_loss_sum_{h}') or 0.0)/max(1,int(a.get(f'return_ok_{h}') or 0))
        return a

    def robust(self,route,size,liquidity_class):
        s=self.stats(route,size); n=int(s.get('trials') or 0)
        min_n=int(self.cfg.get('survival_min_samples',20))
        if n<min_n:return False,'SURVIVAL_PENDING',s
        if liquidity_class=='A':
            req={100:float(self.cfg.get('class_a_l2_survival_100_min',0.99)),250:float(self.cfg.get('class_a_l2_survival_250_min',0.98)),500:float(self.cfg.get('class_a_l2_survival_500_min',0.95))}
        elif liquidity_class=='B':
            req={100:float(self.cfg.get('class_b_l2_survival_100_min',0.98)),250:float(self.cfg.get('class_b_l2_survival_250_min',0.95)),500:float(self.cfg.get('class_b_l2_survival_500_min',0.90))}
        else:return False,'LIQUIDITY_CLASS_C',s
        for h,p in req.items():
            rate=s.get(f'l2_survival_{h}')
            if rate is None or rate<p:return False,f'L2_SURVIVAL_{h}',s
        return True,'ROBUST',s

    def status(self):
        with self.lock:return {'active_trials':len(self.active),'started':self.started,'completed':self.completed,'dropped':self.dropped,'cooldown_ms':self.cooldown_ms,'horizons_ms':list(self.horizons),'min_samples':int(self.cfg.get('survival_min_samples',20))}
