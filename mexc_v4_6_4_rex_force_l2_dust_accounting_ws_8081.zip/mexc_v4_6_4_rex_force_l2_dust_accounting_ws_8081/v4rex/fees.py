from __future__ import annotations

from collections import deque
import threading
import time

from .mexc_api import MexcClient, load_existing_mexc_env, mexc_credentials


def parse_trade_fee_response(payload):
    """Return exact account maker/taker fees in basis points.

    MEXC /api/v3/tradeFee returns decimal commission rates, e.g. 0.0005 = 5 bp.
    Zero is valid and MUST NOT be replaced by a conservative floor.
    """
    data=(payload or {}).get("data",{}) if isinstance(payload,dict) else {}
    maker=float(data.get("makerCommission"))
    taker=float(data.get("takerCommission"))
    if not (0.0 <= maker < 0.1 and 0.0 <= taker < 0.1):
        raise ValueError("invalid MEXC commission response")
    return maker*1e4,taker*1e4


class AccountFeeManager:
    """Read-only, authenticated MEXC account fee cache.

    No order is created. Fees come from GET /api/v3/tradeFee (SPOT_ACCOUNT_READ).
    Unknown fees fall back conservatively for Shadow qualification; MICRO-LIVE can
    require a fresh exact account fee on both legs before entry.
    """
    def __init__(self,cfg,symbol_rules,db=None,client=None):
        self.cfg=cfg;self.db=db
        self.enabled=bool(cfg.get("account_fee_enabled",True))
        self.fallback_bps=float(cfg.get("account_fee_fallback_bps",cfg.get("qualification_fee_bps_per_leg",5.0)))
        self.engine_max_age_s=float(cfg.get("account_fee_engine_max_age_s",7200.0))
        self.live_max_age_s=float(cfg.get("live_account_fee_max_age_s",3600.0))
        self.refresh_cycle_s=float(cfg.get("account_fee_refresh_cycle_s",1800.0))
        self.request_interval_s=max(.25,float(cfg.get("account_fee_request_interval_s",1.0)))
        self.lock=threading.RLock();self.stop=False;self._thread=None
        self.errors=0;self.requests=0;self.success=0;self.last_error=None;self.last_success_ts=None
        self._cache={};self._q=deque();self._pending=set();self._next_full_refresh=0.0

        allowed=set(cfg.get("live_allowed_stablecoins",["USDC","USDT"]))
        rules=list(symbol_rules or [])
        # Live quotes + high-volume symbols are warmed first.
        rules.sort(key=lambda r:(0 if getattr(r,"quote",None) in allowed else 1,-float(getattr(r,"quote_volume_24h",0) or 0),str(getattr(r,"symbol",""))))
        self.symbols=[str(getattr(r,"symbol",r)) for r in rules]

        if self.db:
            try:
                for r in self.db.load_account_fees():
                    self._cache[str(r["symbol"])]=dict(r)
            except Exception:
                pass

        self.client=client
        self.credentials_present=False
        if self.enabled and self.client is None:
            load_existing_mexc_env(cfg.get("live_env_files") or [])
            key,sec=mexc_credentials();self.credentials_present=bool(key and sec)
            if self.credentials_present:
                self.client=MexcClient(key,sec,float(cfg.get("account_fee_rest_timeout_s",3.0)),int(cfg.get("live_recv_window_ms",3000)))
        elif self.client is not None:
            self.credentials_present=True

    def start(self):
        if not self.enabled or not self.client:return
        try:self.client.sync_time()
        except Exception as exc:
            self.errors+=1;self.last_error=repr(exc)
        self._queue_full()
        self._next_full_refresh=time.time()+self.refresh_cycle_s
        self._thread=threading.Thread(target=self._run,daemon=True,name="account-fee-refresh")
        self._thread.start()

    def close(self):
        self.stop=True

    def _enqueue(self,symbol,priority=False):
        symbol=str(symbol)
        with self.lock:
            rec=self._cache.get(symbol);now=time.time()
            if rec and now-float(rec.get("fetched_ts") or 0) < self.refresh_cycle_s:
                return
            if symbol in self._pending:
                if priority:
                    try:self._q.remove(symbol)
                    except ValueError:pass
                    self._q.appendleft(symbol)
                return
            (self._q.appendleft if priority else self._q.append)(symbol);self._pending.add(symbol)

    def _queue_full(self):
        for s in self.symbols:self._enqueue(s,False)

    def touch(self,symbols):
        if not self.enabled or not self.client:return
        for s in reversed(list(symbols or [])):self._enqueue(s,True)

    def ingest(self,symbol,payload,ts=None):
        maker,taker=parse_trade_fee_response(payload);now=float(ts or time.time())
        rec={"symbol":str(symbol),"maker_bps":maker,"taker_bps":taker,"fetched_ts":now,"source":"MEXC_ACCOUNT_API"}
        with self.lock:self._cache[str(symbol)]=rec
        if self.db:
            try:self.db.upsert_account_fee(rec,payload)
            except Exception as exc:self.last_error="DB_FEE:"+repr(exc)
        self.success+=1;self.last_success_ts=now;self.last_error=None
        return rec

    def _run(self):
        while not self.stop:
            symbol=None
            with self.lock:
                if self._q:
                    symbol=self._q.popleft();self._pending.discard(symbol)
            if symbol is None:
                if time.time()>=self._next_full_refresh:
                    self._queue_full();self._next_full_refresh=time.time()+self.refresh_cycle_s
                time.sleep(.25);continue
            try:
                self.requests+=1
                self.ingest(symbol,self.client.trade_fee(symbol))
            except Exception as exc:
                self.errors+=1;self.last_error=f"{symbol}: {exc!r}"
            # tradeFee has IP weight 20; deliberately rate-limit the background scan.
            end=time.time()+self.request_interval_s
            while not self.stop and time.time()<end:time.sleep(min(.1,end-time.time()))

    def get(self,symbol):
        symbol=str(symbol);now=time.time()
        with self.lock:rec=dict(self._cache.get(symbol) or {})
        if rec:
            age=max(0.0,now-float(rec.get("fetched_ts") or 0))
            bps=float(rec.get("taker_bps"))
            return {"symbol":symbol,"taker_bps":bps,"maker_bps":float(rec.get("maker_bps") or 0),
                    "fetched_ts":rec.get("fetched_ts"),"age_s":age,"known":True,
                    "usable_engine":age<=self.engine_max_age_s,"usable_live":age<=self.live_max_age_s,
                    "source":"MEXC_ACCOUNT_API"}
        return {"symbol":symbol,"taker_bps":self.fallback_bps,"maker_bps":None,"fetched_ts":None,
                "age_s":None,"known":False,"usable_engine":False,"usable_live":False,"source":"FALLBACK"}

    def status(self):
        now=time.time()
        with self.lock:
            rows=list(self._cache.values());q=len(self._q)
        known=len(rows);fresh=sum(1 for r in rows if now-float(r.get("fetched_ts") or 0)<=self.engine_max_age_s)
        live=sum(1 for r in rows if now-float(r.get("fetched_ts") or 0)<=self.live_max_age_s)
        zero=sum(1 for r in rows if abs(float(r.get("taker_bps") or 0))<1e-12)
        return {"enabled":self.enabled,"credentials_present":self.credentials_present,"known":known,"total":len(self.symbols),
                "coverage_pct":100.0*known/max(1,len(self.symbols)),"fresh_engine":fresh,"live_usable":live,
                "zero_taker":zero,"fallback_bps":self.fallback_bps,"queue":q,"requests":self.requests,
                "success":self.success,"errors":self.errors,"last_error":self.last_error,
                "last_success_ts":self.last_success_ts,"request_interval_s":self.request_interval_s,
                "refresh_cycle_s":self.refresh_cycle_s,"live_max_age_s":self.live_max_age_s}

    def rows(self,limit=1000):
        now=time.time()
        with self.lock:vals=[dict(x) for x in self._cache.values()]
        out=[]
        for r in vals:
            age=max(0.0,now-float(r.get("fetched_ts") or 0))
            r["age_s"]=age;r["usable_engine"]=age<=self.engine_max_age_s;r["usable_live"]=age<=self.live_max_age_s
            out.append(r)
        out.sort(key=lambda r:(float(r.get("taker_bps") or 0),-float(r.get("fetched_ts") or 0),r.get("symbol") or ""))
        return out[:int(limit)]
