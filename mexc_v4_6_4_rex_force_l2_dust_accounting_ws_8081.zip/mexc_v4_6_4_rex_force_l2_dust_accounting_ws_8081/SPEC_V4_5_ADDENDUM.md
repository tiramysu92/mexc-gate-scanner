# V4.5.1 Addendum — Pre-learning L2 Survivability

## Règle nouvelle

La preuve de survivabilité L2 **doit être acquise avant l'apparition d'un edge tradable** lorsqu'une route A/B fournit des observations RAW-positives, synchronisées et suffisamment profondes.

### Learning gate

`is_qf(25%) AND data_valid AND timing_valid AND class in {A,B} AND raw_edge_bps > 0 AND L1_reserve >=5x AND L2_reserve >=10x`

Le NET edge n'appartient pas au learning gate.

### Trade gate

- A : `expected/net edge >1 bp`
- B : `expected/net edge >2 bp`
- C : interdit.

### Robust gate

Un trade n'est `ROBUST_A/B` que si le trade gate est satisfait **et** si les agrégats historiques L2 route×taille dépassent les seuils de survivabilité configurés.

### Cadence

Au plus un nouveau trial par `route × size` toutes les 1 000 ms. Les tailles restent statistiquement indépendantes.

### Priorité L2

Le RETURN continue d'être mesuré afin de quantifier le risque résiduel, mais ne peut jamais transformer une L2 fragile en qualification ROBUST.
