# V4.6.4 REX — FORCE-L2 / Dust Accounting

- After any confirmed L1 exposure, L2 is never delayed by edge or max-loss gates.
- L2 FOK attempts begin immediately and retry at 50/100/250/500 ms, then every 250 ms.
- Marketable L2 cushion escalates 0.5/1/2/5 bp; the limit is a ceiling on tolerated execution price, not a guaranteed cost.
- Removes the artificial 5 bp base-quantity reserve that created strategy dust every cycle. L1 fast accounting remains responsible for entry-fee base reserve.
- True step-size dust can remain; dashboard now separates cash-realized PnL from dust value and shows strategy PnL estimate = cash + dust.
