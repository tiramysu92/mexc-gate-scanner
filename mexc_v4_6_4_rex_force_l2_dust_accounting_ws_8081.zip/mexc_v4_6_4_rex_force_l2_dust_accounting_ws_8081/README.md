# V4.6.4-REX MICRO-LIVE — EXECUTION RESERVE

V4.6.4 reprend **V4.6.1 RECONCILE** et cible le point réellement observé en MICRO-LIVE : une L1 FOK peut être annulée sans fill si son prix limite est trop serré, même sur une route très liquide. La version reste livrée **désarmée** : `execution_enabled=false`.

## Ce qui change en V4.6.4

- **Réserve d'exécution L1 : 0,50 bp** par défaut (`execution_price_reserve_bps`).
- Qualification A/B sur l'**edge garanti après réserve** :
  - A : `NET - 0,50 bp > 1 bp` ;
  - B : `NET - 0,50 bp > 2 bp`.
- BUY FOK : prix limite construit depuis le terminal Depth, cushion inclus, puis **arrondi vers le haut** au tick (`ceil`).
- SELL FOK : prix limite construit depuis le terminal bid puis **arrondi vers le bas** au tick (`floor`).
- Le cushion est une limite maximale acceptable, pas un coût systématique : si le meilleur prix est toujours disponible, l'ordre l'utilise.
- Confirmation **REST POST / Private WS / Query Order en concurrence**. Le premier chemin terminal libère immédiatement l'executor ; Query Order ne doit pas retarder une L2 déjà prouvée.
- Le snapshot balance pré-L1 est servi par un cache rafraîchi en arrière-plan : **aucun GET account synchrone avant le POST L1**.
- L'accounting critique après L1 n'attend plus `myTrades` : dès qu'un fill est prouvé, L2 part avec une réserve de frais conservatrice. Les fills/frais exacts sont réconciliés après fermeture de l'exposition.
- Session REST dédiée au Query Order et session dédiée au rafraîchissement des balances pour limiter les interférences avec le POST ordre.
- Télémétrie nanoseconde par tentative FOK : signal, décision, POST, réponse REST, Private WS, Query Order, terminal, source de confirmation, prix terminal, limite envoyée et cushion.
- Nouvelle table SQLite `live_order_attempts` et endpoint `/api/live/execution`.
- Dashboard entièrement réorganisé : cockpit LIVE, meilleurs edges garantis, fill rates, p50/p95, meilleures routes, preuve L2, journal FOK, cycles LIVE, exposition active et infrastructure repliable.

## Invariants REX conservés

Avant L1 : liquidité, profondeur, timing, survivabilité L2 et edge garanti doivent être satisfaits. Après tout fill L1, le seuil d'edge d'entrée n'est **jamais** réappliqué : l'état devient exposition stratégie et la priorité est la finalisation L2.

- Une seule exposition maximum.
- MICRO-LIVE initial : 10 USD/cycle, USDC/USDT uniquement ; USD1 reste observé/qualifié en Shadow.
- FOK pour éviter une exposition partielle normale ; toute quantité positive anormale devient malgré tout une exposition à clôturer.
- Timeout/5xx = `UNKNOWN`, jamais un rejet supposé ; réconciliation avant toute action contradictoire.
- Le bot ne vend que l'inventaire acquis par le cycle, jamais un bag préexistant.
- Dust normale <= seuil configuré non bloquante ; au-dessus, les nouvelles entrées restent bloquées.
- Fee floor conservateur = 5 bp/jambe ; un frais authentifié supérieur prévaut.
- Private WS signé, listenKey extrait correctement et heartbeat démarré après `on_open` sont conservés.

## Héritage de la preuve L2

Une DB V4.6.4 fraîche essaie d'importer **une seule fois** les agrégats de survivabilité : d'abord depuis V4.6.1, puis V4.6.0 si nécessaire. Les trials bruts restent dans les anciennes DB. Le gate LIVE impose toujours au moins `live_min_survival_trials=1000` pour la route × taille exacte.

## Installation / démarrage SAFE

```bash
./install.sh
./start.sh
sleep 120
./smoke_check.sh
```

Le package démarre avec `execution_enabled=false`. Le dashboard et les APIs peuvent être vérifiés sans ordre réel.

## Préflight

```bash
source .venv/bin/activate
python preflight_live.py
```

Le script réutilise les variables MEXC existantes sans afficher la clé ni le secret.

## Armer volontairement le MICRO-LIVE 10 USD

Après validation du préflight, du dashboard, de la Private WS et des balances :

```bash
python3 - <<'PY'
import json
p='config.json'
x=json.load(open(p))
x['execution_enabled']=True
json.dump(x,open(p,'w'),indent=2)
PY
export MEXC_LIVE_ARM=V464_LIVE_10USD
./stop.sh
./start.sh
```

Sans **les deux** verrous (`execution_enabled=true` + variable d'environnement exacte), aucun ordre réel n'est autorisé. Après un redémarrage où la variable d'environnement n'est pas restaurée, le bot revient SAFE.

## Dashboard / APIs

- `/` : dashboard V4.6.4 lisible et priorisé.
- `/api/live/status` : executor, balances, PnL, dust, Private WS, métriques d'exécution.
- `/api/live/execution` : tentatives FOK + p50/p95 par étape + sources terminales.
- `/api/live/trades` : cycles LIVE.
- `/api/live/events` : journal state-machine / recovery / UNKNOWN.
- `/api/live/dust` : résidus stratégie.
- `/api/live/balances` : balances courantes / initiales / historique.
- `/api/opportunities` : opportunités qualifiées ; `expected_edge_bps` inclut désormais la réserve d'exécution de 0,50 bp.

## Export

```bash
source .venv/bin/activate
python export_run.py --out export_v464_$(date +%Y%m%d_%H%M)
```

L'export inclut le snapshot SQLite complet, les tentatives FOK, les métriques d'exécution et le résumé analytique.


## V4.6.4 — frais API compte dynamiques

- `GET /api/v3/tradeFee` est un appel **lecture seule** : aucun ordre réel n'est créé.
- Le scanner collecte le `takerCommission` réel du compte API par symbole.
- `0 bp` est conservé comme une vraie valeur et n'est plus relevé artificiellement à 5 bp.
- Le moteur Shadow utilise le fee compte lorsqu'il est connu; sinon fallback conservateur 5 bp.
- Le MICRO-LIVE exige par défaut un fee compte frais sur **les deux jambes** avant toute entrée.
- Scan de fond limité à 1 requête/s; les symboles des routes candidates sont prioritaires.
- Les fees sont rechargés périodiquement et historisés dans SQLite.


## V4.6.4 FORCE-L2
Once L1 exposure is confirmed, no profitability/max-loss gate may delay L2. The bot starts L2 immediately. Cash PnL excludes unsold dust by definition; the dashboard therefore also shows strategy PnL estimate = cash PnL + strategy dust value.
