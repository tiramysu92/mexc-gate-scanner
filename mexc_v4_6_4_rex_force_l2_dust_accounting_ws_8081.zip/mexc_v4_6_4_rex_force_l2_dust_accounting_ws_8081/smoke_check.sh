#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://127.0.0.1:8081}
echo '=== HEALTH ==='; curl -fsS "$BASE/healthz"; echo
echo '=== MICRO-LIVE STATUS ==='; curl -fsS "$BASE/api/live/status"; echo
echo '=== SMOKE SUMMARY ==='; curl -fsS "$BASE/api/smoke"; echo
echo '=== EXECUTION PATH ==='; curl -fsS "$BASE/api/live/execution?limit=20"; echo
echo '=== LIVE TRADES ==='; curl -fsS "$BASE/api/live/trades?limit=20"; echo
echo '=== DUST ==='; curl -fsS "$BASE/api/live/dust?limit=20"; echo
echo '=== L2 SURVIVABILITY ==='; curl -fsS "$BASE/api/survival?limit=20"; echo
echo '=== OPPORTUNITES ROBUSTES ==='; curl -fsS "$BASE/api/opportunities?hours=24&limit=20&min_rank=3"; echo
echo '=== DB ==='; ls -lh v4_rex_micro_live_v464.db* 2>/dev/null || true
echo '=== LOG TAIL ==='; tail -80 v4_rex.log 2>/dev/null || true
