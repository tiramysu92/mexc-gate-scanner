# Addendum V4.6.2 — Execution Reserve & Critical Path

Cet addendum complète la SPEC V4.0-REX et les addenda V4.5 / V4.6 / V4.6.1. Les invariants REX antérieurs restent applicables.

## R1 — Edge garanti avant entrée

La qualification économique d'une route A/B doit utiliser :

`guaranteed_edge_bps = conservative_net_edge_bps - execution_price_reserve_bps`

Valeur initiale de `execution_price_reserve_bps` : **0,50 bp**.

- Classe A : `guaranteed_edge_bps > 1,00 bp`.
- Classe B : `guaranteed_edge_bps > 2,00 bp`.
- Classe C : jamais LIVE.

La réserve est un budget de prix maximal autorisé au FOK, pas une hypothèse de coût systématiquement payé.

## R2 — Construction du prix FOK

L1 BUY : prix terminal requis dans le Depth qualifié → + réserve d'exécution → arrondi **ceil** au tick quote.

L2 SELL : prix terminal requis → éventuelle réserve L2 dédiée → arrondi **floor** au tick quote. La réserve L1 n'est pas réappliquée à L2.

La quantité L1 est plafonnée pour que `qty * limit_price <= requested_size`.

## R3 — Chemin critique L1 → L2

REST POST, Private WS et Query Order sont des autorités concurrentes. Le premier événement terminal cohérent libère le chemin critique. Query Order ne doit pas retarder L2 si le POST ou la Private WS a déjà prouvé une exposition.

Aucun appel REST balance ne doit précéder synchronement le POST L1. Aucun appel `myTrades` ne doit précéder synchronement le POST L2 après un fill L1 confirmé.

Après tout `executedQty > 0`, l'edge d'entrée n'est plus testé. L2 devient prioritaire.

## R4 — Réconciliation

- `FILLED` : exposition prouvée.
- `CANCELED` / `REJECTED` avec quantité nulle : no-fill prouvé ; un contrôle balance peut confirmer l'absence d'exposition.
- Tout statut avec quantité positive : exposition prouvée, même si le statut est anormal pour FOK.
- Timeout / 5xx / contradiction : `UNKNOWN`, entrées bloquées et réconciliation obligatoire.
- Le fallback balance utilise le delta par rapport au baseline pré-L1 et ne doit jamais vendre le bag préexistant.

## R5 — Télémétrie obligatoire

Chaque tentative L1/L2 doit persister, avec `perf_counter_ns()` quand applicable :

- signal ; fin de décision ; début POST ; réponse POST ; événement Private WS ; début/réponse Query ; terminal ;
- prix BBO au signal ; prix terminal Depth ; tick size ; qty ; prix limite brut ; prix envoyé ; reserve bps ;
- source terminale ; statuts REST/WS/Query ; executedQty ; erreurs.

Le dashboard doit afficher au minimum p50/p95 : signal→POST, POST→REST, POST→Private, POST→Query, POST→terminal et fill L1→POST L2.

## R6 — Critères du prochain MICRO-LIVE

Le prochain test reste à 10 USD, une exposition maximum. Le but premier est de mesurer un moteur d'exécution propre, pas d'optimiser le PnL : taux de fill L1, taux de fermeture L2, UNKNOWN, résidus, et distributions de latence. Le cushion pourra ensuite être recalibré sur les fills réels.
