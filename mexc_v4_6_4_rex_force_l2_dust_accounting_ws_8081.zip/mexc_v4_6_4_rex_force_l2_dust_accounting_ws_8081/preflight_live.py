#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from v4rex.mexc_api import load_existing_mexc_env,mexc_credentials,MexcClient
p=argparse.ArgumentParser(description='V4.6.4 read-only MEXC preflight: no order is sent.')
p.add_argument('--config',default='config.json');p.add_argument('--symbols',default='BTCUSDT,BTCUSDC,ETHUSDT,ETHUSDC,SOLUSDT,SOLUSDC,HYPEUSDT,HYPEUSDC')
a=p.parse_args();cfg=json.load(open(a.config,encoding='utf-8'))
loaded=load_existing_mexc_env(cfg.get('live_env_files') or []);key,sec=mexc_credentials()
print('=== V4.6.4 MEXC PREFLIGHT (READ-ONLY) ===')
print('credentials_present:',bool(key and sec));print('env_files_loaded:',loaded or 'process env / already loaded')
if not key or not sec:sys.exit('MEXC credentials not found. V4.6.4 did not send any order.')
c=MexcClient(key,sec,float(cfg.get('live_rest_timeout_s',3)),int(cfg.get('live_recv_window_ms',3000)))
try:
    print('time_sync:',c.sync_time())
    acc=c.account();print('canTrade:',acc.get('canTrade'),'accountType:',acc.get('accountType'),'permissions:',acc.get('permissions'))
    bal=c.balances();
    for asset in ('USDC','USDT','USD1'):
        x=bal.get(asset,{'free':0,'locked':0});print(f'{asset}: free={x["free"]:.8f} locked={x["locked"]:.8f}')
    for sym in [x.strip().upper() for x in a.symbols.split(',') if x.strip()]:
        try:
            x=c.trade_fee(sym);raw=float((x.get('data') or {}).get('takerCommission'));print(f'{sym}: account_taker={raw*100:.5f}% ({raw*1e4:.3f} bp) EXACT_ACCOUNT_FEE')
        except Exception as exc:print(f'{sym}: fee query error: {exc}')
    print('RESULT: READ-ONLY PREFLIGHT OK. /api/v3/order and /api/v3/order/test were NOT called.')
except Exception as exc:
    print('PREFLIGHT FAILED:',repr(exc));sys.exit(2)
