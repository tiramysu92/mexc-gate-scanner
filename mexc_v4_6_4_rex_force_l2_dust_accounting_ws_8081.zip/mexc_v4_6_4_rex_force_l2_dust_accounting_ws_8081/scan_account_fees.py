#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,time
from v4rex.mexc_api import load_existing_mexc_env,mexc_credentials,MexcClient
from v4rex.fees import parse_trade_fee_response

p=argparse.ArgumentParser(description='Read-only MEXC account fee scanner. No order endpoint is called.')
p.add_argument('--config',default='config.json')
p.add_argument('--symbols',default='BTCUSDC,BTCUSDT,ETHUSDC,ETHUSDT,SOLUSDC,SOLUSDT,HYPEUSDC,HYPEUSDT,XRPUSDC,XRPUSDT,DOGEUSDC,DOGEUSDT,ZECUSDC,ZECUSDT')
p.add_argument('--interval',type=float,default=1.0,help='Seconds between /tradeFee calls (weight 20 each).')
a=p.parse_args();cfg=json.load(open(a.config,encoding='utf-8'))
load_existing_mexc_env(cfg.get('live_env_files') or []);key,sec=mexc_credentials()
if not key or not sec:raise SystemExit('MEXC credentials missing')
c=MexcClient(key,sec,float(cfg.get('account_fee_rest_timeout_s',3)),int(cfg.get('live_recv_window_ms',3000)));c.sync_time()
syms=[x.strip().upper() for x in a.symbols.split(',') if x.strip()]
print('symbol\ttaker_bp\tmaker_bp\tsource')
for i,s in enumerate(syms):
    try:
        maker,taker=parse_trade_fee_response(c.trade_fee(s));print(f'{s}\t{taker:.4f}\t{maker:.4f}\tMEXC_ACCOUNT_API')
    except Exception as exc:print(f'{s}\tERROR\tERROR\t{exc!r}')
    if i+1<len(syms):time.sleep(max(.25,a.interval))
print('READ-ONLY COMPLETE: /api/v3/order and /api/v3/order/test were not called.')
