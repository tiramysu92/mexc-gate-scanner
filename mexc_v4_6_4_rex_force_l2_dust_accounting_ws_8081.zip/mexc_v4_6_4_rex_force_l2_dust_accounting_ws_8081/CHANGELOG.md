# V4.6.4
- FORCE-COMPLETE L2 immediately after confirmed L1.
- Removed L2 economic-loss wait that caused >100 s exposure delays.
- Removed artificial 5 bp base reserve creating dust.
- Escalating L2 FOK cushion 0.5/1/2/5 bp and faster retry cadence.
- Dashboard primary PnL = cash realized + strategy dust value estimate; both components remain visible.

# V4.6.3
- Account-specific MEXC taker fees via read-only `/api/v3/tradeFee`.
- Dynamic per-symbol fees in Shadow and MICRO-LIVE qualification.
- LIVE gate refuses entry when either account fee is unknown/stale.
- Zero-fee API pairs remain exactly 0 bp.
- Fee cache/status/API/dashboard + SQLite current/history tables.
- Rate-limited refresh; candidate symbols prioritized.

# CHANGELOG — V4.6.x REX MICRO-LIVE

## V4.6.0 — first MICRO-LIVE

- Exécuteur Spot 2-leg 10 USD, USDC/USDT, une exposition maximum.
- Qualification L2-first héritée de V4.5.1, gate 1000 trials exact route × taille.
- `/order/test` préalable puis FOK réel, Private WS + REST, recovery, protection des bags et dust ledger.

## V4.6.1 — deterministic reconciliation

- Parsing correct des statuts texte (`CANCELED`, etc.).
- Query Order et balance delta pour résoudre L1 ; recovery identique au runtime.
- Correctifs Private WS de production : listenKey signé/extrait, heartbeat après `on_open`.
- `L1_NO_FILL` propre lorsqu'un FOK annulé a exécuté zéro quantité.

## V4.6.2 — execution reserve & fast critical path

- Réserve L1 initiale **0,50 bp** intégrée à `expected_edge_bps` et au gate LIVE.
- A/B qualifiés sur l'edge après reserve ; l'ancien signal BTC +1,091 bp serait donc rejeté car il ne garantit plus le seuil A après cushion.
- BUY FOK marketable : terminal ask + cushion puis ceil au tick ; hard cap du notional au montant demandé.
- SELL FOK : terminal bid puis floor au tick ; priorité L2 inchangée.
- POST, Private WS et Query Order courent en parallèle ; le premier résultat terminal libère l'executor.
- Cache balance pré-L1 réseau-free ; session dédiée balances ; session dédiée Query Order.
- `myTrades` déplacé hors chemin critique : l'accounting exact intervient après fermeture de l'exposition.
- `REJECTED` et `CANCELED` zéro-fill sont des no-fill terminaux connus ; UNKNOWN reste distinct.
- Nouvelle table `live_order_attempts` avec timestamps nanoseconde, prix, tick, cushion, statuts, source terminale et quantité exécutée.
- Métriques p50/p95 : signal→POST, POST→REST, POST→Private, POST→Query, POST→terminal, fill L1→POST L2.
- Endpoint `/api/live/execution`.
- Dashboard entièrement refait : cockpit prioritaire, meilleurs edges garantis, routes A/B, preuve L2, FOK journal, cycles LIVE et détails infra repliables.
- Arm token : `V463_LIVE_10USD` ; package livré désarmé.
