import time
from types import SimpleNamespace

from v4rex.db import DB
from v4rex.fees import AccountFeeManager, parse_trade_fee_response
from v4rex.engine import Engine


def test_parse_trade_fee_preserves_zero():
    maker,taker=parse_trade_fee_response({'data':{'makerCommission':'0','takerCommission':'0'}})
    assert maker == 0.0
    assert taker == 0.0


def test_parse_trade_fee_converts_to_bps():
    maker,taker=parse_trade_fee_response({'data':{'makerCommission':'0.0002','takerCommission':'0.0005'}})
    assert maker == 2.0
    assert taker == 5.0


def test_account_fee_manager_persists_exact_zero(tmp_path):
    db=DB(str(tmp_path/'fee.db'))
    rule=SimpleNamespace(symbol='BTCUSDC',quote='USDC',quote_volume_24h=10_000_000)
    cfg={'account_fee_enabled':False,'account_fee_fallback_bps':5,'account_fee_engine_max_age_s':7200,'live_account_fee_max_age_s':3600}
    m=AccountFeeManager(cfg,[rule],db=db)
    rec=m.ingest('BTCUSDC',{'data':{'makerCommission':'0','takerCommission':'0'}})
    assert rec['taker_bps'] == 0.0
    got=m.get('BTCUSDC')
    assert got['known'] and got['usable_engine'] and got['usable_live']
    assert got['taker_bps'] == 0.0
    rows=db.account_fee_rows()
    assert rows[0]['symbol']=='BTCUSDC' and rows[0]['taker_bps']==0.0


def test_engine_uses_exact_account_fee_instead_of_floor(tmp_path):
    class Clock: offset_ms=0
    class Collector:
        def __init__(self): self.clock=Clock(); self.depth=SimpleNamespace(status=lambda:{'symbols':[]})
    class Fee:
        def get(self,s): return {'known':True,'usable_engine':True,'taker_bps':0.0,'source':'MEXC_ACCOUNT_API'}
        def touch(self,s): pass
    class Rule:
        taker_commission='0.0005'; quote_volume_24h=2_000_000
    uni=SimpleNamespace(routes=[],by_symbol={'BTCUSDC':Rule()})
    cfg={'qualification_fee_bps_per_leg':5.0,'fee_bps_default':5.0}
    e=Engine(cfg,SimpleNamespace(_bbo_provider=None),DB(str(tmp_path/'e.db')),uni,Collector(),Fee())
    assert e._public_fee('BTCUSDC') == 5.0
    assert e._fee('BTCUSDC') == 0.0


def test_unknown_fee_keeps_conservative_floor(tmp_path):
    class Clock: offset_ms=0
    class Collector:
        def __init__(self): self.clock=Clock(); self.depth=SimpleNamespace(status=lambda:{'symbols':[]})
    class Fee:
        def get(self,s): return {'known':False,'usable_engine':False,'taker_bps':5.0,'source':'FALLBACK'}
        def touch(self,s): pass
    class Rule:
        taker_commission='0'; quote_volume_24h=2_000_000
    uni=SimpleNamespace(routes=[],by_symbol={'BTCUSDC':Rule()})
    cfg={'qualification_fee_bps_per_leg':5.0,'fee_bps_default':5.0}
    e=Engine(cfg,SimpleNamespace(_bbo_provider=None),DB(str(tmp_path/'e2.db')),uni,Collector(),Fee())
    assert e._fee('BTCUSDC') == 5.0
