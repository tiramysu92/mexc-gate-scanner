import hashlib,hmac
from urllib.parse import urlencode
from v4rex.mexc_api import MexcClient,PrivateEnvelope,decode_private

def test_sign_matches_hmac():
    p={'symbol':'BTCUSDT','timestamp':123,'recvWindow':3000}
    expected=hmac.new(b'secret',urlencode(list(p.items())).encode(),hashlib.sha256).hexdigest()
    assert MexcClient.sign('secret',p)==expected

def test_private_order_decode():
    e=PrivateEnvelope();e.channel='spot@private.orders.v3.api.pb';e.sendTime=123;e.privateOrders.id='o1';e.privateOrders.clientId='c1';e.privateOrders.status=2;e.privateOrders.cumulativeQuantity='0.001';e.privateOrders.cumulativeAmount='75'
    x=decode_private(e.SerializeToString())
    assert x['kind']=='order' and x['orderId']=='o1' and x['clientOrderId']=='c1' and x['status']==2

def test_private_deal_fee_decode():
    e=PrivateEnvelope();e.channel='spot@private.deals.v3.api.pb';e.privateDeals.orderId='o2';e.privateDeals.feeAmount='0.01';e.privateDeals.feeCurrency='USDT'
    x=decode_private(e.SerializeToString());assert x['kind']=='deal' and x['feeCurrency']=='USDT' and x['feeAmount']=='0.01'


def test_signed_listen_key_extracts_string(monkeypatch):
    from v4rex.mexc_api import MexcClient
    c=MexcClient('k','s')
    calls=[]
    def fake(method,path,params=None,**kw):
        calls.append((method,path,params))
        return {'listenKey':'abc123'}
    monkeypatch.setattr(c,'_signed',fake)
    assert c.create_listen_key()=='abc123'
    assert calls[0][0:2]==('POST','/api/v3/userDataStream')


def test_listen_key_keepalive_is_signed(monkeypatch):
    from v4rex.mexc_api import MexcClient
    c=MexcClient('k','s')
    calls=[]
    monkeypatch.setattr(c,'_signed',lambda method,path,params=None,**kw: calls.append((method,path,params)) or {})
    c.keepalive_listen_key('abc')
    assert calls==[('PUT','/api/v3/userDataStream',{'listenKey':'abc'})]
