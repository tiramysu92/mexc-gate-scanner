from v4rex.universe import parse_exchange_info,balanced_ws_groups,SymbolRule

def payload():
    def s(sym,b,q):return {'symbol':sym,'baseAsset':b,'quoteAsset':q,'status':'1','isSpotTradingAllowed':True,'tradeSideType':'1','takerCommission':'0.0005'}
    return {'symbols':[s('XUSDT','X','USDT'),s('XUSDC','X','USDC'),s('YUSDT','Y','USDT')]}
def test_full_universe_routes():
    u=parse_exchange_info(payload(),{'stablecoins':['USDT','USDC','USD1'],'universe_mode':'FULL_STABLECOIN_2LEG','require_default_symbols':False},set(),[]);assert len(u.symbols)==2;assert len(u.routes)==2

def test_single_quote_excluded():
    u=parse_exchange_info(payload(),{'stablecoins':['USDT','USDC','USD1'],'universe_mode':'FULL_STABLECOIN_2LEG','require_default_symbols':False},set(),[]);assert all(s.base!='Y' for s in u.symbols)

def test_group_capacity():
    sy=[SymbolRule(f'X{i}USDT',f'X{i}','USDT','1',True,True,None,None,None,None,None,None,None,None,1.0,None,None) for i in range(41)];g=balanced_ws_groups(sy,20);assert len(g)==3;assert max(len(x['symbols']) for x in g)<=20
