import time
import pytest
from v4rex.core import L,BBO,DepthBook,Store,buy,sell,max_traversable_quote

def test_buy_single():
    b,v,c=buy((L(10,10),),50,1);assert b==pytest.approx(5);assert v==pytest.approx(10);assert c==1

def test_sell_single():
    q,v,c=sell((L(11,10),),5,1);assert q==pytest.approx(55);assert v==pytest.approx(11);assert c==1

def test_buy_multi():
    b,v,c=buy((L(10,2),L(11,4)),42,1);assert b==pytest.approx(4);assert v==pytest.approx(10.5);assert c==1

def test_sell_multi():
    q,v,c=sell((L(11,2),L(10,4)),5,1);assert q==pytest.approx(52);assert v==pytest.approx(10.4);assert c==1

@pytest.mark.parametrize('f,base,cov',[(1,10,1),(.5,5,.5),(.25,2.5,.25),(.1,1,.1)])
def test_fraction(f,base,cov):
    b,_,c=buy((L(10,10),),100,f);assert b==pytest.approx(base);assert c==pytest.approx(cov)

def test_insufficient():
    b,_,c=buy((L(10,2),),100,1);assert b==2 and c==pytest.approx(.2)

def test_max_traversable():
    q=max_traversable_quote((L(10,10),),(L(11,5),),1);assert q==pytest.approx(50)

def test_bbo_metrics():
    now=time.monotonic_ns();b=BBO('X',10,1,11,1,1,int(time.time()*1000)-10,time.time()*1000,now,now+1_000_000,1)
    assert b.spread_bps==pytest.approx(1000);assert b.decode_lag_ms==pytest.approx(1)

def test_store_bbo_version_guard():
    s=Store();n=time.monotonic_ns();a=BBO('X',10,1,11,1,2,None,None,n,n);b=BBO('X',9,1,12,1,1,None,None,n,n)
    assert s.put_bbo(a);assert not s.put_bbo(b);assert s.get_bbo('X').bid==10

def test_store_depth_version_guard():
    s=Store();n=time.monotonic_ns();a=DepthBook('X',(L(10,1),),(L(11,1),),2,None,None,n,n);b=DepthBook('X',(L(9,1),),(L(12,1),),1,None,None,n,n)
    assert s.put_depth(a);assert not s.put_depth(b);assert s.get_depth('X').best_bid==10

def test_store_signal():
    s=Store();n=time.monotonic_ns();s.put_bbo(BBO('X',10,1,11,1,1,None,None,n,n));assert 'X' in s.drain_updates(.01,0)
