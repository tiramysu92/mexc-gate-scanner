import tempfile,time
from v4rex.mp_bbo import SharedBBO,_write,MultiprocessBBOCollector
from v4rex.hybrid_bbo import HybridSharedBBO,DynamicFastLane
from v4rex.db import DB


def wr(h,s,bid,ask,send,recv_shift=0,wid=1):
    rn=time.monotonic_ns()+recv_shift
    _write(h.args(),h.index[s],bid,1,ask,1,1,send,float(send),rn,rn,wid)


def test_base_collector_uses_configured_100ms_interval():
    g=[{'id':1,'symbols':['XUSDT'],'load_score':1}]
    c=MultiprocessBBOCollector({'bbo_worker_processes':1,'bbo_base_interval_ms':100},['XUSDT'],g,lambda *a,**k:None)
    assert c.interval_ms==100 and c.tier=='BASE'


def test_hybrid_shared_prefers_fast_newer_only_when_active():
    base=SharedBBO(['XUSDT']);fast=SharedBBO(['XUSDT']);active={'XUSDT'}
    wr(base,'XUSDT',10,11,1000,wid=1);wr(fast,'XUSDT',10.5,11.5,1010,wid=1001)
    mask=bytearray([1]);h=HybridSharedBBO(base,fast,mask)
    assert h.get_bbo('XUSDT').bid==10.5
    mask[0]=0
    assert h.get_bbo('XUSDT').bid==10


def test_hybrid_shared_does_not_replace_newer_base_with_old_fast():
    base=SharedBBO(['XUSDT']);fast=SharedBBO(['XUSDT']);active={'XUSDT'}
    wr(base,'XUSDT',10.2,11.2,1020,wid=1);wr(fast,'XUSDT',10.1,11.1,1010,wid=1001)
    mask=bytearray([1]);h=HybridSharedBBO(base,fast,mask)
    assert h.get_bbo('XUSDT').bid==10.2


def test_fast_lane_probe_respects_capacity_and_complete_small_bundles():
    syms=['AUSDT','AUSDC','BUSDT','BUSDC','CUSDT','CUSDC']
    sh=SharedBBO(syms)
    cfg={'fast_lane_ws':1,'fast_lane_group_size':4,'fast_probe_symbol_budget':4,'fast_probe_rotate_s':30}
    f=DynamicFastLane(cfg,syms,sh,probe_bundles=[('AUSDT','AUSDC'),('BUSDT','BUSDC'),('CUSDT','CUSDC')])
    desired,probe,n=f._desired()
    assert len(desired)<=4 and len(probe)<=4
    assert not ({'AUSDT','AUSDC'} & probe) or {'AUSDT','AUSDC'} <= probe


def test_fast_lane_candidate_gets_priority_over_probe():
    syms=['AUSDT','AUSDC','BUSDT','BUSDC','CUSDT','CUSDC']
    sh=SharedBBO(syms)
    cfg={'fast_lane_ws':1,'fast_lane_group_size':4,'fast_probe_symbol_budget':4,'fast_probe_rotate_s':30,'fast_lane_ttl_s':60}
    f=DynamicFastLane(cfg,syms,sh,probe_bundles=[('AUSDT','AUSDC'),('BUSDT','BUSDC')])
    f.touch(['CUSDT','CUSDC'])
    desired,probe,n=f._desired()
    assert {'CUSDT','CUSDC'} <= desired and len(desired)<=4 and n==2


def test_fast_audit_db_upsert():
    t=tempfile.NamedTemporaryFile(suffix='.db',delete=False);t.close();db=DB(t.name)
    row={'route':'USDT>X>USDC','token':'X','stable_a':'USDT','stable_b':'USDC','checks':10,'base_positive':2,'fast_positive':4,'fast_only_samples':2,'fast_only_events':1,'max_fast_only_bps':3.5,'last_base_bps':-1,'last_fast_bps':2,'last_ts':time.time()}
    db.upsert_fast_audit([row]);db.upsert_fast_audit([row]);x=db.fast_audit(10)[0]
    assert x['checks']==20 and x['fast_only_events']==2 and x['max_fast_only_bps']==3.5

def test_engine_records_fast_only_audit_sample():
    from types import SimpleNamespace
    from v4rex.core import Store
    from v4rex.engine import Engine
    syms=['XUSDT','XUSDC'];base=SharedBBO(syms);fast=SharedBBO(syms);active=set(syms)
    now=int(time.time()*1000);rn=time.monotonic_ns()
    # base route negative: buy 10.0 / sell 9.99
    _write(base.args(),base.index['XUSDT'],9.9,10,10.0,10,1,now,now,rn,rn,1)
    _write(base.args(),base.index['XUSDC'],9.99,10,10.1,10,1,now,now,rn,rn,2)
    # fast route positive: buy 10.0 / sell 10.02
    _write(fast.args(),fast.index['XUSDT'],9.9,10,10.0,10,2,now+1,now+1,rn,rn,1001)
    _write(fast.args(),fast.index['XUSDC'],10.02,10,10.1,10,2,now+1,now+1,rn,rn,1002)
    mask=bytearray([1,1]);hs=HybridSharedBBO(base,fast,mask)
    mgr=SimpleNamespace(active_snapshot=lambda:(set(active),set(active),set()))
    provider=SimpleNamespace(shared=hs,base_shared=base,fast_shared=fast,fast=mgr,get_bbo=hs.get_bbo,snapshot_bbo=hs.snapshot_bbo)
    store=Store(bbo_provider=provider)
    class C:
        clock=SimpleNamespace(offset_ms=0);depth=SimpleNamespace(warmup_ms=lambda s:None)
        def touch_fast(self,s,ttl=None):pass
        def touch_depth(self,s):pass
    rule=SimpleNamespace(taker_commission='0.0005')
    uni=SimpleNamespace(routes=[SimpleNamespace(route='USDT>X>USDC',token='X',stable_a='USDT',stable_b='USDC',symbol1='XUSDT',symbol2='XUSDC')],by_symbol={'XUSDT':rule,'XUSDC':rule})
    tf=tempfile.NamedTemporaryFile(suffix='.db',delete=False);tf.close();db=DB(tf.name)
    cfg={'raw_watch_threshold_bps':0,'route_activity_sample_ms':250,'aggregate_flush_s':999,'test_sizes_usd':[10],'depth_fractions':[1.0],'fee_bps_default':5,'min_expected_edge_bps':10}
    e=Engine(cfg,store,db,uni,C());e.bbo_scan_once()
    assert e.audit_fast_only_events==1
    assert e.pending_audit['USDT>X>USDC']['fast_only_samples']==1
