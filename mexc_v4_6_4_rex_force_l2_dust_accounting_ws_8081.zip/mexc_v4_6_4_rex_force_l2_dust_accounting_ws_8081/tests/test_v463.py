import time
from types import SimpleNamespace

from v4rex.fees import AccountFeeManager, parse_trade_fee_response
from v4rex.engine import Engine


def cfg():
    return {
        "account_fee_enabled": False,
        "account_fee_fallback_bps": 5.0,
        "qualification_fee_bps_per_leg": 5.0,
        "account_fee_engine_max_age_s": 7200,
        "live_account_fee_max_age_s": 3600,
        "live_allowed_stablecoins": ["USDC","USDT"],
    }


def rule(symbol, quote="USDT", vol=1_000_000):
    return SimpleNamespace(symbol=symbol, quote=quote, quote_volume_24h=vol)


def test_trade_fee_parser_preserves_zero_and_converts_to_bps():
    maker,taker=parse_trade_fee_response({"data":{"makerCommission":0.0,"takerCommission":0.0}})
    assert maker == 0.0 and taker == 0.0
    maker,taker=parse_trade_fee_response({"data":{"makerCommission":0.0002,"takerCommission":0.0005}})
    assert maker == 2.0 and taker == 5.0


def test_account_fee_cache_uses_exact_zero_not_floor():
    m=AccountFeeManager(cfg(),[rule("BTCUSDC","USDC")])
    m.ingest("BTCUSDC",{"data":{"makerCommission":0.0,"takerCommission":0.0}},ts=time.time())
    x=m.get("BTCUSDC")
    assert x["known"] is True
    assert x["usable_live"] is True
    assert x["taker_bps"] == 0.0
    y=m.get("UNKNOWN")
    assert y["known"] is False
    assert y["taker_bps"] == 5.0


def test_engine_qualification_fee_uses_account_fee_when_known():
    m=AccountFeeManager(cfg(),[rule("BTCUSDC","USDC")])
    m.ingest("BTCUSDC",{"data":{"makerCommission":0.0,"takerCommission":0.0}},ts=time.time())
    e=Engine.__new__(Engine)
    e.cfg=cfg();e.fees=m;e.universe=SimpleNamespace(by_symbol={})
    assert e._fee("BTCUSDC") == 0.0
    assert e._fee("UNKNOWN") == 5.0
