import time
from types import SimpleNamespace

from v4rex.db import DB
from v4rex.live import MicroLiveExecutor, buy_limit_with_cushion, sell_limit_with_cushion


def test_execution_cushion_rounding_direction():
    raw, sent = buy_limit_with_cushion(75000.001, 0.50, 2)
    assert raw > 75000.001
    assert sent == 75003.76
    assert sent >= raw

    raw_s, sent_s = sell_limit_with_cushion(75000.001, 0.50, 2)
    assert raw_s < 75000.001
    assert sent_s == 74996.25
    assert sent_s <= raw_s


def test_live_gate_uses_edge_after_execution_reserve():
    class Survival:
        def survival_stat(self, route, size):
            return {
                'trials': 5000,
                'l2_survival_100': 1.0,
                'l2_survival_250': 1.0,
                'l2_survival_500': 1.0,
            }

    x = MicroLiveExecutor.__new__(MicroLiveExecutor)
    x.cfg = {
        'live_min_stable_reserve_usd': 20,
        'live_balance_cache_max_age_s': 5,
        'live_min_survival_trials': 1000,
        'liquidity_a_min_net_edge_bps': 1.0,
        'liquidity_b_min_net_edge_bps': 2.0,
        'execution_price_reserve_bps': 0.5,
    }
    x.size = 10.0
    x._balances = {'USDC': {'free': 100.0, 'locked': 0.0}}
    x._balances_ts = time.time()
    x.db = Survival()
    x._fee_bps = lambda _symbol: 5.0

    # Raw ~11.1 bp becomes ~1.1 bp after two conservative 5 bp fees,
    # then ~0.6 bp after the 0.5 bp execution reserve: reject Class A.
    e = SimpleNamespace(
        stable_a='USDC', liquidity_class='A', symbol1='BTCUSDC',
        symbol2='BTCUSDT', raw_edge_bps=11.1,
        route='USDC>BTC>USDT'
    )
    ok, reason = x._live_gate(e)
    assert not ok and reason == 'EXECUTION_RESERVE_EDGE'

    # More economic headroom survives the exact same execution reserve.
    e.raw_edge_bps = 12.0
    ok, gate = x._live_gate(e)
    assert ok
    assert gate['execution_reserve_bps'] == 0.5
    assert gate['guaranteed_edge_bps'] > gate['threshold_bps']


def test_terminal_post_fill_does_not_wait_for_query_order():
    class DBFake:
        def __init__(self): self.rows = []
        def upsert_live_order_attempt(self, row): self.rows.append(dict(row))

    class Client:
        def __init__(self): self.query_calls = 0
        def new_fok(self, **_kw):
            return {
                'status': 'FILLED', 'orderId': 'o1',
                'executedQty': '0.0001', 'cummulativeQuoteQty': '10'
            }
        def query_order(self, *_a, **_kw):
            self.query_calls += 1
            return {'status': 'FILLED', 'orderId': 'o1', 'executedQty': '0.0001'}

    x = MicroLiveExecutor.__new__(MicroLiveExecutor)
    x.cfg = {
        'live_order_reconcile_timeout_s': 0.5,
        'live_query_start_delay_ms': 50,
        'live_query_poll_ms': 8,
    }
    x.stop = False
    x.private = None
    x.db = DBFake()
    x.client = Client()
    x.query_client = x.client

    out = x._place_fok(
        'BTCUSDC', 'BUY', 0.0001, 100000.0, 'cid',
        cycle_id='c1', leg='L1', attempt=1,
        signal_ns=time.perf_counter_ns(),
        decision_done_ns=time.perf_counter_ns(),
        plan_meta={'execution_reserve_bps': 0.5}
    )
    assert out['status'] == 'FILLED'
    assert out['_confirm_source'] == 'POST'
    time.sleep(0.07)  # give the query worker time to prove it was cancelled by done.set()
    assert x.client.query_calls == 0


def test_pre_l1_balance_snapshot_is_network_free():
    class Client:
        def balances(self):
            raise AssertionError('critical-path snapshot must not call REST')

    x = MicroLiveExecutor.__new__(MicroLiveExecutor)
    x.client = Client()
    x._balances = {
        'BTC': {'free': 0.1, 'locked': 0.2},
        'USDC': {'free': 90, 'locked': 10},
    }
    x._balances_ts = time.time()
    e = SimpleNamespace(token='BTC', stable_a='USDC')
    token, stable, age = x._snapshot_l1_balances(e)
    assert abs(token - 0.3) < 1e-12
    assert stable == 100
    assert age < 1


def test_execution_summary_exposes_fast_path_latency(tmp_path):
    db = DB(str(tmp_path / 'v462.db'))
    base = 1_000_000_000
    db.upsert_live_order_attempt({
        'cycle_id': 'c1', 'leg': 'L1', 'attempt': 1,
        'signal_ts_ns': base, 'post_start_ns': base + 2_000_000,
        'post_response_ns': base + 30_000_000,
        'private_event_ns': base + 25_000_000,
        'terminal_ns': base + 25_500_000,
        'final_status': 'FILLED', 'final_source': 'PRIVATE', 'executed_qty': 1,
    })
    db.upsert_live_order_attempt({
        'cycle_id': 'c1', 'leg': 'L2', 'attempt': 1,
        'signal_ts_ns': base + 25_500_000,
        'post_start_ns': base + 26_500_000,
        'post_response_ns': base + 50_000_000,
        'terminal_ns': base + 50_100_000,
        'final_status': 'FILLED', 'final_source': 'POST', 'executed_qty': 1,
    })
    db.upsert_live_order_attempt({
        'cycle_id': 'c2', 'leg': 'L1', 'attempt': 1,
        'signal_ts_ns': base, 'post_start_ns': base + 1_000_000,
        'terminal_ns': base + 40_000_000,
        'final_status': 'CANCELED', 'final_source': 'QUERY', 'executed_qty': 0,
    })
    s = db.live_execution_summary()
    assert s['l1_attempts'] == 2
    assert s['l1_filled'] == 1
    assert s['l1_canceled_no_fill'] == 1
    assert s['l2_filled'] == 1
    assert abs(s['latency']['l1_fill_to_l2_post']['p50_ms'] - 1.0) < 1e-9
