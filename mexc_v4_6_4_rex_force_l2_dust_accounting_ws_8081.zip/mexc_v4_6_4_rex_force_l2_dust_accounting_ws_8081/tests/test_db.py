import tempfile,time
from v4rex.db import DB

def test_db_candidate_upsert():
    f=tempfile.NamedTemporaryFile(suffix='.db',delete=False);f.close();d=DB(f.name);now=time.time();r={'bucket_ts':now,'first_ts':now,'last_ts':now,'route':'A>X>B','token':'X','stable_a':'A','stable_b':'B','observations':2,'max_bbo_bps':3,'depth_ready_obs':1,'depth_synced_obs':1,'status':'DEPTH_SYNCED','warmup_ms':20};d.upsert_candidates([r]);x=d.recent_candidates();assert x[0]['observations']==2

def test_route_activity_upsert():
    f=tempfile.NamedTemporaryFile(suffix='.db',delete=False);f.close();d=DB(f.name);r={'route':'A>X>B','token':'X','stable_a':'A','stable_b':'B','quick_scans':2,'bbo_positive':1,'max_bbo_bps':3,'last_bbo_bps':2,'last_ts':1};d.upsert_route_activity([r]);d.upsert_route_activity([r]);assert d.route_activity()[0]['quick_scans']==4


def test_v461_live_cycle_balance_baseline_columns(tmp_path):
    from v4rex.db import DB
    db=DB(str(tmp_path/'v461.db'))
    row={'cycle_id':'x','started_ts':1,'route':'USDC>BTC>USDT','token':'BTC','stable_a':'USDC','stable_b':'USDT','state':'L1_RECONCILING','l1_token_before':0.001,'l1_stable_a_before':100.0,'l1_token_after':0.0011,'l1_stable_a_after':90.0}
    db.upsert_live_cycle(row)
    got=db.live_cycles(1)[0]
    assert got['l1_token_before']==0.001
    assert got['l1_stable_a_before']==100.0
