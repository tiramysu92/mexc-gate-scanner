import time
from v4rex.mp_bbo import SharedBBO, _write, MultiprocessBBOCollector
from v4rex.core import Store


def test_shared_bbo_seqlock_roundtrip():
    h=SharedBBO(['AAAUSDT'])
    rn=time.monotonic_ns();an=rn+123456
    _write(h.args(),0,10.0,2.0,10.1,3.0,7,123456789,123456799.0,rn,an,4)
    x=h.get_bbo('AAAUSDT')
    assert x is not None
    assert x.bid == 10.0 and x.ask == 10.1 and x.bid_qty == 2.0 and x.ask_qty == 3.0
    assert x.version == 7 and x.ws_id == 4
    assert 0.12 <= x.decode_lag_ms <= 0.13


def test_store_uses_external_bbo_provider():
    h=SharedBBO(['AAAUSDT'])
    rn=time.monotonic_ns();_write(h.args(),0,1.0,1.0,1.1,1.0,1,1000,1010.0,rn,rn,1)
    s=Store(100,bbo_provider=h)
    assert s.get_bbo('AAAUSDT').ask == 1.1
    assert 'AAAUSDT' in s.snapshot_bbo()


def test_worker_plan_contains_every_group_once():
    groups=[{'id':i+1,'symbols':[f'S{i}'], 'load_score':float(100-i)} for i in range(12)]
    c=MultiprocessBBOCollector({'bbo_worker_processes':4},[f'S{i}' for i in range(12)],groups,lambda *a,**k:None)
    ids=sorted(g['id'] for plan in c.plan for g in plan)
    assert ids == list(range(1,13))
    assert len(c.plan)==4
