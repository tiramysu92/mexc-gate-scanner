import json
from v4rex.collector import Envelope,decode_bbo,decode_depth,control_frame

def test_control_text(): assert control_frame('{"id":0,"code":0,"msg":"PONG"}')['msg']=='PONG'
def test_control_binary(): assert control_frame(b'{"id":0,"code":0,"msg":"PONG"}')['msg']=='PONG'
def test_control_protobuf_none(): assert control_frame(b'\x08\x01') is None

def test_decode_bbo():
    e=Envelope();e.symbol='BTCUSDT';e.sendTime=123;e.publicAggreBookTicker.bidPrice='100';e.publicAggreBookTicker.bidQuantity='2';e.publicAggreBookTicker.askPrice='101';e.publicAggreBookTicker.askQuantity='3';e.publicAggreBookTicker.version='77'
    x=decode_bbo(e.SerializeToString());assert x['symbol']=='BTCUSDT';assert x['bid']==100;assert x['ask']==101;assert x['version']==77

def test_decode_bbo_crossed_rejected():
    e=Envelope();e.symbol='X';e.publicAggreBookTicker.bidPrice='101';e.publicAggreBookTicker.bidQuantity='1';e.publicAggreBookTicker.askPrice='100';e.publicAggreBookTicker.askQuantity='1';assert decode_bbo(e.SerializeToString()) is None

def test_decode_depth():
    e=Envelope();e.symbol='X';e.sendTime=100;e.publicLimitDepths.version='9';a=e.publicLimitDepths.asks.add();a.price='11';a.quantity='2';b=e.publicLimitDepths.bids.add();b.price='10';b.quantity='3';x=decode_depth(e.SerializeToString());assert x['version']==9;assert x['asks'][0].p==11;assert x['bids'][0].q==3

def test_depth_sorts():
    e=Envelope();e.symbol='X';e.publicLimitDepths.version='1'
    for p in ('9','10'):
        z=e.publicLimitDepths.bids.add();z.price=p;z.quantity='1'
    for p in ('12','11'):
        z=e.publicLimitDepths.asks.add();z.price=p;z.quantity='1'
    x=decode_depth(e.SerializeToString());assert [z.p for z in x['bids']]==[10,9];assert [z.p for z in x['asks']]==[11,12]


def test_bbo_ws_status_uses_stable_metric_snapshots():
    import threading, time
    from v4rex.collector import BBOCollector
    class DummyStore: pass
    c=BBOCollector({},DummyStore(),[{'id':1,'symbols':['BTCUSDT'],'load_score':1}],lambda *a,**k:None)
    ch=c.channels[1]
    stop=False
    def writer():
        nonlocal stop
        i=0
        while not stop:
            with ch['stats_lock']:
                ch['msg_times'].append(time.monotonic())
                ch['decode_lags'].append(float(i%100))
                ch['messages']+=1
                ch['last_message_ts']=time.time()
            i+=1
    t=threading.Thread(target=writer);t.start()
    try:
        for _ in range(300):
            x=c.ws_status()[0]
            assert x['msg_rate_10s'] >= 0
            assert x['decode_lag_p95_ms'] is None or x['decode_lag_p95_ms'] >= 0
    finally:
        stop=True;t.join(timeout=2)


def test_bbo_rate_does_not_mutate_input():
    import time
    from collections import deque
    from v4rex.collector import BBOCollector
    class DummyStore: pass
    c=BBOCollector({},DummyStore(),[{'id':1,'symbols':['BTCUSDT'],'load_score':1}],lambda *a,**k:None)
    q=deque([time.monotonic()-20,time.monotonic()-1])
    before=tuple(q)
    assert c._rate(tuple(q)) == 0.1
    assert tuple(q) == before


def test_hot_depth_ws_status_uses_stable_symbol_and_metric_snapshots():
    import time
    from v4rex.collector import HotDepthCollector
    class DummyStore:
        def get_depth(self,s): return None
    h=HotDepthCollector({},DummyStore(),lambda *a,**k:None)
    c=h._new_channel()
    with h.lock:c['symbols'].add('BTCUSDT')
    with c['stats_lock']:
        c['msg_times'].append(time.monotonic());c['messages']=1;c['last_message_ts']=time.time()
    out=h.ws_status()
    assert out[0]['symbol_count']==1
    assert out[0]['symbols']==['BTCUSDT']
