# V4.6.3 REX — Account Fee Addendum

`GET /api/v3/tradeFee` is read-only and requires SPOT_ACCOUNT_READ. It does not create a trade.

Qualification:
RAW edge - account taker fee L1 - account taker fee L2 - execution reserve = guaranteed edge.

If a fee is unknown, Shadow uses the conservative configured fallback. MICRO-LIVE refuses a new L1 when either leg lacks a fresh account fee. Existing exposure management is never blocked by fee refresh.

Fees are refreshed in the background, prioritized for candidate routes, persisted in `account_fees`, and changes are recorded in `account_fee_history`.
