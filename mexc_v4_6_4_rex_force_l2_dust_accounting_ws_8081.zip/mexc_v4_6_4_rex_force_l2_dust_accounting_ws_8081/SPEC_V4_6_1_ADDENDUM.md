# V4.6.1 — L1 reconciliation addendum

The executor must establish order truth from redundant sources and must never leave strategy token inventory unmanaged.

## L1 truth sequence

1. Capture token and stable-A balances immediately before L1.
2. Submit L1 as FILL_OR_KILL with unique clientOrderId.
3. Query `/api/v3/order` immediately; Private WS runs in parallel.
4. Accept REST terminal string states directly (`FILLED`, `CANCELED`, `PARTIALLY_CANCELED`) without numeric coercion.
5. Before declaring a canceled L1 as `L1_NO_FILL`, refresh balances and compare the token balance against the persisted pre-L1 baseline.
6. If a meaningful positive token delta exists, it is strategy exposure and L2 completion takes priority regardless of current edge.
7. If the order outcome remains ambiguous and no exposure can be proven, disable new entries and retain the cycle for recovery.

## Crash recovery

The pre-L1 balance baseline is persisted with the live cycle. On restart, Query Order is attempted first; if order truth remains ambiguous, the balance delta is used only to detect positive strategy exposure. Pre-existing inventory is never sold.

## Private WS

UserDataStream listenKey operations are signed in production, the listenKey string is extracted explicitly, and application PING begins only after WebSocket `on_open`.
