#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f v4_rex.pid ]; then echo 'Pas de PID enregistré'; exit 0; fi
PID=$(cat v4_rex.pid)
if kill -0 "$PID" 2>/dev/null; then kill -TERM "$PID"; for i in {1..40}; do kill -0 "$PID" 2>/dev/null || break; sleep .25; done; fi
rm -f v4_rex.pid
echo 'V4.3.0 arrêtée'
