"""Multiprocess full-universe BBO collector.

Each worker owns disjoint websocket groups and decodes BookTicker frames in its
own process.  The latest BBO for every symbol is published through lock-free-ish
shared arrays with a per-symbol seqlock.  No per-message IPC queue is used.
Only low-rate telemetry crosses a multiprocessing.Queue.
"""
from __future__ import annotations
import ctypes, json, math, multiprocessing as mp, os, random, threading, time
from collections import deque
import websocket
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory
from .core import BBO

WS='wss://wbs-api.mexc.com/ws'

def _codec():
    fd=descriptor_pb2.FileDescriptorProto(name='mexc_v430.proto',package='v430',syntax='proto3')
    def msg(n):m=fd.message_type.add();m.name=n;return m
    def fld(m,n,num,typ,target=None,oneof=None):
        f=m.field.add();f.name=n;f.number=num;f.type=typ;f.label=1
        if target:f.type_name='.v430.'+target
        if oneof is not None:f.oneof_index=oneof
    bt=msg('PublicAggreBookTickerV3Api')
    for n,num in [('bidPrice',1),('bidQuantity',2),('askPrice',3),('askQuantity',4),('version',5)]:fld(bt,n,num,9)
    fld(bt,'lastOrderCreateTime',6,3)
    env=msg('PushDataV3ApiWrapper');fld(env,'channel',1,9);o=env.oneof_decl.add();o.name='body';fld(env,'publicAggreBookTicker',315,11,'PublicAggreBookTickerV3Api',0);fld(env,'symbol',3,9);fld(env,'symbolId',4,9);fld(env,'createTime',5,3);fld(env,'sendTime',6,3)
    pool=descriptor_pool.DescriptorPool();pool.Add(fd)
    return message_factory.GetMessageClass(pool.FindMessageTypeByName('v430.PushDataV3ApiWrapper'))
Envelope=_codec()

def _control(raw):
    if isinstance(raw,str):s=raw
    elif isinstance(raw,(bytes,bytearray)):
        b=bytes(raw).lstrip()
        if b[:1] not in (b'{',b'['):return None
        try:s=bytes(raw).decode()
        except UnicodeDecodeError:return None
    else:return None
    try:x=json.loads(s)
    except Exception:return None
    return x if isinstance(x,dict) else None

def _decode(raw):
    e=Envelope();e.ParseFromString(raw)
    if not e.symbol or not e.HasField('publicAggreBookTicker'):return None
    x=e.publicAggreBookTicker
    try:
        bid=float(x.bidPrice);ask=float(x.askPrice);bq=float(x.bidQuantity);aq=float(x.askQuantity);ver=int(x.version) if x.version else 0
    except Exception:return None
    if not(math.isfinite(bid) and math.isfinite(ask) and bid>0 and ask>bid and bq>=0 and aq>=0):return None
    return e.symbol,bid,bq,ask,aq,ver,int(e.sendTime or 0)

def _pct(vals,p):
    a=sorted(vals)
    if not a:return None
    k=(len(a)-1)*p;lo=int(k);hi=min(len(a)-1,lo+1);w=k-lo
    return a[lo]*(1-w)+a[hi]*w

class SharedBBO:
    def __init__(self, symbols, ctx=None):
        self.ctx=ctx or mp.get_context('fork');self.symbols=tuple(symbols);self.index={s:i for i,s in enumerate(self.symbols)};n=len(self.symbols)
        self.seq=self.ctx.RawArray(ctypes.c_ulonglong,n)
        self.bid=self.ctx.RawArray(ctypes.c_double,n);self.bq=self.ctx.RawArray(ctypes.c_double,n);self.ask=self.ctx.RawArray(ctypes.c_double,n);self.aq=self.ctx.RawArray(ctypes.c_double,n)
        self.ver=self.ctx.RawArray(ctypes.c_longlong,n);self.exchange=self.ctx.RawArray(ctypes.c_longlong,n);self.recv_wall=self.ctx.RawArray(ctypes.c_double,n);self.recv_ns=self.ctx.RawArray(ctypes.c_longlong,n);self.apply_ns=self.ctx.RawArray(ctypes.c_longlong,n);self.ws_id=self.ctx.RawArray(ctypes.c_int,n)
    def args(self):return (self.seq,self.bid,self.bq,self.ask,self.aq,self.ver,self.exchange,self.recv_wall,self.recv_ns,self.apply_ns,self.ws_id)
    def read_idx(self,i):
        for _ in range(4):
            a=self.seq[i]
            if not a or a&1:continue
            z=(self.bid[i],self.bq[i],self.ask[i],self.aq[i],self.ver[i],self.exchange[i],self.recv_wall[i],self.recv_ns[i],self.apply_ns[i],self.ws_id[i])
            b=self.seq[i]
            if a==b and not(b&1):return z
        return None
    def get_bbo(self,symbol):
        i=self.index.get(symbol)
        if i is None:return None
        z=self.read_idx(i)
        if not z:return None
        bid,bq,ask,aq,ver,ex,rw,rn,an,wid=z
        return BBO(symbol,bid,bq,ask,aq,ver or None,ex or None,rw or None,rn,an,wid,'VALID')
    def snapshot_bbo(self):
        out={}
        for i,s in enumerate(self.symbols):
            z=self.read_idx(i)
            if not z:continue
            bid,bq,ask,aq,ver,ex,rw,rn,an,wid=z;out[s]=BBO(s,bid,bq,ask,aq,ver or None,ex or None,rw or None,rn,an,wid,'VALID')
        return out

def _write(shared,i,bid,bq,ask,aq,ver,ex,rw,rn,an,wid):
    seq,B,BQ,A,AQ,V,E,RW,RN,AN,W=shared
    x=seq[i]+1
    if not(x&1):x+=1
    seq[i]=x;B[i]=bid;BQ[i]=bq;A[i]=ask;AQ[i]=aq;V[i]=ver;E[i]=ex;RW[i]=rw;RN[i]=rn;AN[i]=an;W[i]=wid;seq[i]=x+1

def _worker(worker_id, groups, sym_index, shared, stats_q, stop_ev, cfg):
    states={int(g['id']):{'connected':False,'messages':0,'acks':0,'pongs':0,'errors':0,'reconnects':0,'decode':deque(maxlen=5000),'times':deque(maxlen=50000),'last':0.0,'symbols':tuple(g['symbols']),'load':float(g.get('load_score') or 0),'app':None} for g in groups}
    lock=threading.RLock()
    def socket_loop(g):
        wid=int(g['id']);st=states[wid];back=.5
        while not stop_ev.is_set():
            def on_open(ws):
                with lock:st['connected']=True
                ws.send(json.dumps({'method':'SUBSCRIPTION','params':[f'spot@public.aggre.bookTicker.v3.api.pb@10ms@{s}' for s in st['symbols']]}))
            def on_msg(ws,msg):
                rn=time.monotonic_ns();rw=time.time()*1000
                c=_control(msg)
                if c is not None:
                    with lock:
                        if str(c.get('msg','')).upper()=='PONG':st['pongs']+=1
                        else:st['acks']+=1
                    return
                if not isinstance(msg,(bytes,bytearray)):return
                try:
                    x=_decode(bytes(msg))
                    if not x:return
                    sym,bid,bq,ask,aq,ver,ex=x;i=sym_index.get(sym)
                    if i is None:return
                    an=time.monotonic_ns();_write(shared,i,bid,bq,ask,aq,ver,ex,rw,rn,an,wid)
                    lag=(an-rn)/1e6
                    with lock:st['messages']+=1;st['decode'].append(lag);st['times'].append(time.monotonic());st['last']=time.time()
                except Exception:
                    with lock:st['errors']+=1
            def on_err(ws,e):
                with lock:st['errors']+=1
            def on_close(ws,code,msg):
                with lock:st['connected']=False
            app=websocket.WebSocketApp(WS,on_open=on_open,on_message=on_msg,on_error=on_err,on_close=on_close);st['app']=app
            def ping():
                while not stop_ev.is_set():
                    time.sleep(float(cfg.get('ping_interval_s',15)))
                    with lock:ok=st['connected']
                    if not ok:return
                    try:app.send(json.dumps({'method':'PING'}))
                    except Exception:return
            threading.Thread(target=ping,daemon=True).start()
            try:app.run_forever(ping_interval=0,skip_utf8_validation=True)
            except Exception:
                with lock:st['errors']+=1
            with lock:st['connected']=False;st['reconnects']+=1
            if stop_ev.is_set():break
            time.sleep(back+random.random()*.2);back=min(15,back*1.6)
    for g in groups:threading.Thread(target=socket_loop,args=(g,),daemon=True,name=f'ws-{g["id"]}').start()
    while not stop_ev.wait(1.0):
        now=time.monotonic();rows=[]
        with lock:
            for wid,st in states.items():
                times=tuple(st['times']);dec=tuple(st['decode'])
                rows.append({'id':wid,'worker':worker_id,'pid':os.getpid(),'connected':st['connected'],'symbol_count':len(st['symbols']),'messages':st['messages'],'msg_rate_10s':sum(1 for t in times if now-t<=10)/10,'decode_lag_p50_ms':_pct(dec,.5),'decode_lag_p95_ms':_pct(dec,.95),'acks':st['acks'],'pongs':st['pongs'],'errors':st['errors'],'reconnects':st['reconnects'],'last_message_age_s':max(0,time.time()-st['last']) if st['last'] else None,'estimated_load':st['load'],'symbols':st['symbols']})
        try:stats_q.put_nowait({'worker':worker_id,'ts':time.time(),'channels':rows})
        except Exception:pass
    with lock:
        apps=[s.get('app') for s in states.values()]
    for a in apps:
        try:
            if a:a.close()
        except Exception:pass

class MultiprocessBBOCollector:
    def __init__(self,cfg,symbols,groups,error):
        self.cfg=cfg;self.error=error;self.ctx=mp.get_context('fork');self.shared=SharedBBO(symbols,self.ctx);self.stop_ev=self.ctx.Event();self.stats_q=self.ctx.Queue(maxsize=200);self.groups=groups;self.processes=[];self.stats={};self.worker_stats={};self.lock=threading.RLock();self.stop=False
        n=int(cfg.get('bbo_worker_processes',0) or 0)
        if n<=0:n=min(len(groups),max(2,min(16,(os.cpu_count() or 2)*2)))
        self.worker_count=max(1,n)
        self.plan=[[] for _ in range(self.worker_count)]
        loads=[0.0]*self.worker_count
        for g in sorted(groups,key=lambda z:-float(z.get('load_score') or 0)):
            i=min(range(self.worker_count),key=lambda j:loads[j]);self.plan[i].append(g);loads[i]+=float(g.get('load_score') or 0)
        self.worker_loads=loads
    def start(self):
        args_shared=self.shared.args();idx=self.shared.index
        for i,gs in enumerate(self.plan,1):
            p=self.ctx.Process(target=_worker,args=(i,gs,idx,args_shared,self.stats_q,self.stop_ev,self.cfg),daemon=True,name=f'bbo-worker-{i}');p.start();self.processes.append(p)
        threading.Thread(target=self._listen,daemon=True,name='bbo-stats-listener').start()
    def _listen(self):
        while not self.stop:
            try:x=self.stats_q.get(timeout=.5)
            except Exception:continue
            with self.lock:
                self.worker_stats[x['worker']]={'pid':next((p.pid for p in self.processes if p.name==f'bbo-worker-{x["worker"]}'),None),'ts':x['ts']}
                for c in x['channels']:self.stats[c['id']]=c
    def get_bbo(self,s):return self.shared.get_bbo(s)
    def snapshot_bbo(self):return self.shared.snapshot_bbo()
    def ws_status(self):
        with self.lock:rows=[dict(x) for _,x in sorted(self.stats.items())]
        return rows
    def status(self):
        rows=self.ws_status();bb=self.snapshot_bbo();dec=[x.decode_lag_ms for x in bb.values()]
        return {'ready':len(bb),'symbols':len(self.shared.symbols),'ws_connected':sum(bool(x.get('connected')) for x in rows),'ws_total':len(self.groups),'subscriptions':sum(int(x.get('symbol_count') or 0) for x in rows),'messages':sum(int(x.get('messages') or 0) for x in rows),'msg_rate_10s':sum(float(x.get('msg_rate_10s') or 0) for x in rows),'errors':sum(int(x.get('errors') or 0) for x in rows),'reconnects':sum(int(x.get('reconnects') or 0) for x in rows),'acks':sum(int(x.get('acks') or 0) for x in rows),'pongs':sum(int(x.get('pongs') or 0) for x in rows),'decode_p50_ms':_pct(dec,.5),'decode_p95_ms':_pct(dec,.95),'decode_p95_max_ms':max([float(x.get('decode_lag_p95_ms') or 0) for x in rows] or [0]),'worker_processes':self.worker_count,'workers_alive':sum(p.is_alive() for p in self.processes),'worker_loads':self.worker_loads}
    def close(self):
        self.stop=True;self.stop_ev.set()
        for p in self.processes:
            p.join(timeout=3)
            if p.is_alive():p.terminate()
