# Changelog

## 4.3.0 — Multiprocess BBO
- Conserve BookTicker 10 ms sur **tout** l'univers.
- Remplace le pipeline BBO threadé/central par des workers `multiprocessing` équilibrés par charge.
- Publication des derniers BBO en mémoire partagée avec seqlock par symbole.
- Supprime la queue centrale par update BBO.
- Scanner global des routes à cadence fixe (20 ms par défaut).
- Queue centrale réservée aux updates Depth chauds.
- Tier-2 Depth 20 dynamique inchangé.
- Cockpit : Worker/PID/WS/msg/s/decode p50/p95.
- 39 tests.

### REX V4.2.2 ayant motivé le changement
- ~17 000 BBO msg/s.
- ~198k frames en queue.
- overflows BBO.
- decode p95 > 100 s sur les pires WS.
- transport MEXC/Depth correct : saturation locale, pas défaut exchange.
