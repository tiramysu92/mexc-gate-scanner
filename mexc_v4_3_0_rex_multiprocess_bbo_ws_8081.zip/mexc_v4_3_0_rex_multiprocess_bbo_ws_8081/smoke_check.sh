#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://127.0.0.1:8081}
echo '=== HEALTH ==='; curl -fsS "$BASE/healthz"; echo
echo '=== SMOKE SUMMARY ==='; curl -fsS "$BASE/api/smoke"; echo
echo '=== CANDIDATES BBO+ ==='; curl -fsS "$BASE/api/candidates?hours=1&limit=12"; echo
echo '=== OPPORTUNITES CONCRETES ==='; curl -fsS "$BASE/api/opportunities?hours=24&limit=12&min_rank=1"; echo
echo '=== DB ==='; ls -lh v4_rex_multiprocess_bbo_v430.db* 2>/dev/null || true
echo '=== LOG TAIL ==='; tail -60 v4_rex.log 2>/dev/null || true
