# V4.3.0-REX — FULL UNIVERSE 2-LEG — Multiprocess BBO — SHADOW ONLY

V4.3 conserve **100 % de l'univers 2-leg MEXC** et le BookTicker **10 ms** sur tous les symboles, mais retire le goulot d'étranglement du process Python unique observé en V4.2.2.

## Pourquoi V4.3
Le smoke V4.2.2 a montré ~17k BBO msg/s, ~198k frames en queue, des overflows et >100 s de decode lag. Le réseau et le Depth dynamique étaient sains : le problème était local et CPU/GIL.

## Architecture
- Universe dynamique `exchangeInfo + defaultSymbols`.
- 716+ routes typiques, nombre exact découvert au démarrage.
- 32 WS typiques, 20 streams max/WS.
- WS répartis **heaviest-first** entre plusieurs **processus BBO**.
- Chaque processus décode directement ses frames et écrit le dernier BBO dans des tableaux mémoire partagés.
- **Aucune queue IPC par message BBO**.
- Scanner central full-universe à cadence fixe (`bbo_scan_interval_ms`, 20 ms par défaut).
- Toute route BBO+ active le Tier-2 `Partial Depth 20` sur les deux jambes.
- Le Depth détaillé reste dynamique et chaud 30 s.
- Cooldown de restitution/persistance : 5 s par route.

## Auto-sizing des workers
`bbo_worker_processes: 0` = auto : jusqu'à 2× le nombre de CPU logiques, plafonné à 16, avec au moins 2 workers et équilibrage des groupes par charge estimée.

Si le VPS est insuffisant, le smoke le montrera directement : le critère principal devient `decode p95` des workers, sans backlog central artificiel.

## Interface 8081
- Workers BBO / PID / WS / streams / msg/s / decode p50/p95 / ACK-PONG / erreurs.
- Univers complet : tokens, symboles, routes.
- Depth chauds, warmup, TTL.
- Opportunités 2-leg concrètes avec taille, depth %, raw, frais, net, expected, PnL, coverage et latences.
- Tableau BBO+ en vérification Depth séparé.
- Viabilité cumulée 24 h par route.

## Installation
```bash
./install.sh
./start.sh
sleep 90
./smoke_check.sh
```

## Gates avant run long
- `BBO workers alive == configured`
- `WS connected == WS total`
- `BBO ready == symbols`
- `decode p95` idéalement < 100 ms sur tous les workers/WS
- `errors == 0`, reconnects stables
- Depth queue drops == 0
- update queue proche de 0 (elle ne porte plus les BBO)

## Export
```bash
python export_run.py
```
