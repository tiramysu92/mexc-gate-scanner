# Validation locale — 4.8.0-c-shadow.1

Date : 19 septembre 2026.

## Résultats exécutés

- **81 tests unittest : PASS.** Suite relancée après les dernières modifications.
- Compilation Python de app.py, manage.py, export_data.py, cshadow/ et tests/ : PASS.
- Analyse syntaxique JavaScript `node --check static/app.js` : PASS.
- Analyse syntaxique de tous les scripts shell `bash -n` : PASS.
- API HTTP locale : chargement des assets, endpoint de santé, données JSON, refus de POST, anti-traversée de chemin et en-têtes no-store : PASS dans la suite.
- Service C complet avec règles/frais/carnets injectés, sans réseau externe : création de signaux et essais, `orders_possible=false`, PnL C réel 0 : PASS.
- Rendu Chromium desktop 1440 px / mobile 390 px, données DEMO injectées en mémoire : PASS ; 10 lignes signal, 4 horizons, 6 tailles ; aucune erreur JavaScript ; pas de débordement horizontal du document (tables défilantes).

## Cas de sécurité et de mesure

Frais absents/périmés, zéro frais explicite, quantités décimales, round-up BUY / round-down SELL, minima d'ordre, limites de budget, couverture insuffisante, dust excessif, book/fee symbol mismatch, horloge incertaine, carnet périmé, skew, gros outlier, spread, règles de sens, filtre prix inconnu/référence manquante, frame protobuf tronquée, version dupliquée, reconnexion, absence de nouvelle trame à l'horizon, arrivée trop tardive, L2 devenue négative, un seul trial par taille/épisode, séparation de tailles, fermeture d'épisode avant progression, persistence et changement de politique, plafond stockage, endpoint privé interdit, HTTP 429/backoff, base LIVE manquante non créée.

Le test de lecture des frais vérifie le hash du fichier SQLite source avant/après. Le lecteur source est ouvert en mode=ro et ne peut pas écrire les données LIVE.

## Environnement

Construction/tests : Python 3.13.5, websocket-client 1.9.0. Code compatible syntaxiquement avec Python 3.10+ ; cible utilisateur Ubuntu/Python 3.12. Pas de test d'installation exécuté sur l'AWS de l'utilisateur.

Les fixtures protobuf sont synthétiques et suivent les schémas publics MEXC ; ce rapport ne dit pas qu'une capture WebSocket réelle a été validée depuis cette machine. Le navigateur a été testé en mémoire avec les mêmes HTML/CSS/JS ; l'API locale a été testée séparément par HTTP.

## Ce qui n'est PAS validé par ces tests

- Réception réseau MEXC, cadence et latence réellement observées sur l'AWS.
- Rentabilité future, fills réels, queue-position, changements de prix avant envoi d'ordre.
- Exhaustivité du marché (seuls les tokens chauds ont une profondeur suivie).
- Probabilité de succès financier à partir de 3, 10 ou 25 épisodes.
- Sécurité opérationnelle d'un futur LIVE C. Il n'y a aucun LIVE C dans ce paquet.

## Reproduction

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python -m compileall -q app.py manage.py export_data.py cshadow tests
```

Les 81 tests sont dans tests/ ; ils ne démarrent pas de connexion externe MEXC.
