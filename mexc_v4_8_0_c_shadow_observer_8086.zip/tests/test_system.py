import copy
import hashlib
import json
import sqlite3
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch
from cshadow.config import DEFAULTS
from cshadow.storage import Store
from cshadow.public import ReferenceData,GetOnlyClient,local_live_status
from cshadow.demo import DemoService
from cshadow.episodes import Evidence
from cshadow.model import Clock
from cshadow.feed import BookCache
from test_core import fixture,calc,MemoryStore,WALL,MONO
from app import Server

class StorageTests(unittest.TestCase):
    def test_writes_only_c_and_source_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            base=Path(td);live=base/'live';live.mkdir();dbpath=live/'source.db'
            with sqlite3.connect(dbpath) as db:
                db.execute('CREATE TABLE account_fees(symbol TEXT,taker_bps REAL,fetched_ts REAL,source TEXT)')
                db.execute('INSERT INTO account_fees VALUES(?,?,?,?)',('TESTUSDC',0,time.time(),'MEXC_ACCOUNT_API'))
            (live/'config.json').write_text(json.dumps({'db_path':'source.db'}))
            before=hashlib.sha256(dbpath.read_bytes()).hexdigest()
            cfg={**DEFAULTS,'data_dir':str(base/'cdata'),'live_runtime':str(live),'min_disk_free_mb':0}
            store=Store(cfg['data_dir'],cfg,'TEST')
            try:
                ref=ReferenceData(cfg,store,threading.Event());ref.read_live_fees()
                self.assertIn('TESTUSDC',ref.fees)
                self.assertEqual(before,hashlib.sha256(dbpath.read_bytes()).hexdigest())
            finally:store.close()
            with sqlite3.connect(base/'cdata'/'c_shadow.sqlite') as db:
                self.assertEqual(db.execute('SELECT count(*) FROM c_fee_snapshots').fetchone()[0],1)
    def test_own_db_read_handle_refuses_write(self):
        with tempfile.TemporaryDirectory() as td:
            s=Store(td,{**DEFAULTS,'min_disk_free_mb':0},'RUN1')
            try:
                with s.ro() as db:
                    with self.assertRaises(sqlite3.OperationalError):db.execute('DELETE FROM c_runs')
            finally:s.close()
    def test_policy_change_does_not_mix_evidence(self):
        with tempfile.TemporaryDirectory() as td:
            cfg={**DEFAULTS,'min_disk_free_mb':0}
            s=Store(td,cfg,'RUN1');s.close()
            with self.assertRaises(ValueError):Store(td,{**cfg,'thin_buffer_bps':20},'RUN2')
    def test_own_storage_limit_pauses(self):
        with tempfile.TemporaryDirectory() as td:
            s=Store(td,{**DEFAULTS,'min_disk_free_mb':10**12},'RUN1')
            try:s.check_capacity();self.assertTrue(s.failed)
            finally:s.close()
    def test_restart_preserves_completed_stage_and_censors_open(self):
        with tempfile.TemporaryDirectory() as td:
            cfg={**DEFAULTS,'min_disk_free_mb':0}
            s=Store(td,cfg,'RUN1')
            s.emit('stage',{'route':'R','size':5,'clean':4,'total':5})
            s.emit('episode',{'episode_id':'E','route':'R','start_ts':1,'last_ts':2,'status':'OPEN'})
            s.close();s=Store(td,cfg,'RUN2')
            try:
                self.assertEqual(s.load_stages()[('R',5.)]['clean'],4)
                with s.ro() as db:self.assertEqual(db.execute('SELECT status FROM c_episodes').fetchone()[0],'INTERRUPTED_RESTART')
            finally:s.close()
    def test_distinct_size_rows_kept(self):
        with tempfile.TemporaryDirectory() as td:
            s=Store(td,{**DEFAULTS,'min_disk_free_mb':0},'RUN1')
            for size in (2.5,5,10,15,20,25):
                s.emit('sample',{'ts':time.time(),'route':'R','size':size,'testable':True,'protected_cash_bps':5})
            s.close()
            with sqlite3.connect(Path(td)/'c_shadow.sqlite') as db:
                self.assertEqual(db.execute('SELECT count(distinct size) FROM c_size_samples').fetchone()[0],6)
    def test_json_nonfinite_is_rejected(self):
        from cshadow.storage import encode
        with self.assertRaises(ValueError):encode({'edge':float('inf')})

class PermissionsTests(unittest.TestCase):
    def test_no_private_endpoint(self):
        client=GetOnlyClient()
        for endpoint in ('/api/v3/order','/api/v3/account','/api/v3/myTrades','/api/v3/tradeFee'):
            with self.assertRaises(ValueError):client.get(endpoint)
    def test_local_status_only(self):
        for url in ('http://127.0.0.1:8081/api/live/arm','http://evil.test/api/live/status','http://127.0.0.1:8085/api/live/status'):
            with self.assertRaises(ValueError):local_live_status(url)
    def test_get_method_and_no_key(self):
        import io
        client=GetOnlyClient()
        seen=[]
        def fake(req,timeout):
            seen.append(req)
            return io.BytesIO(b'{"serverTime":1000}')
        with patch('urllib.request.urlopen',fake):client.get('/api/v3/time')
        self.assertEqual(seen[0].get_method(),'GET')
        self.assertNotIn('X-mexc-apikey',seen[0].headers)
    def test_backoff_429(self):
        client=GetOnlyClient()
        with patch('urllib.request.urlopen',side_effect=urllib.error.HTTPError('X',429,'rate',{'Retry-After':'180'},None)):
            with self.assertRaises(urllib.error.HTTPError):client.get('/api/v3/time')
        self.assertGreater(client.backoff_until,time.monotonic()+170)
    def test_missing_live_db_does_not_create_file(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'config.json').write_text(json.dumps({'db_path':'missing.db'}))
            ref=ReferenceData({**DEFAULTS,'live_runtime':td},MemoryStore(),threading.Event())
            with self.assertRaises(FileNotFoundError):ref.read_live_fees()
            self.assertFalse((p/'missing.db').exists())

class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=Server(('127.0.0.1',0),DemoService());cls.port=cls.server.server_port
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.thread.join(2)
    def fetch(self,path):return urllib.request.urlopen(f'http://127.0.0.1:{self.port}{path}',timeout=2)
    def test_real_read_only_flag(self):
        with self.fetch('/api/data') as r:d=json.load(r)
        self.assertFalse(d['orders_possible']);self.assertTrue(d['demo'])
    def test_no_cache(self):
        with self.fetch('/api/data') as r:self.assertIn('no-store',r.headers['Cache-Control'])
    def test_no_order_post(self):
        req=urllib.request.Request(f'http://127.0.0.1:{self.port}/api/live/arm',data=b'{}',method='POST')
        with self.assertRaises(urllib.error.HTTPError) as c:urllib.request.urlopen(req)
        self.assertEqual(c.exception.code,405)
    def test_static_no_traversal(self):
        with self.assertRaises(urllib.error.HTTPError) as c:self.fetch('/../config.json')
        self.assertEqual(c.exception.code,404)
    def test_index_and_assets(self):
        for path in ('/','/static/app.js','/static/style.css'):
            with self.fetch(path) as r:self.assertEqual(r.status,200);self.assertGreater(len(r.read()),100)
    def test_health(self):
        with self.fetch('/api/health') as r:self.assertEqual(json.load(r)['mode'],'SHADOW_ONLY')

class EpisodeClosureTests(unittest.TestCase):
    def test_clean_evidence_only_after_observed_close(self):
        store=MemoryStore();cache=BookCache();cfg={**DEFAULTS,'episode_separation_s':1}
        e=Evidence(cfg,store,cache);x=fixture();p=calc(x);clock=Clock(0,1,WALL)
        e.observe(p['route'],[p],x[1],x[5],x[3],MONO,WALL)
        for i,h in enumerate([50,100,250,500]):
            delay=h/1000+.01
            cache.add({'symbol':'TESTUSDT','bids':[['1.0015','1000']],'asks':[['1.0016','1000']],
                       'version':i+2,'send_ms':int((WALL+delay)*1000)},WALL+delay,MONO+delay)
            e.tick(WALL+delay,MONO+delay,clock)
        self.assertEqual(e.stage(p['route'],5)['clean_episodes'],0)
        low={**copy.deepcopy(p),'protected_cash_bps':-1}
        e.observe(p['route'],[low],x[1],x[5],x[3],MONO+.6,WALL+.6)
        e.observe(p['route'],[low],x[1],x[5],x[3],MONO+1.61,WALL+1.61)
        self.assertEqual(e.stage(p['route'],5)['clean_episodes'],1)
        self.assertFalse(e.active)
    def test_config_and_test_names_do_not_imply_live(self):
        store=MemoryStore();e=Evidence(DEFAULTS,store,BookCache());e.stages[('R',5.)]={'clean':25,'total':25}
        self.assertFalse(e.stage('R',5)['live_authorized'])

if __name__=='__main__':unittest.main()
