import tempfile
import threading
import time
import unittest
from dataclasses import replace
from cshadow.config import DEFAULTS
from cshadow.model import Clock
from cshadow.service import Service
from test_core import fixture

class ServiceSmokeTest(unittest.TestCase):
    def test_independent_service_with_public_frames_and_no_network(self):
        with tempfile.TemporaryDirectory() as td:
            cfg={**DEFAULTS,'data_dir':td,'min_disk_free_mb':0}
            service=Service(cfg)
            wall=time.time();mono=time.monotonic();r1,r2,b1,b2,f1,f2=fixture()
            r1,r2=replace(r1,fetched_ts=wall),replace(r2,fetched_ts=wall)
            f1,f2=replace(f1,fetched_ts=wall),replace(f2,fetched_ts=wall)
            ref={'rules':{r1.symbol:r1,r2.symbol:r2},'fees':{f1.symbol:f1,f2.symbol:f2},
                 'volumes':{r1.symbol:10000,r2.symbol:10000},'refs':{},
                 'bbo':{r1.symbol:(b1.bids[0][0],b1.asks[0][0]),r2.symbol:(b2.bids[0][0],b2.asks[0][0])},
                 'clock':Clock(0,1,wall),'live':{},'live_ts':0,'bbo_ts':wall,'rules_ts':wall,
                 'volume_ts':wall,'fees_ts':wall,'errors':{},'last_error':None}
            service.reference.snapshot=lambda:ref
            service.reference.heartbeat=mono
            service.feed.connected=True;service.feed.last_depth_rx=wall
            for b in (b1,b2):
                service.cache.add({'symbol':b.symbol,'bids':b.bids,'asks':b.asks,'version':1,'send_ms':int(wall*1000)},wall,mono)
            # Do NOT call feed.start/reference.start: no external network in this test.
            service.thread=threading.Thread(target=service.run,daemon=True);service.thread.start()
            try:
                until=time.monotonic()+2
                while time.monotonic()<until and not service.public_view:time.sleep(.02)
                d=service.snapshot()
                self.assertFalse(d['orders_possible'])
                self.assertEqual(d['mode'],'SHADOW_ONLY')
                self.assertTrue(d['top10'])
                self.assertGreaterEqual(d['evidence']['trials_started'],1)
                self.assertEqual(d['realized_c_pnl_su'],0)
            finally:service.close()

if __name__=='__main__':unittest.main()
