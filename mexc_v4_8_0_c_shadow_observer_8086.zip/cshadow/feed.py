from __future__ import annotations
import json
import logging
import threading
import time
from collections import Counter, deque
from .model import Book

LOG = logging.getLogger(__name__)

# Minimal, strict wire reader for the public partial-depth message. Field numbers
# checked against mexcdevelop/websocket-proto, SHAs in SOURCES.md. Private bodies
# are never decoded or subscribed to. Unknown protobuf fields are skipped.
def fields(buf: bytes):
    if len(buf) > 2_000_000:
        raise ValueError('Oversize protobuf frame')
    pos = 0
    def varint():
        nonlocal pos
        n = 0
        for shift in range(0, 70, 7):
            if pos >= len(buf): raise ValueError('Truncated varint')
            b = buf[pos]; pos += 1
            n |= (b & 127) << shift
            if not b & 128: return n
        raise ValueError('Invalid varint')
    while pos < len(buf):
        key = varint(); number, wire = key >> 3, key & 7
        if number == 0: raise ValueError('Invalid protobuf field')
        if wire == 0:
            value = varint()
        elif wire in (1, 5, 2):
            length = 8 if wire == 1 else 4 if wire == 5 else varint()
            if pos + length > len(buf): raise ValueError('Truncated protobuf payload')
            value = buf[pos:pos+length]; pos += length
        else:
            raise ValueError('Unsupported protobuf wire type')
        yield number, wire, value

def decode_partial(buf: bytes) -> dict | None:
    wrapper = {n: v for n, _, v in fields(buf)}
    payload = wrapper.get(303)  # PublicLimitDepthsV3Api
    if payload is None: return None
    def string(v):
        if not isinstance(v, bytes): raise ValueError('Expected UTF-8 string')
        return v.decode('utf-8')
    channel = string(wrapper.get(1, b''))
    if not channel.startswith('spot@public.limit.depth.v3.api.pb@'):
        raise ValueError('Unexpected channel')
    sym = string(wrapper.get(3, b''))
    parts = channel.split('@')
    if len(parts) != 4 or parts[2] != sym or parts[3] != '20':
        raise ValueError('Channel / symbol mismatch')
    out = {'symbol': sym, 'asks': [], 'bids': [], 'send_ms': int(wrapper.get(6, 0)), 'version': 0}
    for n, _, v in fields(payload):
        if n in (1, 2):
            item = {k: val for k, _, val in fields(v)}
            out['asks' if n == 1 else 'bids'].append((string(item.get(1, b'')), string(item.get(2, b''))))
        elif n == 4:
            out['version'] = int(string(v))
    if out['version'] <= 0 or out['send_ms'] <= 0:
        raise ValueError('Partial depth missing version/time')
    return out

class BookCache:
    def __init__(self):
        self.lock = threading.RLock()
        self.history = {}
        self.generation = 0
        self.stats = Counter()

    def clear(self):
        with self.lock:
            self.generation += 1
            self.history.clear()

    def discard(self, symbols):
        with self.lock:
            for sym in symbols: self.history.pop(sym, None)

    def add(self, x, wall=None, mono=None):
        wall = time.time() if wall is None else wall
        mono = time.monotonic() if mono is None else mono
        with self.lock:
            book = Book.build(x['symbol'], x['bids'], x['asks'], x['version'], x['send_ms'], wall, mono, self.generation)
            rows = self.history.setdefault(book.symbol, deque(maxlen=256))
            if rows and book.version <= rows[-1].version:
                self.stats['old_or_duplicate_version'] += 1
                return False
            if rows and book.exchange_ms < rows[-1].exchange_ms:
                self.stats['out_of_order_timestamp'] += 1
                return False
            rows.append(book)
            self.stats['depth_frames'] += 1
            return True

    def latest(self, symbol):
        with self.lock:
            rows = self.history.get(symbol)
            return rows[-1] if rows else None

    def first_after(self, symbol, due_mono, generation, min_version, min_exchange_ms):
        with self.lock:
            for b in self.history.get(symbol, ()):
                if (b.generation == generation and b.recv_mono >= due_mono and
                    b.version > min_version and b.exchange_ms > min_exchange_ms):
                    return b
        return None

class PublicDepthFeed:
    URL = 'wss://wbs-api.mexc.com/ws'
    def __init__(self, cache: BookCache, stop: threading.Event):
        self.cache, self.stop = cache, stop
        self.lock = threading.RLock()
        self.desired, self.subscribed = set(), set()
        self.ws = None
        self.connected = False
        self.connect_ts = 0.0
        self.last_rx = 0.0
        self.last_depth_rx = 0.0
        self.last_error = None
        self.stats = Counter()
        self.thread = None
        self.pause_until = 0.0

    def set_symbols(self, symbols):
        symbols = set(symbols)
        if len(symbols) > 25: raise ValueError('Public channel budget exceeded')
        with self.lock: self.desired = symbols

    def start(self):
        self.thread = threading.Thread(target=self.run, name='c-public-depth', daemon=True)
        self.thread.start()

    def close(self):
        with self.lock:
            if self.ws: self.ws.close()

    def run(self):
        import websocket
        backoff = 3.0
        while not self.stop.is_set():
            if time.monotonic() < self.pause_until:
                self.stop.wait(1); continue
            try:
                # TLS verification remains enabled; no account key, listen key or private channel.
                ws = websocket.create_connection(self.URL, timeout=3, enable_multithread=True)
                ws.settimeout(.5)
                with self.lock:
                    self.ws, self.connected = ws, True
                    self.subscribed.clear(); self.cache.clear()
                    self.connect_ts = time.time()
                    self.last_rx=0.0;self.last_depth_rx=0.0
                self.stats['connections'] += 1
                last_ping, last_reconcile = 0.0, 0.0
                backoff = 3.0
                while not self.stop.is_set():
                    now = time.monotonic()
                    if now < self.pause_until: break
                    if now - last_reconcile >= 1:
                        with self.lock:
                            desired = set(self.desired)
                        removed = self.subscribed - desired
                        added = desired - self.subscribed
                        for method, syms in [('UNSUBSCRIPTION', removed), ('SUBSCRIPTION', added)]:
                            if syms:
                                channels = [f'spot@public.limit.depth.v3.api.pb@{s}@20' for s in sorted(syms)]
                                ws.send(json.dumps({'method': method, 'params': channels, 'id': int(time.time()*1000)%2147483647}))
                        self.cache.discard(removed)
                        self.subscribed = desired
                        last_reconcile = now
                    if now - last_ping >= 15:
                        ws.send(json.dumps({'method': 'PING'})); last_ping = now
                    if time.time() - self.connect_ts > 23.5*3600: break
                    try:
                        msg = ws.recv()
                    except websocket.WebSocketTimeoutException:
                        if time.time()-(self.last_rx or self.connect_ts) > 60:
                            raise TimeoutError('Public feed silent >60s')
                        continue
                    if not msg: raise ConnectionError('Public WebSocket closed')
                    self.last_rx = time.time()
                    if isinstance(msg, bytes):
                        try:
                            x = decode_partial(msg)
                            if x and x['symbol'] in self.subscribed:
                                if self.cache.add(x):self.last_depth_rx=time.time()
                        except Exception as exc:
                            self.stats['decode_errors'] += 1
                            self.last_error = str(exc)
                            LOG.warning('Invalid public frame: %s', exc)
                    else:
                        try:
                            x = json.loads(msg)
                            if x.get('method') == 'PING': ws.send(json.dumps({'method': 'PONG'}))
                            if x.get('msg') == 'PONG': self.stats['pongs'] += 1
                            code = x.get('code')
                            if code not in (None, 0, '0'):
                                self.stats['subscription_errors'] += 1
                                self.last_error = str(x)[:500]
                                raise RuntimeError('Subscription rejected: ' + self.last_error)
                            else: self.stats['control_acks'] += 1
                        except json.JSONDecodeError:
                            self.stats['invalid_control'] += 1
                ws.close()
            except Exception as exc:
                self.last_error = f'{type(exc).__name__}: {exc}'
                self.stats['disconnects'] += 1
                LOG.warning('C public feed: %s', self.last_error)
            finally:
                with self.lock:
                    self.connected = False
                    self.subscribed.clear()
                    self.cache.clear()
                    self.ws = None
            self.stop.wait(backoff)
            backoff = min(60, backoff*2)

    def status(self):
        with self.lock:
            return {'connected': self.connected, 'channels': len(self.subscribed), 'desired': len(self.desired),
                    'last_frame_age_s': None if not self.last_depth_rx else max(0, time.time()-self.last_depth_rx),
                    'last_error': self.last_error, **dict(self.stats), **dict(self.cache.stats)}
