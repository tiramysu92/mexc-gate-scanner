from __future__ import annotations
import time
import uuid
from collections import Counter, deque
from .model import timing, horizon_exit

class Evidence:
    """Separate chronological episodes, not statistically independent iid samples."""
    def __init__(self, cfg, store, cache):
        self.cfg, self.store, self.cache = cfg, store, cache
        self.active = {}
        self.pending = {}
        self.stages = store.load_stages()
        self.counts = Counter()
        self.horizon_counts = {h: Counter() for h in cfg['horizons_ms']}
        self.delays = {h: deque(maxlen=1000) for h in cfg['horizons_ms']}
        self.slips = {h: deque(maxlen=1000) for h in cfg['horizons_ms']}
        self.remaining_edges = {h: deque(maxlen=1000) for h in cfg['horizons_ms']}
        self.last_sample = {}
        self.rearm_after = {}

    def stage(self, route, size):
        n = self.stages.get((route,float(size)),{}).get('clean',0)
        a,b,c = self.cfg['stage_episode_counts']
        i = 2 if n >= c else 1 if n >= b else 0 if n >= a else -1
        label = ['C_PROBE_SHADOW','C_VALIDATED_SHADOW','C_PROVEN_SHADOW'][i] if i >= 0 else 'C_DISCOVERY'
        return {'label':label,'clean_episodes':n,'live_authorized':False,
                'size_cap_su': self.cfg['stage_size_caps_su'][i] if i>=0 else 0,
                'required_edge_bps':self.cfg['stage_edges_bps'][i] if i>=0 else None}

    def observe(self, route, plans, r2, fee2, b2, mono, wall):
        eligible = [p for p in plans if p['testable'] and p['protected_cash_bps'] >= self.cfg['episode_entry_bps']]
        ep = self.active.get(route)
        # Silent feeds or rule/fee errors may censor evidence; they cannot create
        # a new successful episode by pretending the edge disappeared.
        observable = any(p.get('protected_cash_bps') is not None and not any(
            word in reason for reason in p['reasons'] for word in ('STALE','CLOCK','SKEW','FEES')) for p in plans)
        if eligible and ep is None and mono >= self.rearm_after.get(route,0):
            ep = {'episode_id':uuid.uuid4().hex, 'route':route,'start_ts':wall,'last_ts':wall,
                  'start_mono':mono,'last_observed_mono':mono,'below_since':None,
                  'status':'OPEN','sizes':{},'positive_observations':0}
            self.active[route] = ep
            self.counts['episodes_opened'] += 1
            self._save_episode(ep)
        if ep:
            if observable:
                ep['last_observed_mono'] = mono
                ep['last_ts'] = wall
            if eligible:
                ep['below_since'] = None
                ep['positive_observations'] += 1
                for p in eligible:
                    size = float(p['size'])
                    if size not in ep['sizes'] and b2 is not None:
                        tid = uuid.uuid4().hex
                        record = {'trial_id':tid,'episode_id':ep['episode_id'],'route':route,'size':size,
                                  'start_ts':wall,'done_ts':None,'clean':False,'status':'PENDING',
                                  'plan':p,'horizons':{}, 'live_authorized':False,
                                  'hypothesis':'L1_FILLED_AT_SIGNAL_NOT_EXECUTED'}
                        ep['sizes'][size] = record
                        self.pending[tid] = {'record':record,'rule':r2,'fee':fee2,'book':b2,'mono':mono}
                        self.store.emit('trial',record.copy())
                        self.counts['trials_started'] += 1
            elif observable:
                vals = [p['protected_cash_bps'] for p in plans if p.get('protected_cash_bps') is not None and p.get('testable')]
                if not vals or max(vals) <= self.cfg['episode_exit_bps']:
                    if ep['below_since'] is None: ep['below_since'] = mono
                    if mono-ep['below_since'] >= self.cfg['episode_separation_s']:
                        self.finish(route,'CLOSED_OBSERVED',wall,mono)
                else:
                    ep['below_since'] = None
        for p in plans:
            p['stage'] = self.stage(route,p['size'])
            if ep: p['episode_id'] = ep['episode_id']
            key = (route,p['size'])
            if mono-self.last_sample.get(key,-1e20) >= self.cfg['sample_interval_s']:
                # Persist all size outcomes when a modeled edge exists; failed
                # freshness/fee checks go to counters and latest view, not a DB flood.
                if p.get('protected_cash_bps') is not None or (p.get('raw_bps') is not None and p['raw_bps'] >= self.cfg['watch_raw_bps'] and p.get('c_reasons')):
                    self.store.emit('sample',{k:v for k,v in p.items() if k!='entry_books'})
                self.last_sample[key] = mono
        return plans

    def tick(self, wall, mono, clock):
        for tid, pending in list(self.pending.items()):
            tr, initial = pending['record'], pending['book']
            for h in self.cfg['horizons_ms']:
                if str(h) in tr['horizons']: continue
                due = pending['mono'] + h/1000
                if mono < due: continue
                b = self.cache.first_after(initial.symbol,due,initial.generation,initial.version,initial.exchange_ms)
                deadline = due+self.cfg['horizon_tolerance_ms']/1000
                if b is not None and b.recv_mono <= deadline:
                    # Evaluate the captured frame at ITS time, not an arbitrary
                    # later polling time. Record actual delay and coverage.
                    invalid = [r for r in timing(b,b.recv_ts,b.recv_mono,clock,self.cfg) if r!='EMPTY_BOOK']
                    if invalid:
                        result = {'status':'CENSORED','reason':','.join(invalid)}
                    elif not pending['fee'] or not pending['fee'].fresh(b.recv_ts,self.cfg['fee_max_age_s']):
                        result = {'status':'CENSORED','reason':'FEES_STALE_AT_HORIZON'}
                    else:
                        result = horizon_exit(tr['plan'],b,pending['rule'],pending['fee'],self.cfg)
                        result['status'] = 'OBSERVED'
                        result['pass'] = bool(result['liquidity_ok'] and result['protected_cash_bps'] is not None and result['protected_cash_bps'] > 0)
                    result['actual_delay_ms'] = (b.recv_mono-pending['mono'])*1000
                    result['scheduler_lag_ms'] = max(0,(mono-b.recv_mono)*1000)
                    result['frame_version'] = b.version
                    result['exchange_ms'] = b.exchange_ms
                    self.delays[h].append(result['actual_delay_ms'])
                elif mono >= deadline:
                    reason = 'DISCONNECTED_OR_ROTATED' if self.cache.generation!=initial.generation else 'NO_NEW_FRAME_IN_HORIZON_WINDOW'
                    result = {'status':'CENSORED','reason':reason,'actual_delay_ms':None}
                else:
                    continue
                tr['horizons'][str(h)] = result
                stats = self.horizon_counts[h]; stats['total'] += 1
                if result['status']=='OBSERVED':
                    stats['observed'] += 1
                    if result.get('l2_slippage_bps') is not None:self.slips[h].append(result['l2_slippage_bps'])
                    if result.get('protected_cash_bps') is not None:self.remaining_edges[h].append(result['protected_cash_bps'])
                    stats['liquidity_ok'] += int(result['liquidity_ok'])
                    stats['positive'] += int(result['pass'])
                    stats['negative_or_unfillable'] += int(not result['pass'])
                else: stats['censored'] += 1
            if len(tr['horizons']) == len(self.cfg['horizons_ms']):
                # Stage progression needs observed 250/500ms and no measured
                # negative horizon; missing 50/100 remain explicitly unknown.
                outcomes = tr['horizons']
                clean = all(outcomes[str(h)].get('pass') is True for h in (250,500)) and not any(
                    x['status']=='OBSERVED' and not x['pass'] for x in outcomes.values())
                tr.update(clean=clean,done_ts=wall,status='COMPLETE')
                self.store.emit('trial',tr.copy())
                self.pending.pop(tid,None)
                self.counts['trials_completed'] += 1
        for route,ep in list(self.active.items()):
            if mono-ep['last_observed_mono'] > self.cfg['episode_data_gap_s']:
                self.finish(route,'CENSORED_DATA_GAP',wall,mono)
            elif mono-ep['start_mono'] > self.cfg['episode_max_s']:
                self.finish(route,'CENSORED_MAX_DURATION',wall,mono)

    def finish(self, route, status, wall, mono):
        ep = self.active.pop(route,None)
        if not ep: return
        ep.update(status=status,end_ts=wall)
        clean_sizes = []
        for size,tr in ep['sizes'].items():
            if tr['status'] == 'PENDING':
                for h in self.cfg['horizons_ms']:
                    if str(h) not in tr['horizons']:
                        tr['horizons'][str(h)]={'status':'CENSORED','reason':status}
                tr.update(status='INTERRUPTED',done_ts=wall,clean=False)
                self.pending.pop(tr['trial_id'],None)
                self.store.emit('trial',tr.copy())
            counts = self.stages.setdefault((route,size),{'clean':0,'total':0})
            counts['total'] += 1
            if status=='CLOSED_OBSERVED' and tr['clean']:
                counts['clean'] += 1
                clean_sizes.append(size)
            self.store.emit('stage',{'route':route,'size':size,**counts})
        ep['clean_sizes'] = clean_sizes
        self._save_episode(ep)
        self.counts['episodes_closed_observed' if status=='CLOSED_OBSERVED' else 'episodes_censored'] += 1
        # A data gap is NOT evidence of independence; require a separate rearm delay.
        self.rearm_after[route] = mono + (0 if status=='CLOSED_OBSERVED' else self.cfg['episode_separation_s'])

    def _save_episode(self, ep):
        self.store.emit('episode',{k:v for k,v in ep.items() if k not in ('sizes','start_mono','last_observed_mono','below_since')})

    def status(self):
        horizons = {}
        for h,counts in self.horizon_counts.items():
            vals = sorted(self.delays[h])
            slip=sorted(self.slips[h]);edge=sorted(self.remaining_edges[h])
            horizons[str(h)] = {**dict(counts),
                'p95_actual_ms': vals[min(len(vals)-1,int(len(vals)*.95))] if vals else None,
                'p95_slippage_bps': slip[min(len(slip)-1,int(len(slip)*.95))] if slip else None,
                'worst_slippage_bps': max(slip) if slip else None,
                'p50_remaining_bps': edge[len(edge)//2] if edge else None}
        return {**dict(self.counts),'active_episodes':len(self.active),'pending_trials':len(self.pending),
                'horizons':horizons,'stages':[{'route':r,'size':s,**v,**self.stage(r,s)} for (r,s),v in self.stages.items()]}

    def close(self):
        for route in list(self.active):
            self.finish(route,'INTERRUPTED_SHUTDOWN',time.time(),time.monotonic())
