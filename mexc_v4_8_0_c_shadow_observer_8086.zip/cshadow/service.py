from __future__ import annotations
import copy
import logging
import threading
import time
import uuid
from collections import Counter
from dataclasses import asdict
from .model import evaluate, BPS
from .feed import BookCache, PublicDepthFeed
from .public import ReferenceData
from .episodes import Evidence
from .storage import Store

LOG = logging.getLogger(__name__)

class Service:
    def __init__(self,cfg):
        self.cfg=cfg
        self.run_id='C480-'+time.strftime('%Y%m%d-%H%M%S',time.gmtime())+'-'+uuid.uuid4().hex[:6]
        self.started_ts=time.time()
        self.stop=threading.Event()
        self.store=Store(cfg['data_dir'],cfg,self.run_id)
        self.cache=BookCache()
        self.feed=PublicDepthFeed(self.cache,self.stop)
        self.reference=ReferenceData(cfg,self.store,self.stop)
        self.evidence=Evidence(cfg,self.store,self.cache)
        self.lock=threading.RLock()
        self.latest={};self.decisions=Counter();self.watch={};self.last_seen={};self.last_check={}
        self.last_watch_rotation=0.0;self.last_tick=time.monotonic();self.last_error=None
        self.state='STARTING';self.public_view={};self.discovery=[];self.thread=None
        self.sequence=0

    def start(self):
        self.reference.start();self.feed.start()
        self.thread=threading.Thread(target=self.run,name='c-shadow-engine',daemon=True)
        self.thread.start()

    def discover(self,ref,mono):
        rules,fees,bbo,vol=ref['rules'],ref['fees'],ref['bbo'],ref['volumes']
        bases={r.base: {} for r in rules.values()}
        for r in rules.values():bases[r.base][r.quote]=r
        allroutes={};candidates=[]
        for token,pairs in bases.items():
            if set(pairs)!={'USDC','USDT'}:continue
            r1,r2=pairs['USDC'],pairs['USDT']
            allroutes[token]=(r1,r2)
            a,b=bbo.get(r1.symbol),bbo.get(r2.symbol)
            if not a or not b:continue
            raw1=float((b[0]/a[1]-1)*BPS);raw2=float((a[0]/b[1]-1)*BPS)
            f1,f2=fees.get(r1.symbol),fees.get(r2.symbol)
            known=bool(f1 and f2 and f1.fresh(time.time(),self.cfg['fee_max_age_s']) and f2.fresh(time.time(),self.cfg['fee_max_age_s']))
            fee_sum=float(f1.taker_bps+f2.taker_bps) if known else None
            gross=max(raw1,raw2)
            score=gross-(fee_sum if fee_sum is not None else 0)
            v1,v2=vol.get(r1.symbol),vol.get(r2.symbol)
            minvol=min(v1,v2) if v1 is not None and v2 is not None else None
            candidates.append({'token':token,'best_raw_bps':gross,'selection_score':score,
                               'account_fees_known':known,'fee_sum_bps':fee_sum,'min_volume_su':minvol,
                               'bbo_timestamp_known':False, 'source':'REST_HINT_NOT_EXECUTABILITY'})
        ranked=sorted(candidates,key=lambda x:x['selection_score'],reverse=True)
        self.discovery=ranked[:20]
        if mono-self.last_watch_rotation < self.cfg['rotation_s'] and self.watch:return allroutes
        self.last_watch_rotation=mono
        protected={r.split('>')[1] for r in self.evidence.active}
        retained={t:expiry for t,expiry in self.watch.items() if t in allroutes and (expiry>mono or t in protected)}
        cap=self.cfg['max_hot_tokens']
        hints=[x['token'] for x in ranked if x['best_raw_bps']>=self.cfg['watch_raw_bps']]
        pinned=[x for x in self.cfg['pinned_tokens'] if x in allroutes]
        # One exploration slot helps distinguish genuinely low volume from lack of
        # sampling. It is not a promise of continuous full-universe depth coverage.
        explore=sorted([x for x in ranked if x['token'] not in retained],
                       key=lambda x:(self.last_seen.get(x['token'],0),-(x['selection_score'])))
        order=pinned+hints[:max(0,cap-1)]+([explore[0]['token']] if explore else [])+hints
        for token in order:
            if len(retained)>=cap:break
            if token not in retained:
                retained[token]=mono+self.cfg['watch_hold_s'];self.last_seen[token]=mono
        self.watch=retained
        syms={'USDCUSDT'}
        for token in self.watch:
            syms.update(r.symbol for r in allroutes[token])
        self.feed.set_symbols(syms)
        return allroutes

    def run(self):
        last_view=0.0;last_metric=0.0
        try:
            while not self.stop.is_set():
                wall,mono=time.time(),time.monotonic();self.last_tick=mono
                ref=self.reference.snapshot()
                routes=self.discover(ref,mono)
                if self.store.failed:
                    self.state='PAUSED_STORAGE'
                    self.feed.set_symbols(set())
                elif mono-self.reference.heartbeat>30 and self.reference.heartbeat:
                    self.state='PAUSED_REFERENCE_WORKER'
                elif mono < self.reference.client.backoff_until:
                    self.state='PAUSED_PUBLIC_RATE_LIMIT'
                    self.feed.pause_until=self.reference.client.backoff_until
                else:
                    if not ref['rules']:self.state='WAITING_RULES'
                    elif not any(f.fresh(wall,self.cfg['fee_max_age_s']) for f in ref['fees'].values()):self.state='WAITING_ACCOUNT_FEES'
                    elif not ref['clock'] or not ref['clock'].valid(wall,self.cfg):self.state='WAITING_CLOCK'
                    elif not self.feed.connected:self.state='WAITING_PUBLIC_FEED'
                    elif not self.feed.last_depth_rx:self.state='WAITING_DEPTH'
                    else:self.state='SHADOW_COLLECTING'
                    for token in list(self.watch):
                        if token not in routes:continue
                        pair=routes[token]
                        for r1,r2 in (pair,pair[::-1]):
                            route=f'{r1.quote}>{token}>{r2.quote}'
                            b1,b2=self.cache.latest(r1.symbol),self.cache.latest(r2.symbol)
                            f1,f2=ref['fees'].get(r1.symbol),ref['fees'].get(r2.symbol)
                            key=(getattr(b1,'generation',None),getattr(b1,'version',None),getattr(b2,'version',None),
                                 getattr(f1,'fetched_ts',None),getattr(f2,'fetched_ts',None))
                            prev=self.last_check.get(route)
                            if prev and prev[0]==key and mono-prev[1]<1:continue
                            self.last_check[route]=(key,mono)
                            v1,v2=ref['volumes'].get(r1.symbol),ref['volumes'].get(r2.symbol)
                            volume=min(v1,v2) if v1 is not None and v2 is not None and wall-ref['volume_ts']<=3600 else None
                            plans=[]
                            for size in self.cfg['sizes_su']:
                                try:
                                    p=evaluate(r1,r2,b1,b2,f1,f2,size,volume,wall,mono,ref['clock'],self.cfg,ref['refs'])
                                except Exception as exc:
                                    self.last_error=f'MODEL_ERROR {route} {size}: {exc}'
                                    self.store.emit('model_error',{'error':self.last_error})
                                    self.decisions['MODEL_ERROR']+=1
                                    continue
                                self.decisions['size_evaluations']+=1
                                for reason in p['reasons']:self.decisions[reason]+=1
                                if p['testable']:self.decisions['C_BOOK_TESTABLE']+=1
                                if p['testable'] and p['protected_cash_bps']>=self.cfg['episode_entry_bps']:
                                    self.decisions['C_PROTECTED_EDGE_SIGNAL']+=1
                                plans.append(p)
                            self.evidence.observe(route,plans,r2,f2,b2,mono,wall)
                            for p in plans:self.latest[(route,p['size'])]=p
                self.evidence.tick(wall,mono,ref['clock'])
                if mono-last_view>=1:
                    self.make_view(ref,wall,mono);last_view=mono
                if mono-last_metric>=self.cfg['metrics_interval_s']:
                    self.store.emit('metrics',{'ts':wall,'state':self.state,'decisions':dict(self.decisions),
                                               'feed':self.feed.status(),'evidence':self.evidence.status()})
                    last_metric=mono
                self.stop.wait(.02)
        except Exception as exc:
            self.state='ENGINE_FAILED';self.last_error=f'{type(exc).__name__}: {exc}'
            LOG.exception('C shadow engine stopped')
            self.store.emit('fatal',{'error':self.last_error})
        finally:
            self.evidence.close()

    def make_view(self,ref,wall,mono):
        values=[]
        for p in self.latest.values():
            if wall-p['ts']>1200:continue
            x={k:v for k,v in p.items() if k!='entry_books'}
            x['age_s']=max(0,wall-p['ts'])
            x['stale']=x['age_s']>1
            if x['stale']:
                x['testable']=False
                x['reasons']=list(x['reasons'])+['DISPLAY_SIGNAL_STALE']
            x['stage']=self.evidence.stage(x['route'],x['size'])
            values.append(x)
        def score(p):
            v=p.get('protected_cash_bps')
            return (p.get('testable',False),v if v is not None else -1e12)
        values.sort(key=score,reverse=True)
        live=ref['live'];flow=live.get('flow_inventory') or {};base=flow.get('session_baseline') or {}
        balances=live.get('balances') or {}
        # Do not promote the legacy free-only delta to definitive PnL. Show it as
        # reported, suppress it during exposure, and surface missing external-flow reconciliation.
        settled=live.get('active_cycle') is None and live.get('state') in ('READY','SAFE_NOT_ARMED')
        liveview={'state':live.get('state'),'execution_enabled':live.get('execution_enabled'),
                  'arm_ok':live.get('arm_ok'),'active_cycle':live.get('active_cycle'),
                  'last_error':live.get('last_error'),'private_ws':{k:(live.get('private_ws') or {}).get(k) for k in ('connected','acks','errors','reconnects','last_event_age_s')},
                  'balances':balances,'inventory':flow.get('inventory'),
                  'baseline':{k:base.get(k) for k in ('session_id','ts','USDC','USDT','stable_units','strategy_dust_est_usd','stable_units_plus_dust')},
                  'reported_delta_su':flow.get('session_delta_stable_units') if settled else None,
                  'reported_delta_reconciled':False,'settled':settled,
                  'age_s':wall-ref['live_ts'] if ref['live_ts'] else None,
                  'fx':(live.get('maintenance') or {}).get('stable_fx')}
        freshfees=sum(f.fresh(wall,self.cfg['fee_max_age_s']) for f in ref['fees'].values())
        clock=ref['clock']
        ev=self.evidence.status()
        view={'version':'4.8.0-c-shadow.1','mode':'SHADOW_ONLY','orders_possible':False,
              'realized_c_pnl_su':0,'run_id':self.run_id,'started_ts':self.started_ts,'now':wall,
              'state':self.state,'last_error':self.last_error,'feed':self.feed.status(),
              'storage':{'healthy':not self.store.failed,'error':self.store.last_error,
                         'queue':self.store.queue.qsize(),'dropped':self.store.dropped,'written':self.store.written},
              'references':{'fee_fresh':freshfees,'fee_total':len(ref['fees']),
                            'rules':len(ref['rules']),'bbo_age_s':wall-ref['bbo_ts'] if ref['bbo_ts'] else None,
                            'clock':asdict(clock) if clock else None,'clock_ok':bool(clock and clock.valid(wall,self.cfg)),
                            'errors':ref['errors'],'last_error':ref['last_error']},
              'coverage':{'hot_tokens':list(self.watch),'hot_limit':self.cfg['max_hot_tokens'],
                          'depth_levels':20,'discovery_poll_s':self.cfg['discovery_poll_s']},
              'decisions':dict(self.decisions),'evidence':ev,'top10':values[:10],
              'latest_sizes':values[:150],'discovery':self.discovery,'live':liveview,
              'policy':{k:self.cfg[k] for k in ('sizes_su','episode_entry_bps','thin_buffer_bps',
                        'l1_cushion_bps','l2_cushion_bps','participation_fraction','episode_separation_s',
                        'horizon_tolerance_ms','stage_episode_counts','stage_edges_bps','stage_size_caps_su')}}
        with self.lock:
            self.sequence+=1;view['sequence']=self.sequence;self.public_view=view

    def snapshot(self):
        with self.lock:
            out=copy.deepcopy(self.public_view)
        if not out:
            out={'version':'4.8.0-c-shadow.1','state':self.state,'mode':'SHADOW_ONLY','orders_possible':False,'now':time.time()}
        out['heartbeat_age_s']=max(0,time.monotonic()-self.last_tick)
        if out['heartbeat_age_s']>3:out['state']='STALE_ENGINE_STATUS'
        out['served_ts']=time.time()
        try:out['recent_episodes']=self.store.recent('episodes',20)
        except Exception as exc:out['read_error']=str(exc)
        return out

    def close(self):
        self.stop.set();self.feed.close()
        if self.thread:self.thread.join(4)
        if self.reference.thread:self.reference.thread.join(5)
        self.store.close()
