"""Fictitious data for local UI tests only. NEVER used by real collection."""
import copy
import time

class DemoService:
    def __init__(self):
        self.sequence=0
    def snapshot(self):
        self.sequence+=1;now=time.time()
        rows=[]
        for token,raw,edge in [('DEMO_A',23.2,11.7),('DEMO_B',18.5,6.3),('DEMO_C',12.4,-1.2)]:
            for size in (2.5,5,10,15,20,25):
                edge_i=edge-size*.12
                rows.append({'route':f'USDC>{token}>USDT','token':token,'size':size,'raw_bps':raw,
                    'protected_cash_bps':edge_i,'net_mark_bps':edge_i+2.1,'dust_mark_su':.0003,
                    'cash_pnl_su':size*(edge_i+2)/10000,'spend_su':size-.01,
                    'l1_reserve_x':8.2,'l2_reserve_x':12.1,'fee1_bps':0.,'fee2_bps':5.,
                    'ts':now-.12,'age_s':.12,'testable':edge_i>2,'c_reasons':['C_VOLUME'],
                    'reasons':[] if edge_i>2 else ['C_L2_RESERVE'],'stage':{'label':'C_DISCOVERY','clean_episodes':2}})
        rows.sort(key=lambda x:x['protected_cash_bps'],reverse=True)
        return {'demo':True,'version':'4.8.0-c-shadow.1','mode':'SHADOW_ONLY','orders_possible':False,
            'run_id':'DEMO-DONNEES-FICTIVES','state':'SHADOW_COLLECTING','now':now,'heartbeat_age_s':.04,'sequence':self.sequence,
            'feed':{'connected':True,'channels':17,'depth_frames':32648,'last_frame_age_s':.11},
            'coverage':{'hot_tokens':['DEMO_A','DEMO_B','DEMO_C','DEMO_D'],'hot_limit':8,'discovery_poll_s':5},
            'references':{'fee_fresh':620,'fee_total':630,'rules':1200,'clock_ok':True,'clock':{'uncertainty_ms':4.2}},
            'storage':{'healthy':True,'queue':0,'dropped':0},
            'evidence':{'episodes_opened':12,'active_episodes':2,'episodes_closed_observed':7,'episodes_censored':3,
                'trials_completed':38,'pending_trials':2,'horizons':{str(h):{'total':38,'observed':n,'liquidity_ok':n-2,
                'positive':n-3,'negative_or_unfillable':3,'censored':38-n,'p95_actual_ms':h+17.1}
                    for h,n in [(50,11),(100,22),(250,30),(500,33)]},'stages':[]},
            'top10':rows[:10],'latest_sizes':rows,'decisions':{'STALE_LOCAL':108,'C_L2_RESERVE':63,'L1_MINIMUM_OR_MAXIMUM':41,'ACCOUNT_FEES_UNKNOWN_OR_STALE':9},
            'policy':{'participation_fraction':.25,'l1_cushion_bps':.5,'l2_cushion_bps':.5,'thin_buffer_bps':2.,'episode_entry_bps':2.},
            'recent_episodes':[{'start_ts':now-400,'route':'USDC>DEMO_A>USDT','status':'CLOSED_OBSERVED','end_ts':now-60,'clean_sizes':[2.5,5]}],
            'live':{'state':'READY','execution_enabled':True,'arm_ok':True,'active_cycle':None,'settled':True,'age_s':2,
                'balances':{'USDC':{'free':150},'USDT':{'free':150}},'inventory':{'zone':'CENTER','usdc_share':.5},
                'reported_delta_su':None,'fx':{'mid':1.0002},'private_ws':{'connected':True},'baseline':{'session_id':'DEMO_ONLY'}},
            'discovery':[]}
    def close(self):pass
