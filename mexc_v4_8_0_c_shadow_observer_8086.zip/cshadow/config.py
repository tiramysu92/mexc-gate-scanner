from __future__ import annotations
import json
import math
from pathlib import Path

DEFAULTS = {
    'live_runtime': '/home/ubuntu/mexc-spot-2leg-v4/runtime_v470/mexc_v4_7_0_2leg_flow_inventory_ws_8081',
    'live_status_url': 'http://127.0.0.1:8081/api/live/status',
    'bind': '0.0.0.0', 'port': 8086, 'data_dir': './data',
    'sizes_su': [2.5, 5, 10, 15, 20, 25], 'max_hot_tokens': 8,
    'discovery_poll_s': 5.0, 'watch_hold_s': 120.0, 'rotation_s': 30.0,
    'watch_raw_bps': 2.0, 'sample_interval_s': 2.0,
    'participation_fraction': 0.25, 'l1_cushion_bps': 0.50, 'l2_cushion_bps': 0.50,
    'thin_buffer_bps': 2.0, 'episode_entry_bps': 2.0, 'episode_exit_bps': 0.0,
    'episode_separation_s': 30.0, 'episode_data_gap_s': 10.0, 'episode_max_s': 1800.0,
    'horizons_ms': [50, 100, 250, 500], 'horizon_tolerance_ms': 25.0,
    'max_local_age_ms': 250.0, 'max_exchange_age_ms': 500.0,
    'max_local_skew_ms': 100.0, 'max_exchange_skew_ms': 150.0,
    'max_clock_uncertainty_ms': 50.0, 'clock_max_age_s': 180.0,
    'fee_max_age_s': 3600.0, 'rules_max_age_s': 3600.0,
    'ab_min_volume_su': 100000.0, 'ab_l1_reserve_x': 5.0, 'ab_l2_reserve_x': 10.0,
    'c_min_l1_reserve_x': 3.0, 'c_min_l2_reserve_x': 5.0,
    'reserve_price_band_bps': 25.0, 'max_dust_fraction': 0.005,
    'max_spread_bps': 300.0, 'max_raw_bps': 1000.0,
    'min_disk_free_mb': 1024, 'max_db_mb': 1024, 'retention_days': 7,
    'writer_queue_size': 4000, 'metrics_interval_s': 5.0,
    'stage_episode_counts': [3, 10, 25], 'stage_edges_bps': [10.0, 6.0, 4.0],
    'stage_size_caps_su': [5.0, 10.0, 25.0],
    'excluded_bases': ['USDT','USDC','USD1','DAI','USDE','FDUSD','TUSD','USDP','PYUSD','EUR','EURT'],
    'pinned_tokens': [],
}

def load_config(path: Path) -> dict:
    raw = json.loads(path.read_text(encoding='utf-8'))
    unknown = set(raw) - set(DEFAULTS)
    if unknown:
        raise ValueError('Unknown configuration keys: ' + ', '.join(sorted(unknown)))
    cfg = {**DEFAULTS, **raw}
    for k,v in cfg.items():
        if isinstance(DEFAULTS[k], (int,float)) and (not isinstance(v,(int,float)) or isinstance(v,bool) or not math.isfinite(v) or v<0):
            raise ValueError('Invalid finite nonnegative numeric setting: '+k)
    for key in ('data_dir', 'live_runtime'):
        p = Path(cfg[key]).expanduser()
        cfg[key] = str((path.parent / p).resolve() if not p.is_absolute() else p.resolve())
    data, live = Path(cfg['data_dir']), Path(cfg['live_runtime'])
    if data == live or live in data.parents:
        raise ValueError('C-SHADOW data_dir must be OUTSIDE the LIVE runtime')
    if cfg['port'] in (8081, 8082, 8085) or not 1024 <= cfg['port'] <= 65535:
        raise ValueError('Use a dedicated port; defaults to 8086, never 8081/8082/8085')
    if not 1 <= cfg['max_hot_tokens'] <= 12:
        raise ValueError('max_hot_tokens must be 1..12 (at most 25 public subscriptions)')
    if not .01 <= cfg['participation_fraction'] <= .5:
        raise ValueError('participation_fraction must be 0.01..0.5')
    if not cfg['sizes_su'] or len(cfg['sizes_su']) > 10 or any(not 0 < x <= 25 for x in cfg['sizes_su']):
        raise ValueError('sizes_su must contain 1..10 sizes in (0,25]')
    if cfg['horizons_ms'] != [50, 100, 250, 500]:
        raise ValueError('This build records 50/100/250/500 ms horizons')
    if cfg['discovery_poll_s'] < 3 or cfg['sample_interval_s'] < 1:
        raise ValueError('Polling/sampling configured too aggressively')
    if cfg['episode_exit_bps'] >= cfg['episode_entry_bps']:
        raise ValueError('Episode exit must be strictly below entry (hysteresis)')
    if not str(cfg['live_status_url']).startswith('http://127.0.0.1:8081/'):
        raise ValueError('LIVE observer is restricted to localhost port 8081')
    return cfg
