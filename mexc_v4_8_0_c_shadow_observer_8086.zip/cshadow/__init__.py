"""Independent, observation-only MEXC C-liquidity research service."""
VERSION = '4.8.0-c-shadow.1'
