from __future__ import annotations
from dataclasses import dataclass, asdict
from decimal import Decimal, InvalidOperation, ROUND_DOWN, ROUND_UP
import math
from typing import Any

D = Decimal
BPS = D(10000)
ZERO = D(0)

def dec(value: Any) -> Decimal:
    try:
        x = D(str(value))
    except (InvalidOperation, ValueError, TypeError) as e:
        raise ValueError('Invalid decimal') from e
    if not x.is_finite():
        raise ValueError('Non-finite decimal')
    return x

def floor_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError('Missing or invalid step')
    return (value / step).to_integral_value(rounding=ROUND_DOWN) * step

def ceil_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError('Missing or invalid tick')
    return (value / step).to_integral_value(rounding=ROUND_UP) * step

@dataclass(frozen=True)
class Rule:
    symbol: str
    base: str
    quote: str
    step: Decimal
    tick: Decimal
    min_qty: Decimal
    min_notional: Decimal
    max_notional: Decimal | None
    base_fee_tick: Decimal
    quote_fee_tick: Decimal
    side_type: str
    spot: bool
    online: bool
    percent_filters: tuple
    fetched_ts: float
    quantity_source: str

    @classmethod
    def from_exchange(cls, x: dict, now: float) -> 'Rule':
        filters = {f.get('filterType'): f for f in x.get('filters', [])}
        # MEXC fallback: baseSizePrecision is treated conservatively as the size increment
        # (legacy executor convention); a dedicated LOT_SIZE step overrides it.
        lot = filters.get('LOT_SIZE', {})
        step = dec(lot.get('stepSize', x.get('baseSizePrecision')))
        min_qty = dec(lot.get('minQty', x.get('baseSizePrecision')))
        pf = filters.get('PRICE_FILTER', {})
        precision = int(x['quotePrecision'])
        tick = dec(pf['tickSize']) if 'tickSize' in pf else D(1).scaleb(-precision)
        notional = filters.get('NOTIONAL', filters.get('MIN_NOTIONAL', {}))
        min_n = dec(notional.get('minNotional', x.get('quoteAmountPrecision')))
        mx = x.get('maxQuoteAmount')
        max_n = dec(mx) if mx is not None and dec(mx) > 0 else None
        if min(step, tick, min_qty, min_n) <= 0:
            raise ValueError('Symbol rules missing positive tick/step/minimum')
        base_fp = int(x.get('baseCommissionPrecision', x.get('baseAssetPrecision', 8)))
        quote_fp = int(x.get('quoteCommissionPrecision', precision))
        if not 0 <= base_fp <= 18 or not 0 <= quote_fp <= 18:
            raise ValueError('Invalid commission precision')
        return cls(str(x['symbol']), str(x['baseAsset']), str(x['quoteAsset']), step, tick,
                   min_qty, min_n, max_n, D(1).scaleb(-base_fp), D(1).scaleb(-quote_fp),
                   str(x.get('tradeSideType', 'UNKNOWN')), x.get('isSpotTradingAllowed') is True,
                   str(x.get('status')) == '1', tuple(x.get('filters', [])), now,
                   'LOT_SIZE' if lot else 'baseSizePrecision_legacy_convention')

    def permits(self, side: str) -> bool:
        return self.spot and self.online and self.side_type in ('1', '2' if side == 'BUY' else '3')

@dataclass(frozen=True)
class Fee:
    symbol: str
    taker_bps: Decimal
    fetched_ts: float
    source: str

    def fresh(self, now: float, max_age: float) -> bool:
        return (ZERO <= self.taker_bps < BPS and -2 <= now - self.fetched_ts <= max_age
                and self.source in ('MEXC_ACCOUNT_API', 'DIRECT_ACCOUNT_API'))

@dataclass(frozen=True)
class Book:
    symbol: str
    bids: tuple[tuple[Decimal, Decimal], ...]
    asks: tuple[tuple[Decimal, Decimal], ...]
    version: int
    exchange_ms: int
    recv_ts: float
    recv_mono: float
    generation: int = 0

    @classmethod
    def build(cls, symbol, bids, asks, version, exchange_ms, recv_ts, recv_mono, generation=0):
        def levels(data, reverse):
            parsed=tuple((dec(p),dec(q)) for p,q in data)
            if any(q<0 for _,q in parsed):raise ValueError('Negative displayed quantity')
            out=tuple(sorted(((p,q) for p,q in parsed if q>0),reverse=reverse))
            if len(out) > 20 or any(p <= 0 or q <= 0 for p, q in out):
                raise ValueError('Invalid partial depth')
            if len({p for p, _ in out}) != len(out):
                raise ValueError('Duplicate price level')
            return out
        bb, aa = levels(bids, True), levels(asks, False)
        if bb and aa and bb[0][0] >= aa[0][0]:
            raise ValueError('Crossed order book')
        return cls(symbol, bb, aa, int(version), int(exchange_ms), recv_ts, recv_mono, generation)

    def wire(self):
        return {'symbol': self.symbol, 'version': self.version, 'exchange_ms': self.exchange_ms,
                'recv_ts': self.recv_ts, 'generation': self.generation,
                'bids': [[str(p), str(q)] for p, q in self.bids],
                'asks': [[str(p), str(q)] for p, q in self.asks]}

@dataclass(frozen=True)
class Clock:
    offset_ms: float
    uncertainty_ms: float
    sampled_ts: float

    def valid(self, now: float, cfg: dict) -> bool:
        return (0 <= now - self.sampled_ts <= cfg['clock_max_age_s'] and
                self.uncertainty_ms <= cfg['max_clock_uncertainty_ms'])

def timing(book: Book | None, now: float, mono: float, clock: Clock | None, cfg: dict) -> list[str]:
    if book is None:
        return ['NO_DEPTH']
    reasons = []
    if not book.bids or not book.asks:
        reasons.append('EMPTY_BOOK')
    age = (mono - book.recv_mono) * 1000
    if not -1 <= age <= cfg['max_local_age_ms']:
        reasons.append('STALE_LOCAL')
    if not clock or not clock.valid(now, cfg):
        reasons.append('CLOCK_UNCERTAIN')
    elif book.exchange_ms <= 0:
        reasons.append('NO_EXCHANGE_TIME')
    else:
        age_ex = now * 1000 + clock.offset_ms - book.exchange_ms
        if age_ex < -clock.uncertainty_ms - 2 or age_ex + clock.uncertainty_ms > cfg['max_exchange_age_ms']:
            reasons.append('STALE_EXCHANGE')
    return reasons

def walk(levels, qty: Decimal, fraction: Decimal, limit=None, side='SELL'):
    """Return actual notional, filled base, terminal price. Never extrapolate missing depth."""
    rem, value, terminal = qty, ZERO, None
    for p, q in levels:
        if limit is not None and ((side == 'BUY' and p > limit) or (side == 'SELL' and p < limit)):
            break
        take = min(rem, q * fraction)
        if take > 0:
            rem -= take
            value += take * p
            terminal = p
        if rem <= 0:
            break
    return value, qty - rem, terminal

def buy_base(levels, budget: Decimal, fraction: Decimal):
    rem, qty = budget, ZERO
    for p, q in levels:
        cost = min(rem, p * q * fraction)
        qty += cost / p
        rem -= cost
        if rem <= 0:
            break
    return qty, rem

def price_filter_reasons(rule: Rule, side: str, price: Decimal, ref: dict | None, now: float):
    reasons = []
    for f in rule.percent_filters:
        typ = f.get('filterType')
        if typ in ('LOT_SIZE','MIN_NOTIONAL','NOTIONAL','PRICE_FILTER'):
            continue
        if typ == 'PERCENT_PRICE_BY_SIDE':
            if not ref or now - ref.get('ts', 0) > 10:
                reasons.append('PRICE_FILTER_REFERENCE_UNKNOWN')
                continue
            last = dec(ref['price'])
            if side == 'BUY' and price > last * (1 + dec(f['bidMultiplierUp'])):
                reasons.append('PRICE_FILTER_BUY')
            if side == 'SELL' and price < last * (1 - dec(f['askMultiplierDown'])):
                reasons.append('PRICE_FILTER_SELL')
        else:
            reasons.append('UNSUPPORTED_EXCHANGE_FILTER')
    return reasons

def evaluate(r1: Rule, r2: Rule, b1: Book | None, b2: Book | None,
             fee1: Fee | None, fee2: Fee | None, size, volume_min: float | None,
             now: float, mono: float, clock: Clock | None, cfg: dict,
             refs: dict | None = None) -> dict:
    """Conservative two-leg price-limit model. No order submission, no fill assertion."""
    refs = refs or {}
    route = f'{r1.quote}>{r1.base}>{r2.quote}'
    out = {'route': route, 'token': r1.base, 'size': float(size), 'ts': now,
           'symbol1': r1.symbol, 'symbol2': r2.symbol, 'stable_a': r1.quote, 'stable_b': r2.quote,
           'model': 'LIMIT_BOUND_L1_BASE_FEE_L2_QUOTE_FEE', 'reasons': [],
           'c_reasons': [], 'testable': False, 'live_authorized': False,
           'fee1_bps': None, 'fee2_bps': None, 'volume_min_su_24h': volume_min,
           'raw_bps': None, 'protected_cash_bps': None, 'net_mark_bps': None,
           'clock_at_signal':asdict(clock) if clock else None,
           'rule_steps':{'l1':str(r1.step),'l2':str(r2.step)},
           'rule_ticks':{'l1':str(r1.tick),'l2':str(r2.tick)},
           'minimum_notionals':{'l1':str(r1.min_notional),'l2':str(r2.min_notional)}}
    reasons = out['reasons']
    if r1.base != r2.base or {r1.quote, r2.quote} != {'USDC','USDT'}:
        reasons.append('UNSUPPORTED_ROUTE')
    if not r1.permits('BUY') or not r2.permits('SELL'):
        reasons.append('SYMBOL_TRADE_DISABLED')
    if now - min(r1.fetched_ts, r2.fetched_ts) > cfg['rules_max_age_s']:
        reasons.append('STALE_RULES')
    if not fee1 or not fee2 or not fee1.fresh(now, cfg['fee_max_age_s']) or not fee2.fresh(now, cfg['fee_max_age_s']):
        reasons.append('ACCOUNT_FEES_UNKNOWN_OR_STALE')
    else:
        out.update(fee1_bps=float(fee1.taker_bps), fee2_bps=float(fee2.taker_bps),
                   fee1_ts=fee1.fetched_ts, fee2_ts=fee2.fetched_ts,
                   fee1_source=fee1.source,fee2_source=fee2.source)
    reasons.extend('L1_' + x for x in timing(b1, now, mono, clock, cfg))
    reasons.extend('L2_' + x for x in timing(b2, now, mono, clock, cfg))
    if b1 and b2:
        if abs(b1.recv_mono - b2.recv_mono) * 1000 > cfg['max_local_skew_ms']:
            reasons.append('LOCAL_SKEW')
        if abs(b1.exchange_ms - b2.exchange_ms) > cfg['max_exchange_skew_ms']:
            reasons.append('EXCHANGE_SKEW')
        if b1.asks and b2.bids:
            out['raw_bps'] = float((b2.bids[0][0] / b1.asks[0][0] - 1) * BPS)
        out.update(local_age1_ms=max(0, (mono-b1.recv_mono)*1000),
                   local_age2_ms=max(0, (mono-b2.recv_mono)*1000))
    if volume_min is not None and volume_min < cfg['ab_min_volume_su']:
        out['c_reasons'].append('C_VOLUME')
    if b1 and b1.symbol != r1.symbol or b2 and b2.symbol != r2.symbol:
        reasons.append('BOOK_SYMBOL_MISMATCH')
    if fee1 and fee1.symbol != r1.symbol or fee2 and fee2.symbol != r2.symbol:
        reasons.append('FEE_SYMBOL_MISMATCH')
    if reasons:
        return out
    assert b1 is not None and b2 is not None and fee1 and fee2
    if abs(out['raw_bps']) > cfg['max_raw_bps']:
        reasons.append('OUTLIER_CROSS')
        return out
    for b in (b1, b2):
        spread = float((b.asks[0][0] - b.bids[0][0]) / b.bids[0][0] * BPS)
        if spread > cfg['max_spread_bps']:
            reasons.append('SPREAD_TOO_WIDE')
    budget, part = dec(size), dec(cfg['participation_fraction'])
    qraw, remaining = buy_base(b1.asks, budget, part)
    if remaining > budget * D('0.000001'):
        reasons.append('L1_INSUFFICIENT_TOP20'); return out
    q1 = floor_step(qraw, r1.step)
    # The full budget is a cap, not automatically an amount spent.
    for _ in range(5):
        cost, filled, terminal = walk(b1.asks, q1, part, side='BUY')
        if not terminal or filled < q1 or q1 <= 0:
            reasons.append('L1_INSUFFICIENT_TOP20'); return out
        limit1 = ceil_step(terminal * (1 + dec(cfg['l1_cushion_bps'])/BPS), r1.tick)
        capped = floor_step(min(q1, budget / limit1), r1.step)
        if capped == q1: break
        q1 = capped
    spend = q1 * limit1
    if q1 < r1.min_qty or spend < r1.min_notional or (r1.max_notional and spend > r1.max_notional):
        reasons.append('L1_MINIMUM_OR_MAXIMUM'); return out
    base_fee = ceil_step(q1 * fee1.taker_bps / BPS, r1.base_fee_tick) if fee1.taker_bps else ZERO
    net_base = q1 - base_fee
    q2 = floor_step(max(ZERO, net_base), r2.step)
    dust = net_base - q2
    value2, filled2, terminal2 = walk(b2.bids, q2, part)
    if not terminal2 or q2 <= 0 or filled2 < q2:
        reasons.append('L2_INSUFFICIENT_TOP20'); return out
    limit2 = floor_step(terminal2 * (1 - dec(cfg['l2_cushion_bps']) / BPS), r2.tick)
    proceeds = q2 * limit2
    if q2 < r2.min_qty or proceeds < r2.min_notional or (r2.max_notional and proceeds > r2.max_notional):
        reasons.append('L2_MINIMUM_OR_MAXIMUM'); return out
    qfee = ceil_step(proceeds * fee2.taker_bps / BPS, r2.quote_fee_tick) if fee2.taker_bps else ZERO
    proceeds -= qfee
    dust_mark = max(ZERO, dust) * min(b1.bids[0][0], b2.bids[0][0])
    net_cash = (proceeds / spend - 1) * BPS
    net_mark = ((proceeds + dust_mark) / spend - 1) * BPS
    # Reserve is measured near the price, never using all distant levels as reassurance.
    band = dec(cfg['reserve_price_band_bps']) / BPS
    l1_quote = sum(p*q for p,q in b1.asks if p <= b1.asks[0][0]*(1+band))
    l2_base = sum(q for p,q in b2.bids if p >= b2.bids[0][0]*(1-band))
    rx1, rx2 = float(l1_quote/spend), float(l2_base/q2)
    if rx1 < cfg['ab_l1_reserve_x'] or rx2 < cfg['ab_l2_reserve_x']:
        out['c_reasons'].append('C_DEPTH')
    if volume_min is None:
        reasons.append('VOLUME_CLASS_UNKNOWN')
    if rx1 < cfg['c_min_l1_reserve_x']:
        reasons.append('C_L1_RESERVE')
    if rx2 < cfg['c_min_l2_reserve_x']:
        reasons.append('C_L2_RESERVE')
    if dust_mark / spend > dec(cfg['max_dust_fraction']):
        reasons.append('DUST_TOO_LARGE')
    reasons.extend(price_filter_reasons(r1, 'BUY', limit1, refs.get(r1.symbol), now))
    reasons.extend(price_filter_reasons(r2, 'SELL', limit2, refs.get(r2.symbol), now))
    if not out['c_reasons']:
        reasons.append('AB_NOT_C')
    protected = net_cash - dec(cfg['thin_buffer_bps'])
    out.update(q1=str(q1), q2=str(q2), l1_limit=str(limit1), l2_limit=str(limit2),
               spend_su=float(spend), unspent_su=float(budget-spend), proceeds_su=float(proceeds),
               dust_qty=str(dust), dust_mark_su=float(dust_mark), cash_pnl_su=float(proceeds-spend),
               net_cash_bps=float(net_cash), net_mark_bps=float(net_mark),
               protected_cash_bps=float(protected), l1_reserve_x=rx1, l2_reserve_x=rx2,
               thin_buffer_bps=cfg['thin_buffer_bps'],
               l1_cushion_bps=cfg['l1_cushion_bps'], l2_cushion_bps=cfg['l2_cushion_bps'],
               fee_base_units=str(base_fee), fee_quote_units=str(qfee),
               entry_books=[b1.wire(), b2.wire()])
    out['testable'] = not reasons
    return out

def horizon_exit(plan: dict, book: Book, rule: Rule, fee: Fee, cfg: dict) -> dict:
    """L2 shadow exit for a FIXED hypothetical L1 quantity; no profitable resizing."""
    qty, part, spend = dec(plan['q2']), dec(cfg['participation_fraction']), dec(plan['spend_su'])
    value, filled, terminal = walk(book.bids, qty, part)
    cover = float(filled/qty) if qty > 0 else 0.0
    out = {'coverage': cover, 'liquidity_ok': filled >= qty and terminal is not None,
           'protected_cash_bps': None, 'l2_slippage_bps': None,
           'limit_still_coverable': False, 'dust_qty': plan['dust_qty']}
    if terminal is None or filled < qty:
        return out
    limit = floor_step(terminal*(1-dec(cfg['l2_cushion_bps'])/BPS), rule.tick)
    gross = qty*limit
    fee_q = ceil_step(gross*fee.taker_bps/BPS, rule.quote_fee_tick) if fee.taker_bps else ZERO
    protected = ((gross-fee_q)/spend - 1)*BPS-dec(cfg['thin_buffer_bps'])
    _, filled_limit, _ = walk(book.bids, qty, part, limit=dec(plan['l2_limit']))
    out.update(liquidity_ok=gross>=rule.min_notional, protected_cash_bps=float(protected),
               l2_slippage_bps=float((dec(plan['l2_limit'])-limit)/dec(plan['l2_limit'])*BPS),
               limit_still_coverable=filled_limit>=qty, limit_price=str(limit),
               cash_pnl_su=float(gross-fee_q-spend), exit_book=book.wire())
    return out
