# Sources techniques contrôlées pour cette version

Vérifiées le 19 septembre 2026. Les paramètres exploratoires C ne sont pas des recommandations de MEXC.

- Flux publics et plafond de 30 abonnements par connexion : https://www.mexc.com/api-docs/spot-v3/websocket-market-streams
- Carnets partiels 5/10/20 niveaux et canal `spot@public.limit.depth.v3.api.pb@<symbol>@20` : https://www.mexc.com/api-docs/spot-v3/websocket-market-streams/partial-book-depth-streams
- Règles de trading, quoteAmountPrecision, baseSizePrecision, tradeSideType, filtres de prix : https://www.mexc.com/api-docs/spot-v3/market-data-endpoints/exchange-information
- BBO public, sans horodatage d'exchange dans la réponse REST : https://www.mexc.com/api-docs/spot-v3/market-data-endpoints/symbol-order-book-ticker
- Définition officielle du message enveloppe : https://github.com/mexcdevelop/websocket-proto/blob/main/PushDataV3ApiWrapper.proto
  - SHA lu : `bd77f48b6ed95efa15f755613323f64f06970e55`
  - Corps `publicLimitDepths` : champ 303 ; symbole 3 ; sendTime 6.
- Définition officielle de la profondeur partielle : https://github.com/mexcdevelop/websocket-proto/blob/main/PublicLimitDepthsV3Api.proto
  - SHA lu : `5a31293f1d5ad998e98f2f68271538015d80ef29`
  - asks 1 ; bids 2 ; version 4 ; item price 1 / quantity 2.

Le lecteur protobuf est une implémentation minimale indépendante, limitée au flux public ci-dessus. Il refuse les messages incohérents et n'interprète aucun flux privé. Les frames de tests sont synthétiques, encodées d'après ces champs.

# Sources locales de compatibilité

- Dépôt utilisateur `tiramysu92/mexc-gate-scanner`, branche `mexc-spot-2leg-v4`, arborescence lue : `55d50606ad5bd83583b9106f3bd15bf9bd66be1a`.
- Schéma `account_fees(symbol,taker_bps,fetched_ts,source)` du runtime V4.6/V4.7 et structure `flow_inventory` du statut V4.7 fournis dans les échanges et les artefacts.
- Le programme ne charge aucun module Python du LIVE et n'importe pas le fichier `app.py` de la racine GitHub (qui n'est pas le runtime V4.7).
- Frais obtenus de la table du LIVE alimentée par tradeFee, avec source compte reconnue et âge maximal. Aucune lecture de v240.env. Aucun appel signé par C.

# Limites de la vérification

Les tests de cette livraison sont hors ligne / locaux. La réception WebSocket réelle depuis le serveur AWS de l'utilisateur n'a pas été testée ici. Les premières minutes sur le serveur doivent confirmer : règles chargées, frais frais, horloge validée, trames profondeur décodées, absence d'erreurs, mesures aux horizons effectivement observées.
