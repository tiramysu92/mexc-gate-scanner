# MEXC 4.8.0 — C-SHADOW + interface 8086

## Ce que cette livraison fait, et ne fait pas

Elle étudie les routes spot `USDC → token → USDT` et `USDT → token → USDC` moins liquides, sans envoyer d'ordre. Elle possède son propre processus, son propre environnement Python et sa propre base SQLite. Elle ne modifie pas le moteur A/B V4.7, les seuils d'entrée A/B, FORCE-L2, les clés API, le baseline du compte ou les bags existants.

Le LIVE 8081 et l'interface précédente 8085 restent en place. La nouvelle interface C est sur 8086.

**Il n'existe aucun mode LIVE C dans cette livraison.** Les étapes PROBE / VALIDATED / PROVEN portent toutes le suffixe SHADOW. Elles ne donnent jamais le droit de trader.

## Installation sur le serveur

Décompresser le ZIP dans un nouveau dossier `/home/ubuntu/mexc-c-shadow-v480`, hors de tous les runtimes LIVE. Puis :

```bash
cd /home/ubuntu/mexc-c-shadow-v480
bash ./install.sh
bash ./start.sh
```

L'installation crée un venv dédié et installe seulement websocket-client 1.9.0. Les tests utilisent unittest, sans pytest ni modification du venv V4.7. Le précontrôle vérifie la présence du fichier config du LIVE et l'accès en lecture seule à sa table de frais. Il ne contacte aucune API d'ordre et ne démarre rien avant `start.sh`.

`python3 -m venv` doit être disponible sur Ubuntu. Ne pas installer de dépendances dans l'environnement du scanner pour dépanner C.

Lancement détaché : on peut fermer la console KVM/SSH. Le script de départ ne dépend pas des variables exportées dans la console et retire les variables d'environnement MEXC héritées du processus enfant.

```bash
bash ./status.sh
curl -fsS --max-time 5 http://127.0.0.1:8086/api/health
```

URL extérieure : `http://<IP-publique-AWS>:8086/`. Autoriser TCP 8086 **uniquement depuis votre IP / VPN** dans le Security Group. Cette interface contient des données financières du LIVE, n'a pas d'authentification ni de TLS intégré : ne pas la publier à tout Internet. HTTPS peut être apporté par un reverse proxy existant sans changer le LIVE.

Pour arrêter uniquement C : `bash ./stop.sh`. Ne jamais utiliser `pkill python`, un PID 8081 ou un `rm` visant un runtime LIVE.

L'installation échoue proprement sur un port occupé ; elle ne tue pas son propriétaire.

## Démarrage automatique après un vrai reboot (facultatif)

Après validation du mode manuel : arrêter C avec `./stop.sh`, puis `./install_systemd.sh`. Ce modèle est volontairement restreint au dossier de déploiement indiqué et au data_dir par défaut `./data`. Il ne crée qu'un service `mexc-c-shadow-v480` avec plafond CPU 50 %, mémoire 512 Mo, LIVE en lecture seule et dossier de credentials inaccessible. Les limites peuvent accroître les non-observations : le tableau des délais doit le montrer.

Sous systemd, utiliser `sudo systemctl stop mexc-c-shadow-v480` pour arrêter C. Un redémarrage de KVM n'est pas un reboot de la machine.

## Collecte : budget limité et couverture déclarée

- Découverte par BBO public global toutes les 5 secondes ; cela fournit un indice, pas une preuve d'exécutabilité. Ces BBO REST ne sont pas synchronisés et les signaux plus courts peuvent être ratés.
- Au plus 8 tokens chauds, les deux paires de chaque token + un flux FX de référence : 17 abonnements publics au maximum par défaut.
- Rotation au plus toutes les 30 s ; maintien cible d'un token 120 s et protection d'un épisode en cours. Un emplacement exploratoire aide à ne pas regarder uniquement les plus gros BBO.
- Carnets partiels 20 niveaux via WebSocket public. On n'extrapole jamais au-delà des niveaux reçus. Un manque de profondeur peut venir d'un carnet réellement insuffisant OU de la limite de 20 niveaux.
- Les nouvelles connexions/générations invalident les anciennes preuves temporelles. Un ancien numéro de version ne rafraîchit jamais le carnet.
- Un 403 / 418 / 429 déclenche un backoff public. La charge reste limitée, mais C partage le CPU, le disque et l'IP avec A/B : ce n'est pas « zéro impact ».
- L'historique de frais compte est lu toutes les 30 s dans la DB V4.7 avec `mode=ro` et `query_only=ON`. Des frais absents/périmés ne sont jamais remplacés par zéro ou par un forfait présenté comme connu.
- Aucun import de code LIVE, aucune lecture des credentials, aucun appel à tradeFee signé : le scanner existant reste propriétaire de ses frais compte.

## Qualification C (observation uniquement)

Une route est dans l'environnement C si la plus faible liquidité quotidienne des deux paires est sous 100 000 SU, ou si les réserves de carnet dans la bande de prix de 25 bp sont sous les critères A/B 5× / 10×. Ce classement C doit ensuite passer ses propres contrôles :

- réserve C minimale L1 3× / L2 5× dans cette bande, pas en additionnant des niveaux de prix lointains ;
- participation limitée à 25 % du volume affiché par niveau ;
- tailles évaluées séparément : **2,50 / 5 / 10 / 15 / 20 / 25 SU** ;
- minimum d'ordre, minimum de quantité, précision, arrondis et permissions de sens des deux symboles ;
- filtrage d'écarts extrêmes et de spreads anormaux ;
- ancienneté locale, ancienneté exchange, skew, incertitude d'horloge, règles et frais frais.

`baseSizePrecision` sert de pas conservateur en l'absence d'un filtre LOT_SIZE, conformément à la convention du moteur historique. La documentation MEXC le décrit comme minimum de quantité : **la compatibilité exacte des increments/filters devra encore être confirmée avant du LIVE C**. Les filtres d'exchange non reconnus bloquent la preuve plutôt que d'être ignorés.

### Modèle économique

1. Budget = plafond de L1, pas dépense automatique.
2. Quantité brute arrondie au pas L1 ; BUY limit avec cushion 0,50 bp, arrondi supérieur au tick et contrôle du budget.
3. Frais L1 modélisés en base, arrondis conservativement à la précision de commission.
4. Quantité L2 = base nette arrondie au pas L2 ; SELL limit avec cushion 0,50 bp, arrondi inférieur.
5. Frais L2 modélisés en quote, arrondis conservativement.
6. `cash net` = quote nette L2 moins dépense L1.
7. `cash protégé bps` = edge cash net moins réserve C supplémentaire de 2 bp. Les cushions L1/L2 étant déjà dans les prix limites, ils ne sont pas retirés une deuxième fois.
8. Dust marqué séparément, au plus bas des bids des deux jambes. Un ratio de dust excessif bloque le statut testable.

Le dust n'est pas jeté dans la comptabilité : il apparaît dans `net + dust`. Il ne finance cependant pas une fausse marge cash, ni un rebalance. Les monnaies de commission sont des hypothèses conservatrices documentées, pas des commissions déjà exécutées.

**Cash protégé n'est pas une garantie de fill ni de bénéfice.** Les ordres ne sont pas atomiques ; un carnet peut disparaître après L1. Plus de cent cycles passés sur A/B ne valident pas automatiquement le risque C.

### Épisodes et essais

Début : au moins une taille C testable avec cash protégé ≥2 bp. Un seul essai initial par taille dans cet épisode. Le groupe se ferme après un retour observé ≤0 bp pendant au moins 30 s. Un trou de données de plus de 10 s, une rotation ou une interruption censurent les preuves ; ils ne les rendent pas « réussies ».

Un épisode regroupe des observations corrélées ; des épisodes séparés ne sont pas nécessairement indépendants statistiquement. Un délai minimum est une méthode de regroupement, pas une certification de confiance.

Le premier plan fige la quantité hypothétique. Les sorties L2 sont testées à 50/100/250/500 ms sur la **première nouvelle trame** reçue dans la fenêtre `[horizon, horizon+25ms]`. Sans trame appropriée : CENSORED / NON OBSERVÉ, jamais succès. La cadence du flux partiel n'étant pas garantie à 50 ms, ce compteur peut rester peu documenté. L'interface expose les délais réels.

Chaque horizon conserve séparément quantité couvrable, sortie positive après buffers, slippage, prix, numéro de version, temps exchange et carnet. L1 est supposée remplie au signal ; le modèle ne prouve pas le fill L1.

Pour la progression exploratoire, il faut un épisode **clos observé**, des mesures positives observées à 250 ET 500 ms et aucune mesure négative sur les autres horizons. Les 50/100 ms manquantes restent visibles. Paramètres exploratoires :

| Étape | Épisodes propres clos | Taille indicative max | Edge protégé indicatif |
|---|---:|---:|---:|
| C_DISCOVERY | <3 | aucun LIVE | étude dès 2 bp |
| C_PROBE_SHADOW | 3–9 | 5 SU | 10 bp |
| C_VALIDATED_SHADOW | 10–24 | 10 SU | 6 bp |
| C_PROVEN_SHADOW | ≥25 | 25 SU | 4 bp |

**Ces paliers sont affichés pour la recherche. Aucun changement vers LIVE n'est implémenté.** Ils ne remplacent pas un test réel limité, une étude des pertes de queue, des limites d'exposition et un arrêt d'urgence validés.

## Nouvelle interface : pas de faux PnL

- Top 10 route × taille avec BBO brut, cash protégé, net + dust, frais et réserves.
- Comparateur des six tailles pour la même route, y compris les rejets.
- Survival : nombre dû, nombre observé, couverture, positivity, mesures négatives, mesures non observées, délai réel, slippage et edge restant.
- Étapes C persistantes, épisodes clos/censurés et motifs de blocage.
- Fenêtre A/B LIVE en lecture seulement : état, balances, zone, delta rapporté avec son statut d'estimation et sa session T0. Pas de réinitialisation de compte.
- **PnL C réalisé = 0 et ordres C possibles = faux.** On ne somme pas les opportunités pour les déguiser en argent gagné.
- Pas de tiret silencieusement converti en succès. Frais absents, données périmées et mesures non observées restent visibles.

L'interface reçoit un snapshot mémoire mis en cache ; ses rafraîchissements ne relancent pas les GET publics. Les réponses sont `Cache-Control: no-store`. Les lignes dynamiques sont échappées pour éviter l'injection HTML par un nom de token.

## Persistence, export et limites disque

Fichier indépendant : `data/c_shadow.sqlite`, avec tables `c_episodes`, `c_size_trials`, `c_size_samples`, `c_stage_counts`, snapshots de règles/frais, métriques et événements.

Les six tailles ne se remplacent pas entre elles. Un redémarrage conserve les compteurs C, censure les épisodes ouverts et ne touche jamais `survival_aggregates` A/B. Une modification des règles de mesure demande un **nouveau data_dir** : pas de mélange de preuves sous des politiques différentes.

Garde-fous : queue bornée, logs tournants, pause de collecte si queue perdue, base C >1 Go ou espace libre <1 Go. Les mesures et événements anciens sont nettoyés progressivement après 7 jours dans la base C seulement ; les épisodes/trials/compteurs sont conservés. Une pause capacité doit donc être traitée par export/archivage, pas en supprimant la base LIVE.

- Interface : CSV des 5 000 dernières mesures, lecture seule.
- Export complet de C : `bash ./export.sh`. Backup cohérent + quick_check + gzip, écrit sous `exports/`, jamais dans le runtime LIVE.

## Vérifications et limites avant de tirer une conclusion

Tests hors ligne fournis. Le flux MEXC réel n'a pas été contacté depuis l'environnement de construction. Les premières observations AWS doivent valider les champs et délais. Les résultats financiers ne sont pas prédits.

Le système pourra montrer qu'il n'existe aucun C réellement testable dans les limites définies. Cette réponse est utile ; abaisser automatiquement les contrôles pour obtenir davantage de lignes serait trompeur.

Avant un futur C LIVE : audit du moteur existant et de la comptabilité, exactitude des frais/filters, mapping complet des rejets, minNotional et arrondis réels, mesure L1→L2, book depletion, inventaire et limite de perte. Les faux positifs, la collecte incomplète et la faible taille d'échantillon doivent être inclus dans la décision.
