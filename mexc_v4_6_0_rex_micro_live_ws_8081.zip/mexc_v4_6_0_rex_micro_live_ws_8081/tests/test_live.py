import sqlite3,time
from pathlib import Path
from v4rex.db import DB
from v4rex.live import floor_step,ceil_price,floor_price,fee_bps_from_response,worst_bid_for_base
from v4rex.core import L

def test_rounding_helpers():
    assert floor_step(1.234567,'0.001')==1.234
    assert ceil_price(12.341,2)==12.35
    assert floor_price(12.349,2)==12.34

def test_fee_floor():
    assert fee_bps_from_response({'data':{'takerCommission':0.0003}},5)==5
    assert fee_bps_from_response({'data':{'takerCommission':0.0008}},5)==8

def test_worst_bid_for_base():
    levels=[L(10,1),L(9,2)]
    assert worst_bid_for_base(levels,0.25,1.0)==10
    assert worst_bid_for_base(levels,1.5,1.0)==9
    assert worst_bid_for_base(levels,4,1.0) is None

def test_live_journal_and_dust(tmp_path):
    db=DB(str(tmp_path/'x.db'))
    cycle={'cycle_id':'c1','started_ts':time.time(),'route':'USDC>BTC>USDT','token':'BTC','stable_a':'USDC','stable_b':'USDT','liquidity_class':'A','requested_size':10,'expected_net_bps':1.5,'state':'CLOSED','l1_quote_spent':10,'l2_quote_net':10.01,'realized_pnl_nominal':0.01,'realized_pnl_bps':10,'dust_qty':1e-7,'dust_est_usd':0.007}
    db.upsert_live_cycle(cycle);db.add_live_dust('BTC',1e-7,.007,'c1');db.add_live_event('c1','CYCLE_CLOSED',{'pnl':.01})
    assert db.live_pnl_summary()['closed_cycles']==1
    assert abs(db.live_pnl_summary()['realized_pnl_nominal']-.01)<1e-9
    assert db.live_dust_summary()['events']==1
    assert db.live_cycles(1)[0]['cycle_id']=='c1'
    assert db.live_events(1)[0]['kind']=='CYCLE_CLOSED'

def test_survival_bootstrap_only_when_empty(tmp_path):
    src=DB(str(tmp_path/'old.db'))
    row={'route':'USDC>BTC>USDT','size':10,'trials':123,'last_ts':time.time()}
    for h in (50,100,150,250,500):row.update({f'l2_ok_{h}':123,f'return_ok_{h}':100,f'l2_slip_sum_{h}':1.0,f'l2_slip_max_{h}':.1,f'return_loss_sum_{h}':2.0,f'return_loss_max_{h}':.2})
    src.upsert_survival_aggregates([row])
    dst=DB(str(tmp_path/'new.db'));r=dst.bootstrap_survival_from(str(tmp_path/'old.db'))
    assert r['copied']==1 and dst.survival_stat('USDC>BTC>USDT',10)['trials']==123
    r2=dst.bootstrap_survival_from(str(tmp_path/'old.db'));assert r2['reason']=='DEST_NOT_EMPTY'
