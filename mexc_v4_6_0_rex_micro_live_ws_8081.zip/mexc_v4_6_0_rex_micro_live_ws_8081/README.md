# V4.6.0-REX MICRO-LIVE

V4.6 est la première couche d'exécution réelle construite au-dessus de la qualification L2-first de V4.5.1. Elle est livrée **désarmée** : `execution_enabled=false` et aucun ordre réel n'est envoyé tant que le second verrou `MEXC_LIVE_ARM=V460_LIVE_10USD` n'est pas présent.

## Philosophie REX

Avant L1 : edge + liquidité + profondeur + survivabilité L2 doivent être satisfaits. Après un fill L1, l'objectif change : `EXPOSURE_ACTIVE` et la priorité devient la finalisation de L2. Le seuil d'edge d'entrée n'est jamais réappliqué à une exposition déjà ouverte.

Le live initial est volontairement limité à USDC/USDT et 10 USD par cycle. USD1 reste scanné/qualifié en Shadow mais n'est pas autorisé par `live_allowed_stablecoins`.

## Dust / bags protégés

La quantité réellement achetée est suivie au niveau du cycle. La quantité L2 est arrondie vers le bas selon `baseSizePrecision` et une réserve de fee. Le reliquat devient `DUST` dans le ledger. Une poussière normale (par défaut <= 0,25 USD par cycle) n'empêche pas le trade suivant. Au-dessus, le résidu n'est plus considéré comme de la poussière mais comme une exposition anormale et les nouvelles entrées sont désactivées.

Le bot ne vend jamais un solde global du token : il vend uniquement l'inventaire stratégie acquis par le cycle, ce qui protège un bag préexistant. La conversion MEXC de poussière vers MX n'est pas utilisée automatiquement.

## Robustesse reprise de V4.5.1

Sur une DB V4.6 vide, `bootstrap_survival_db` copie une seule fois les **agrégats** de survivabilité depuis V4.5.1. Les centaines de Mo de trials bruts restent archivés dans V4.5.1. Le gate MICRO-LIVE impose ensuite au minimum `live_min_survival_trials=1000` sur la route × taille exacte.

## Préflight sans ordre

```bash
source .venv/bin/activate
python preflight_live.py
```

Le script réutilise les variables MEXC déjà présentes dans l'environnement ou les `.env` historiques du projet, sans afficher la clé ni le secret. Il vérifie l'heure serveur, `GET /account`, les balances et `GET /tradeFee`. Il n'appelle ni `/order` ni `/order/test`.

## Démarrage SAFE

```bash
./start.sh
sleep 120
./smoke_check.sh
```

Avec le fichier fourni, le moteur est en `MICRO_LIVE` mais **SAFE_NOT_ARMED** : collecte, qualification, API account et Private WS peuvent fonctionner, sans ordre réel.

## Armer le 10 USD MICRO-LIVE

Faire d'abord le préflight et vérifier le dashboard. Ensuite seulement :

```bash
python3 - <<'PY'
import json
p='config.json'
x=json.load(open(p))
x['execution_enabled']=True
json.dump(x,open(p,'w'),indent=2)
PY
export MEXC_LIVE_ARM=V460_LIVE_10USD
./stop.sh
./start.sh
```

Important : la variable d'armement doit aussi être disponible au process lors de tout redémarrage voulu en LIVE. Sans elle, V4.6 revient SAFE.

## Interface

- `/` : dashboard complet.
- `/api/live/status` : executor, Private WS, balances, PnL, dust.
- `/api/live/trades` : cycles et fills enregistrés.
- `/api/live/events` : state-machine / erreurs / UNKNOWN / tentatives L2.
- `/api/live/dust` : résidus par token.
- `/api/live/balances` : balances courantes / initiales / historique.

## Export

```bash
source .venv/bin/activate
python export_run.py --out export_v460_$(date +%Y%m%d_%H%M)
```

## Limites volontaires du premier MICRO-LIVE

- 1 exposition simultanée.
- 10 USD/trade.
- USDC et USDT uniquement en exécution.
- Aucun rebalance automatique.
- Aucun auto-unwind systématique : L2 reste prioritaire.
- Aucune conversion automatique de dust.
- Fee floor = 5 bp/jambe même si un tarif public apparaît inférieur; un frais authentifié supérieur prévaut.
