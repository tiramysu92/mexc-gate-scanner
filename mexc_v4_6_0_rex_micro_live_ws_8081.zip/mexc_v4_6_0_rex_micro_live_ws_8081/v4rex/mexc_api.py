from __future__ import annotations

import hashlib
import hmac
import json
import os
import random
import threading
import time
from dataclasses import dataclass
from typing import Callable, Optional
from urllib.parse import urlencode

import requests
import websocket
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory

REST = "https://api.mexc.com"
WS = "wss://wbs-api.mexc.com/ws"


class MexcAPIError(RuntimeError):
    def __init__(self, message: str, status: int | None = None, payload=None):
        super().__init__(message)
        self.status = status
        self.payload = payload


class MexcUnknown(RuntimeError):
    """The request outcome is UNKNOWN and MUST be reconciled before retrying."""
    def __init__(self, message: str, client_order_id: str | None = None, symbol: str | None = None):
        super().__init__(message)
        self.client_order_id = client_order_id
        self.symbol = symbol


def _load_env_file(path: str) -> bool:
    if not path or not os.path.isfile(path):
        return False
    loaded = False
    try:
        for raw in open(path, encoding="utf-8"):
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            k = k.strip(); v = v.strip().strip('"').strip("'")
            if k and k not in os.environ:
                os.environ[k] = v
                loaded = True
    except OSError:
        return False
    return loaded


def load_existing_mexc_env(extra_paths: list[str] | None = None) -> list[str]:
    """Load .env without ever logging secret values.

    V4.6 searches the current runtime, parent directories, and the historical project
    locations used by the earlier micro-live builds. Existing process environment
    variables always win.
    """
    here = os.path.abspath(os.getcwd())
    candidates = []
    p = here
    for _ in range(5):
        candidates.append(os.path.join(p, ".env"))
        p = os.path.dirname(p)
    candidates += [
        "/home/ubuntu/mexc-spot-2leg-v4/.env",
        "/home/ubuntu/mexc-gate-scanner/.env",
    ]
    candidates += list(extra_paths or [])
    seen, loaded = set(), []
    for x in candidates:
        x = os.path.abspath(os.path.expanduser(x))
        if x in seen:
            continue
        seen.add(x)
        if _load_env_file(x):
            loaded.append(x)
    return loaded


def mexc_credentials() -> tuple[str | None, str | None]:
    key_names = ("MEXC_API_KEY", "MEXC_ACCESS_KEY", "MEXC_KEY")
    secret_names = ("MEXC_API_SECRET", "MEXC_SECRET_KEY", "MEXC_SECRET")
    key = next((os.getenv(k) for k in key_names if os.getenv(k)), None)
    sec = next((os.getenv(k) for k in secret_names if os.getenv(k)), None)
    return key, sec


class MexcClient:
    def __init__(self, api_key: str, secret: str, timeout_s: float = 4.0, recv_window_ms: int = 3000, session=None):
        if not api_key or not secret:
            raise ValueError("MEXC API credentials missing")
        self.api_key = api_key
        self.secret = secret.encode()
        self.timeout_s = float(timeout_s)
        self.recv_window_ms = int(recv_window_ms)
        self.session = session or requests.Session()
        self.session.headers.update({"X-MEXC-APIKEY": api_key})
        self._time_offset_ms = 0.0

    @staticmethod
    def sign(secret: str | bytes, params: dict) -> str:
        key = secret.encode() if isinstance(secret, str) else secret
        qs = urlencode([(k, str(v)) for k, v in params.items() if v is not None])
        return hmac.new(key, qs.encode(), hashlib.sha256).hexdigest()

    def sync_time(self):
        a = time.time() * 1000
        r = self.session.get(REST + "/api/v3/time", timeout=self.timeout_s)
        r.raise_for_status()
        b = time.time() * 1000
        server = float(r.json()["serverTime"])
        self._time_offset_ms = server - (a + b) / 2
        return {"offset_ms": self._time_offset_ms, "rtt_ms": b - a}

    def _signed(self, method: str, path: str, params: dict | None = None, *, order_mutation=False, client_order_id=None, symbol=None):
        p = dict(params or {})
        p.setdefault("recvWindow", self.recv_window_ms)
        p["timestamp"] = int(time.time() * 1000 + self._time_offset_ms)
        p["signature"] = self.sign(self.secret, p)
        url = REST + path
        try:
            r = self.session.request(method.upper(), url, params=p, timeout=self.timeout_s)
        except (requests.Timeout, requests.ConnectionError) as exc:
            if order_mutation:
                raise MexcUnknown(f"{method} {path}: {type(exc).__name__}", client_order_id, symbol) from exc
            raise MexcAPIError(f"{method} {path}: {type(exc).__name__}") from exc
        payload = None
        try:
            payload = r.json()
        except Exception:
            payload = r.text[:1000]
        if r.status_code >= 500 and order_mutation:
            raise MexcUnknown(f"MEXC HTTP {r.status_code}: outcome UNKNOWN", client_order_id, symbol)
        if r.status_code >= 400:
            raise MexcAPIError(f"MEXC HTTP {r.status_code}: {payload}", r.status_code, payload)
        if isinstance(payload, dict) and payload.get("code") not in (None, 0, 200):
            raise MexcAPIError(f"MEXC code={payload.get('code')}: {payload.get('msg')}", r.status_code, payload)
        return payload

    def account(self):
        return self._signed("GET", "/api/v3/account")

    def balances(self) -> dict[str, dict[str, float]]:
        x = self.account()
        out = {}
        for b in x.get("balances", []) if isinstance(x, dict) else []:
            try:
                out[str(b["asset"])] = {"free": float(b.get("free") or 0), "locked": float(b.get("locked") or 0)}
            except Exception:
                continue
        return out

    def trade_fee(self, symbol: str):
        return self._signed("GET", "/api/v3/tradeFee", {"symbol": symbol})

    def query_order(self, symbol: str, *, order_id: str | None = None, client_order_id: str | None = None):
        p = {"symbol": symbol}
        if order_id:
            p["orderId"] = order_id
        if client_order_id:
            p["origClientOrderId"] = client_order_id
        return self._signed("GET", "/api/v3/order", p)

    def my_trades(self, symbol: str, order_id: str | None = None):
        p = {"symbol": symbol, "limit": 100}
        if order_id:
            p["orderId"] = order_id
        x = self._signed("GET", "/api/v3/myTrades", p)
        return x if isinstance(x, list) else []

    def order_test(self, *, symbol: str, side: str, quantity: str, price: str, client_order_id: str | None = None):
        p = {"symbol": symbol, "side": side, "type": "FILL_OR_KILL", "quantity": quantity, "price": price}
        if client_order_id:
            p["newClientOrderId"] = client_order_id
        return self._signed("POST", "/api/v3/order/test", p)

    def new_fok(self, *, symbol: str, side: str, quantity: str, price: str, client_order_id: str):
        p = {"symbol": symbol, "side": side, "type": "FILL_OR_KILL", "quantity": quantity, "price": price, "newClientOrderId": client_order_id}
        return self._signed("POST", "/api/v3/order", p, order_mutation=True, client_order_id=client_order_id, symbol=symbol)

    def create_listen_key(self):
        try:
            r = self.session.post(REST + "/api/v3/userDataStream", timeout=self.timeout_s)
            r.raise_for_status()
            return r.json()["listenKey"]
        except Exception as exc:
            raise MexcAPIError(f"listenKey create failed: {exc}") from exc

    def keepalive_listen_key(self, listen_key: str):
        try:
            r = self.session.put(REST + "/api/v3/userDataStream", params={"listenKey": listen_key}, timeout=self.timeout_s)
            r.raise_for_status()
            return r.json()
        except Exception as exc:
            raise MexcAPIError(f"listenKey keepalive failed: {exc}") from exc

    def close_listen_key(self, listen_key: str):
        try:
            r = self.session.delete(REST + "/api/v3/userDataStream", params={"listenKey": listen_key}, timeout=self.timeout_s)
            return r.json() if r.content else {}
        except Exception:
            return {}


def _private_codec():
    fd = descriptor_pb2.FileDescriptorProto(name="mexc_private_v460.proto", package="v460", syntax="proto3")
    def msg(n):
        m = fd.message_type.add(); m.name = n; return m
    def fld(m, n, num, typ, repeated=False, target=None, oneof=None):
        f = m.field.add(); f.name = n; f.number = num; f.type = typ; f.label = 3 if repeated else 1
        if target: f.type_name = ".v460." + target
        if oneof is not None: f.oneof_index = oneof
    o = msg("PrivateOrdersV3Api")
    for n,num,typ in [
        ("id",1,9),("clientId",2,9),("price",3,9),("quantity",4,9),("amount",5,9),("avgPrice",6,9),
        ("orderType",7,5),("tradeType",8,5),("isMaker",9,8),("remainAmount",10,9),("remainQuantity",11,9),
        ("lastDealQuantity",12,9),("cumulativeQuantity",13,9),("cumulativeAmount",14,9),("status",15,5),("createTime",16,3),
        ("market",17,9),("triggerType",18,5),("triggerPrice",19,9),("state",20,5),("ocoId",21,9),("routeFactor",22,9),
        ("symbolId",23,9),("marketId",24,9),("marketCurrencyId",25,9),("currencyId",26,9)]: fld(o,n,num,typ)
    d = msg("PrivateDealsV3Api")
    for n,num,typ in [("price",1,9),("quantity",2,9),("amount",3,9),("tradeType",4,5),("isMaker",5,8),("isSelfTrade",6,8),("tradeId",7,9),("clientOrderId",8,9),("orderId",9,9),("feeAmount",10,9),("feeCurrency",11,9),("time",12,3)]: fld(d,n,num,typ)
    a = msg("PrivateAccountV3Api")
    for n,num,typ in [("vcoinName",1,9),("coinId",2,9),("balanceAmount",3,9),("balanceAmountChange",4,9),("frozenAmount",5,9),("frozenAmountChange",6,9),("type",7,9),("time",8,3)]: fld(a,n,num,typ)
    w = msg("PushDataV3ApiWrapper"); fld(w,"channel",1,9); one=w.oneof_decl.add(); one.name="body"
    fld(w,"privateOrders",304,11,target="PrivateOrdersV3Api",oneof=0); fld(w,"privateDeals",306,11,target="PrivateDealsV3Api",oneof=0); fld(w,"privateAccount",307,11,target="PrivateAccountV3Api",oneof=0)
    fld(w,"symbol",3,9); fld(w,"symbolId",4,9); fld(w,"createTime",5,3); fld(w,"sendTime",6,3)
    pool=descriptor_pool.DescriptorPool(); pool.Add(fd)
    return message_factory.GetMessageClass(pool.FindMessageTypeByName("v460.PushDataV3ApiWrapper"))


PrivateEnvelope = _private_codec()


def decode_private(payload: bytes):
    e = PrivateEnvelope(); e.ParseFromString(payload)
    base = {"channel": e.channel, "symbol": e.symbol or None, "sendTime": int(e.sendTime or 0), "createTime": int(e.createTime or 0)}
    if e.HasField("privateOrders"):
        x=e.privateOrders
        return {**base,"kind":"order","orderId":x.id,"clientOrderId":x.clientId,"price":x.price,"quantity":x.quantity,"amount":x.amount,"avgPrice":x.avgPrice,"orderType":int(x.orderType),"tradeType":int(x.tradeType),"remainQuantity":x.remainQuantity,"cumulativeQuantity":x.cumulativeQuantity,"cumulativeAmount":x.cumulativeAmount,"status":int(x.status),"createTimeOrder":int(x.createTime or 0)}
    if e.HasField("privateDeals"):
        x=e.privateDeals
        return {**base,"kind":"deal","price":x.price,"quantity":x.quantity,"amount":x.amount,"tradeType":int(x.tradeType),"isMaker":bool(x.isMaker),"tradeId":x.tradeId,"clientOrderId":x.clientOrderId,"orderId":x.orderId,"feeAmount":x.feeAmount,"feeCurrency":x.feeCurrency,"time":int(x.time or 0)}
    if e.HasField("privateAccount"):
        x=e.privateAccount
        return {**base,"kind":"account","asset":x.vcoinName,"balanceAmount":x.balanceAmount,"balanceAmountChange":x.balanceAmountChange,"frozenAmount":x.frozenAmount,"type":x.type,"time":int(x.time or 0)}
    return None


def _control(raw):
    if isinstance(raw, str): s=raw
    elif isinstance(raw, (bytes,bytearray)):
        b=bytes(raw).lstrip()
        if b[:1] not in (b"{",b"["): return None
        try: s=bytes(raw).decode("utf-8")
        except UnicodeDecodeError: return None
    else: return None
    try: x=json.loads(s)
    except Exception: return None
    return x if isinstance(x,dict) else None


class PrivateStream:
    """Private WS is the fast confirmation path; REST remains reconciliation authority."""
    def __init__(self, client: MexcClient, on_event: Callable[[dict], None] | None = None, log: Callable[[str,str],None] | None = None):
        self.client=client; self.on_event=on_event or (lambda e:None); self.log=log or (lambda k,d:None)
        self.stop=False; self.connected=False; self.listen_key=None; self.last_event_ts=None; self.errors=0; self.reconnects=0; self.acks=0
        self.lock=threading.RLock(); self.order_events={}; self.deals={}; self.balance_events={}; self.cv=threading.Condition(self.lock); self.app=None

    def start(self):
        threading.Thread(target=self._run,daemon=True,name="mexc-private-ws").start()

    def close(self):
        self.stop=True
        try:
            if self.app: self.app.close()
        except Exception: pass
        if self.listen_key: self.client.close_listen_key(self.listen_key)

    def _record(self,e):
        self.last_event_ts=time.time()
        with self.cv:
            if e.get("kind")=="order":
                if e.get("orderId"): self.order_events[e["orderId"]]=e
                if e.get("clientOrderId"): self.order_events[e["clientOrderId"]]=e
            elif e.get("kind")=="deal":
                k=e.get("orderId") or e.get("clientOrderId")
                if k: self.deals.setdefault(k,[]).append(e)
            elif e.get("kind")=="account" and e.get("asset"):
                self.balance_events[e["asset"]]=e
            self.cv.notify_all()
        self.on_event(e)

    def wait_order(self, *, order_id=None, client_order_id=None, timeout_s=0.8):
        keys=[x for x in (order_id,client_order_id) if x]
        end=time.monotonic()+timeout_s
        with self.cv:
            while True:
                for k in keys:
                    e=self.order_events.get(k)
                    if e and int(e.get("status") or 0) in (2,4,5): return e
                rem=end-time.monotonic()
                if rem<=0:return None
                self.cv.wait(min(rem,.05))

    def _run(self):
        back=.5
        while not self.stop:
            try:
                self.listen_key=self.client.create_listen_key()
                url=WS+"?listenKey="+self.listen_key
                def on_open(ws):
                    self.connected=True
                    ws.send(json.dumps({"method":"SUBSCRIPTION","params":["spot@private.orders.v3.api.pb","spot@private.deals.v3.api.pb","spot@private.account.v3.api.pb"]}))
                def on_msg(ws,msg):
                    c=_control(msg)
                    if c is not None:
                        self.acks+=1; return
                    if not isinstance(msg,(bytes,bytearray)): return
                    try:
                        e=decode_private(bytes(msg))
                        if e:self._record(e)
                    except Exception as exc:
                        self.errors+=1; self.log("PRIVATE_WS_DECODE",repr(exc))
                def on_err(ws,err): self.log("PRIVATE_WS",repr(err))
                def on_close(ws,code,msg): self.connected=False
                self.app=websocket.WebSocketApp(url,on_open=on_open,on_message=on_msg,on_error=on_err,on_close=on_close)
                def keepalive():
                    while not self.stop and self.connected:
                        time.sleep(25*60)
                        if self.stop or not self.connected:return
                        try:self.client.keepalive_listen_key(self.listen_key)
                        except Exception as exc:self.log("PRIVATE_KEEPALIVE",repr(exc))
                def ping():
                    while not self.stop and self.connected:
                        time.sleep(15)
                        if self.stop or not self.connected:return
                        try:self.app.send(json.dumps({"method":"PING"}))
                        except Exception:return
                threading.Thread(target=keepalive,daemon=True).start(); threading.Thread(target=ping,daemon=True).start()
                self.app.run_forever(ping_interval=0,skip_utf8_validation=True)
            except Exception as exc:
                self.errors+=1; self.log("PRIVATE_WS_RUN",repr(exc))
            self.connected=False
            if self.stop:break
            self.reconnects+=1; time.sleep(back+random.random()*.2); back=min(10,back*1.6)

    def status(self):
        return {"connected":self.connected,"listen_key":bool(self.listen_key),"last_event_age_s":None if not self.last_event_ts else max(0,time.time()-self.last_event_ts),"errors":self.errors,"reconnects":self.reconnects,"acks":self.acks}
