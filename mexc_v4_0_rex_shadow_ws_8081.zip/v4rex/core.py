from dataclasses import dataclass
import time, threading
@dataclass(frozen=True)
class L: p:float; q:float
@dataclass(frozen=True)
class Book:
 symbol:str; bids:tuple; asks:tuple; gen:int; ver:int|None; exchange_ms:int|None; recv_ns:int; apply_ns:int; state:str='VALID'
 @property
 def age_ms(self): return (time.monotonic_ns()-self.apply_ns)/1e6
class Store:
 def __init__(self): self.l=threading.RLock(); self.b={}
 def put(self,x):
  with self.l:self.b[x.symbol]=x
 def get(self,s):
  with self.l:return self.b.get(s)
 def n(self):
  with self.l:return len(self.b)
def buy(levels,quote,f=.25):
 rem=quote;base=spent=0.
 for x in levels:
  take=min(rem,x.p*x.q*f); base+=take/x.p;spent+=take;rem-=take
  if rem<=1e-10:break
 return base,(spent/base if base else 0),spent/quote if quote else 0
def sell(levels,base,f=.25):
 rem=base;sold=out=0.
 for x in levels:
  take=min(rem,x.q*f);sold+=take;out+=take*x.p;rem-=take
  if rem<=1e-10:break
 return out,(out/sold if sold else 0),sold/base if base else 0
