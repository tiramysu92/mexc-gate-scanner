import sqlite3,time,threading
SC='''PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS decisions(id INTEGER PRIMARY KEY,ts REAL,route TEXT,token TEXT,size REAL,fraction REAL,edge_bps REAL,cov1 REAL,cov2 REAL,age1 REAL,age2 REAL,skew REAL,accepted INT,reason TEXT);
CREATE INDEX IF NOT EXISTS idx_dt ON decisions(ts); CREATE INDEX IF NOT EXISTS idx_dr ON decisions(route,ts);
CREATE TABLE IF NOT EXISTS health(id INTEGER PRIMARY KEY,ts REAL,books INT,scans INT,accepted INT,scan_ms REAL,collector_errors INT);'''
class DB:
 def __init__(self,p):
  self.p=p;self.l=threading.Lock();c=self.c();c.executescript(SC);c.close()
 def c(self):
  c=sqlite3.connect(self.p,timeout=20);c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA synchronous=NORMAL');return c
 def add_many(self,rows):
  if not rows:return
  ts=time.time(); data=[(ts,)+r for r in rows]
  with self.l:
   c=self.c();c.executemany('INSERT INTO decisions VALUES(NULL,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',data);c.commit();c.close()
 def health(self,*x):
  with self.l:
   c=self.c();c.execute('INSERT INTO health VALUES(NULL,?,?,?,?,?,?)',(time.time(),)+x);c.commit();c.close()
 def summary(self,h=24):
  c=self.c();s=time.time()-3600*h
  a=c.execute('SELECT count(*),sum(accepted),avg(edge_bps),max(edge_bps),avg(age1),avg(age2),avg(skew) FROM decisions WHERE ts>?',(s,)).fetchone()
  top=c.execute('SELECT token,count(*),sum(accepted),max(edge_bps),avg(edge_bps) FROM decisions WHERE ts>? GROUP BY token ORDER BY sum(accepted) DESC,count(*) DESC LIMIT 30',(s,)).fetchall();c.close()
  return {'decisions':a[0] or 0,'accepted':a[1] or 0,'avg_edge_bps':a[2],'max_edge_bps':a[3],'avg_age1':a[4],'avg_age2':a[5],'avg_skew':a[6],'tokens':[{'token':x[0],'decisions':x[1],'accepted':x[2] or 0,'max_edge_bps':x[3],'avg_edge_bps':x[4]} for x in top]}
