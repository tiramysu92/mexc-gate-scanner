import time
from .core import buy,sell
class Engine:
 def __init__(self,cfg,store,db):self.cfg=cfg;self.s=store;self.db=db;self.scans=self.acc=0;self.scan_ms=0
 def once(self):
  t=time.monotonic_ns(); st=self.cfg['stablecoins']; n=ok=0; rows=[]
  for tok in self.cfg['tokens']:
   for a in st:
    for b in st:
     if a==b:continue
     x=self.s.get(tok+a);y=self.s.get(tok+b)
     if not x or not y:continue
     for size in self.cfg['test_sizes_usd']:
      for f in self.cfg['depth_fractions']:
       base,v1,c1=buy(x.asks,size,f);out,v2,c2=sell(y.bids,base,f);fee=self.cfg['fee_bps_default']/1e4
       edge=(out*(1-fee)**2/size-1)*1e4 if size else -1e9; skew=abs(x.apply_ns-y.apply_ns)/1e6
       reasons=[]
       if x.state!='VALID' or y.state!='VALID':reasons.append('BOOK')
       if x.age_ms>self.cfg['max_local_age_ms'] or y.age_ms>self.cfg['max_local_age_ms']:reasons.append('STALE')
       if skew>self.cfg['max_skew_ms']:reasons.append('SKEW')
       if c1<.999 or c2<.999:reasons.append('DEPTH')
       if edge<self.cfg['min_edge_bps']:reasons.append('EDGE')
       good=not reasons;n+=1;ok+=int(good)
       rows.append((f'{a}>{tok}>{b}',tok,size,f,edge,c1,c2,x.age_ms,y.age_ms,skew,int(good),'OK' if good else '|'.join(reasons)))
  self.db.add_many(rows);self.scans+=n;self.acc+=ok;self.scan_ms=(time.monotonic_ns()-t)/1e6
