import json,time,threading,random,requests,websocket
from collections import defaultdict,deque
from .core import Book,L

REST='https://api.mexc.com'; WS='wss://wbs-api.mexc.com/ws'

def _codec():
 from google.protobuf import descriptor_pb2,descriptor_pool,message_factory
 fd=descriptor_pb2.FileDescriptorProto(name='mexc_v4.proto',package='v4',syntax='proto3')
 def msg(n): x=fd.message_type.add();x.name=n;return x
 def fld(m,n,num,typ,rep=False,target=None):
  f=m.field.add();f.name=n;f.number=num;f.type=typ;f.label=3 if rep else 1
  if target:f.type_name='.v4.'+target
 lv=msg('Level');fld(lv,'price',1,9);fld(lv,'quantity',2,9)
 dp=msg('Depth');fld(dp,'asks',1,11,True,'Level');fld(dp,'bids',2,11,True,'Level');fld(dp,'fromVersion',4,9);fld(dp,'toVersion',5,9)
 en=msg('Envelope');fld(en,'symbol',3,9);fld(en,'sendTime',6,3);fld(en,'depth',313,11,False,'Depth')
 pool=descriptor_pool.DescriptorPool();pool.Add(fd)
 return message_factory.GetMessageClass(pool.FindMessageTypeByName('v4.Envelope'))
Envelope=_codec()

def decode(payload):
 e=Envelope();e.ParseFromString(payload)
 if not e.symbol or not e.HasField('depth'):return None
 try: fv=int(e.depth.fromVersion);tv=int(e.depth.toVersion)
 except: return None
 return {'symbol':e.symbol,'send':int(e.sendTime or 0),'from':fv,'to':tv,
         'bids':[(float(z.price),float(z.quantity)) for z in e.depth.bids],
         'asks':[(float(z.price),float(z.quantity)) for z in e.depth.asks]}

class Collector:
 def __init__(self,cfg,store):
  self.cfg=cfg;self.s=store;self.errors=0;self.requests=0;self.messages=0;self.reconnects=0;self.gaps=0;self.resyncs=0;self.acks=0;self.pongs=0
  self.gen=0;self.lock=threading.RLock();self.raw={};self.buffers=defaultdict(lambda:deque(maxlen=5000));self.ready=set();self.stop=False
  self.symbols=sorted({t+s for t in cfg['tokens'] for s in cfg['stablecoins']})
 def _publish(self,sym):
  with self.lock:
   x=self.raw.get(sym)
   if not x or not x.get('ready'):return
   bids=tuple(L(p,q) for p,q in sorted(x['bids'].items(),reverse=True)[:self.cfg.get('depth_levels',100)])
   asks=tuple(L(p,q) for p,q in sorted(x['asks'].items())[:self.cfg.get('depth_levels',100)])
   if not bids or not asks or bids[0].p>=asks[0].p:return
   self.s.put(Book(sym,bids,asks,x['gen'],x['ver'],x.get('send') or None,x['recv_ns'],x['apply_ns'],'VALID'))
 def _apply(self,u):
  sym=u['symbol']; recv_ns=time.monotonic_ns()
  with self.lock:
   x=self.raw.get(sym)
   if not x or not x.get('ready'):
    self.buffers[sym].append((u,recv_ns));return
   if u['to']<=x['ver']:return
   if u['from']!=x['ver']+1:
    x['ready']=False;self.ready.discard(sym);self.buffers[sym].append((u,recv_ns));self.gaps+=1
    threading.Thread(target=self._resync,args=(sym,),daemon=True).start();return
   for side in ('bids','asks'):
    for p,q in u[side]:
     if q==0:x[side].pop(p,None)
     else:x[side][p]=q
   x.update(ver=u['to'],send=u['send'],recv_ns=recv_ns,apply_ns=time.monotonic_ns())
  self._publish(sym)
 def _resync(self,sym):
  # One symbol may request multiple triggers; serialize by per-symbol marker.
  with self.lock:
   x=self.raw.setdefault(sym,{})
   if x.get('resyncing'):return
   x['resyncing']=True;gen=self.gen
  try:
   for attempt in range(8):
    try:
     r=requests.get(REST+'/api/v3/depth',params={'symbol':sym,'limit':1000},timeout=8);self.requests+=1;r.raise_for_status();j=r.json()
     ver=int(j['lastUpdateId']);bids={float(p):float(q) for p,q in j['bids'] if float(q)>0};asks={float(p):float(q) for p,q in j['asks'] if float(q)>0}
     with self.lock:
      if gen!=self.gen:return
      buf=list(self.buffers[sym]); self.buffers[sym].clear()
      # Official bridge: discard deltas already included; first remaining must be exactly next version.
      rem=[z for z in buf if z[0]['to']>ver]
      cur={'bids':bids,'asks':asks,'ver':ver,'send':0,'recv_ns':time.monotonic_ns(),'apply_ns':time.monotonic_ns(),'gen':gen,'ready':True,'resyncing':True}
      for u,rns in rem:
       if u['from']!=cur['ver']+1: cur['ready']=False;break
       for side in ('bids','asks'):
        for p,q in u[side]:
         if q==0:cur[side].pop(p,None)
         else:cur[side][p]=q
       cur.update(ver=u['to'],send=u['send'],recv_ns=rns,apply_ns=time.monotonic_ns())
      if not cur['ready']:
       self.buffers[sym].extend(rem);raise RuntimeError('snapshot bridge gap')
      cur['resyncing']=False;self.raw[sym]=cur;self.ready.add(sym);self.resyncs+=1
     self._publish(sym);return
    except Exception:
     self.errors+=1;time.sleep(min(5,.25*2**attempt))
  finally:
   with self.lock:
    if sym in self.raw:self.raw[sym]['resyncing']=False
 def _socket(self,group,wid):
  backoff=1
  while not self.stop:
   self.gen+=1;gen=self.gen;opened=time.monotonic()
   with self.lock:
    for s in group:
     self.ready.discard(s);self.raw.pop(s,None);self.buffers[s].clear()
   def on_open(ws):
    ws.send(json.dumps({'method':'SUBSCRIPTION','params':[f'spot@public.aggre.depth.v3.api.pb@10ms@{s}' for s in group]}))
    for s in group: threading.Thread(target=self._resync,args=(s,),daemon=True).start()
   def on_message(ws,msg):
    try:
     if isinstance(msg,str):
      j=json.loads(msg)
      if str(j.get('msg','')).upper()=='PONG':self.pongs+=1
      else:self.acks+=1
      return
     u=decode(msg)
     if u and u['symbol'] in group:self.messages+=1;self._apply(u)
    except Exception:self.errors+=1
   def on_error(ws,err): self.errors+=1
   def on_close(ws,code,msg): pass
   app=websocket.WebSocketApp(WS,on_open=on_open,on_message=on_message,on_error=on_error,on_close=on_close)
   def ping():
    while not self.stop:
     time.sleep(15)
     try:app.send(json.dumps({'method':'PING'}))
     except:return
   threading.Thread(target=ping,daemon=True).start()
   try:app.run_forever(ping_interval=0)
   except Exception:self.errors+=1
   self.reconnects+=1
   lived=time.monotonic()-opened;backoff=1 if lived>120 else min(30,backoff*1.7);time.sleep(backoff+random.random())
 def run(self):
  # <=25 subscriptions/socket, below MEXC's 30 max.
  groups=[self.symbols[i:i+25] for i in range(0,len(self.symbols),25)]
  for i,g in enumerate(groups):threading.Thread(target=self._socket,args=(g,i),daemon=True).start()
  while not self.stop:time.sleep(3600)
 def status(self):
  with self.lock:return {'symbols':len(self.symbols),'ready':len(self.ready),'messages':self.messages,'requests':self.requests,'errors':self.errors,'reconnects':self.reconnects,'gaps':self.gaps,'resyncs':self.resyncs,'acks':self.acks,'pongs':self.pongs,'generation':self.gen}
