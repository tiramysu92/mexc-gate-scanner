import json,sys,time,threading
from flask import Flask,jsonify,render_template
from v4rex.core import Store
from v4rex.db import DB
from v4rex.engine import Engine
from v4rex.collector import Collector
cfg=json.load(open(sys.argv[1] if len(sys.argv)>1 else 'config.json'));assert cfg['mode']=='SHADOW'
s=Store();db=DB(cfg['db_path']);e=Engine(cfg,s,db);c=Collector(cfg,s);started=time.time();app=Flask(__name__)
def scan():
 while True:
  e.once();db.health(s.n(),e.scans,e.acc,e.scan_ms,c.errors);time.sleep(.5)
threading.Thread(target=c.run,daemon=True).start();threading.Thread(target=scan,daemon=True).start()
@app.get('/healthz')
def hz():return jsonify(ok=True,mode='SHADOW',port=cfg['port'])
@app.get('/api/status')
def st():return jsonify(mode='SHADOW',uptime_s=time.time()-started,books=s.n(),collector_requests=c.requests,collector_errors=c.errors,collector=c.status(),scans=e.scans,accepted=e.acc,last_scan_ms=e.scan_ms,summary=db.summary())
@app.get('/')
def ix():return render_template('index.html')
if __name__=='__main__':app.run(host='0.0.0.0',port=int(cfg['port']),threaded=True)
