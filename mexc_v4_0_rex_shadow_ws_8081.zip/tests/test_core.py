from v4rex.core import L,buy,sell
def test_depth():
 b,v,c=buy((L(10,10),),50,1);assert b==5 and c==1
 q,v,c=sell((L(11,10),),5,1);assert q==55 and c==1
