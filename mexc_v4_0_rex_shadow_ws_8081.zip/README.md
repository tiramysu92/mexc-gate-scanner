# MEXC V4.0-REX — Shadow WS 8081

Qualification longue durée conforme à la SPEC V4.0-REX. **Aucun code d'ordre, aucune clé API, aucun LIVE.**

## Market data
- MEXC public Diff.Depth Protobuf `@10ms`.
- 25 abonnements maximum par socket.
- Snapshot REST + buffer des deltas + raccord strict de versions.
- Gap => carnet invalide + resync ; aucune décision sur le carnet pendant la reconstruction.
- `sendTime` MEXC, réception monotone, application monotone et version conservés dans le Book.

## Mesures
Le scanner teste les tailles 10/20/25/50/100/200 USDT et les fractions de profondeur 10/15/20/25/33/50/75/100 %, enregistre aussi les refus, et expose le dashboard sur `:8081`.

## Installation
```bash
unzip mexc_v4_0_rex_shadow_ws_8081.zip -d ~/mexc-v4-rex
cd ~/mexc-v4-rex
./run.sh
```
Avant lancement, arrêter l'ancien service qui occupe 8081. Ne pas supprimer ses DB : les archiver séparément.

## Vérification
```bash
curl http://127.0.0.1:8081/healthz
curl http://127.0.0.1:8081/api/status
```
Attendre que `collector.ready` monte vers le nombre de symboles disponibles. Surveiller `gaps`, `resyncs`, `reconnects`, `errors` et le temps de scan.

## Limite volontaire
Cette build mesure la robustesse publique et la viabilité Shadow. Les commissions sont encore une hypothèse configurable pour le Shadow ; la SPEC impose l'interrogation des frais du compte avant une future qualification privée/Micro-Live.
