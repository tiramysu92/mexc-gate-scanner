#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -f sidecar.pid ]; then
  kill "$(cat sidecar.pid)" 2>/dev/null || true
  rm -f sidecar.pid
  echo "Sidecar arrêté"
else
  echo "Pas de PID sidecar enregistré"
fi
