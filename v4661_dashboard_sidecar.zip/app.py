from __future__ import annotations

import argparse
import json
import os
import sqlite3
import time
import urllib.request
from pathlib import Path

from flask import Flask, jsonify, render_template
from waitress import serve

parser = argparse.ArgumentParser()
parser.add_argument("--runtime", required=True)
parser.add_argument("--port", type=int, default=8085)
parser.add_argument("--scanner-url", default="http://127.0.0.1:8081")
args = parser.parse_args()

RUNTIME = Path(args.runtime).resolve()
CFG = json.loads((RUNTIME / "config.json").read_text())
DB_PATH = Path(CFG["db_path"])
if not DB_PATH.is_absolute():
    DB_PATH = (RUNTIME / DB_PATH).resolve()
SCANNER = args.scanner_url.rstrip("/")
PORT = int(args.port)

app = Flask(__name__, template_folder="templates")


def rodb():
    return sqlite3.connect(f"file:{DB_PATH}?mode=ro", uri=True, timeout=2.0)


def get_json(path, default=None, timeout=2.0):
    try:
        with urllib.request.urlopen(SCANNER + path, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return default


def f(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return float(default)


def jloads(s):
    try:
        return json.loads(s or "{}")
    except Exception:
        return {}


def stable_fx(live):
    m = (live.get("maintenance") or {}).get("stable_fx") or {}
    return {
        "bid": f(m.get("bid")),
        "ask": f(m.get("ask")),
        "mid": f(m.get("mid")),
        "age_s": m.get("age_s"),
        "fresh": bool(m.get("fresh")),
        "last_error": m.get("last_error"),
    }


def economic_net_bps(net_bps, stable_a, stable_b, mid):
    if net_bps is None or not mid or mid <= 0:
        return None
    ratio = 1.0 + f(net_bps) / 1e4
    if stable_a == "USDC" and stable_b == "USDT":
        ratio /= mid
    elif stable_a == "USDT" and stable_b == "USDC":
        ratio *= mid
    else:
        return None
    return (ratio - 1.0) * 1e4


def current_threshold(row, recovery):
    klass = row["liquidity_class"]
    if klass == "A":
        standard = f(CFG.get("liquidity_a_min_net_edge_bps", 1.0))
    else:
        standard = f(CFG.get("liquidity_b_min_net_edge_bps", 2.0))
    if recovery and row["stable_a"] == "USDT" and row["stable_b"] == "USDC":
        return f(CFG.get("inventory_recovery_live_min_economic_bps", 0.0))
    if recovery and row["stable_a"] == "USDC" and row["stable_b"] == "USDT":
        return max(standard, f(CFG.get("inventory_forward_min_economic_bps", 5.0)))
    return standard


def survival_requirements(klass):
    if klass == "A":
        return (
            f(CFG.get("class_a_l2_survival_100_min", .99)),
            f(CFG.get("class_a_l2_survival_250_min", .98)),
            f(CFG.get("class_a_l2_survival_500_min", .95)),
        )
    return (
        f(CFG.get("class_b_l2_survival_100_min", .98)),
        f(CFG.get("class_b_l2_survival_250_min", .95)),
        f(CFG.get("class_b_l2_survival_500_min", .90)),
    )


def reasons_for(row, live, econ_guaranteed, threshold, recovery):
    reasons = []
    klass = row["liquidity_class"]
    size = f(row["size"])
    a, b = row["stable_a"], row["stable_b"]

    if not live.get("execution_enabled"):
        reasons.append("LIVE désarmé")
    if not live.get("arm_ok"):
        reasons.append("ARM absent")
    if live.get("state") != "READY":
        reasons.append("executor " + str(live.get("state")))
    if not bool((live.get("private_ws") or {}).get("connected")):
        reasons.append("Private WS down")
    if klass not in ("A", "B"):
        reasons.append("classe " + str(klass))

    normal_size = f(CFG.get("live_trade_size_usd", 10))
    recovery_sizes = {f(x) for x in CFG.get("inventory_recovery_sizes_usd", [40,25,20,10])}
    if recovery and a == "USDT" and b == "USDC":
        if size not in recovery_sizes:
            reasons.append("taille non recovery")
    elif abs(size - normal_size) > 1e-9:
        reasons.append(f"taille standard=${normal_size:g}")

    trials = int(row["survival_trials"] or 0)
    min_trials = int(CFG.get("live_min_survival_trials", 1000))
    if trials < min_trials:
        reasons.append(f"trials {trials}/{min_trials}")

    r100, r250, r500 = survival_requirements(klass)
    s100 = f(row["l2_survival_100"])
    s250 = f(row["l2_survival_250"])
    s500 = f(row["l2_survival_500"])
    if trials >= min_trials and (s100 < r100 or s250 < r250 or s500 < r500):
        reasons.append("survivability")

    reserve = f(CFG.get("live_min_stable_reserve_usd", 20))
    bal = f(((live.get("balances") or {}).get(a) or {}).get("free"))
    if bal < size + reserve:
        reasons.append(f"{a} {bal:.2f} < {size+reserve:.2f}")

    if econ_guaranteed is None:
        reasons.append("FX indisponible")
    elif econ_guaranteed <= threshold:
        reasons.append(f"edge {econ_guaranteed:.2f} ≤ seuil {threshold:.2f}")

    return reasons or ["ÉLIGIBLE"]


def strategy_pnl(db):
    row = db.execute(
        "SELECT COUNT(*),COALESCE(SUM(realized_pnl_nominal),0),"
        "COALESCE(SUM(l1_quote_spent),0) "
        "FROM live_cycles WHERE state IN ('CLOSED','CLOSED_WITH_RESIDUAL')"
    ).fetchone()
    cycles, cash, turnover = int(row[0] or 0), f(row[1]), f(row[2])
    dust = f(db.execute("SELECT COALESCE(SUM(est_usd),0) FROM live_dust").fetchone()[0])

    recovered = 0.0
    rebal_friction = 0.0
    legacy_basis = 0.0
    rebal_fills = 0
    try:
        rows = db.execute(
            "SELECT kind,status,value_usd,detail_json FROM maintenance_events ORDER BY id"
        ).fetchall()
        for kind, status, value, detail in rows:
            d = jloads(detail)
            if kind in ("DUST_DIRECT_SELL", "DUST_MX_SELL") and status == "FILLED":
                recovered += f(value)
            if kind == "REBALANCE" and status == "FILLED":
                rebal_fills += 1
                rebal_friction += f(d.get("execution_cost_mid_quote"))
                legacy_basis += f(d.get("nominal_pnl_1to1"))
    except sqlite3.Error:
        pass

    nominal = cash + dust + recovered
    after_friction = nominal - rebal_friction
    return {
        "cycles": cycles,
        "cash": cash,
        "turnover": turnover,
        "dust_outstanding": dust,
        "dust_recovered": recovered,
        "after_rebalance_friction": after_friction,
        "bps": (after_friction / turnover * 1e4) if turnover else None,
        "rebalance_friction": rebal_friction,
        "legacy_rebalance_basis": legacy_basis,
        "rebalance_fills": rebal_fills,
    }


def top_recent(db, live, fx, seconds=900, limit=10):
    now = time.time()
    recovery = bool((live.get("inventory_recovery") or {}).get("active"))
    mid = fx["mid"]
    execution_reserve = f(CFG.get("execution_price_reserve_bps", .5))

    sizes = {f(CFG.get("live_trade_size_usd", 10))}
    if recovery:
        sizes |= {f(x) for x in CFG.get("inventory_recovery_sizes_usd", [40,25,20,10])}

    sql = (
        "SELECT h.route,h.token,h.stable_a,h.stable_b,h.symbol1,h.symbol2,"
        "h.size,h.liquidity_class,h.net_edge_bps,h.expected_edge_bps,"
        "h.survival_trials,h.l2_survival_100,h.l2_survival_250,h.l2_survival_500,"
        "h.l1_reserve_x,h.l2_reserve_x,h.min_quote_volume_24h,h.accepted,"
        "h.qualification_state,h.last_ts,h.reasons "
        "FROM opportunity_hits h JOIN ("
        "SELECT route,size,MAX(last_ts) mx FROM opportunity_hits "
        "WHERE last_ts>=? GROUP BY route,size"
        ") z ON z.route=h.route AND z.size=h.size AND z.mx=h.last_ts "
        "WHERE h.last_ts>=? ORDER BY h.last_ts DESC LIMIT 600"
    )
    rows = db.execute(sql, (now-seconds, now-seconds)).fetchall()
    cols = [
        "route","token","stable_a","stable_b","symbol1","symbol2","size","liquidity_class",
        "net_edge_bps","expected_edge_bps","survival_trials","l2_survival_100","l2_survival_250",
        "l2_survival_500","l1_reserve_x","l2_reserve_x","min_quote_volume_24h","accepted",
        "qualification_state","last_ts","reasons"
    ]

    out = []
    for raw in rows:
        row = dict(zip(cols, raw))
        if f(row["size"]) not in sizes:
            continue
        econ_net = economic_net_bps(row["net_edge_bps"], row["stable_a"], row["stable_b"], mid)
        econ_guaranteed = None if econ_net is None else econ_net - execution_reserve
        threshold = current_threshold(row, recovery)
        row["economic_guaranteed_bps"] = econ_guaranteed
        row["threshold_bps"] = threshold
        row["block_reasons"] = reasons_for(row, live, econ_guaranteed, threshold, recovery)
        row["age_s"] = max(0.0, now - f(row["last_ts"]))
        out.append(row)

    out.sort(
        key=lambda x: -1e12 if x["economic_guaranteed_bps"] is None else x["economic_guaranteed_bps"],
        reverse=True
    )
    return out[:limit]


def recovery_trials(db):
    rows = db.execute(
        "SELECT route,size,trials,l2_ok_100,l2_ok_250,l2_ok_500 "
        "FROM survival_aggregates "
        "WHERE route LIKE 'USDT>%>USDC' AND size IN (10,20,25,40) AND trials>0 "
        "ORDER BY trials DESC,size DESC LIMIT 30"
    ).fetchall()
    out = []
    for route, size, trials, a, b, c in rows:
        n = max(1, int(trials or 0))
        out.append({
            "route": route,
            "size": f(size),
            "trials": int(trials or 0),
            "s100": f(a)/n,
            "s250": f(b)/n,
            "s500": f(c)/n,
        })
    return out


def recent_cycles(db, limit=15):
    rows = db.execute(
        "SELECT started_ts,route,requested_size,state,guaranteed_edge_bps,"
        "realized_pnl_nominal,dust_est_usd,l1_latency_ms,l2_latency_ms "
        "FROM live_cycles ORDER BY started_ts DESC LIMIT ?",
        (int(limit),)
    ).fetchall()
    return [{
        "ts":r[0],"route":r[1],"size":r[2],"state":r[3],"guaranteed":r[4],
        "cash":r[5],"dust":r[6],"l1_ms":r[7],"l2_ms":r[8]
    } for r in rows]


@app.get("/api/data")
def api_data():
    live = get_json("/api/live/status", {}) or {}
    fx = stable_fx(live)
    db = rodb()
    try:
        pnl = strategy_pnl(db)
        top = top_recent(db, live, fx)
        trials = recovery_trials(db)
        cycles = recent_cycles(db)
        last = db.execute("SELECT MAX(started_ts) FROM live_cycles").fetchone()[0]
    finally:
        db.close()

    return jsonify({
        "now": time.time(),
        "scanner_reachable": bool(live),
        "live": live,
        "fx": fx,
        "pnl": pnl,
        "top10": top,
        "recovery_trials": trials,
        "recent_cycles": cycles,
        "last_cycle_age_s": None if last is None else max(0.0, time.time()-f(last)),
    })


@app.get("/")
def index():
    return render_template("index.html")


@app.after_request
def no_cache(resp):
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    return resp


if __name__ == "__main__":
    print(f"[sidecar] runtime={RUNTIME}")
    print(f"[sidecar] db={DB_PATH}")
    print(f"[sidecar] scanner={SCANNER}")
    print(f"[sidecar] listen=0.0.0.0:{PORT}")
    serve(app, host="0.0.0.0", port=PORT, threads=4)
