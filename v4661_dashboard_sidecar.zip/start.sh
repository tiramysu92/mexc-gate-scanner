#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
RUNTIME="${SCANNER_RUNTIME:-/home/ubuntu/mexc-spot-2leg-v4/runtime_v4661/mexc_v4_6_6_1_fx_normalized_inventory_ws_8081}"
PORT="${SIDECAR_PORT:-8085}"
cd "$HERE"
if ss -ltn 2>/dev/null | grep -q ":${PORT} "; then echo "ERREUR: port ${PORT} déjà occupé"; exit 1; fi
PY="$RUNTIME/.venv/bin/python"
[ -x "$PY" ] || { echo "ERREUR: Python introuvable: $PY"; exit 1; }
nohup "$PY" app.py --runtime "$RUNTIME" --port "$PORT" > sidecar.log 2>&1 &
echo $! > sidecar.pid
sleep 1
echo "Sidecar démarré PID $(cat sidecar.pid) sur port ${PORT}"
