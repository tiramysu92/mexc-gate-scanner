# V4.6.6.1 Observer — sidecar READ ONLY

- Aucun ordre MEXC.
- Aucune clé API.
- SQLite ouvert en `mode=ro`.
- Scanner 8081 interrogé seulement en GET.
- Aucun fichier du runtime n'est modifié.
- Port 8085 par défaut.

Le Top 10 montre les edges économiques garantis récents et les gates probables qui empêchent le LIVE.
