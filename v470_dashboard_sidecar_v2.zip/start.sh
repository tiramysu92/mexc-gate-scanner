#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
RUNTIME="${SCANNER_RUNTIME:-/home/ubuntu/mexc-spot-2leg-v4/runtime_v470/mexc_v4_7_0_2leg_flow_inventory_ws_8081}"
PORT="${SIDECAR_PORT:-8085}"
cd "$HERE"
if ss -ltn 2>/dev/null | grep -q ":${PORT} "; then echo "ERREUR: port ${PORT} déjà occupé"; exit 1; fi
PY="$RUNTIME/.venv/bin/python"
nohup "$PY" app.py --runtime "$RUNTIME" --port "$PORT" > sidecar.log 2>&1 &
echo $! > sidecar.pid
sleep 1
kill -0 "$(cat sidecar.pid)" 2>/dev/null || { tail -100 sidecar.log; exit 1; }
echo "V4.7 sidecar démarré PID $(cat sidecar.pid) sur port ${PORT}"
