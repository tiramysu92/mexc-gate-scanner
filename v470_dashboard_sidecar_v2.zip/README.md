# V4.7 Dashboard Sidecar READ-ONLY

Port 8085. Aucune clé API. Le scanner 8081 est interrogé uniquement en GET.
SQLite est ouvert en mode=ro. Aucun fichier du runtime V4.7 n'est modifié.
