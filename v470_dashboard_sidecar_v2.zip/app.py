from __future__ import annotations
import argparse, json, sqlite3, time, urllib.request
from pathlib import Path
from flask import Flask, jsonify, render_template
from waitress import serve

ap=argparse.ArgumentParser()
ap.add_argument("--runtime",default="/home/ubuntu/mexc-spot-2leg-v4/runtime_v470/mexc_v4_7_0_2leg_flow_inventory_ws_8081")
ap.add_argument("--scanner-url",default="http://127.0.0.1:8081")
ap.add_argument("--port",type=int,default=8085)
args=ap.parse_args()

RUNTIME=Path(args.runtime).resolve()
CFG=json.loads((RUNTIME/"config.json").read_text())
DB=Path(CFG["db_path"])
if not DB.is_absolute(): DB=(RUNTIME/DB).resolve()
SCANNER=args.scanner_url.rstrip("/")
PORT=args.port

app=Flask(__name__,template_folder="templates")

def f(x,d=0.0):
    try:return float(x)
    except:return float(d)

def getj(path,default=None,timeout=2):
    try:
        with urllib.request.urlopen(SCANNER+path,timeout=timeout) as r:
            return json.loads(r.read().decode())
    except:return default

def rodb():
    return sqlite3.connect(f"file:{DB}?mode=ro",uri=True,timeout=2)

def inv_role(a,b,inv):
    need=inv.get("needed_direction","NONE")
    rd="USDC_TO_USDT" if a=="USDC" and b=="USDT" else "USDT_TO_USDC" if a=="USDT" and b=="USDC" else "OTHER"
    if need=="NONE":return "NEUTRAL"
    if rd==need:return "CORRECTIVE"
    if rd!="OTHER":return "AGGRAVATING"
    return "OTHER"

def threshold(klass,role,zone):
    std=f(CFG.get("liquidity_a_min_net_edge_bps",1) if klass=="A" else CFG.get("liquidity_b_min_net_edge_bps",2))
    if zone=="CENTER" or role in ("NEUTRAL","OTHER"):return std
    vals={
      ("MILD","CORRECTIVE","A"):("flow_mild_corrective_a_bps",.5),("MILD","CORRECTIVE","B"):("flow_mild_corrective_b_bps",1),
      ("MILD","AGGRAVATING","A"):("flow_mild_aggravating_a_bps",2),("MILD","AGGRAVATING","B"):("flow_mild_aggravating_b_bps",3),
      ("STRONG","CORRECTIVE","A"):("flow_strong_corrective_a_bps",.25),("STRONG","CORRECTIVE","B"):("flow_strong_corrective_b_bps",.5),
      ("STRONG","AGGRAVATING","A"):("flow_strong_aggravating_a_bps",4),("STRONG","AGGRAVATING","B"):("flow_strong_aggravating_b_bps",5),
      ("SEVERE","CORRECTIVE","A"):("flow_severe_corrective_a_bps",.1),("SEVERE","CORRECTIVE","B"):("flow_severe_corrective_b_bps",.25),
      ("SEVERE","AGGRAVATING","A"):("flow_severe_aggravating_a_bps",7),("SEVERE","AGGRAVATING","B"):("flow_severe_aggravating_b_bps",8),
      ("HARD","CORRECTIVE","A"):("flow_hard_corrective_a_bps",0),("HARD","CORRECTIVE","B"):("flow_hard_corrective_b_bps",.1)
    }
    if zone=="HARD" and role=="AGGRAVATING":return None
    key,default=vals.get((zone,role,klass),(None,std))
    return f(CFG.get(key,default)) if key else std

def qualification(r):
    klass=r.get("liquidity_class") or r.get("class")
    n=int(r.get("survival_trials") or 0);size=f(r.get("size"))
    s100,s250,s500=f(r.get("l2_survival_100")),f(r.get("l2_survival_250")),f(r.get("l2_survival_500"))
    full=int(CFG.get("live_min_survival_trials",1000))
    if klass=="A":req=(f(CFG.get("class_a_l2_survival_100_min",.99)),f(CFG.get("class_a_l2_survival_250_min",.98)),f(CFG.get("class_a_l2_survival_500_min",.95)))
    else:req=(f(CFG.get("class_b_l2_survival_100_min",.98)),f(CFG.get("class_b_l2_survival_250_min",.95)),f(CFG.get("class_b_l2_survival_500_min",.90)))
    if n>=full and s100>=req[0] and s250>=req[1] and s500>=req[2]:return "FULL"
    if abs(size-f(CFG.get("live_trade_size_usd",10)))<1e-9 and n>=int(CFG.get("flow_probation_min_trials",500)):
        p=f(CFG.get("flow_probation_survival_min",1.0))
        if s100>=p and s250>=p and s500>=p:return "PROBATION"
    return None

def fees():
    x=getj("/api/fees?limit=1500",{}) or {}
    return {r.get("symbol"):r for r in x.get("rows",[]) if r.get("symbol")},x.get("summary") or {}

def guaranteed(r,fm):
    raw=r.get("raw_edge_bps")
    if raw is None:return r.get("expected_edge_bps")
    a,b=fm.get(r.get("symbol1"),{}),fm.get(r.get("symbol2"),{})
    if not a.get("usable_live") or not b.get("usable_live"):return None
    b1,b2=f(a.get("taker_bps")),f(b.get("taker_bps"))
    net=((1+f(raw)/1e4)*(1-b1/1e4)*(1-b2/1e4)-1)*1e4
    return net-f(CFG.get("execution_price_reserve_bps",.5))

def top10(live,inv,fm):
    rows=getj("/api/opportunities?hours=24&limit=1200&min_rank=1",[]) or []
    out=[];now=time.time()
    for r in rows:
        if f(r.get("size")) not in (10,20,25):continue
        ts=f(r.get("last_ts") or r.get("ts"))
        if ts and now-ts>1200:continue
        role=inv_role(r.get("stable_a"),r.get("stable_b"),inv)
        klass=r.get("liquidity_class") or r.get("class") or "-"
        q=qualification(r);th=threshold(klass,role,inv.get("zone","CENTER"));g=guaranteed(r,fm)
        if q=="PROBATION":
            p=f(CFG.get("flow_probation_a_min_bps",3) if klass=="A" else CFG.get("flow_probation_b_min_bps",4))
            th=max(th if th is not None else p,p)
        reasons=[]
        if role=="AGGRAVATING" and inv.get("zone")=="HARD":reasons.append("HARD: aggravant bloqué")
        if q is None:reasons.append(f"trials/survival {int(r.get('survival_trials') or 0)}")
        if th is None:reasons.append("seuil BLOCK")
        elif g is None:reasons.append("fees/edge indisponibles")
        elif f(g)<=f(th):reasons.append(f"edge {f(g):.2f} ≤ seuil {f(th):.2f}")
        source=r.get("stable_a");bal=f(((live.get("balances") or {}).get(source) or {}).get("free"));size=f(r.get("size"));reserve=f(CFG.get("live_min_stable_reserve_usd",20))
        if bal<size+reserve:reasons.append(f"{source} {bal:.2f} < {size+reserve:.2f}")
        if role!="CORRECTIVE" and abs(size-f(CFG.get("live_trade_size_usd",10)))>1e-9:reasons.append("taille non corrective")
        if role=="CORRECTIVE" and size>f(inv.get("total"))*f(CFG.get("flow_max_trade_pct",.1))+1e-9:reasons.append(">10% bag")
        if not reasons:reasons=["ÉLIGIBLE"]
        x=dict(r);x.update({"role":role,"qual":q,"threshold":th,"guaranteed_v470":g,"reasons_v470":reasons,"age_s":None if not ts else now-ts});out.append(x)
    out.sort(key=lambda x:-1e12 if x.get("guaranteed_v470") is None else f(x.get("guaranteed_v470")),reverse=True)
    return out[:10]

def session(live):
    fl=live.get("flow_inventory") or {};base=fl.get("session_baseline") or {};start=f(base.get("ts"))
    db=rodb()
    try:
        if not start:return {"closed":0,"turnover":0,"cash":0,"dust":0,"dirs":{},"recent":[]}
        rows=db.execute("""SELECT started_ts,route,requested_size,state,guaranteed_edge_bps,realized_pnl_nominal,dust_est_usd,l1_latency_ms,l2_latency_ms FROM live_cycles WHERE started_ts>=? ORDER BY started_ts DESC LIMIT 30""",(start,)).fetchall()
        recent=[{"ts":r[0],"route":r[1],"size":r[2],"state":r[3],"edge":r[4],"cash":r[5],"dust":r[6],"l1":r[7],"l2":r[8]} for r in rows]
        q="SELECT COUNT(*),COALESCE(SUM(l1_quote_spent),0),COALESCE(SUM(realized_pnl_nominal),0),COALESCE(SUM(dust_est_usd),0) FROM live_cycles WHERE started_ts>=? AND state IN ('CLOSED','CLOSED_WITH_RESIDUAL')"
        a=db.execute(q,(start,)).fetchone()
        dirs={}
        for pat,name in [("USDC>%>USDT","USDC→USDT"),("USDT>%>USDC","USDT→USDC")]:
            r=db.execute(q.replace("WHERE started_ts>=?","WHERE started_ts>=? AND route LIKE ?"),(start,pat)).fetchone()
            dirs[name]={"cycles":int(r[0] or 0),"turnover":f(r[1]),"cash":f(r[2]),"dust":f(r[3])}
        return {"closed":int(a[0] or 0),"turnover":f(a[1]),"cash":f(a[2]),"dust":f(a[3]),"dirs":dirs,"recent":recent}
    finally:db.close()

@app.get("/api/data")
def data():
    live=getj("/api/live/status",{}) or {};fl=live.get("flow_inventory") or {};inv=fl.get("inventory") or {}
    fm,fs=fees()
    return jsonify({"live":live,"flow":fl,"inv":inv,"baseline":fl.get("session_baseline") or {},"session":session(live),"top10":top10(live,inv,fm),"fees":fs,"fx":(live.get("maintenance") or {}).get("stable_fx") or {}})

@app.get("/")
def index():return render_template("index.html")

if __name__=="__main__":serve(app,host="0.0.0.0",port=PORT,threads=4)
