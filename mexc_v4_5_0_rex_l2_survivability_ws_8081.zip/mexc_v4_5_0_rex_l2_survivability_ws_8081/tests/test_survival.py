import tempfile,time
from types import SimpleNamespace
import pytest
from v4rex.core import Store,DepthBook,L
from v4rex.db import DB
from v4rex.survival import L2SurvivalTracker


def cfg():return {'survival_horizons_ms':[50,100,150,250,500],'survival_trial_cooldown_ms':0,'survival_min_samples':2,'class_a_l2_survival_100_min':.99,'class_a_l2_survival_250_min':.98,'class_a_l2_survival_500_min':.95,'class_b_l2_survival_100_min':.98,'class_b_l2_survival_250_min':.95,'class_b_l2_survival_500_min':.90}

def depth(sym,bids,asks):
    n=time.monotonic_ns();w=time.time()*1000
    return DepthBook(sym,tuple(L(*x) for x in bids),tuple(L(*x) for x in asks),1,int(w-5),w,n,n)

def eligible(route='USDT>X>USDC'):
    return SimpleNamespace(survival_eligible=True,route=route,token='X',stable_a='USDT',stable_b='USDC',symbol1='XUSDT',symbol2='XUSDC',liquidity_class='A',size=10.0,fraction=.25,base_qty=1.0,l1_cost_quote=10.0,vwap2=10.2,net_edge_bps=3.0,min_quote_volume_24h=2_000_000,l1_reserve_x=20,l2_reserve_x=20,return_reserve_x=20)

def test_l2_survival_completion_and_return_are_separate():
    f=tempfile.NamedTemporaryFile(suffix='.db',delete=False);f.close();db=DB(f.name);s=Store();s.put_depth(depth('XUSDT',[(9.99,100)],[(10,100)]));s.put_depth(depth('XUSDC',[(10.2,100)],[(10.3,100)]));t=L2SurvivalTracker(cfg(),s,db);e=eligible();assert t.maybe_start(e)
    # Force trial old enough to cover all horizons without sleeping.
    for tr in t.active.values():tr.start_ns-=600_000_000
    assert t.tick()==1
    st=t.stats(e.route,e.size);assert st['trials']==1;assert st['l2_survival_100']==1;assert st['return_survival_100']==1

def test_robust_gate_uses_l2_not_return():
    f=tempfile.NamedTemporaryFile(suffix='.db',delete=False);f.close();t=L2SurvivalTracker(cfg(),Store(),DB(f.name));a=t.total_agg[('R',10.0)];a['trials']=2
    for h in (50,100,150,250,500):a[f'l2_ok_{h}']=2;a[f'return_ok_{h}']=0
    ok,reason,_=t.robust('R',10,'A');assert ok and reason=='ROBUST'

def test_class_b_thresholds_can_be_less_strict_than_a():
    f=tempfile.NamedTemporaryFile(suffix='.db',delete=False);f.close();t=L2SurvivalTracker(cfg(),Store(),DB(f.name));a=t.total_agg[('R',10.0)];a['trials']=100
    for h in (50,150):a[f'l2_ok_{h}']=100
    a['l2_ok_100']=98;a['l2_ok_250']=95;a['l2_ok_500']=90
    assert not t.robust('R',10,'A')[0];assert t.robust('R',10,'B')[0]
