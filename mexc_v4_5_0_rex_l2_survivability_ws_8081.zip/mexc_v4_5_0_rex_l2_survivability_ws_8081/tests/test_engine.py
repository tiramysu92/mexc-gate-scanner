from types import SimpleNamespace
import time, tempfile
import pytest
from v4rex.core import Store,BBO,DepthBook,L
from v4rex.engine import Engine
from v4rex.db import DB

class Clock: offset_ms=0
class Collector:
    def __init__(self): self.clock=Clock();self.touched=[];self.depth=SimpleNamespace(status=lambda:{'symbols':[]})
    def touch_depth(self,s): self.touched.append(tuple(s))
class Rule:
    def __init__(self,f,vol=2_000_000):self.taker_commission=f;self.quote_volume_24h=vol
class Uni:
    def __init__(self):
        self.routes=[SimpleNamespace(route='USDT>X>USDC',token='X',stable_a='USDT',stable_b='USDC',symbol1='XUSDT',symbol2='XUSDC')]
        self.by_symbol={'XUSDT':Rule('0.0005'),'XUSDC':Rule('0.0005')}

def cfg():return {'raw_watch_threshold_bps':0,'test_sizes_usd':[10],'depth_fractions':[.25,1.0],'fee_bps_default':5,'qualification_fee_bps_per_leg':5,'qualification_depth_fraction':.25,'liquidity_a_min_quote_volume_24h':1_000_000,'liquidity_b_min_quote_volume_24h':100_000,'liquidity_a_min_net_edge_bps':1,'liquidity_b_min_net_edge_bps':2,'liquidity_l1_reserve_multiple':5,'liquidity_l2_reserve_multiple':10,'survival_min_samples':20,'max_transport_age_ms':500,'max_decode_lag_ms':100,'opportunity_cooldown_s':5,'aggregate_flush_s':999}
def states(store,bid2=10.2):
    n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10)
    store.put_bbo(BBO('XUSDT',9.9,10,10,10,1,send,wall,n,n,1));store.put_bbo(BBO('XUSDC',bid2,10,bid2+.1,10,1,send,wall,n,n,2))

def mk():
    s=Store();states(s);td=tempfile.NamedTemporaryFile(suffix='.db',delete=False);td.close();c=Collector();e=Engine(cfg(),s,DB(td.name),Uni(),c);return e,s,c

def test_quick_positive():
    e,s,c=mk();assert e._quick(e.universe.routes[0])==pytest.approx(200)

def test_positive_touches_depth():
    e,s,c=mk();e._process(e.universe.routes);assert c.touched

def test_no_depth_means_warming():
    e,s,c=mk();n,status=e._depth_eval(e.universe.routes[0],100);assert n==0 and status=='WARMING'

def test_synced_depth():
    e,s,c=mk();n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10);s.put_depth(DepthBook('XUSDT',(L(9.9,10),),(L(10,10),),1,send,wall,n,n,1));s.put_depth(DepthBook('XUSDC',(L(10.2,10),),(L(10.3,10),),1,send,wall,n,n,2));ok,_,_=e._depth_sync(e.universe.routes[0]);assert ok

def test_unsynced_depth():
    e,s,c=mk();n=time.monotonic_ns();s.put_depth(DepthBook('XUSDT',(L(9.9,10),),(L(10.01,10),),1,None,None,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,10),),(L(10.3,10),),1,None,None,n,n));ok,_,_=e._depth_sync(e.universe.routes[0]);assert not ok

def test_evaluate_fee_net():
    e,s,c=mk();n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10);s.put_depth(DepthBook('XUSDT',(L(9.9,10),),(L(10,10),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,10),),(L(10.3,10),),1,send,wall,n,n));x=e._evaluate(e.universe.routes[0],10,1);assert x.raw_edge_bps==pytest.approx(200);assert x.net_edge_bps<200;assert x.depth_synced

def test_class_a_candidate_before_survival_stats():
    e,s,c=mk();n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10);s.put_depth(DepthBook('XUSDT',(L(9.9,100),),(L(10,100),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,100),),(L(10.3,100),),1,send,wall,n,n));x=e._evaluate(e.universe.routes[0],10,.25);assert x.liquidity_class=='A';assert x.survival_eligible;assert not x.accepted;assert x.qualification_state=='SURVIVAL_PENDING'

def test_conservative_fee_floor_is_5_plus_5():
    e,s,c=mk();e.universe.by_symbol['XUSDT'].taker_commission='0';e.universe.by_symbol['XUSDC'].taker_commission='0';n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10);s.put_depth(DepthBook('XUSDT',(L(9.9,100),),(L(10,100),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,100),),(L(10.3,100),),1,send,wall,n,n));x=e._evaluate(e.universe.routes[0],10,.25);assert x.fee_bps_leg1==5;assert x.fee_bps_leg2==5

def test_bbo_scan_direct_shared_arrays_path():
    from v4rex.mp_bbo import SharedBBO, _write
    h=SharedBBO(['XUSDT','XUSDC'])
    rn=time.monotonic_ns(); wall=time.time()*1000
    _write(h.args(),h.index['XUSDT'],9.9,10,10.0,10,1,int(wall-10),wall,rn,rn,1)
    _write(h.args(),h.index['XUSDC'],10.2,10,10.3,10,1,int(wall-10),wall,rn,rn,2)
    provider=SimpleNamespace(shared=h,get_bbo=h.get_bbo,snapshot_bbo=h.snapshot_bbo)
    s=Store(bbo_provider=provider)
    td=tempfile.NamedTemporaryFile(suffix='.db',delete=False);td.close();c=Collector();e=Engine(cfg(),s,DB(td.name),Uni(),c)
    assert e._fast_shared is h
    assert e.bbo_scan_once() == 1
    assert c.touched[-1] == ('XUSDT','XUSDC')

def test_class_a_edge_threshold_strictly_over_1bp():
    e,s,c=mk();states(s,bid2=10.0111);n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10)
    s.put_depth(DepthBook('XUSDT',(L(9.9,100),),(L(10,100),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.0111,100),),(L(10.1111,100),),1,send,wall,n,n))
    x=e._evaluate(e.universe.routes[0],10,.25);assert x.liquidity_class=='A';assert x.net_edge_bps>1;assert x.survival_eligible

def test_class_b_requires_over_2bp():
    e,s,c=mk();states(s,bid2=10.0125);e.universe.by_symbol['XUSDT'].quote_volume_24h=200_000;e.universe.by_symbol['XUSDC'].quote_volume_24h=200_000;n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10)
    s.put_depth(DepthBook('XUSDT',(L(9.9,100),),(L(10,100),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.0125,100),),(L(10.1125,100),),1,send,wall,n,n))
    x=e._evaluate(e.universe.routes[0],10,.25);assert x.liquidity_class=='B';assert x.net_edge_bps>2;assert x.survival_eligible

def test_class_c_never_survival_eligible_even_huge_edge():
    e,s,c=mk();e.universe.by_symbol['XUSDT'].quote_volume_24h=5_000;e.universe.by_symbol['XUSDC'].quote_volume_24h=5_000;n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10)
    s.put_depth(DepthBook('XUSDT',(L(9.9,100),),(L(10,100),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(12,100),),(L(12.1,100),),1,send,wall,n,n))
    x=e._evaluate(e.universe.routes[0],10,.25);assert x.net_edge_bps>1000;assert x.liquidity_class=='C';assert not x.survival_eligible;assert not x.accepted

def test_v45_opportunity_db_contract_with_liquidity_fields():
    e,s,c=mk();n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10)
    s.put_depth(DepthBook('XUSDT',(L(9.9,100),),(L(10,100),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,100),),(L(10.3,100),),1,send,wall,n,n))
    e._depth_eval(e.universe.routes[0],200);e.flush(True)
    rows=e.db.recent_opportunities(limit=10)
    assert rows and rows[0]['liquidity_class']=='A' and rows[0]['l2_reserve_x']>=10

def test_class_a_becomes_robust_only_after_l2_survival_proof():
    e,s,c=mk();states(s,bid2=10.2);n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10)
    s.put_depth(DepthBook('XUSDT',(L(9.9,100),),(L(10,100),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,100),),(L(10.3,100),),1,send,wall,n,n))
    a=e.survival.total_agg[('USDT>X>USDC',10.0)];a['trials']=20
    for h in (50,100,150,250,500):a[f'l2_ok_{h}']=20
    x=e._evaluate(e.universe.routes[0],10,.25);assert x.accepted;assert x.qualification_state=='ROBUST_A'
