# CHANGELOG — V4.5.0 L2 Survivability

- Base technique V4.4 conservée : full universe Base100 + Fast10 + Depth20 adaptatif.
- Qualification conservative 5 bp + 5 bp.
- Classe A : min 1M$/24h, NET >1 bp.
- Classe B : min 100k$/24h, NET >2 bp.
- Classe C : jamais qualifiée ; `RISKY_HIGH_EDGE` uniquement.
- Qualification Depth fixe à 25 %.
- Réserve L1 >=5x ; **réserve L2 >=10x**.
- Nouveau moteur L2 survivability : 50/100/150/250/500 ms.
- RETURN mesuré comme secours, jamais utilisé pour faire passer le gate ROBUST.
- Statuts : A_CANDIDATE / B_CANDIDATE / ROBUST_A / ROBUST_B / RISKY_HIGH_EDGE.
- Seuils TEST et futur Micro-Live centralisés dans le même `config.json`.
- Nouvelles tables SQLite `survival_trials` et `survival_aggregates`.
- Nouveaux endpoints `/api/survival` et `/api/survival-trials`.
- Dashboard centré sur liquidité, L2 reserve et L2 survival ; affichage bp + edge décimal.
