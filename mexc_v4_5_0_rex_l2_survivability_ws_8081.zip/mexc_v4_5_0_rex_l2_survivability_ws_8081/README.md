# V4.5.0-REX — L2 Survivability / Robust Qualification — SHADOW ONLY

V4.5 conserve l'architecture réseau V4.4 qui a validé le Free Tier 2 vCPU : full universe BBO 100 ms, Fast Lane 10 ms dynamique, Depth 20 adaptatif. Le changement est économique et risque : **la jambe 2 devient le critère central de qualification**.

## Doctrine

Le bot ne cherche plus d'abord les plus gros edges. Il cherche des cycles **terminables avec une très forte probabilité**.

Ordre de décision :
1. edge après frais conservateurs ;
2. classe de liquidité ;
3. profondeur L1 ;
4. profondeur **L2 renforcée** ;
5. mesure de survivabilité L2 dans le temps ;
6. qualification ROBUST seulement lorsque la statistique L2 est suffisante.

Le RETURN/unwind est mesuré comme filet de sécurité, mais **ne pilote pas l'admission**. La priorité est la finalisation de la jambe 2.

## Frais de qualification

Même si `exchangeInfo` affiche moins, la qualification utilise au minimum :
- L1 : 5 bp = 0,05 % ;
- L2 : 5 bp = 0,05 %.

Donc TEST et futur Micro-Live utilisent la même hypothèse conservative, sauf si un coût réel supérieur est constaté.

## Classes de liquidité et seuils TEST = Micro-Live

### Classe A — très liquide
- volume quote 24 h de la jambe la moins liquide >= **1 000 000 $** ;
- NET edge **> 1 bp** (`edge > 0.0001`) ;
- réserve L1 >= 5x la taille ;
- réserve L2 >= 10x la quantité à revendre.

### Classe B — liquide
- volume quote 24 h >= **100 000 $** ;
- NET edge **> 2 bp** (`edge > 0.0002`) ;
- réserve L1 >= 5x ;
- réserve L2 >= 10x.

### Classe C — fragile
- volume < 100 000 $/24 h ;
- **jamais qualifiée**, même avec un edge énorme ;
- visible comme `RISKY HIGH EDGE` uniquement pour analyse.

Ces seuils sont une source unique de configuration : le futur Micro-Live ne les assouplira pas.

## Depth de qualification

La décision robuste utilise **25 % de la profondeur affichée**. Les autres fractions 10/15/20/33/50/75/100 % restent collectées pour analyse mais ne qualifient pas un trade.

## L2 Survivability

Quand une opportunité A/B passe les gates edge + liquidité + profondeur, V4.5 lance un trial Shadow avec **exactement la quantité de token qui aurait été achetée en L1**.

La L2 est re-testée à :
- T+50 ms
- T+100 ms
- T+150 ms
- T+250 ms
- T+500 ms

Pour chaque horizon :
- quantité L2 entièrement vendable ou non ;
- slippage défavorable observé ;
- RETURN également mesuré mais non utilisé pour accepter le trade.

## Gate ROBUST initial

Après au moins 20 trials route+taille :

Classe A :
- L2 survival 100 ms >= 99 % ;
- 250 ms >= 98 % ;
- 500 ms >= 95 %.

Classe B :
- 100 ms >= 98 % ;
- 250 ms >= 95 % ;
- 500 ms >= 90 %.

Avant 20 observations : `A_CANDIDATE` / `B_CANDIDATE`. Ensuite : `ROBUST_A` / `ROBUST_B` si les seuils sont satisfaits.

## Interface 8081

Le tableau principal affiche : route, classe A/B/C, taille, Raw bp, frais conservateurs, Net bp, **edge décimal**, volume 24 h minimum, réserves L1/L2/RETURN, nombre de trials, L2 survival 100/250/500 ms et verdict.

Un tableau dédié montre la survivabilité L2 par route/taille. Un autre conserve l'audit Fast10 vs Base100. Toute la télémétrie WS/Depth reste accessible.

## Installation

```bash
./install.sh
./start.sh
sleep 120
./smoke_check.sh
```

## Export

```bash
source .venv/bin/activate
python export_run.py
```

L'export V4.5 inclut la DB, les opportunités, les agrégats L2 survivability, les trials récents, les profils et l'audit Fast Lane.
