from __future__ import annotations
import json, os, sqlite3, threading, time

SCHEMA='''
PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS universe_symbols(symbol TEXT PRIMARY KEY,base TEXT,quote TEXT,status TEXT,spot_allowed INT,api_default INT,activity_score REAL,quote_volume_24h REAL,trade_count_24h REAL,taker_commission TEXT,trade_side_type TEXT);
CREATE TABLE IF NOT EXISTS market_samples(id INTEGER PRIMARY KEY,ts REAL,symbol TEXT,ws_id INT,ready INT,bid REAL,ask REAL,spread_bps REAL,transport_ms REAL,decode_ms REAL,inactivity_ms REAL,depth_hot INT,depth_ready INT,depth_ws_id INT,depth_transport_ms REAL,depth_decode_ms REAL,version INT);
CREATE INDEX IF NOT EXISTS ix_market_ts ON market_samples(ts); CREATE INDEX IF NOT EXISTS ix_market_sym ON market_samples(symbol,ts);
CREATE TABLE IF NOT EXISTS collector_errors(id INTEGER PRIMARY KEY,ts REAL,kind TEXT,symbol TEXT,detail TEXT,extra_json TEXT);
CREATE TABLE IF NOT EXISTS reason_aggregates(reason TEXT PRIMARY KEY,count INT,last_ts REAL);
CREATE TABLE IF NOT EXISTS route_activity(route TEXT PRIMARY KEY,token TEXT,stable_a TEXT,stable_b TEXT,quick_scans INT,bbo_positive INT,max_bbo_bps REAL,last_bbo_bps REAL,last_ts REAL);
CREATE TABLE IF NOT EXISTS candidate_windows(id INTEGER PRIMARY KEY,bucket_ts REAL,first_ts REAL,last_ts REAL,route TEXT,token TEXT,stable_a TEXT,stable_b TEXT,observations INT,max_bbo_bps REAL,depth_ready_obs INT,depth_synced_obs INT,status TEXT,warmup_ms REAL,UNIQUE(route,bucket_ts));
CREATE INDEX IF NOT EXISTS ix_candidate_ts ON candidate_windows(last_ts DESC);
CREATE TABLE IF NOT EXISTS route_profiles(route TEXT,token TEXT,stable_a TEXT,stable_b TEXT,size REAL,fraction REAL,samples INT,data_valid INT,timing_valid INT,raw_positive INT,net_positive INT,qualified INT,sum_raw REAL,sum_net REAL,sum_expected REAL,max_raw REAL,max_net REAL,max_expected REAL,sum_cov1 REAL,sum_cov2 REAL,sum_traversable REAL,max_traversable REAL,last_ts REAL,last_reason TEXT,PRIMARY KEY(route,size,fraction));
CREATE TABLE IF NOT EXISTS opportunity_hits(id INTEGER PRIMARY KEY,bucket_ts REAL,first_ts REAL,last_ts REAL,route TEXT,token TEXT,stable_a TEXT,stable_b TEXT,symbol1 TEXT,symbol2 TEXT,observations INT,class TEXT,class_rank INT,score REAL,size REAL,fraction REAL,bbo_raw_bps REAL,raw_edge_bps REAL,fee_bps_leg1 REAL,fee_bps_leg2 REAL,public_fee_bps_leg1 REAL,public_fee_bps_leg2 REAL,liquidity_class TEXT,min_quote_volume_24h REAL,l1_reserve_x REAL,l2_reserve_x REAL,return_reserve_x REAL,survival_trials INT,l2_survival_100 REAL,l2_survival_250 REAL,l2_survival_500 REAL,qualification_state TEXT,net_edge_bps REAL,expected_edge_bps REAL,potential_pnl_usd REAL,cov1 REAL,cov2 REAL,max_traversable_quote REAL,vwap1 REAL,vwap2 REAL,bbo_transport1_ms REAL,bbo_transport2_ms REAL,bbo_decode1_ms REAL,bbo_decode2_ms REAL,depth_transport1_ms REAL,depth_transport2_ms REAL,depth_decode1_ms REAL,depth_decode2_ms REAL,depth_synced INT,timing_valid INT,accepted INT,reasons TEXT,UNIQUE(route,bucket_ts));
CREATE INDEX IF NOT EXISTS ix_opp_ts ON opportunity_hits(last_ts DESC); CREATE INDEX IF NOT EXISTS ix_opp_route ON opportunity_hits(route,last_ts DESC);
CREATE TABLE IF NOT EXISTS fast_lane_audit(route TEXT PRIMARY KEY,token TEXT,stable_a TEXT,stable_b TEXT,checks INT,base_positive INT,fast_positive INT,fast_only_samples INT,fast_only_events INT,max_fast_only_bps REAL,last_base_bps REAL,last_fast_bps REAL,last_ts REAL);
CREATE TABLE IF NOT EXISTS health_samples(id INTEGER PRIMARY KEY,ts REAL,uptime_s REAL,bbo_ready INT,total_symbols INT,bbo_ws_connected INT,bbo_ws_total INT,bbo_msg_rate REAL,bbo_rx_queue INT,bbo_rx_age_ms REAL,bbo_decode_p95 REAL,hot_symbols INT,depth_ws_connected INT,depth_ws_total INT,depth_queue INT,cpu_pct REAL,rss_mb REAL,db_mb REAL,update_queue INT,update_drops INT);
CREATE TABLE IF NOT EXISTS survival_trials(id INTEGER PRIMARY KEY,trial_id TEXT UNIQUE,start_ts REAL,done_ts REAL,route TEXT,token TEXT,stable_a TEXT,stable_b TEXT,liquidity_class TEXT,size REAL,fraction REAL,base_qty REAL,l1_cost_quote REAL,planned_l2_vwap REAL,initial_net_bps REAL,min_quote_volume_24h REAL,l1_reserve_x REAL,l2_reserve_x REAL,return_reserve_x REAL,l2_ok_50 INT,return_ok_50 INT,l2_slippage_bps_50 REAL,return_loss_bps_50 REAL,l2_ok_100 INT,return_ok_100 INT,l2_slippage_bps_100 REAL,return_loss_bps_100 REAL,l2_ok_150 INT,return_ok_150 INT,l2_slippage_bps_150 REAL,return_loss_bps_150 REAL,l2_ok_250 INT,return_ok_250 INT,l2_slippage_bps_250 REAL,return_loss_bps_250 REAL,l2_ok_500 INT,return_ok_500 INT,l2_slippage_bps_500 REAL,return_loss_bps_500 REAL);
CREATE INDEX IF NOT EXISTS ix_survival_route ON survival_trials(route,size,done_ts DESC); CREATE INDEX IF NOT EXISTS ix_survival_ts ON survival_trials(done_ts DESC);
CREATE TABLE IF NOT EXISTS survival_aggregates(route TEXT,size REAL,trials INT,l2_ok_50 INT,return_ok_50 INT,l2_slip_sum_50 REAL,l2_slip_max_50 REAL,return_loss_sum_50 REAL,return_loss_max_50 REAL,l2_ok_100 INT,return_ok_100 INT,l2_slip_sum_100 REAL,l2_slip_max_100 REAL,return_loss_sum_100 REAL,return_loss_max_100 REAL,l2_ok_150 INT,return_ok_150 INT,l2_slip_sum_150 REAL,l2_slip_max_150 REAL,return_loss_sum_150 REAL,return_loss_max_150 REAL,l2_ok_250 INT,return_ok_250 INT,l2_slip_sum_250 REAL,l2_slip_max_250 REAL,return_loss_sum_250 REAL,return_loss_max_250 REAL,l2_ok_500 INT,return_ok_500 INT,l2_slip_sum_500 REAL,l2_slip_max_500 REAL,return_loss_sum_500 REAL,return_loss_max_500 REAL,last_ts REAL,PRIMARY KEY(route,size));
'''

class DB:
    def __init__(self,path):
        self.path=path;self.lock=threading.RLock()
        with self.conn() as c:c.executescript(SCHEMA)
    def conn(self):
        c=sqlite3.connect(self.path,timeout=30);c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA synchronous=NORMAL');c.execute('PRAGMA busy_timeout=30000');return c
    def set_meta(self,k,v):
        with self.lock,self.conn() as c:c.execute('INSERT INTO meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(k,json.dumps(v,separators=(',',':'),default=str)))
    def save_universe(self,symbols):
        rows=[(s.symbol,s.base,s.quote,s.status,int(bool(s.spot_allowed)),int(bool(s.api_default)),float(s.activity_score or 1),s.quote_volume_24h,s.trade_count_24h,s.taker_commission,s.trade_side_type) for s in symbols]
        with self.lock,self.conn() as c:c.executemany('INSERT OR REPLACE INTO universe_symbols VALUES(?,?,?,?,?,?,?,?,?,?,?)',rows)
    def log_collector_error(self,e):
        known={'ts','kind','symbol','detail'};extra={k:v for k,v in e.items() if k not in known}
        with self.lock,self.conn() as c:c.execute('INSERT INTO collector_errors(ts,kind,symbol,detail,extra_json) VALUES(?,?,?,?,?)',(e.get('ts',time.time()),e.get('kind'),e.get('symbol'),e.get('detail'),json.dumps(extra,default=str)))
    def add_market_samples(self,rows):
        if not rows:return
        ts=time.time();vals=[(ts,x['symbol'],x.get('ws_id'),int(bool(x.get('ready'))),x.get('bid'),x.get('ask'),x.get('spread_bps'),x.get('transport_age_ms'),x.get('decode_lag_ms'),x.get('inactivity_ms'),int(bool(x.get('depth_hot'))),int(bool(x.get('depth_ready'))),x.get('depth_ws_id'),x.get('depth_transport_ms'),x.get('depth_decode_lag_ms'),x.get('version')) for x in rows]
        with self.lock,self.conn() as c:c.executemany('INSERT INTO market_samples VALUES(NULL,'+','.join('?' for _ in vals[0])+')',vals)
    def add_health(self,x):
        cols=['uptime_s','bbo_ready','total_symbols','bbo_ws_connected','bbo_ws_total','bbo_msg_rate','bbo_rx_queue','bbo_rx_age_ms','bbo_decode_p95','hot_symbols','depth_ws_connected','depth_ws_total','depth_queue','cpu_pct','rss_mb','db_mb','update_queue','update_drops'];vals=[time.time()]+[x.get(k) for k in cols]
        with self.lock,self.conn() as c:c.execute('INSERT INTO health_samples VALUES(NULL,'+','.join('?' for _ in vals)+')',vals)
    def upsert_route_activity(self,rows):
        if not rows:return
        vals=[(x['route'],x['token'],x['stable_a'],x['stable_b'],x['quick_scans'],x['bbo_positive'],x.get('max_bbo_bps'),x.get('last_bbo_bps'),x['last_ts']) for x in rows]
        sql='''INSERT INTO route_activity VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(route) DO UPDATE SET quick_scans=quick_scans+excluded.quick_scans,bbo_positive=bbo_positive+excluded.bbo_positive,max_bbo_bps=CASE WHEN max_bbo_bps IS NULL THEN excluded.max_bbo_bps WHEN excluded.max_bbo_bps IS NULL THEN max_bbo_bps ELSE MAX(max_bbo_bps,excluded.max_bbo_bps) END,last_bbo_bps=excluded.last_bbo_bps,last_ts=excluded.last_ts'''
        with self.lock,self.conn() as c:c.executemany(sql,vals)
    def upsert_candidates(self,rows):
        if not rows:return
        cols=['bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','observations','max_bbo_bps','depth_ready_obs','depth_synced_obs','status','warmup_ms'];vals=[tuple(x.get(k) for k in cols) for x in rows]
        sql='''INSERT INTO candidate_windows(%s) VALUES(%s) ON CONFLICT(route,bucket_ts) DO UPDATE SET observations=observations+excluded.observations,last_ts=MAX(last_ts,excluded.last_ts),first_ts=MIN(first_ts,excluded.first_ts),max_bbo_bps=MAX(max_bbo_bps,excluded.max_bbo_bps),depth_ready_obs=depth_ready_obs+excluded.depth_ready_obs,depth_synced_obs=depth_synced_obs+excluded.depth_synced_obs,status=excluded.status,warmup_ms=CASE WHEN warmup_ms IS NULL THEN excluded.warmup_ms WHEN excluded.warmup_ms IS NULL THEN warmup_ms ELSE MIN(warmup_ms,excluded.warmup_ms) END'''%(','.join(cols),','.join('?' for _ in cols))
        with self.lock,self.conn() as c:c.executemany(sql,vals)
    def upsert_route_profiles(self,rows):
        if not rows:return
        vals=[(r['route'],r['token'],r['stable_a'],r['stable_b'],r['size'],r['fraction'],r['samples'],r['data_valid'],r['timing_valid'],r['raw_positive'],r['net_positive'],r['qualified'],r['sum_raw'],r['sum_net'],r['sum_expected'],r.get('max_raw'),r.get('max_net'),r.get('max_expected'),r['sum_cov1'],r['sum_cov2'],r['sum_traversable'],r.get('max_traversable'),r['last_ts'],r.get('last_reason')) for r in rows]
        sql='''INSERT INTO route_profiles VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(route,size,fraction) DO UPDATE SET samples=samples+excluded.samples,data_valid=data_valid+excluded.data_valid,timing_valid=timing_valid+excluded.timing_valid,raw_positive=raw_positive+excluded.raw_positive,net_positive=net_positive+excluded.net_positive,qualified=qualified+excluded.qualified,sum_raw=sum_raw+excluded.sum_raw,sum_net=sum_net+excluded.sum_net,sum_expected=sum_expected+excluded.sum_expected,max_raw=CASE WHEN max_raw IS NULL THEN excluded.max_raw ELSE MAX(max_raw,excluded.max_raw) END,max_net=CASE WHEN max_net IS NULL THEN excluded.max_net ELSE MAX(max_net,excluded.max_net) END,max_expected=CASE WHEN max_expected IS NULL THEN excluded.max_expected ELSE MAX(max_expected,excluded.max_expected) END,sum_cov1=sum_cov1+excluded.sum_cov1,sum_cov2=sum_cov2+excluded.sum_cov2,sum_traversable=sum_traversable+excluded.sum_traversable,max_traversable=CASE WHEN max_traversable IS NULL THEN excluded.max_traversable ELSE MAX(max_traversable,excluded.max_traversable) END,last_ts=excluded.last_ts,last_reason=excluded.last_reason'''
        with self.lock,self.conn() as c:c.executemany(sql,vals)
    def add_reason_counts(self,counts):
        if not counts:return
        ts=time.time()
        with self.lock,self.conn() as c:c.executemany('INSERT INTO reason_aggregates VALUES(?,?,?) ON CONFLICT(reason) DO UPDATE SET count=count+excluded.count,last_ts=excluded.last_ts',[(k,int(v),ts) for k,v in counts.items()])
    def upsert_opportunity_hits(self,hits):
        if not hits:return
        cols=['bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','symbol1','symbol2','observations','class','class_rank','score','size','fraction','bbo_raw_bps','raw_edge_bps','fee_bps_leg1','fee_bps_leg2','public_fee_bps_leg1','public_fee_bps_leg2','liquidity_class','min_quote_volume_24h','l1_reserve_x','l2_reserve_x','return_reserve_x','survival_trials','l2_survival_100','l2_survival_250','l2_survival_500','qualification_state','net_edge_bps','expected_edge_bps','potential_pnl_usd','cov1','cov2','max_traversable_quote','vwap1','vwap2','bbo_transport1_ms','bbo_transport2_ms','bbo_decode1_ms','bbo_decode2_ms','depth_transport1_ms','depth_transport2_ms','depth_decode1_ms','depth_decode2_ms','depth_synced','timing_valid','accepted','reasons'];vals=[tuple(h.get(k) for k in cols) for h in hits]
        best=[c for c in cols if c not in {'bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','symbol1','symbol2','observations'}];upd=','.join(f'{c}=CASE WHEN excluded.score>score THEN excluded.{c} ELSE {c} END' for c in best)
        sql=f'''INSERT INTO opportunity_hits({','.join(cols)}) VALUES({','.join('?' for _ in cols)}) ON CONFLICT(route,bucket_ts) DO UPDATE SET observations=observations+excluded.observations,last_ts=MAX(last_ts,excluded.last_ts),first_ts=MIN(first_ts,excluded.first_ts),{upd}'''
        with self.lock,self.conn() as c:c.executemany(sql,vals)
    def recent_opportunities(self,limit=150,hours=24,min_class_rank=1):
        since=time.time()-hours*3600;cols=['bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','observations','class','class_rank','size','fraction','bbo_raw_bps','raw_edge_bps','fee_bps_leg1','fee_bps_leg2','public_fee_bps_leg1','public_fee_bps_leg2','liquidity_class','min_quote_volume_24h','l1_reserve_x','l2_reserve_x','return_reserve_x','survival_trials','l2_survival_100','l2_survival_250','l2_survival_500','qualification_state','net_edge_bps','expected_edge_bps','potential_pnl_usd','cov1','cov2','max_traversable_quote','vwap1','vwap2','bbo_transport1_ms','bbo_transport2_ms','bbo_decode1_ms','bbo_decode2_ms','depth_transport1_ms','depth_transport2_ms','depth_decode1_ms','depth_decode2_ms','depth_synced','timing_valid','accepted','reasons']
        with self.conn() as c:rows=c.execute('SELECT '+','.join(cols)+' FROM opportunity_hits WHERE last_ts>=? AND class_rank>=? ORDER BY last_ts DESC,class_rank DESC,score DESC LIMIT ?',(since,int(min_class_rank),int(limit))).fetchall()
        return [dict(zip(cols,r)) for r in rows]
    def recent_candidates(self,limit=100,hours=1):
        since=time.time()-hours*3600;cols=['bucket_ts','first_ts','last_ts','route','token','stable_a','stable_b','observations','max_bbo_bps','depth_ready_obs','depth_synced_obs','status','warmup_ms']
        with self.conn() as c:rows=c.execute('SELECT '+','.join(cols)+' FROM candidate_windows WHERE last_ts>=? ORDER BY last_ts DESC,max_bbo_bps DESC LIMIT ?',(since,int(limit))).fetchall()
        return [dict(zip(cols,r)) for r in rows]
    def route_viability(self,hours=24,limit=150):
        since=time.time()-hours*3600
        with self.conn() as c:
            rows=c.execute('''SELECT route,token,stable_a,stable_b,count(*),sum(observations),sum(CASE WHEN accepted=1 THEN 1 ELSE 0 END),sum(CASE WHEN class_rank>=2 THEN 1 ELSE 0 END),max(raw_edge_bps),max(net_edge_bps),max(expected_edge_bps),avg(expected_edge_bps),max(potential_pnl_usd),max(last_ts) FROM opportunity_hits WHERE last_ts>=? GROUP BY route ORDER BY 7 DESC,8 DESC,11 DESC LIMIT ?''',(since,int(limit))).fetchall();out=[]
            for r in rows:
                best=c.execute('SELECT class,size,fraction,raw_edge_bps,net_edge_bps,expected_edge_bps,potential_pnl_usd,max_traversable_quote,timing_valid,reasons FROM opportunity_hits WHERE route=? AND last_ts>=? ORDER BY class_rank DESC,score DESC LIMIT 1',(r[0],since)).fetchone();out.append({'route':r[0],'token':r[1],'stable_a':r[2],'stable_b':r[3],'windows_5s':r[4],'observations':r[5] or 0,'qualified_windows':r[6] or 0,'net_positive_windows':r[7] or 0,'max_raw_bps':r[8],'max_net_bps':r[9],'max_expected_bps':r[10],'avg_expected_bps':r[11],'max_potential_pnl_usd':r[12],'last_ts':r[13],'best_class':best[0] if best else None,'best_size':best[1] if best else None,'best_fraction':best[2] if best else None,'best_raw_bps':best[3] if best else None,'best_net_bps':best[4] if best else None,'best_expected_bps':best[5] if best else None,'best_potential_pnl_usd':best[6] if best else None,'best_traversable':best[7] if best else None,'best_timing_valid':best[8] if best else None,'best_reasons':best[9] if best else None})
        return out
    def route_activity(self,limit=250):
        with self.conn() as c:rows=c.execute('SELECT route,token,stable_a,stable_b,quick_scans,bbo_positive,max_bbo_bps,last_bbo_bps,last_ts,CASE WHEN quick_scans>0 THEN 100.0*bbo_positive/quick_scans ELSE 0 END FROM route_activity ORDER BY bbo_positive DESC,max_bbo_bps DESC LIMIT ?',(int(limit),)).fetchall()
        cols=['route','token','stable_a','stable_b','quick_scans','bbo_positive','max_bbo_bps','last_bbo_bps','last_ts','bbo_positive_pct'];return [dict(zip(cols,r)) for r in rows]
    def profile_summary(self,limit=150):
        with self.conn() as c:rows=c.execute('SELECT route,token,stable_a,stable_b,size,fraction,samples,data_valid,timing_valid,raw_positive,net_positive,qualified,CASE WHEN samples>0 THEN sum_raw/samples END,CASE WHEN samples>0 THEN sum_net/samples END,CASE WHEN samples>0 THEN sum_expected/samples END,max_raw,max_net,max_expected,CASE WHEN samples>0 THEN sum_cov1/samples END,CASE WHEN samples>0 THEN sum_cov2/samples END,CASE WHEN samples>0 THEN sum_traversable/samples END,max_traversable,last_ts,last_reason FROM route_profiles ORDER BY max_expected DESC,max_net DESC LIMIT ?',(int(limit),)).fetchall()
        cols=['route','token','stable_a','stable_b','size','fraction','samples','data_valid','timing_valid','raw_positive','net_positive','qualified','avg_raw_bps','avg_net_bps','avg_expected_bps','max_raw_bps','max_net_bps','max_expected_bps','avg_cov1','avg_cov2','avg_traversable','max_traversable','last_ts','last_reason'];return [dict(zip(cols,r)) for r in rows]
    def upsert_fast_audit(self,rows):
        if not rows:return
        vals=[(r['route'],r['token'],r['stable_a'],r['stable_b'],r['checks'],r['base_positive'],r['fast_positive'],r['fast_only_samples'],r['fast_only_events'],r.get('max_fast_only_bps'),r.get('last_base_bps'),r.get('last_fast_bps'),r['last_ts']) for r in rows]
        sql='''INSERT INTO fast_lane_audit VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(route) DO UPDATE SET checks=checks+excluded.checks,base_positive=base_positive+excluded.base_positive,fast_positive=fast_positive+excluded.fast_positive,fast_only_samples=fast_only_samples+excluded.fast_only_samples,fast_only_events=fast_only_events+excluded.fast_only_events,max_fast_only_bps=CASE WHEN max_fast_only_bps IS NULL THEN excluded.max_fast_only_bps WHEN excluded.max_fast_only_bps IS NULL THEN max_fast_only_bps ELSE MAX(max_fast_only_bps,excluded.max_fast_only_bps) END,last_base_bps=excluded.last_base_bps,last_fast_bps=excluded.last_fast_bps,last_ts=excluded.last_ts'''
        with self.lock,self.conn() as c:c.executemany(sql,vals)
    def fast_audit(self,limit=100):
        cols=['route','token','stable_a','stable_b','checks','base_positive','fast_positive','fast_only_samples','fast_only_events','max_fast_only_bps','last_base_bps','last_fast_bps','last_ts']
        with self.conn() as c:rows=c.execute('SELECT '+','.join(cols)+' FROM fast_lane_audit ORDER BY fast_only_events DESC,max_fast_only_bps DESC,fast_positive DESC LIMIT ?',(int(limit),)).fetchall()
        out=[]
        for r in rows:
            x=dict(zip(cols,r));x['fast_only_pct']=100.0*(x['fast_only_samples'] or 0)/max(1,x['checks'] or 0);out.append(x)
        return out
    def add_survival_trials(self,rows):
        if not rows:return
        horizons=(50,100,150,250,500)
        cols=['trial_id','start_ts','done_ts','route','token','stable_a','stable_b','liquidity_class','size','fraction','base_qty','l1_cost_quote','planned_l2_vwap','initial_net_bps','min_quote_volume_24h','l1_reserve_x','l2_reserve_x','return_reserve_x']
        for h in horizons: cols += [f'l2_ok_{h}',f'return_ok_{h}',f'l2_slippage_bps_{h}',f'return_loss_bps_{h}']
        vals=[tuple(r.get(k) for k in cols) for r in rows]
        sql=f"INSERT OR REPLACE INTO survival_trials({','.join(cols)}) VALUES({','.join('?' for _ in cols)})"
        with self.lock,self.conn() as c:c.executemany(sql,vals)
    def upsert_survival_aggregates(self,rows):
        if not rows:return
        horizons=(50,100,150,250,500)
        cols=['route','size','trials']
        for h in horizons:cols += [f'l2_ok_{h}',f'return_ok_{h}',f'l2_slip_sum_{h}',f'l2_slip_max_{h}',f'return_loss_sum_{h}',f'return_loss_max_{h}']
        cols += ['last_ts'];vals=[tuple(r.get(k) for k in cols) for r in rows]
        updates=['trials=trials+excluded.trials']
        for h in horizons:
            updates += [f'l2_ok_{h}=l2_ok_{h}+excluded.l2_ok_{h}',f'return_ok_{h}=return_ok_{h}+excluded.return_ok_{h}',f'l2_slip_sum_{h}=l2_slip_sum_{h}+excluded.l2_slip_sum_{h}',f'return_loss_sum_{h}=return_loss_sum_{h}+excluded.return_loss_sum_{h}',
                        f'l2_slip_max_{h}=CASE WHEN l2_slip_max_{h} IS NULL THEN excluded.l2_slip_max_{h} WHEN excluded.l2_slip_max_{h} IS NULL THEN l2_slip_max_{h} ELSE MAX(l2_slip_max_{h},excluded.l2_slip_max_{h}) END',
                        f'return_loss_max_{h}=CASE WHEN return_loss_max_{h} IS NULL THEN excluded.return_loss_max_{h} WHEN excluded.return_loss_max_{h} IS NULL THEN return_loss_max_{h} ELSE MAX(return_loss_max_{h},excluded.return_loss_max_{h}) END']
        updates.append('last_ts=MAX(last_ts,excluded.last_ts)')
        sql=f"INSERT INTO survival_aggregates({','.join(cols)}) VALUES({','.join('?' for _ in cols)}) ON CONFLICT(route,size) DO UPDATE SET {','.join(updates)}"
        with self.lock,self.conn() as c:c.executemany(sql,vals)
    def load_survival_aggregates(self):
        horizons=(50,100,150,250,500);cols=['route','size','trials']
        for h in horizons:cols += [f'l2_ok_{h}',f'return_ok_{h}',f'l2_slip_sum_{h}',f'l2_slip_max_{h}',f'return_loss_sum_{h}',f'return_loss_max_{h}']
        cols += ['last_ts']
        with self.conn() as c:rows=c.execute('SELECT '+','.join(cols)+' FROM survival_aggregates').fetchall()
        return [dict(zip(cols,r)) for r in rows]
    def survival_stat(self,route,size):
        horizons=(50,100,150,250,500)
        cols=['route','size','trials']
        for h in horizons:cols += [f'l2_ok_{h}',f'return_ok_{h}',f'l2_slip_sum_{h}',f'l2_slip_max_{h}',f'return_loss_sum_{h}',f'return_loss_max_{h}']
        cols += ['last_ts']
        with self.conn() as c:r=c.execute('SELECT '+','.join(cols)+' FROM survival_aggregates WHERE route=? AND size=?',(route,float(size))).fetchone()
        if not r:return {'route':route,'size':float(size),'trials':0}
        x=dict(zip(cols,r));n=max(1,int(x['trials'] or 0))
        for h in horizons:
            x[f'l2_survival_{h}']=(x.get(f'l2_ok_{h}') or 0)/n;x[f'return_survival_{h}']=(x.get(f'return_ok_{h}') or 0)/n
            x[f'avg_l2_slippage_bps_{h}']=(x.get(f'l2_slip_sum_{h}') or 0.0)/max(1,int(x.get(f'l2_ok_{h}') or 0))
            x[f'avg_return_loss_bps_{h}']=(x.get(f'return_loss_sum_{h}') or 0.0)/max(1,int(x.get(f'return_ok_{h}') or 0))
        return x
    def survival_summary(self,limit=150):
        with self.conn() as c:keys=c.execute('SELECT route,size,trials,last_ts FROM survival_aggregates ORDER BY trials DESC,last_ts DESC LIMIT ?',(int(limit),)).fetchall()
        return [self.survival_stat(r[0],r[1]) for r in keys]
    def recent_survival_trials(self,limit=100):
        cols=['trial_id','start_ts','done_ts','route','token','liquidity_class','size','initial_net_bps','min_quote_volume_24h','l1_reserve_x','l2_reserve_x','return_reserve_x','l2_ok_50','l2_ok_100','l2_ok_150','l2_ok_250','l2_ok_500','l2_slippage_bps_100','return_ok_100','return_loss_bps_100']
        with self.conn() as c:rows=c.execute('SELECT '+','.join(cols)+' FROM survival_trials ORDER BY id DESC LIMIT ?',(int(limit),)).fetchall()
        return [dict(zip(cols,r)) for r in rows]
    def reasons(self):
        with self.conn() as c:rows=c.execute('SELECT reason,count,last_ts FROM reason_aggregates ORDER BY count DESC').fetchall()
        total=sum(x[1] for x in rows) or 1;return [{'reason':x[0],'count':x[1],'pct':100*x[1]/total,'last_ts':x[2]} for x in rows]
    def qualification_stats(self,hours=24):
        since=time.time()-hours*3600
        with self.conn() as c:
            rows=c.execute("SELECT class,count(*) FROM opportunity_hits WHERE last_ts>=? GROUP BY class",(since,)).fetchall()
        d={k:int(v) for k,v in rows};return {'robust_a':d.get('ROBUST_A',0),'robust_b':d.get('ROBUST_B',0),'candidate_a':d.get('A_CANDIDATE',0),'candidate_b':d.get('B_CANDIDATE',0),'risky':d.get('RISKY_HIGH_EDGE',0)}
    def opportunity_stats(self,hours=24):
        since=time.time()-hours*3600
        with self.conn() as c:r=c.execute('SELECT count(*),count(DISTINCT route),sum(CASE WHEN class_rank>=2 THEN 1 ELSE 0 END),sum(CASE WHEN accepted=1 THEN 1 ELSE 0 END),max(raw_edge_bps),max(net_edge_bps),max(expected_edge_bps),sum(observations) FROM opportunity_hits WHERE last_ts>=?',(since,)).fetchone()
        return {'windows_5s':r[0] or 0,'unique_routes':r[1] or 0,'net_positive_windows':r[2] or 0,'qualified_windows':r[3] or 0,'max_raw_bps':r[4],'max_net_bps':r[5],'max_expected_bps':r[6],'observations':r[7] or 0}
    def recent_errors(self,limit=100):
        with self.conn() as c:rows=c.execute('SELECT ts,kind,symbol,detail,extra_json FROM collector_errors ORDER BY id DESC LIMIT ?',(int(limit),)).fetchall()
        return [{'ts':r[0],'kind':r[1],'symbol':r[2],'detail':r[3],'extra':json.loads(r[4] or '{}')} for r in rows]
    def counts(self):
        names=['market_samples','health_samples','route_activity','candidate_windows','route_profiles','opportunity_hits','fast_lane_audit','survival_trials','survival_aggregates','collector_errors']
        with self.conn() as c:out={n:c.execute(f'SELECT count(*) FROM {n}').fetchone()[0] for n in names}
        try:out['db_mb']=os.path.getsize(self.path)/1024/1024
        except OSError:out['db_mb']=0
        return out
