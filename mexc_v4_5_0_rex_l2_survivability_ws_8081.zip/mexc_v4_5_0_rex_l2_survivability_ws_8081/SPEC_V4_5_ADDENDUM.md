# Addendum SPEC V4.5 — Qualification L2-first

Cet addendum complète `SPEC_V4_0_REX_MEXC_2LEG.docx`.

## Invariant principal
Avant L1, un trade ne peut devenir ROBUST que si la capacité de réalisation de L2 est démontrée statistiquement. Le moteur doit privilégier la réalisation de L2 ; RETURN est un filet de sécurité observé, pas une voie d'exécution normale.

## Seuils uniques TEST / Micro-Live
- A : min volume 1M$/24h, NET >1bp.
- B : min volume 100k$/24h, NET >2bp.
- C : non tradable.
- frais minimum de qualification : 5bp par jambe.
- Depth trusted fraction : 25%.
- L1 reserve : 5x.
- L2 reserve : 10x.

## Preuve de survivabilité
Chaque trial conserve la quantité token issue de L1 et mesure L2 à 50/100/150/250/500ms. ROBUST exige un nombre minimal de trials et les seuils de réussite définis dans `config.json`. Toute évolution future de ces valeurs doit être versionnée ; le Micro-Live consomme la même configuration que le TEST.
