# V4.4.0-REX — Free-Tier Hybrid — FULL UNIVERSE 2-LEG — SHADOW ONLY

Cette version part de V4.3.1 et vise explicitement le serveur **2 vCPU / offre gratuite**.
Elle conserve 100 % de l'univers MEXC 2-leg stablecoin→token→stablecoin, mais ne force plus le BookTicker 10 ms sur ~637 symboles en permanence.

## Architecture

### Tier 1 — Full universe BBO @100 ms
- Universe dynamique `exchangeInfo + defaultSymbols`.
- Tous les symboles utiles aux routes `USDT / USDC / USD1`.
- Tous les 2-leg dirigés éligibles.
- BookTicker MEXC @100 ms sur tout l'univers.
- Multiprocess + shared arrays comme V4.3.1.
- Scanner central de toutes les routes toutes les 20 ms.

### Tier 2 — Fast Lane BBO @10 ms
Capacité bornée (60 symboles par défaut) :
1. priorité aux symboles appartenant à une route BBO+ détectée sur Tier 1 ;
2. maintien 60 s après la dernière détection ;
3. capacité restante utilisée par une sonde rotative 10 ms sur des **bundles complets de tokens** ;
4. rotation de sonde toutes les 30 s par défaut.

La Fast Lane utilise `SUBSCRIPTION / UNSUBSCRIPTION` dynamiques sur des WS persistants. Le scanner lit à chaque instant le BBO le plus récent entre Tier 1 et Tier 2.

### Tier 3 — Depth 20 adaptatif
Toute route BBO+ active le Partial Book Depth 20 sur ses deux jambes. Une opportunité n'entre dans le tableau principal qu'après réception et synchronisation du Depth avec le BBO courant.

## Mesure de ce que le 100 ms rate
Pendant qu'une paire de symboles est en Fast Lane, le moteur compare en parallèle :
- edge BBO global 100 ms ;
- edge BBO Fast Lane 10 ms.

Table `fast_lane_audit` :
- checks ;
- base_positive ;
- fast_positive ;
- fast_only_samples ;
- fast_only_events (transition vers un signal visible uniquement à 10 ms) ;
- max_fast_only_bps.

Le dashboard affiche donc objectivement si le 10 ms permanent apporterait une valeur économique suffisante pour justifier plus de CPU.

## Restitution opportunités
- maximum **1 ligne / route / fenêtre de 5 s** ;
- BRUT+, NET+, QUALIFIÉE ;
- taille, fraction Depth, raw, frais, net, expected, PnL théorique, coverage, traversable, latences BBO/Depth et raison.

## Configuration free-tier par défaut
- BBO global : 100 ms ;
- 2 workers baseline ;
- Fast Lane : 3 WS × 20 = 60 symboles max ;
- probe budget : 20 symboles ;
- rotation probe : 30 s ;
- Fast TTL candidat : 60 s ;
- Depth TTL : 30 s ;
- scan route : 20 ms.

## Références MEXC
Documentation Spot V3 :
https://mexcdevelop.github.io/apidocs/spot_v3_en/#websocket-market-streams

MEXC documente `BookTicker` en `(100ms|10ms)`, les abonnements/désabonnements live, et le Partial Book Depth 5/10/20.

## Installation
```bash
./install.sh
./start.sh
sleep 120
./smoke_check.sh
```

## Gates avant run long
- HEALTH `ok:true` ;
- Base BBO ready == total symboles ;
- Base WS connected == total ;
- Fast Lane worker alive ;
- erreurs / reconnects / update drops == 0 ;
- transport BBO nettement inférieur au V4.3.1 sur 2 vCPU ;
- scan routes < 20 ms ;
- Depth queue / drops proches de 0 ;
- CPU avec marge (pas 100 % soutenu).

## Export
```bash
python export_run.py
```
L'export inclut la DB cohérente, les opportunités, la viabilité, les profils et l'audit Fast Lane 10 ms vs base 100 ms.

## Benchmark synthétique du hot path
Le wrapper hybride (base + fast mask partagé) a été testé sur 718 routes synthétiques à ~1.4 ms/scan dans l'environnement de build. La mesure sur le VPS reste la référence.
