# CHANGELOG — V4.4.0 Free-Tier Hybrid

## Motivation
V4.3.1 a validé le multiprocess et le full universe, mais ~637 BookTicker 10 ms représentent ~60k+ messages/s et saturent encore un VPS gratuit 2 vCPU au niveau scheduling/socket, malgré un decode quasi instantané.

## Changements
- Full universe conservé.
- Tier 1 BookTicker passe à 100 ms sur tous les symboles.
- Tier 2 Fast Lane dynamique BookTicker 10 ms, capacité bornée.
- Promotion automatique des deux jambes de toute route BBO+.
- TTL Fast Lane 60 s renouvelé tant que la route reste candidate.
- Sonde rotative 10 ms sur bundles complets de tokens.
- Support `SUBSCRIPTION / UNSUBSCRIPTION` live MEXC.
- Tier 3 Depth 20 adaptatif conservé.
- Shared BBO hybride : choix de l'événement exchange le plus récent entre base 100 ms et Fast 10 ms.
- Nouvelle table `fast_lane_audit` pour mesurer les signaux vus uniquement en 10 ms.
- Nouveau tableau UI « Apport de la Fast Lane 10 ms ».
- Dashboard clarifie BASE100 / FAST10 / Depth.
- 47 tests.
