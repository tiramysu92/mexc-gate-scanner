from types import SimpleNamespace
import time, tempfile
import pytest
from v4rex.core import Store,BBO,DepthBook,L
from v4rex.engine import Engine
from v4rex.db import DB

class Clock: offset_ms=0
class Collector:
    def __init__(self): self.clock=Clock();self.touched=[];self.depth=SimpleNamespace(status=lambda:{'symbols':[]})
    def touch_depth(self,s): self.touched.append(tuple(s))
class Rule:
    def __init__(self,f):self.taker_commission=f
class Uni:
    def __init__(self):
        self.routes=[SimpleNamespace(route='USDT>X>USDC',token='X',stable_a='USDT',stable_b='USDC',symbol1='XUSDT',symbol2='XUSDC')]
        self.by_symbol={'XUSDT':Rule('0.0005'),'XUSDC':Rule('0.0005')}

def cfg():return {'raw_watch_threshold_bps':0,'test_sizes_usd':[10],'depth_fractions':[1.0],'fee_bps_default':5,'min_expected_edge_bps':1,'max_transport_age_ms':500,'max_decode_lag_ms':100,'opportunity_cooldown_s':5,'aggregate_flush_s':999}
def states(store,bid2=10.2):
    n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10)
    store.put_bbo(BBO('XUSDT',9.9,10,10,10,1,send,wall,n,n,1));store.put_bbo(BBO('XUSDC',bid2,10,bid2+.1,10,1,send,wall,n,n,2))

def mk():
    s=Store();states(s);td=tempfile.NamedTemporaryFile(suffix='.db',delete=False);td.close();c=Collector();e=Engine(cfg(),s,DB(td.name),Uni(),c);return e,s,c

def test_quick_positive():
    e,s,c=mk();assert e._quick(e.universe.routes[0])==pytest.approx(200)

def test_positive_touches_depth():
    e,s,c=mk();e._process(e.universe.routes);assert c.touched

def test_no_depth_means_warming():
    e,s,c=mk();n,status=e._depth_eval(e.universe.routes[0],100);assert n==0 and status=='WARMING'

def test_synced_depth():
    e,s,c=mk();n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10);s.put_depth(DepthBook('XUSDT',(L(9.9,10),),(L(10,10),),1,send,wall,n,n,1));s.put_depth(DepthBook('XUSDC',(L(10.2,10),),(L(10.3,10),),1,send,wall,n,n,2));ok,_,_=e._depth_sync(e.universe.routes[0]);assert ok

def test_unsynced_depth():
    e,s,c=mk();n=time.monotonic_ns();s.put_depth(DepthBook('XUSDT',(L(9.9,10),),(L(10.01,10),),1,None,None,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,10),),(L(10.3,10),),1,None,None,n,n));ok,_,_=e._depth_sync(e.universe.routes[0]);assert not ok

def test_evaluate_fee_net():
    e,s,c=mk();n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10);s.put_depth(DepthBook('XUSDT',(L(9.9,10),),(L(10,10),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,10),),(L(10.3,10),),1,send,wall,n,n));x=e._evaluate(e.universe.routes[0],10,1);assert x.raw_edge_bps==pytest.approx(200);assert x.net_edge_bps<200;assert x.depth_synced

def test_qualified_when_threshold_low():
    e,s,c=mk();n=time.monotonic_ns();wall=time.time()*1000;send=int(wall-10);s.put_depth(DepthBook('XUSDT',(L(9.9,10),),(L(10,10),),1,send,wall,n,n));s.put_depth(DepthBook('XUSDC',(L(10.2,10),),(L(10.3,10),),1,send,wall,n,n));assert e._evaluate(e.universe.routes[0],10,1).accepted

def test_bbo_scan_direct_shared_arrays_path():
    from v4rex.mp_bbo import SharedBBO, _write
    h=SharedBBO(['XUSDT','XUSDC'])
    rn=time.monotonic_ns(); wall=time.time()*1000
    _write(h.args(),h.index['XUSDT'],9.9,10,10.0,10,1,int(wall-10),wall,rn,rn,1)
    _write(h.args(),h.index['XUSDC'],10.2,10,10.3,10,1,int(wall-10),wall,rn,rn,2)
    provider=SimpleNamespace(shared=h,get_bbo=h.get_bbo,snapshot_bbo=h.snapshot_bbo)
    s=Store(bbo_provider=provider)
    td=tempfile.NamedTemporaryFile(suffix='.db',delete=False);td.close();c=Collector();e=Engine(cfg(),s,DB(td.name),Uni(),c)
    assert e._fast_shared is h
    assert e.bbo_scan_once() == 1
    assert c.touched[-1] == ('XUSDT','XUSDC')
