from __future__ import annotations
from dataclasses import dataclass
from collections import Counter,defaultdict
import math,threading,time
from .core import buy,sell,max_traversable_quote

@dataclass
class Eval:
    route:str;token:str;stable_a:str;stable_b:str;symbol1:str;symbol2:str;size:float;fraction:float
    raw_edge_bps:float|None;net_edge_bps:float|None;expected_edge_bps:float|None;fee_bps_leg1:float;fee_bps_leg2:float
    cov1:float;cov2:float;max_traversable_quote:float;vwap1:float;vwap2:float
    bbo_transport1_ms:float|None;bbo_transport2_ms:float|None;bbo_decode1_ms:float;bbo_decode2_ms:float
    depth_transport1_ms:float|None;depth_transport2_ms:float|None;depth_decode1_ms:float;depth_decode2_ms:float
    depth_synced:bool;data_valid:bool;timing_valid:bool;accepted:bool;hard_reasons:tuple;timing_reasons:tuple;reasons:tuple;ts:float

class Engine:
    """Tier-1 full-universe BBO scanner + tier-2 adaptive depth evaluator."""
    def __init__(self,cfg,store,db,universe,collector):
        self.cfg=cfg;self.store=store;self.db=db;self.universe=universe;self.collector=collector;self.clock=collector.clock;self._touch_fast=getattr(collector,'touch_fast',lambda symbols,ttl=None:None);self.routes_by_symbol=defaultdict(list)
        for r in universe.routes:self.routes_by_symbol[r.symbol1].append(r);self.routes_by_symbol[r.symbol2].append(r)
        # Hot path: pre-resolve symbol indexes into the multiprocess shared BBO arrays.
        # This avoids rebuilding ~600 BBO dataclasses on every 20 ms route scan.
        provider=getattr(store,'_bbo_provider',None);self._fast_shared=getattr(provider,'shared',None);self._base_shared=getattr(provider,'base_shared',None);self._fast_lane_shared=getattr(provider,'fast_shared',None);self._fast_lane_mgr=getattr(provider,'fast',None)
        if self._fast_shared is not None:
            idx=self._fast_shared.index;self._fast_routes=[(r,idx.get(r.symbol1),idx.get(r.symbol2)) for r in universe.routes]
        else:self._fast_routes=[]
        self._last_activity_sample=0.0
        self.lock=threading.RLock();self.pending_activity={};self.pending_candidates={};self.pending_profiles={};self.pending_hits={};self.pending_reasons=Counter();self.pending_audit={};self._audit_state={};self.audit_checks=0;self.audit_fast_only_events=0;self.last_flush=time.monotonic();self.sweeps=0;self.sweep_ms=0;self.last_sweep_bbo=0;self.last_positive_routes=0;self.fast_batches=0;self.fast_ms=0;self.fast_routes=0;self.fast_bbo=0;self.fast_depth=0;self.total_bbo_checks=0;self.total_depth_evals=0;self.qualified_evals=0;self.bbo_scans=0;self.bbo_scan_ms=0;self.bbo_positive=0;self.depth_batches=0;self.depth_fast_ms=0
    def _fee(self,s):
        rule=self.universe.by_symbol.get(s);raw=getattr(rule,'taker_commission',None) if rule else None
        try:
            v=float(raw)
            if 0<=v<=.02:return v*1e4
        except Exception:pass
        return float(self.cfg.get('fee_bps_default',5))
    def _quick(self,r):
        a=self.store.get_bbo(r.symbol1);b=self.store.get_bbo(r.symbol2)
        if not a or not b or a.state!='VALID' or b.state!='VALID' or a.ask<=0:return None
        return (b.bid/a.ask-1)*1e4
    def _depth_sync(self,r):
        a=self.store.get_bbo(r.symbol1);b=self.store.get_bbo(r.symbol2);d1=self.store.get_depth(r.symbol1);d2=self.store.get_depth(r.symbol2)
        if not all((a,b,d1,d2)):return False,d1,d2
        ok=math.isclose(d1.best_ask,a.ask,rel_tol=1e-12,abs_tol=1e-12) and math.isclose(d2.best_bid,b.bid,rel_tol=1e-12,abs_tol=1e-12)
        return ok,d1,d2
    def _record_activity(self,r,bbo,ts=None):
        now=time.time() if ts is None else ts;a=self.pending_activity.get(r.route)
        if not a:a={'route':r.route,'token':r.token,'stable_a':r.stable_a,'stable_b':r.stable_b,'quick_scans':0,'bbo_positive':0,'max_bbo_bps':None,'last_bbo_bps':None,'last_ts':now};self.pending_activity[r.route]=a
        a['quick_scans']+=1;a['last_ts']=now;a['last_bbo_bps']=bbo
        if bbo is not None:a['bbo_positive']+=int(bbo>float(self.cfg.get('raw_watch_threshold_bps',0)));a['max_bbo_bps']=bbo if a['max_bbo_bps'] is None else max(a['max_bbo_bps'],bbo)
    def _candidate(self,r,bbo,status):
        now=time.time();bucket=math.floor(now/float(self.cfg.get('opportunity_cooldown_s',5)))*float(self.cfg.get('opportunity_cooldown_s',5));k=(r.route,bucket);sync=(status=='DEPTH_SYNCED');ready=status in ('DEPTH_READY','DEPTH_SYNCED');warm=None
        wm=getattr(self.collector.depth,'warmup_ms',lambda _s:None);vals=[wm(r.symbol1),wm(r.symbol2)];vals=[x for x in vals if x is not None]
        if len(vals)==2:warm=max(vals)
        old=self.pending_candidates.get(k)
        if not old:self.pending_candidates[k]={'bucket_ts':bucket,'first_ts':now,'last_ts':now,'route':r.route,'token':r.token,'stable_a':r.stable_a,'stable_b':r.stable_b,'observations':1,'max_bbo_bps':bbo,'depth_ready_obs':int(ready),'depth_synced_obs':int(sync),'status':status,'warmup_ms':warm}
        else:old['observations']+=1;old['last_ts']=now;old['max_bbo_bps']=max(old['max_bbo_bps'],bbo);old['depth_ready_obs']+=int(ready);old['depth_synced_obs']+=int(sync);old['status']=status;old['warmup_ms']=warm if old['warmup_ms'] is None else (min(old['warmup_ms'],warm) if warm is not None else old['warmup_ms'])
    def _evaluate(self,r,size,f):
        b1=self.store.get_bbo(r.symbol1);b2=self.store.get_bbo(r.symbol2);sync,d1,d2=self._depth_sync(r);now=time.time()
        if not all((b1,b2,d1,d2)):return None
        base,v1,c1=buy(d1.asks,size,f);out,v2,c2=sell(d2.bids,base,f);full=c1>=.999 and c2>=.999;raw=(out/size-1)*1e4 if full else None;f1=self._fee(r.symbol1);f2=self._fee(r.symbol2);net=(out*(1-f1/1e4)*(1-f2/1e4)/size-1)*1e4 if full else None;reserve=sum(float(self.cfg.get(k,0)) for k in ('slippage_reserve_bps','latency_reserve_bps','exit_risk_reserve_bps'));expected=net-reserve if net is not None else None
        bt1=b1.transport_delay_ms(self.clock.offset_ms);bt2=b2.transport_delay_ms(self.clock.offset_ms);dt1=d1.transport_delay_ms(self.clock.offset_ms);dt2=d2.transport_delay_ms(self.clock.offset_ms);hard=[];tim=[]
        if not sync:hard.append('DEPTH_BBO_UNSYNCED')
        if c1<.999:hard.append('DEPTH_L1')
        if c2<.999:hard.append('DEPTH_L2')
        vals=[bt1,bt2,dt1,dt2]
        if any(x is None for x in vals):tim.append('TRANSPORT_TS_MISSING')
        elif max(vals)>float(self.cfg.get('max_transport_age_ms',500)):tim.append('TRANSPORT_DELAY')
        if max(b1.decode_lag_ms,b2.decode_lag_ms,d1.decode_lag_ms,d2.decode_lag_ms)>float(self.cfg.get('max_decode_lag_ms',100)):tim.append('LOCAL_DECODE_BACKLOG')
        hard=tuple(dict.fromkeys(hard));tim=tuple(dict.fromkeys(tim));dv=not hard;tv=not tim;acc=dv and tv and expected is not None and expected>=float(self.cfg.get('min_expected_edge_bps',10));reasons=list(hard)+list(tim)
        if dv and tv and not acc:reasons.append('EDGE_EXPECTED')
        return Eval(r.route,r.token,r.stable_a,r.stable_b,r.symbol1,r.symbol2,float(size),float(f),raw,net,expected,f1,f2,c1,c2,max_traversable_quote(d1.asks,d2.bids,f),v1,v2,bt1,bt2,b1.decode_lag_ms,b2.decode_lag_ms,dt1,dt2,d1.decode_lag_ms,d2.decode_lag_ms,sync,dv,tv,acc,hard,tim,tuple(reasons),now)
    @staticmethod
    def _class(e):
        if e.accepted:return 'QUALIFIED',3
        if e.data_valid and e.net_edge_bps is not None and e.net_edge_bps>0:return 'NET_POSITIVE',2
        if e.data_valid and e.raw_edge_bps is not None and e.raw_edge_bps>0:return 'RAW_POSITIVE',1
        return 'NOT_OPPORTUNITY',0
    def _score(self,e):
        _,rank=self._class(e);pnl=e.size*(e.expected_edge_bps or 0)/1e4;return rank*1e12+pnl*1e8+(e.expected_edge_bps or e.raw_edge_bps or -1e9)*1e3+e.size
    def _profile(self,e):
        k=(e.route,e.size,e.fraction);a=self.pending_profiles.get(k)
        if not a:a={'route':e.route,'token':e.token,'stable_a':e.stable_a,'stable_b':e.stable_b,'size':e.size,'fraction':e.fraction,'samples':0,'data_valid':0,'timing_valid':0,'raw_positive':0,'net_positive':0,'qualified':0,'sum_raw':0,'sum_net':0,'sum_expected':0,'max_raw':None,'max_net':None,'max_expected':None,'sum_cov1':0,'sum_cov2':0,'sum_traversable':0,'max_traversable':None,'last_ts':e.ts,'last_reason':''};self.pending_profiles[k]=a
        a['samples']+=1;a['data_valid']+=int(e.data_valid);a['timing_valid']+=int(e.timing_valid);a['raw_positive']+=int((e.raw_edge_bps or -1)>0);a['net_positive']+=int((e.net_edge_bps or -1)>0);a['qualified']+=int(e.accepted)
        for n,v in [('raw',e.raw_edge_bps),('net',e.net_edge_bps),('expected',e.expected_edge_bps)]:
            if v is not None:a['sum_'+n]+=v;a['max_'+n]=v if a['max_'+n] is None else max(a['max_'+n],v)
        a['sum_cov1']+=e.cov1;a['sum_cov2']+=e.cov2;a['sum_traversable']+=e.max_traversable_quote;a['max_traversable']=e.max_traversable_quote if a['max_traversable'] is None else max(a['max_traversable'],e.max_traversable_quote);a['last_ts']=e.ts;a['last_reason']='|'.join(e.reasons) if e.reasons else 'OK'
        for z in e.hard_reasons:self.pending_reasons['HARD:'+z]+=1
        for z in e.timing_reasons:self.pending_reasons['TIMING:'+z]+=1
        if e.data_valid and e.timing_valid and not e.accepted:self.pending_reasons['EDGE:BELOW_EXPECTED']+=1
    def _hit(self,e,bbo):
        klass,rank=self._class(e)
        if rank<=0:return
        cd=float(self.cfg.get('opportunity_cooldown_s',5));bucket=math.floor(e.ts/cd)*cd;k=(e.route,bucket);score=self._score(e);h={'bucket_ts':bucket,'first_ts':e.ts,'last_ts':e.ts,'route':e.route,'token':e.token,'stable_a':e.stable_a,'stable_b':e.stable_b,'symbol1':e.symbol1,'symbol2':e.symbol2,'observations':1,'class':klass,'class_rank':rank,'score':score,'size':e.size,'fraction':e.fraction,'bbo_raw_bps':bbo,'raw_edge_bps':e.raw_edge_bps,'fee_bps_leg1':e.fee_bps_leg1,'fee_bps_leg2':e.fee_bps_leg2,'net_edge_bps':e.net_edge_bps,'expected_edge_bps':e.expected_edge_bps,'potential_pnl_usd':e.size*(e.expected_edge_bps or 0)/1e4,'cov1':e.cov1,'cov2':e.cov2,'max_traversable_quote':e.max_traversable_quote,'vwap1':e.vwap1,'vwap2':e.vwap2,'bbo_transport1_ms':e.bbo_transport1_ms,'bbo_transport2_ms':e.bbo_transport2_ms,'bbo_decode1_ms':e.bbo_decode1_ms,'bbo_decode2_ms':e.bbo_decode2_ms,'depth_transport1_ms':e.depth_transport1_ms,'depth_transport2_ms':e.depth_transport2_ms,'depth_decode1_ms':e.depth_decode1_ms,'depth_decode2_ms':e.depth_decode2_ms,'depth_synced':int(e.depth_synced),'timing_valid':int(e.timing_valid),'accepted':int(e.accepted),'reasons':'|'.join(e.reasons) if e.reasons else 'OK'};old=self.pending_hits.get(k)
        if old:
            old['observations']+=1;old['last_ts']=max(old['last_ts'],e.ts)
            if score>old['score']:
                obs,first,last=old['observations'],old['first_ts'],old['last_ts'];old.update(h);old['observations']=obs;old['first_ts']=first;old['last_ts']=last
        else:self.pending_hits[k]=h
    def _depth_eval(self,r,bbo):
        sync,d1,d2=self._depth_sync(r)
        if not d1 or not d2:return 0,'WARMING'
        if not sync:return 0,'DEPTH_READY'
        ev=[]
        for size in self.cfg['test_sizes_usd']:
            for f in self.cfg['depth_fractions']:
                e=self._evaluate(r,size,f)
                if e:
                    ev.append(e)
                    with self.lock:self._profile(e)
        best=None
        for e in ev:
            if self._class(e)[1]>0 and (best is None or self._score(e)>self._score(best)):best=e
        if best:
            with self.lock:self._hit(best,bbo)
        with self.lock:
            self.total_depth_evals+=len(ev);self.qualified_evals+=sum(int(e.accepted) for e in ev)
        return len(ev),'DEPTH_SYNCED'
    def _process(self,routes):
        bc=de=pos=0;th=float(self.cfg.get('raw_watch_threshold_bps',0))
        for r in routes:
            b=self._quick(r);bc+=1
            with self.lock:self._record_activity(r,b)
            if b is not None and b>th:
                pos+=1;self._touch_fast([r.symbol1,r.symbol2]);self.collector.touch_depth([r.symbol1,r.symbol2]);n,status=self._depth_eval(r,b);de+=n
                with self.lock:self._candidate(r,b,status)
        self.total_bbo_checks+=bc;return bc,de,pos

    def _audit_route(self,r,i1,i2,active,ts):
        if self._base_shared is None or self._fast_lane_shared is None or r.symbol1 not in active or r.symbol2 not in active:return
        a0=self._base_shared.read_idx(i1);b0=self._base_shared.read_idx(i2);af=self._fast_lane_shared.read_idx(i1);bf=self._fast_lane_shared.read_idx(i2)
        if not all((a0,b0,af,bf)) or a0[2]<=0 or af[2]<=0:return
        eb=(b0[0]/a0[2]-1.0)*1e4;ef=(bf[0]/af[2]-1.0)*1e4;th=float(self.cfg.get('raw_watch_threshold_bps',0));bo=eb>th;fo=ef>th;only=fo and not bo;prev=self._audit_state.get(r.route,False);event=only and not prev;self._audit_state[r.route]=only
        x=self.pending_audit.get(r.route)
        if not x:x={'route':r.route,'token':r.token,'stable_a':r.stable_a,'stable_b':r.stable_b,'checks':0,'base_positive':0,'fast_positive':0,'fast_only_samples':0,'fast_only_events':0,'max_fast_only_bps':None,'last_base_bps':None,'last_fast_bps':None,'last_ts':ts};self.pending_audit[r.route]=x
        x['checks']+=1;x['base_positive']+=int(bo);x['fast_positive']+=int(fo);x['fast_only_samples']+=int(only);x['fast_only_events']+=int(event);x['last_base_bps']=eb;x['last_fast_bps']=ef;x['last_ts']=ts
        if only:x['max_fast_only_bps']=ef if x['max_fast_only_bps'] is None else max(x['max_fast_only_bps'],ef)
        self.audit_checks+=1;self.audit_fast_only_events+=int(event)

    def bbo_scan_once(self):
        """Full-universe BBO scan using shared-array indexes on the hot path."""
        t=time.monotonic_ns();th=float(self.cfg.get('raw_watch_threshold_bps',0));pos=0;positive=[];activity=[]
        active=set()
        if self._fast_lane_mgr is not None:
            try:active=self._fast_lane_mgr.active_snapshot()[0]
            except Exception:active=set()
        now_mono=time.monotonic();sample_activity=(now_mono-self._last_activity_sample)*1000.0>=float(self.cfg.get('route_activity_sample_ms',250))
        if self._fast_shared is not None:
            read=self._fast_shared.read_idx
            for r,i1,i2 in self._fast_routes:
                edge=None
                if i1 is not None and i2 is not None:
                    a=read(i1);b=read(i2)
                    if a is not None and b is not None and a[2]>0:edge=(b[0]/a[2]-1.0)*1e4
                if active and i1 is not None and i2 is not None:
                    with self.lock:self._audit_route(r,i1,i2,active,time.time())
                if sample_activity:activity.append((r,edge))
                if edge is not None and edge>th:pos+=1;positive.append((r,edge))
        else:
            bb=self.store.snapshot_bbo()
            for r in self.universe.routes:
                a=bb.get(r.symbol1);b=bb.get(r.symbol2);edge=None
                if a and b and a.state=='VALID' and b.state=='VALID' and a.ask>0:edge=(b.bid/a.ask-1)*1e4
                if sample_activity:activity.append((r,edge))
                if edge is not None and edge>th:pos+=1;positive.append((r,edge))
        if sample_activity:
            ts=time.time()
            with self.lock:
                for r,edge in activity:self._record_activity(r,edge,ts)
            self._last_activity_sample=now_mono
        for r,edge in positive:
            self._touch_fast((r.symbol1,r.symbol2));self.collector.touch_depth((r.symbol1,r.symbol2))
            d1=self.store.get_depth(r.symbol1);d2=self.store.get_depth(r.symbol2)
            if not d1 or not d2:status='WARMING'
            else:
                # Only positives pay the cost of materialising BBO objects for depth/BBO sync.
                a=self.store.get_bbo(r.symbol1);b=self.store.get_bbo(r.symbol2)
                sync=bool(a and b and math.isclose(d1.best_ask,a.ask,rel_tol=1e-12,abs_tol=1e-12) and math.isclose(d2.best_bid,b.bid,rel_tol=1e-12,abs_tol=1e-12))
                status='DEPTH_SYNCED' if sync else 'DEPTH_READY'
            with self.lock:self._candidate(r,edge,status)
        self.total_bbo_checks+=len(self.universe.routes);self.bbo_scans+=1;self.bbo_positive=pos;self.bbo_scan_ms=(time.monotonic_ns()-t)/1e6;self.flush();return pos

    def depth_fast_once(self,changed):
        """Evaluate detailed depth only when a hot depth book actually changes."""
        t=time.monotonic_ns();routes={r.route:r for s in changed for r in self.routes_by_symbol.get(s,[])};de=0;pos=0;th=float(self.cfg.get('raw_watch_threshold_bps',0))
        for r in routes.values():
            b=self._quick(r)
            if b is None or b<=th:continue
            pos+=1;self._touch_fast([r.symbol1,r.symbol2]);n,status=self._depth_eval(r,b);de+=n
            with self.lock:self._candidate(r,b,status)
        self.depth_batches+=1;self.depth_fast_ms=(time.monotonic_ns()-t)/1e6;self.fast_batches+=1;self.fast_routes=len(routes);self.fast_bbo=len(routes);self.fast_depth=de;self.fast_ms=self.depth_fast_ms;self.flush();return len(routes),de,pos
    def flush(self,force=False):
        if not force and time.monotonic()-self.last_flush<float(self.cfg.get('aggregate_flush_s',2)):return
        with self.lock:a=list(self.pending_activity.values());c=list(self.pending_candidates.values());p=list(self.pending_profiles.values());h=list(self.pending_hits.values());r=dict(self.pending_reasons);fa=list(self.pending_audit.values());self.pending_activity={};self.pending_candidates={};self.pending_profiles={};self.pending_hits={};self.pending_reasons=Counter();self.pending_audit={};self.last_flush=time.monotonic()
        self.db.upsert_route_activity(a);self.db.upsert_candidates(c);self.db.upsert_route_profiles(p);self.db.upsert_opportunity_hits(h);self.db.add_reason_counts(r);self.db.upsert_fast_audit(fa)
    def sweep_once(self):
        t=time.monotonic_ns();b,d,p=self._process(self.universe.routes);self.flush();self.sweeps+=1;self.last_sweep_bbo=b;self.last_positive_routes=p;self.sweep_ms=(time.monotonic_ns()-t)/1e6;return b,d
    def fast_once(self,changed):return self.depth_fast_once(changed)
    def status(self):return {'sweeps':self.sweeps,'last_sweep_ms':self.sweep_ms,'last_sweep_bbo_checks':self.last_sweep_bbo,'last_positive_routes':self.last_positive_routes,'bbo_scans':self.bbo_scans,'bbo_scan_ms':self.bbo_scan_ms,'bbo_positive_routes':self.bbo_positive,'depth_batches':self.depth_batches,'depth_fast_ms':self.depth_fast_ms,'fast_batches':self.fast_batches,'fast_last_ms':self.fast_ms,'fast_routes_touched':self.fast_routes,'fast_bbo_checks':self.fast_bbo,'fast_depth_evals':self.fast_depth,'total_bbo_checks':self.total_bbo_checks,'total_depth_evals':self.total_depth_evals,'qualified_evaluations':self.qualified_evals,'pending_hits':len(self.pending_hits),'pending_candidates':len(self.pending_candidates),'fast_audit_checks':self.audit_checks,'fast_only_events':self.audit_fast_only_events}
