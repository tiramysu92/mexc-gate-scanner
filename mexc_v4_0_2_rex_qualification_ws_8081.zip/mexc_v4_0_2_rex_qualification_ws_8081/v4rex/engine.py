from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import Counter, defaultdict
import threading,time,uuid
from .core import buy,sell,max_traversable_quote

@dataclass
class Eval:
    route:str; token:str; stable_a:str; stable_b:str; symbol1:str; symbol2:str
    size:float; fraction:float
    raw_edge_bps:float|None; net_edge_bps:float|None; expected_edge_bps:float|None
    fee_bps_leg1:float; fee_bps_leg2:float; fee_source:str
    cov1:float; cov2:float; max_traversable_quote:float; vwap1:float; vwap2:float
    local_age1_ms:float; local_age2_ms:float
    exchange_age1_ms:float|None; exchange_age2_ms:float|None
    transport_age1_ms:float|None; transport_age2_ms:float|None
    local_skew_ms:float; exchange_skew_ms:float|None
    data_valid:bool; timing_valid:bool; accepted:bool
    hard_reasons:tuple[str,...]; timing_reasons:tuple[str,...]; reasons:tuple[str,...]
    ts:float
    def as_dict(self):
        d=asdict(self); d['reasons']='|'.join(self.reasons) if self.reasons else 'OK'; d['hard_reasons']='|'.join(self.hard_reasons); d['timing_reasons']='|'.join(self.timing_reasons); return d

class OpportunityTracker:
    """Lifecycle of economically interesting books.

    IMPORTANT: timing-age/skew thresholds do NOT open/close a lifecycle. Diff depth is event-driven;
    a book can remain unchanged while the feed is perfectly healthy. Timing is tracked as a strict
    execution counterfactual, while integrity/depth + raw edge define the observed opportunity.
    """
    def __init__(self,cfg,db):
        self.cfg=cfg; self.db=db; self.active={}; self.lock=threading.RLock()
        self.raw_threshold=float(cfg.get('raw_watch_threshold_bps',0.0)); self.update_delta=float(cfg.get('event_update_delta_bps',2.0))
    @staticmethod
    def key(e): return (e.route,float(e.size),float(e.fraction))
    @staticmethod
    def klass(e):
        if e.accepted: return 'QUALIFIED'
        if e.net_edge_bps is not None and e.net_edge_bps>0: return 'NET_POSITIVE'
        if e.raw_edge_bps is not None and e.raw_edge_bps>=0: return 'RAW_POSITIVE'
        return 'BELOW_RAW'
    def _event(self,typ,x,e,duration=None,close_reason=None):
        self.db.add_opportunity_event({'ts':time.time(),'event_type':typ,'opp_id':x['opp_id'],'route':e.route,'token':e.token,'size':e.size,'fraction':e.fraction,
          'raw_edge_bps':e.raw_edge_bps,'net_edge_bps':e.net_edge_bps,'expected_edge_bps':e.expected_edge_bps,'cov1':e.cov1,'cov2':e.cov2,
          'local_skew_ms':e.local_skew_ms,'exchange_skew_ms':e.exchange_skew_ms,'timing_valid':e.timing_valid,'qualified':e.accepted,
          'class':self.klass(e),'reason':close_reason or ('|'.join(e.reasons) if e.reasons else 'OK'),'duration_ms':duration})
    def process(self,evaluations):
        now=time.time(); seen=set()
        with self.lock:
            for e in evaluations:
                k=self.key(e); seen.add(k)
                watch=e.data_valid and e.raw_edge_bps is not None and e.raw_edge_bps>=self.raw_threshold
                x=self.active.get(k)
                if watch and x is None:
                    x={'opp_id':uuid.uuid4().hex[:16],'route':e.route,'token':e.token,'size':e.size,'fraction':e.fraction,'open_ts':now,'close_ts':None,'duration_ms':0.0,'samples':1,
                       'timing_valid_samples':int(e.timing_valid),'peak_raw_bps':e.raw_edge_bps,'peak_net_bps':e.net_edge_bps,'peak_expected_bps':e.expected_edge_bps,
                       'last_raw_bps':e.raw_edge_bps,'last_net_bps':e.net_edge_bps,'last_expected_bps':e.expected_edge_bps,'net_positive_ever':bool(e.net_edge_bps is not None and e.net_edge_bps>0),
                       'qualified_ever':bool(e.accepted),'status':'OPEN','last_reason':'OK','last_class':self.klass(e)}
                    self.active[k]=x; self._event('OPEN',x,e,0.0); self.db.upsert_lifecycle(x)
                elif watch and x is not None:
                    x['samples']+=1; x['timing_valid_samples']+=int(e.timing_valid); x['duration_ms']=(now-x['open_ts'])*1000.0
                    old_class=x['last_class']; prior_peak=x.get('peak_expected_bps'); was_q=bool(x['qualified_ever']); was_net=bool(x['net_positive_ever'])
                    x['peak_raw_bps']=max(v for v in [x.get('peak_raw_bps'),e.raw_edge_bps] if v is not None)
                    if e.net_edge_bps is not None: x['peak_net_bps']=max(v for v in [x.get('peak_net_bps'),e.net_edge_bps] if v is not None)
                    if e.expected_edge_bps is not None: x['peak_expected_bps']=max(v for v in [x.get('peak_expected_bps'),e.expected_edge_bps] if v is not None)
                    x['net_positive_ever']=was_net or bool(e.net_edge_bps is not None and e.net_edge_bps>0); x['qualified_ever']=was_q or bool(e.accepted)
                    x['last_raw_bps']=e.raw_edge_bps; x['last_net_bps']=e.net_edge_bps; x['last_expected_bps']=e.expected_edge_bps; x['last_class']=self.klass(e)
                    improved=e.expected_edge_bps is not None and (prior_peak is None or e.expected_edge_bps>=prior_peak+self.update_delta)
                    class_flip=x['last_class']!=old_class; important_flip=(not was_q and e.accepted) or (not was_net and x['net_positive_ever'])
                    if improved or class_flip or important_flip: self._event('UPDATE',x,e,x['duration_ms'])
                elif (not watch) and x is not None:
                    x['close_ts']=now; x['duration_ms']=(now-x['open_ts'])*1000.0; x['status']='CLOSED'
                    close_reason='|'.join(e.hard_reasons) if not e.data_valid and e.hard_reasons else 'RAW_BELOW_WATCH'
                    x['last_reason']=close_reason; self._event('CLOSE',x,e,x['duration_ms'],close_reason); self.db.upsert_lifecycle(x); del self.active[k]
            # Partial fast-watch batches intentionally do not close routes that were not evaluated.
    def flush_active(self):
        with self.lock:
            now=time.time()
            for x in self.active.values(): x['duration_ms']=(now-x['open_ts'])*1000.0; self.db.upsert_lifecycle(x)
    def status(self):
        with self.lock:
            now=time.time(); out=[]
            for x in self.active.values():
                z=dict(x); z['duration_ms']=(now-z['open_ts'])*1000.0; z['timing_valid_pct']=100*z.get('timing_valid_samples',0)/max(1,z.get('samples',0)); out.append(z)
            return sorted(out,key=lambda z:(z.get('last_expected_bps') if z.get('last_expected_bps') is not None else -1e99),reverse=True)

class Engine:
    def __init__(self,cfg,store,db,universe,clock):
        self.cfg=cfg; self.store=store; self.db=db; self.universe=universe; self.clock=clock
        self.scans=self.evaluations=self.accepted=0; self.scan_ms=0.0; self.last_scan_evals=0
        self.fast_batches=self.fast_evaluations=0; self.fast_ms=0.0; self.fast_last_evals=0
        self.pending={}; self.pending_reasons=Counter(); self.last_flush=time.monotonic(); self.lock=threading.RLock(); self.latest_candidates=[]
        self.tracker=OpportunityTracker(cfg,db); self.routes_by_symbol=defaultdict(list)
        for r in universe.routes:
            self.routes_by_symbol[r.symbol1].append(r); self.routes_by_symbol[r.symbol2].append(r)

    def _fee_bps(self,symbol):
        rule=getattr(self.universe,'by_symbol',{}).get(symbol); raw=getattr(rule,'taker_commission',None) if rule else None
        try:
            v=float(raw)
            if 0<=v<=0.02: return v*1e4,'exchangeInfo'
        except Exception: pass
        return float(self.cfg.get('fee_bps_default',5.0)),'config_default'

    def _evaluate(self,r,size,f):
        x=self.store.get(r.symbol1); y=self.store.get(r.symbol2); now=time.time()
        if not x or not y: return None
        base,v1,c1=buy(x.asks,size,f); out,v2,c2=sell(y.bids,base,f); full=c1>=.999 and c2>=.999
        raw=((out/size)-1)*1e4 if full and size>0 else None
        fee1,src1=self._fee_bps(r.symbol1); fee2,src2=self._fee_bps(r.symbol2); f1=fee1/1e4; f2=fee2/1e4
        net=((out*(1-f1)*(1-f2)/size)-1)*1e4 if full and size>0 else None
        reserve=sum(float(self.cfg.get(k,0)) for k in ('slippage_reserve_bps','latency_reserve_bps','exit_risk_reserve_bps')); expected=(net-reserve) if net is not None else None
        la1=x.age_ms; la2=y.age_ms; ea1=x.exchange_age_ms(self.clock.offset_ms); ea2=y.exchange_age_ms(self.clock.offset_ms); ta1=x.transport_age_ms(self.clock.offset_ms); ta2=y.transport_age_ms(self.clock.offset_ms)
        lsk=abs(x.apply_ns-y.apply_ns)/1e6; esk=abs(float(x.exchange_ms)-float(y.exchange_ms)) if x.exchange_ms and y.exchange_ms else None
        hard=[]; timing=[]
        if x.state!='VALID' or y.state!='VALID': hard.append('BOOK')
        if c1<.999: hard.append('DEPTH_L1')
        if c2<.999: hard.append('DEPTH_L2')
        # Age/skew measure time since last change, not proof of packet loss. They remain strict-execution counterfactuals.
        if la1>float(self.cfg.get('max_local_age_ms',250)) or la2>float(self.cfg.get('max_local_age_ms',250)): timing.append('INACTIVITY_LOCAL')
        if ea1 is None or ea2 is None: timing.append('EXCHANGE_TS_MISSING')
        elif ea1>float(self.cfg.get('max_exchange_age_ms',500)) or ea2>float(self.cfg.get('max_exchange_age_ms',500)): timing.append('INACTIVITY_EXCHANGE')
        if ta1 is not None and ta1>float(self.cfg.get('max_transport_age_ms',500)): timing.append('TRANSPORT_AGE')
        if ta2 is not None and ta2>float(self.cfg.get('max_transport_age_ms',500)): timing.append('TRANSPORT_AGE')
        if lsk>float(self.cfg.get('max_local_skew_ms',150)): timing.append('UPDATE_SKEW_LOCAL')
        if esk is None: timing.append('EXCHANGE_SKEW_MISSING')
        elif esk>float(self.cfg.get('max_exchange_skew_ms',150)): timing.append('UPDATE_SKEW_EXCHANGE')
        hard=tuple(dict.fromkeys(hard)); timing=tuple(dict.fromkeys(timing)); data_valid=not hard; timing_valid=not timing
        accepted=data_valid and timing_valid and expected is not None and expected>=float(self.cfg.get('min_expected_edge_bps',10.0))
        reasons=list(hard)+list(timing)
        if data_valid and timing_valid and not accepted: reasons.append('EDGE_EXPECTED')
        return Eval(r.route,r.token,r.stable_a,r.stable_b,r.symbol1,r.symbol2,float(size),float(f),raw,net,expected,fee1,fee2,src1 if src1==src2 else src1+'+'+src2,c1,c2,max_traversable_quote(x.asks,y.bids,f),v1,v2,la1,la2,ea1,ea2,ta1,ta2,lsk,esk,data_valid,timing_valid,accepted,hard,timing,tuple(reasons),now)

    def _eval_routes(self,routes):
        out=[]
        for r in routes:
            for size in self.cfg['test_sizes_usd']:
                for f in self.cfg['depth_fractions']:
                    e=self._evaluate(r,size,f)
                    if e is not None: out.append(e)
        return out

    def _agg(self,e):
        k=(e.route,e.size,e.fraction); a=self.pending.get(k)
        if a is None:
            a={'route':e.route,'token':e.token,'stable_a':e.stable_a,'stable_b':e.stable_b,'size':e.size,'fraction':e.fraction,'samples':0,'data_valid':0,'timing_valid':0,'edge_samples':0,'raw_positive':0,'net_positive':0,'qualified':0,
               'sum_raw':0.0,'sum_net':0.0,'sum_expected':0.0,'max_raw':None,'max_net':None,'max_expected':None,'min_expected':None,'sum_cov1':0.0,'sum_cov2':0.0,'sum_local_age':0.0,'sum_exchange_age':0.0,
               'sum_local_skew':0.0,'sum_exchange_skew':0.0,'sum_traversable':0.0,'max_traversable':None,'sum_fee1':0.0,'sum_fee2':0.0,'last_ts':e.ts,'last_reason':''}; self.pending[k]=a
        a['samples']+=1; a['data_valid']+=int(e.data_valid); a['timing_valid']+=int(e.timing_valid); a['edge_samples']+=int(e.raw_edge_bps is not None); a['raw_positive']+=int(e.raw_edge_bps is not None and e.raw_edge_bps>0); a['net_positive']+=int(e.net_edge_bps is not None and e.net_edge_bps>0); a['qualified']+=int(e.accepted)
        for name,val in (('raw',e.raw_edge_bps),('net',e.net_edge_bps),('expected',e.expected_edge_bps)):
            if val is not None:
                a['sum_'+name]+=val; a['max_'+name]=val if a['max_'+name] is None else max(a['max_'+name],val)
                if name=='expected': a['min_expected']=val if a['min_expected'] is None else min(a['min_expected'],val)
        a['sum_cov1']+=e.cov1; a['sum_cov2']+=e.cov2; a['sum_local_age']+=max(e.local_age1_ms,e.local_age2_ms); a['sum_exchange_age']+=max(v or 0 for v in [e.exchange_age1_ms,e.exchange_age2_ms]); a['sum_local_skew']+=e.local_skew_ms; a['sum_exchange_skew']+=e.exchange_skew_ms or 0; a['sum_traversable']+=e.max_traversable_quote; a['max_traversable']=e.max_traversable_quote if a['max_traversable'] is None else max(a['max_traversable'],e.max_traversable_quote); a['sum_fee1']+=e.fee_bps_leg1; a['sum_fee2']+=e.fee_bps_leg2; a['last_ts']=e.ts; a['last_reason']='|'.join(e.reasons) if e.reasons else 'OK'
        for r in e.hard_reasons: self.pending_reasons['HARD:'+r]+=1
        for r in e.timing_reasons: self.pending_reasons['TIMING:'+r]+=1
        if e.data_valid and e.timing_valid and not e.accepted: self.pending_reasons['EDGE:BELOW_EXPECTED']+=1

    def flush(self):
        with self.lock:
            rows=list(self.pending.values()); reasons=dict(self.pending_reasons); self.pending={}; self.pending_reasons=Counter(); self.last_flush=time.monotonic()
        self.db.upsert_route_aggs(rows); self.db.add_reason_counts(reasons); self.tracker.flush_active()

    def once(self):
        t=time.monotonic_ns(); ev=self._eval_routes(self.universe.routes)
        with self.lock:
            for e in ev: self._agg(e)
            self.scans+=1; self.evaluations+=len(ev); self.accepted+=sum(int(e.accepted) for e in ev); self.last_scan_evals=len(ev); self.scan_ms=(time.monotonic_ns()-t)/1e6
            # Slow sweep is analytical only; fast watcher owns opportunity lifecycle.
            if time.monotonic()-self.last_flush>=float(self.cfg.get('aggregate_flush_s',5.0)): self.flush()
        return len(ev)

    def fast_once(self,changed_symbols):
        t=time.monotonic_ns(); routes={r.route:r for s in changed_symbols for r in self.routes_by_symbol.get(s,[])}; ev=self._eval_routes(routes.values())
        self.tracker.process(ev)
        with self.lock:
            self.fast_batches+=1; self.fast_evaluations+=len(ev); self.fast_last_evals=len(ev); self.fast_ms=(time.monotonic_ns()-t)/1e6
            self.latest_candidates=sorted([e.as_dict() for e in ev],key=lambda z:(z.get('expected_edge_bps') if z.get('expected_edge_bps') is not None else -1e99),reverse=True)[:int(self.cfg.get('dashboard_candidate_limit',120))]
        return len(ev)

    def status(self):
        with self.lock:
            active=self.tracker.status(); return {'scans':self.scans,'evaluations':self.evaluations,'accepted_evaluations':self.accepted,'last_scan_ms':self.scan_ms,'last_scan_evals':self.last_scan_evals,
              'fast_batches':self.fast_batches,'fast_evaluations':self.fast_evaluations,'fast_last_ms':self.fast_ms,'fast_last_evals':self.fast_last_evals,'active_opportunities':active,
              'active_raw':len(active),'active_net':sum(1 for x in active if x.get('last_net_bps') is not None and x['last_net_bps']>0),'active_qualified':sum(1 for x in active if x.get('last_class')=='QUALIFIED')}
