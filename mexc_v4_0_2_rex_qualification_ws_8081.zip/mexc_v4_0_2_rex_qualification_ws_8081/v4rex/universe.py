from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import gzip,json,time,requests
REST='https://api.mexc.com'

@dataclass(frozen=True)
class SymbolRule:
    symbol:str; base:str; quote:str; status:str; spot_allowed:bool; api_default:bool
    base_precision:int|None; quote_precision:int|None; base_size_precision:str|None
    quote_amount_precision:str|None; max_quote_amount:str|None; maker_commission:str|None
    taker_commission:str|None; trade_side_type:str|None

@dataclass(frozen=True)
class Route:
    route:str; token:str; stable_a:str; stable_b:str; symbol1:str; symbol2:str

class Universe:
    def __init__(self,symbols,routes,excluded,raw_exchange_info,default_symbols,route_excluded=None):
        self.symbols=symbols; self.routes=routes; self.excluded=excluded; self.raw_exchange_info=raw_exchange_info
        self.default_symbols=default_symbols; self.route_excluded=route_excluded or []; self.by_symbol={s.symbol:s for s in symbols}
    def as_dict(self):
        by_token={}
        for s in self.symbols: by_token.setdefault(s.base,[]).append(s.quote)
        return {'symbol_count':len(self.symbols),'route_count':len(self.routes),'symbols':[asdict(x) for x in self.symbols],
                'routes':[asdict(x) for x in self.routes],'quotes_by_token':{k:sorted(v) for k,v in sorted(by_token.items())},
                'excluded':self.excluded,'route_excluded':self.route_excluded}

def _status_ok(status:Any)->bool:
    return str(status).upper() in {'1','ENABLED','ONLINE','TRADING'}

def _can_buy(t):
    # MEXC: 1=all, 2=buy only, 3=sell only. Missing => do not over-filter in Shadow.
    return t in (None,'None','', '1','2')

def _can_sell(t):
    return t in (None,'None','', '1','3')

def parse_exchange_info(payload:dict,cfg:dict,default_symbols:set[str]|None=None)->Universe:
    default_symbols=default_symbols or set(); target_tokens=set(cfg.get('tokens',[])); stablecoins=set(cfg.get('stablecoins',[]))
    require_default=bool(cfg.get('require_default_symbols',True)); selected=[]; excluded=[]
    for x in payload.get('symbols') or []:
        symbol=str(x.get('symbol') or ''); base=str(x.get('baseAsset') or ''); quote=str(x.get('quoteAsset') or '')
        if base not in target_tokens or quote not in stablecoins: continue
        reasons=[]; status=x.get('status')
        if not _status_ok(status): reasons.append('STATUS')
        spot=bool(x.get('isSpotTradingAllowed',False))
        if not spot: reasons.append('SPOT_API_DISABLED')
        api_default=(symbol in default_symbols) if default_symbols else True
        if require_default and default_symbols and not api_default: reasons.append('NOT_DEFAULT_API_SYMBOL')
        if reasons:
            excluded.append({'symbol':symbol,'base':base,'quote':quote,'reasons':reasons}); continue
        selected.append(SymbolRule(symbol,base,quote,str(status),spot,api_default,x.get('baseAssetPrecision'),x.get('quotePrecision'),
            x.get('baseSizePrecision'),x.get('quoteAmountPrecision'),x.get('maxQuoteAmount'),x.get('makerCommission'),x.get('takerCommission'),
            str(x.get('tradeSideType')) if x.get('tradeSideType') is not None else None))
    market={(s.base,s.quote):s for s in selected}; routes=[]; rex=[]
    for token in sorted(target_tokens):
        quotes=sorted(q for q in stablecoins if (token,q) in market)
        for a in quotes:
            for b in quotes:
                if a==b: continue
                s1=market[(token,a)]; s2=market[(token,b)]
                rr=f'{a}>{token}>{b}'; reasons=[]
                if not _can_buy(s1.trade_side_type): reasons.append('LEG1_BUY_NOT_ALLOWED')
                if not _can_sell(s2.trade_side_type): reasons.append('LEG2_SELL_NOT_ALLOWED')
                if reasons:
                    rex.append({'route':rr,'symbol1':s1.symbol,'symbol2':s2.symbol,'reasons':reasons}); continue
                routes.append(Route(rr,token,a,b,s1.symbol,s2.symbol))
    return Universe(selected,routes,excluded,payload,default_symbols,rex)

class UniverseBuilder:
    def __init__(self,cfg): self.cfg=cfg; self.session=requests.Session()
    def build(self):
        timeout=float(self.cfg.get('rest_timeout_s',8)); r=self.session.get(REST+'/api/v3/exchangeInfo',timeout=timeout); r.raise_for_status(); exchange=r.json(); defaults=set()
        try:
            x=self.session.get(REST+'/api/v3/defaultSymbols',timeout=timeout); x.raise_for_status(); defaults=set(x.json().get('data') or [])
        except Exception: defaults=set()
        return parse_exchange_info(exchange,self.cfg,defaults)
    @staticmethod
    def save_snapshot(universe,path):
        with gzip.open(path,'wt',encoding='utf-8') as f:
            json.dump({'saved_at':time.time(),'universe':universe.as_dict(),'exchange_info':universe.raw_exchange_info,'default_symbols':sorted(universe.default_symbols)},f,separators=(',',':'))
