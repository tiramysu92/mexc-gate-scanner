# CHANGELOG

## 4.0.2-rex-qualification
- Sépare intégrité du carnet et timing strict.
- Supprime les faux OPEN/CLOSE dus à l'inactivité normale d'un diff-depth événementiel.
- Ajoute un fast opportunity watcher déclenché par mises à jour de livres, debounce 25 ms.
- Conserve le sweep analytique complet à 200 ms.
- Utilise les taker commissions publiques exchangeInfo par jambe quand disponibles.
- Sépare bootstraps et recovery resyncs.
- Ajoute telemetry update queue/drops et statistiques timing strict.
- Dashboard technique/économique enrichi.
- Nouveau schéma SQLite 4.0.2 et DB séparée.

# MEXC V4.0.2-REX Qualification — SHADOW ONLY — :8081

Cette build est conçue pour tourner plusieurs heures et produire un dataset **analytique**, pas une avalanche de lignes identiques. Elle applique la SPEC V4.0-REX incluse dans le package.

## Ce qui change par rapport au smoke V4.0

- univers construit au démarrage depuis `GET /api/v3/exchangeInfo` + `GET /api/v3/defaultSymbols` : aucune hypothèse `TOKEN x 3 stables` ;
- WebSocket MEXC Diff.Depth Protobuf 10 ms ; codec aligné sur les champs officiels `PushDataV3ApiWrapper` / `PublicAggreDepthsV3Api` ;
- reconstruction locale conforme à la doctrine MEXC : buffer → snapshot `limit=5000` → premier delta couvrant `lastUpdateId+1` → continuité stricte ensuite ;
- snapshots REST throttlés pour éviter une rafale de 18 requêtes au boot ;
- télémétrie d'erreur persistée avec type, symbole, détail, versions ;
- horloge MEXC calibrée via `/api/v3/time` pour distinguer âge local / exchange / transport ;
- stockage séparé : `market_samples`, `route_aggregates`, `opportunity_events`, `opportunity_lifecycles`, `health_samples`, `collector_errors` ;
- opportunités suivies en cycle `OPEN / UPDATE / CLOSE` avec durée et pics ;
- raw edge, net edge (hypothèse de frais), expected edge (réserves configurables) distincts ;
- dashboard complet sur `http://IP_SERVEUR:8081` ;
- export online cohérent via SQLite backup, même scanner actif.

## Dashboard

La page :8081 expose :

- santé process : uptime, CPU, RAM, DB, threads ;
- WebSocket : READY/total, messages/s, gaps, resyncs, reconnects, decode errors, buffer overflow, ACK/PONG ;
- data quality : p50/p95 âge local, exchange, transport, spread ;
- santé de **chaque symbole** : bid/ask, version, génération, débit, âges, gaps/resync/errors et dernière erreur ;
- opportunités actives avec durée, peak raw/net/expected et statut qualifié ;
- meilleurs candidats instantanés, y compris refusés et raison précise ;
- événements OPEN/UPDATE/CLOSE ;
- agrégats par route/taille/fraction de profondeur ;
- répartition des motifs `STALE`, `SKEW`, `DEPTH`, `EDGE`, etc. ;
- univers réellement retenu et marchés exclus ;
- courbe santé 60 minutes.

## Hypothèses importantes

`fee_bps_default=5.0` signifie **5 bps par jambe comme hypothèse Shadow**, pas la commission réelle du compte. Une future qualification privée utilisera l'endpoint de commission et les frais effectivement débités. Les seuils d'âge/skew sont des garde-fous provisoires destinés à être recalibrés avec les distributions collectées.

## Installation

```bash
cd /home/ubuntu/mexc-spot-2leg-v4
mkdir -p runtime_v402
unzip -o mexc_v4_0_2_rex_qualification_ws_8081.zip -d runtime_v402
cd runtime_v402
./install.sh
```

Attendu : `25 passed` (ou plus si la suite est enrichie).

## Démarrage

Vérifier d'abord que 8081 est libre :

```bash
sudo ss -ltnp | grep ':8081' || echo '8081 LIBRE'
```

Puis :

```bash
./start.sh
sleep 30
./smoke_check.sh
```

## Gate avant run long

Ne pas lancer 8–12 h immédiatement. Contrôler 5 à 10 minutes :

- thread scanner vivant ;
- READY proche de 100 % des symboles retenus ;
- `scans > 0` et agrégats route alimentés ;
- pas de boucle continue de `RESYNC_RETRY` ;
- `gaps/min`, `resync/min`, `errors/min` faibles/stables après le boot ;
- pas de `BUFFER_OVERFLOW` ni thread fatal ;
- âges/skews plausibles ;
- DB croît lentement grâce aux agrégats, pas à des dizaines de milliers de décisions/s.

## Export sans arrêt du scanner

```bash
source .venv/bin/activate
python export_run.py
```

L'export contient un snapshot SQLite cohérent, un résumé `.json.gz`, le snapshot exchangeInfo et les SHA-256.

## Arrêt

```bash
./stop.sh
```

## Références MEXC utilisées

- Diff.Depth : `https://www.mexc.com/api-docs/spot-v3/websocket-market-streams/diffdepth-stream`
- Reconstruction locale : `https://www.mexc.com/api-docs/spot-v3/websocket-market-streams/how-to-properly-maintain-a-local-copy-of-the-order-book`
- Protobuf officiel : `https://github.com/mexcdevelop/websocket-proto`
- API V3 / exchangeInfo / defaultSymbols : `https://mexcdevelop.github.io/apidocs/spot_v3_en/`


## V4.0.2 — correction qualification temporelle
- Les âges de dernière modification et les skews de dernière modification ne rendent plus un carnet invalide à eux seuls.
- La continuité de version, l'état du carnet et la couverture de profondeur définissent l'intégrité.
- Les anciennes gardes temporelles restent calculées comme scénario `timing strict` et ne disparaissent pas de l'analyse.
- Opportunity lifecycle : OPEN/CLOSE sur intégrité + raw edge, pas sur un simple changement d'âge.
- Fast watcher événementiel : les mises à jour de carnet réveillent un moteur dédié (debounce 25 ms par défaut).
- Sweep complet 200 ms conservé pour les agrégats statistiques de toutes tailles/profondeurs.
- Frais taker publics `exchangeInfo` utilisés par symbole lorsqu'ils sont disponibles; fallback 5 bps/jambe clairement identifié.
- Bootstraps initiaux séparés des recovery resyncs.
- Dashboard enrichi : RAW/NET/QUAL, timing strict %, watcher rapide, queue/drop, frais par jambe.
