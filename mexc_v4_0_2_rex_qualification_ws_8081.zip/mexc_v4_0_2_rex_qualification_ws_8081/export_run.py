#!/usr/bin/env python3
import argparse,gzip,hashlib,json,os,sqlite3,time
from pathlib import Path
from v4rex.db import DB

p=argparse.ArgumentParser();p.add_argument('--config',default='config.json');p.add_argument('--out',default=None);a=p.parse_args()
cfg=json.load(open(a.config)); src=Path(cfg['db_path']); stamp=time.strftime('%Y%m%d_%H%M%S'); out=Path(a.out or f'export_v402_{stamp}');out.mkdir(parents=True,exist_ok=True)
# Consistent SQLite online backup, safe with WAL active.
s=sqlite3.connect(src); d=sqlite3.connect(out/'v4_rex_qualification_v402_snapshot.db'); s.backup(d); d.close(); s.close()
db=DB(str(out/'v4_rex_qualification_v402_snapshot.db'))
summary={'generated_at':time.time(),'version':'4.0.2-rex-qualification','config':cfg,'counts':db.counts(),'routes':db.route_summary(100000),'reasons':db.reasons(),'lifecycles':db.recent_lifecycles(100000),'errors':db.recent_errors(10000)}
with gzip.open(out/'analysis_summary.json.gz','wt',encoding='utf-8') as f: json.dump(summary,f,separators=(',',':'),default=str)
if Path('exchange_info_v402_start.json.gz').exists(): (out/'exchange_info_v402_start.json.gz').write_bytes(Path('exchange_info_v402_start.json.gz').read_bytes())
lines=[]
for f in sorted(out.iterdir()):
 if f.is_file() and f.name!='SHA256SUMS': lines.append(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name)
(out/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
print(out.resolve())
