# V4.2.2-REX Adaptive Depth — FULL UNIVERSE 2-LEG — SHADOW ONLY

Cette build conserve **toutes les routes MEXC Spot stablecoin A → token → stablecoin B** mais remplace les 635 Diff.Depth 10 ms permanents par une architecture à deux étages.

## Tier 1 — découverte exhaustive
- `BookTicker @10ms` sur **tous les symboles éligibles**.
- Universe dynamique via `exchangeInfo + defaultSymbols`.
- WS équilibrés par activité 24 h, 20 streams max par WS.
- Toute route BBO+ déclenche Tier 2.

## Tier 2 — viabilité concrète
- `Partial Book Depth @20 levels` activé dynamiquement sur les deux jambes d'une route BBO+.
- Le Depth reste chaud 30 s après la dernière détection BBO+.
- Une opportunité concrète n'est enregistrée que lorsque les deux Depth sont READY et que leur top-of-book correspond au BBO courant.
- 6 tailles × 8 fractions de profondeur.
- Cooldown d'affichage/persistance : **5 s par route**, sans ralentir la détection.

## Pourquoi cette architecture
Le smoke V4.1.1 a validé le protocole (0 decode error, ACK/PONG corrects, 635/635) mais montré 0.5–1.6 s de backlog sur certains WS avec 635 Diff.Depth 10 ms permanents. Le BBO est un préfiltre exhaustif : si `bestBid(L2) <= bestAsk(L1)`, parcourir davantage de profondeur ne peut pas créer un edge positif.

## Interface 8081
- Univers : tokens / symboles / routes.
- BBO WS : msg/s, queues, âge queue, decode p50/p95, drops/errors.
- Depth dynamique : symboles chauds, warmup, TTL, WS, queue.
- **Opportunités 2-leg concrètes** : route, taille, profondeur, raw, frais, net, expected, PnL, coverage, traversable, latences.
- Routes BBO+ en vérification Depth, séparées du tableau concret.
- Viabilité 24h par route.

## Installation
```bash
./install.sh
./start.sh
sleep 60
./smoke_check.sh
```

## Export cohérent
```bash
python export_run.py
```

## 4.2.1 UI robustness
The dashboard no longer fails globally if an optional table endpoint has a transient error. Dynamic Depth websocket symbol sets are snapshotted under lock before serialization.


## 4.2.2 — observabilité thread-safe
- Corrige `RuntimeError: deque mutated during iteration` dans `ws_status()`.
- Snapshots atomiques des métriques `msg_times` / `decode_lags` sous lock dédié.
- Les calculs de taux ne mutent plus les deques partagées.
- Les métriques Hot Depth sont snapshotées sous lock avant sérialisation.
- `recent_errors` et la map dynamique Depth sont snapshotés sous lock.
- Le thread `health` ne meurt plus sur une erreur de télémétrie transitoire : il journalise, reste vivant et se rétablit au cycle suivant.
- `/healthz` passe temporairement `ok:false` pendant une erreur puis revient automatiquement `ok:true` après récupération.
- Tests de concurrence dédiés ajoutés.
