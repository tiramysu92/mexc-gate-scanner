# V4.2.0

- Full-universe conservé : toutes les routes 2-leg restent surveillées.
- Remplacement du Diff.Depth permanent par `BookTicker 10ms` sur tout l'univers.
- `Partial Book Depth 20` dynamique sur les symboles de routes BBO+.
- Hot-depth TTL 30 s, souscriptions/désouscriptions automatiques.
- Validation `Depth top == BBO top` avant toute opportunité concrète.
- Cooldown 5 s par route pour la restitution, pas pour la détection.
- Tableau principal limité aux opportunités réellement depth-vérifiées.
- Tableau séparé des routes BBO+ en phase WARMING / DEPTH_READY / DEPTH_SYNCED.
- Mesures distinctes BBO transport/decode et Depth transport/decode.
- Export des candidate windows et opportunités concrètes.

## 4.2.1
- UI refresh is resilient to optional API failures.
- Removed unused `/api/depth-ws` dependency from the main refresh path.
- Hot-depth status and WS status snapshot dynamic symbol sets under lock to avoid transient `Set changed size during iteration` 500s.
- Dashboard uses explicit DOM lookups instead of relying on browser id-to-global behavior.
- UI error pill now includes the failing HTTP/error message.


## 4.2.2
- Fix complet des lectures concurrentes de métriques WS (`deque mutated during iteration`).
- Locks dédiés pour snapshots des deques BBO/Depth.
- `_rate()` est désormais purement read-only.
- Health loop auto-résiliente au lieu de mourir définitivement sur une erreur d'observabilité.
- `/healthz` reflète l'état dégradé et le rétablissement automatique.
- Ajout de tests de concurrence ; 36 tests verts.
