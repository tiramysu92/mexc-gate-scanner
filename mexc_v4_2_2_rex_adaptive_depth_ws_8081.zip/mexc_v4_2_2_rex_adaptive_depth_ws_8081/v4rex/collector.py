from __future__ import annotations
import json, math, random, threading, time, queue
from collections import deque
from typing import Callable, Optional
import requests, websocket
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory
from .core import BBO, DepthBook, L, Store

REST='https://api.mexc.com'; WS='wss://wbs-api.mexc.com/ws'

def _codec():
    fd=descriptor_pb2.FileDescriptorProto(name='mexc_v420.proto',package='v420',syntax='proto3')
    def msg(n):m=fd.message_type.add();m.name=n;return m
    def fld(m,n,num,typ,repeated=False,target=None,oneof=None):
        f=m.field.add();f.name=n;f.number=num;f.type=typ;f.label=3 if repeated else 1
        if target:f.type_name='.v420.'+target
        if oneof is not None:f.oneof_index=oneof
    lev=msg('PublicLimitDepthV3ApiItem');fld(lev,'price',1,9);fld(lev,'quantity',2,9)
    dep=msg('PublicLimitDepthsV3Api');fld(dep,'asks',1,11,True,'PublicLimitDepthV3ApiItem');fld(dep,'bids',2,11,True,'PublicLimitDepthV3ApiItem');fld(dep,'eventType',3,9);fld(dep,'version',4,9);fld(dep,'lastOrderCreateTime',5,3)
    bt=msg('PublicAggreBookTickerV3Api');fld(bt,'bidPrice',1,9);fld(bt,'bidQuantity',2,9);fld(bt,'askPrice',3,9);fld(bt,'askQuantity',4,9);fld(bt,'version',5,9);fld(bt,'lastOrderCreateTime',6,3)
    env=msg('PushDataV3ApiWrapper');fld(env,'channel',1,9);o=env.oneof_decl.add();o.name='body';fld(env,'publicLimitDepths',303,11,False,'PublicLimitDepthsV3Api',0);fld(env,'publicAggreBookTicker',315,11,False,'PublicAggreBookTickerV3Api',0);fld(env,'symbol',3,9);fld(env,'symbolId',4,9);fld(env,'createTime',5,3);fld(env,'sendTime',6,3)
    pool=descriptor_pool.DescriptorPool();pool.Add(fd)
    return message_factory.GetMessageClass(pool.FindMessageTypeByName('v420.PushDataV3ApiWrapper'))
Envelope=_codec()

def control_frame(raw):
    if isinstance(raw,str):s=raw
    elif isinstance(raw,(bytes,bytearray)):
        b=bytes(raw).lstrip()
        if b[:1] not in (b'{',b'['):return None
        try:s=bytes(raw).decode('utf-8')
        except UnicodeDecodeError:return None
    else:return None
    try:x=json.loads(s)
    except Exception:return None
    return x if isinstance(x,dict) else None

def decode_bbo(payload:bytes):
    e=Envelope();e.ParseFromString(payload)
    if not e.symbol or not e.HasField('publicAggreBookTicker'):return None
    x=e.publicAggreBookTicker
    try:
        bid=float(x.bidPrice);ask=float(x.askPrice);bq=float(x.bidQuantity);aq=float(x.askQuantity);ver=int(x.version) if x.version else None
    except (ValueError,TypeError):return None
    if not (math.isfinite(bid) and math.isfinite(ask) and bid>0 and ask>0 and bid<ask and bq>=0 and aq>=0):return None
    return {'symbol':e.symbol,'send':int(e.sendTime or 0),'version':ver,'bid':bid,'ask':ask,'bid_qty':bq,'ask_qty':aq}

def decode_depth(payload:bytes):
    e=Envelope();e.ParseFromString(payload)
    if not e.symbol or not e.HasField('publicLimitDepths'):return None
    x=e.publicLimitDepths
    try:
        ver=int(x.version) if x.version else None
        bids=tuple(sorted((L(float(z.price),float(z.quantity)) for z in x.bids if float(z.quantity)>0),key=lambda a:a.p,reverse=True))
        asks=tuple(sorted((L(float(z.price),float(z.quantity)) for z in x.asks if float(z.quantity)>0),key=lambda a:a.p))
    except (ValueError,TypeError):return None
    if not bids or not asks or bids[0].p>=asks[0].p:return None
    return {'symbol':e.symbol,'send':int(e.sendTime or 0),'version':ver,'bids':bids,'asks':asks}

def percentile(vals,p):
    a=sorted(float(x) for x in vals if x is not None and math.isfinite(float(x)))
    if not a:return None
    if len(a)==1:return a[0]
    k=(len(a)-1)*p;lo=int(k);hi=min(len(a)-1,lo+1);w=k-lo
    return a[lo]*(1-w)+a[hi]*w

class ClockSync:
    def __init__(self):self.offset_ms=0.0;self.rtt_ms=None
    def sync(self,sess,samples=5):
        best=None
        for _ in range(samples):
            try:
                a=time.time()*1000;r=sess.get(REST+'/api/v3/time',timeout=3);r.raise_for_status();b=time.time()*1000
                s=float(r.json()['serverTime']);z=(b-a,s-(a+b)/2)
                if best is None or z[0]<best[0]:best=z
            except Exception:pass
            time.sleep(.03)
        if best:self.rtt_ms,self.offset_ms=best
        return self.offset_ms

class BBOCollector:
    def __init__(self,cfg,store,groups,error):
        self.cfg=cfg;self.store=store;self.error=error;self.stop=False;self.lock=threading.RLock();self.channels={};self.rx_event=threading.Event();self.messages=0;self.acks=0;self.pongs=0;self.errors=0;self.reconnects=0;self.binary_controls=0
        for p in groups:
            wid=int(p['id']);self.channels[wid]={'id':wid,'symbols':list(p['symbols']),'symbol_count':len(p['symbols']),'estimated_load':float(p.get('load_score') or 0),'connected':False,'generation':0,'app':None,'opened_ts':None,'last_message_ts':None,'last_frame_ts':None,'messages':0,'msg_times':deque(maxlen=100000),'acks':0,'pongs':0,'controls':0,'errors':0,'reconnects':0,'rx':deque(),'rx_lock':threading.Lock(),'stats_lock':threading.Lock(),'rx_bytes':0,'rx_drops':0,'queue_lags':deque(maxlen=10000),'decode_lags':deque(maxlen=10000)}
    def _ctrl(self,raw,wid):
        j=control_frame(raw)
        if j is None:return False
        c=self.channels[wid]
        with c['stats_lock']:
            c['controls']+=1
            if str(j.get('msg','')).upper()=='PONG':self.pongs+=1;c['pongs']+=1
            else:self.acks+=1;c['acks']+=1
        if isinstance(raw,(bytes,bytearray)):self.binary_controls+=1
        return True
    def _enqueue(self,wid,payload,recv_ns,recv_wall):
        c=self.channels[wid];mx=int(self.cfg.get('bbo_rx_queue_max_frames',8192));mb=int(self.cfg.get('bbo_rx_queue_max_bytes',16*1024*1024))
        with c['rx_lock']:
            if len(c['rx'])>=mx or c['rx_bytes']+len(payload)>mb:
                c['rx_drops']+=1;self.error('BBO_RX_OVERFLOW',None,f'wid={wid}');return
            c['rx'].append((bytes(payload),recv_ns,recv_wall));c['rx_bytes']+=len(payload)
        self.rx_event.set()
    def _process(self,wid,quantum):
        c=self.channels[wid];n=0
        for _ in range(quantum):
            with c['rx_lock']:
                if not c['rx']:break
                raw,rns,rwall=c['rx'].popleft();c['rx_bytes']-=len(raw)
            qlag=(time.monotonic_ns()-rns)/1e6
            with c['stats_lock']:c['queue_lags'].append(qlag)
            try:
                x=decode_bbo(raw)
                if x and x['symbol'] in c['symbols']:
                    apply=time.monotonic_ns();self.store.put_bbo(BBO(x['symbol'],x['bid'],x['bid_qty'],x['ask'],x['ask_qty'],x['version'],x['send'] or None,rwall,rns,apply,wid,'VALID'))
                    lag=(apply-rns)/1e6
                    with c['stats_lock']:
                        c['decode_lags'].append(lag);c['messages']+=1;c['last_message_ts']=time.time();c['msg_times'].append(time.monotonic())
                    self.messages+=1;n+=1
            except Exception as exc:
                with c['stats_lock']:c['errors']+=1
                self.errors+=1;self.error('BBO_DECODE',None,repr(exc),wid=wid)
        return n
    def _decoder(self,wids):
        pos=0;q=max(1,int(self.cfg.get('bbo_decoder_quantum',128)))
        while not self.stop:
            work=0
            for i in range(len(wids)):work+=self._process(wids[(pos+i)%len(wids)],q)
            if wids:pos=(pos+1)%len(wids)
            if not work:self.rx_event.clear();self.rx_event.wait(.002)
    def _socket(self,wid):
        c=self.channels[wid];back=.5
        while not self.stop:
            c['generation']+=1;gen=c['generation'];opened=time.monotonic()
            def on_open(ws):
                c['connected']=True;c['opened_ts']=time.time();ws.send(json.dumps({'method':'SUBSCRIPTION','params':[f'spot@public.aggre.bookTicker.v3.api.pb@10ms@{s}' for s in c['symbols']]}))
            def on_msg(ws,msg):
                c['last_frame_ts']=time.time();rns=time.monotonic_ns();rw=time.time()*1000
                if self._ctrl(msg,wid):return
                if isinstance(msg,(bytes,bytearray)):self._enqueue(wid,msg,rns,rw)
            def on_err(ws,e):
                with c['stats_lock']:c['errors']+=1
                self.errors+=1;self.error('BBO_WS',None,repr(e),wid=wid)
            def on_close(ws,code,msg):c['connected']=False
            app=websocket.WebSocketApp(WS,on_open=on_open,on_message=on_msg,on_error=on_err,on_close=on_close);c['app']=app
            def ping():
                while not self.stop and c['connected']:
                    time.sleep(float(self.cfg.get('ping_interval_s',15)))
                    try:app.send(json.dumps({'method':'PING'}))
                    except Exception:return
            threading.Thread(target=ping,daemon=True).start()
            try:app.run_forever(ping_interval=0,skip_utf8_validation=True)
            except Exception as exc:self.error('BBO_WS_RUN',None,repr(exc),wid=wid)
            c['connected']=False
            if self.stop:break
            self.reconnects+=1
            with c['stats_lock']:c['reconnects']+=1
            time.sleep(back+random.random()*.2);back=min(15,back*1.6)
    def run(self):
        workers=max(1,int(self.cfg.get('bbo_decoder_workers',8)));ids=sorted(self.channels)
        for w in range(workers):
            z=[wid for i,wid in enumerate(ids) if i%workers==w]
            threading.Thread(target=self._decoder,args=(z,),daemon=True,name=f'bbo-decoder-{w+1}').start()
        for wid in ids:threading.Thread(target=self._socket,args=(wid,),daemon=True,name=f'bbo-ws-{wid}').start()
    def _rate(self,times):
        now=time.monotonic()
        return sum(1 for t in times if now-t<=10.0)/10.0
    def ws_status(self):
        now=time.time();out=[]
        for wid in sorted(self.channels):
            c=self.channels[wid]
            with c['rx_lock']:
                qn=len(c['rx']);old=(time.monotonic_ns()-c['rx'][0][1])/1e6 if c['rx'] else 0.0;qb=c['rx_bytes'];drops=c['rx_drops']
            with c['stats_lock']:
                msg_times=tuple(c['msg_times']);decode_lags=tuple(c['decode_lags']);messages=c['messages'];acks=c['acks'];pongs=c['pongs'];errors=c['errors'];last_message_ts=c['last_message_ts']
            out.append({'id':wid,'connected':c['connected'],'symbol_count':c['symbol_count'],'messages':messages,'msg_rate_10s':self._rate(msg_times),'rx_queue':qn,'rx_bytes':qb,'rx_queue_age_ms':old,'rx_drops':drops,'decode_lag_p50_ms':percentile(decode_lags,.5),'decode_lag_p95_ms':percentile(decode_lags,.95),'acks':acks,'pongs':pongs,'errors':errors,'reconnects':c['reconnects'],'last_message_age_s':max(0,now-last_message_ts) if last_message_ts else None,'estimated_load':c['estimated_load'],'symbols':tuple(c['symbols'])})
        return out

class HotDepthCollector:
    def __init__(self,cfg,store,error):
        self.cfg=cfg;self.store=store;self.error=error;self.stop=False;self.lock=threading.RLock();self.channels={};self.symbol_channel={};self.expiry={};self.activated_at={};self.ready_at={};self.q=queue.Queue(maxsize=int(cfg.get('depth_rx_queue_max_frames',100000)));self.q_drops=0;self.messages=0;self.acks=0;self.pongs=0;self.errors=0;self.next_id=1
        self.ttl=float(cfg.get('hot_depth_ttl_s',30));self.group_size=max(1,min(30,int(cfg.get('hot_depth_group_size',20))));self.max_ws=max(1,int(cfg.get('hot_depth_max_ws',32)))
    def _new_channel(self):
        if len(self.channels)>=self.max_ws:return None
        wid=self.next_id;self.next_id+=1;c={'id':wid,'symbols':set(),'connected':False,'app':None,'messages':0,'msg_times':deque(maxlen=50000),'stats_lock':threading.Lock(),'errors':0,'acks':0,'pongs':0,'opened_ts':None,'last_message_ts':None};self.channels[wid]=c
        threading.Thread(target=self._socket,args=(wid,),daemon=True,name=f'hot-depth-ws-{wid}').start();return c
    def _choose(self):
        with self.lock:
            pool=[c for c in self.channels.values() if len(c['symbols'])<self.group_size]
            if pool:return min(pool,key=lambda c:len(c['symbols']))
            return self._new_channel()
    def touch(self,symbols):
        now=time.time();new=[]
        with self.lock:
            for s in symbols:
                self.expiry[s]=max(self.expiry.get(s,0),now+self.ttl)
                if s in self.symbol_channel:continue
                c=self._choose()
                if c is None:
                    self.error('HOT_DEPTH_CAPACITY',s,'no depth WS capacity');continue
                c['symbols'].add(s);self.symbol_channel[s]=c['id'];self.activated_at[s]=now;new.append((s,c['id']))
        for s,wid in new:
            c=self.channels[wid];app=c.get('app')
            if c.get('connected') and app:
                try:app.send(json.dumps({'method':'SUBSCRIPTION','params':[f'spot@public.limit.depth.v3.api.pb@{s}@20']}))
                except Exception as exc:self.error('DEPTH_SUBSCRIBE',s,repr(exc),wid=wid)
    def _socket(self,wid):
        c=self.channels[wid];back=.5
        while not self.stop:
            def on_open(ws):
                c['connected']=True;c['opened_ts']=time.time()
                with self.lock:syms=list(c['symbols'])
                if syms:ws.send(json.dumps({'method':'SUBSCRIPTION','params':[f'spot@public.limit.depth.v3.api.pb@{s}@20' for s in syms]}))
            def on_msg(ws,msg):
                j=control_frame(msg)
                if j is not None:
                    with c['stats_lock']:
                        if str(j.get('msg','')).upper()=='PONG':c['pongs']+=1;self.pongs+=1
                        else:c['acks']+=1;self.acks+=1
                    return
                if not isinstance(msg,(bytes,bytearray)):return
                item=(wid,bytes(msg),time.monotonic_ns(),time.time()*1000)
                try:self.q.put_nowait(item)
                except queue.Full:self.q_drops+=1;self.error('DEPTH_RX_OVERFLOW',None,f'wid={wid}')
            def on_err(ws,e):
                with c['stats_lock']:c['errors']+=1
                self.errors+=1;self.error('DEPTH_WS',None,repr(e),wid=wid)
            def on_close(ws,code,msg):c['connected']=False
            app=websocket.WebSocketApp(WS,on_open=on_open,on_message=on_msg,on_error=on_err,on_close=on_close);c['app']=app
            def ping():
                while not self.stop and c['connected']:
                    time.sleep(float(self.cfg.get('ping_interval_s',15)))
                    try:app.send(json.dumps({'method':'PING'}))
                    except Exception:return
            threading.Thread(target=ping,daemon=True).start()
            try:app.run_forever(ping_interval=0,skip_utf8_validation=True)
            except Exception as exc:self.error('DEPTH_WS_RUN',None,repr(exc),wid=wid)
            c['connected']=False
            if self.stop:break
            time.sleep(back+random.random()*.2);back=min(15,back*1.6)
    def _decode_loop(self):
        while not self.stop:
            try:wid,raw,rns,rwall=self.q.get(timeout=.1)
            except queue.Empty:continue
            try:
                x=decode_depth(raw)
                if not x:continue
                with self.lock:
                    if self.symbol_channel.get(x['symbol'])!=wid:continue
                apply=time.monotonic_ns();self.store.put_depth(DepthBook(x['symbol'],x['bids'],x['asks'],x['version'],x['send'] or None,rwall,rns,apply,wid,'VALID'))
                c=self.channels[wid]
                with c['stats_lock']:
                    c['messages']+=1;c['msg_times'].append(time.monotonic());c['last_message_ts']=time.time()
                self.messages+=1
                with self.lock:
                    if x['symbol'] not in self.ready_at:self.ready_at[x['symbol']]=time.time()
            except Exception as exc:self.errors+=1;self.error('DEPTH_DECODE',None,repr(exc),wid=wid)
    def _expiry_loop(self):
        while not self.stop:
            now=time.time();expired=[]
            with self.lock:
                for s,t in list(self.expiry.items()):
                    if t<=now:expired.append(s)
            for s in expired:self._deactivate(s)
            time.sleep(1)
    def _deactivate(self,s):
        with self.lock:
            wid=self.symbol_channel.pop(s,None);self.expiry.pop(s,None);self.activated_at.pop(s,None);self.ready_at.pop(s,None)
            if wid is None:return
            c=self.channels.get(wid)
            if c:c['symbols'].discard(s);app=c.get('app')
            else:app=None
        if app and c.get('connected'):
            try:app.send(json.dumps({'method':'UNSUBSCRIPTION','params':[f'spot@public.limit.depth.v3.api.pb@{s}@20']}))
            except Exception:pass
        self.store.drop_depth(s)
    def run(self):
        for i in range(max(1,int(self.cfg.get('hot_depth_decoder_workers',4)))):threading.Thread(target=self._decode_loop,daemon=True,name=f'hot-depth-decoder-{i+1}').start()
        threading.Thread(target=self._expiry_loop,daemon=True,name='hot-depth-expiry').start()
    def _rate(self,times):
        now=time.monotonic()
        return sum(1 for t in times if now-t<=10.0)/10.0
    def warmup_ms(self, symbol):
        with self.lock:
            a=self.activated_at.get(symbol); r=self.ready_at.get(symbol)
        return (r-a)*1000.0 if a is not None and r is not None else None
    def status(self):
        now=time.time()
        with self.lock:
            hot=list(self.symbol_channel)
            symbol_channel=dict(self.symbol_channel)
            expiry=dict(self.expiry)
            act=dict(self.activated_at)
            ready=dict(self.ready_at)
            ch=[{'connected':bool(c['connected'])} for c in self.channels.values()]
        return {'hot_symbols':len(hot),'ws_connected':sum(1 for c in ch if c['connected']),'ws_total':len(ch),'messages':self.messages,'queue':self.q.qsize(),'queue_drops':self.q_drops,'errors':self.errors,'acks':self.acks,'pongs':self.pongs,'symbols':[{'symbol':s,'ws_id':symbol_channel.get(s),'status':'READY' if self.store.get_depth(s) else 'WARMING','warmup_ms':((ready.get(s)-act.get(s))*1000 if ready.get(s) is not None and act.get(s) is not None else None),'ttl_s':max(0,expiry.get(s,0)-now)} for s in hot]}
    def ws_status(self):
        now=time.time();out=[]
        with self.lock:refs=[(c,tuple(c['symbols'])) for c in self.channels.values()]
        chs=[]
        for c,symbols in refs:
            with c['stats_lock']:
                chs.append({'id':c['id'],'connected':bool(c['connected']),'symbols':symbols,'messages':c['messages'],'msg_times':tuple(c['msg_times']),'acks':c['acks'],'pongs':c['pongs'],'errors':c['errors'],'last_message_ts':c['last_message_ts']})
        for c in chs:
            out.append({'id':c['id'],'connected':c['connected'],'symbol_count':len(c['symbols']),'symbols':sorted(c['symbols']),'messages':c['messages'],'msg_rate_10s':self._rate(c['msg_times']),'acks':c['acks'],'pongs':c['pongs'],'errors':c['errors'],'last_message_age_s':max(0,now-c['last_message_ts']) if c['last_message_ts'] else None})
        return out

class Collector:
    def __init__(self,cfg,store:Store,symbols,ws_groups=None,error_sink:Optional[Callable[[dict],None]]=None):
        self.cfg=cfg;self.store=store;self.symbols=list(symbols);self.error_sink=error_sink;self.stop=False;self.session=requests.Session();self.clock=ClockSync();self.clock.sync(self.session);self.recent_errors=deque(maxlen=300);self.error_count=0;self.error_lock=threading.Lock()
        def err(kind,symbol=None,detail='',**extra):
            ev={'ts':time.time(),'kind':kind,'symbol':symbol,'detail':str(detail)[:1000],**extra}
            with self.error_lock:self.error_count+=1;self.recent_errors.appendleft(ev)
            if self.error_sink:
                try:self.error_sink(ev)
                except Exception:pass
        self._err=err;self.bbo=BBOCollector(cfg,store,ws_groups or [],err);self.depth=HotDepthCollector(cfg,store,err)
    def run(self):
        self.bbo.run();self.depth.run()
        while not self.stop:time.sleep(.5)
        self.bbo.stop=True;self.depth.stop=True
        for c in self.bbo.channels.values():
            try:
                if c.get('app'):c['app'].close()
            except Exception:pass
        for c in self.depth.channels.values():
            try:
                if c.get('app'):c['app'].close()
            except Exception:pass
    def touch_depth(self,symbols):self.depth.touch(symbols)
    def ws_status(self):return self.bbo.ws_status()
    def depth_ws_status(self):return self.depth.ws_status()
    def symbol_status(self):
        bbo=self.store.snapshot_bbo();depth=self.store.snapshot_depth();wid={s:w for w,c in self.bbo.channels.items() for s in c['symbols']}
        with self.depth.lock:depth_channels=dict(self.depth.symbol_channel)
        out=[]
        for s in self.symbols:
            b=bbo.get(s);d=depth.get(s);dw=depth_channels.get(s)
            out.append({'symbol':s,'ws_id':wid.get(s),'ready':b is not None,'bid':b.bid if b else None,'ask':b.ask if b else None,'spread_bps':b.spread_bps if b else None,'version':b.version if b else None,'transport_age_ms':b.transport_delay_ms(self.clock.offset_ms) if b else None,'decode_lag_ms':b.decode_lag_ms if b else None,'inactivity_ms':b.inactivity_ms if b else None,'depth_hot':d is not None or dw is not None,'depth_ready':d is not None,'depth_ws_id':d.ws_id if d else dw,'depth_levels':min(len(d.bids),len(d.asks)) if d else 0,'depth_transport_ms':d.transport_delay_ms(self.clock.offset_ms) if d else None,'depth_decode_lag_ms':d.decode_lag_ms if d else None})
        return out
    def status(self):
        ws=self.bbo.ws_status();depth=self.depth.status();bbos=self.store.snapshot_bbo();trans=[x.transport_delay_ms(self.clock.offset_ms) for x in bbos.values()];dec=[x.decode_lag_ms for x in bbos.values()]
        with self.error_lock:error_count=self.error_count;recent_errors=list(self.recent_errors)[:30]
        return {'symbols':len(self.symbols),'ready':len(bbos),'messages':self.bbo.messages,'msg_rate_10s':sum(x['msg_rate_10s'] for x in ws),'errors':error_count,'reconnects':self.bbo.reconnects,'acks':self.bbo.acks,'pongs':self.bbo.pongs,'binary_json_controls':self.bbo.binary_controls,'ws_connected':sum(1 for x in ws if x['connected']),'ws_total':len(ws),'subscriptions':sum(x['symbol_count'] for x in ws),'rx_queue_total':sum(x['rx_queue'] for x in ws),'rx_queue_age_max_ms':max([x['rx_queue_age_ms'] for x in ws] or [0]),'decode_lag_p95_max_ms':max([x['decode_lag_p95_ms'] or 0 for x in ws] or [0]),'transport_p50_ms':percentile(trans,.5),'transport_p95_ms':percentile(trans,.95),'decode_p50_ms':percentile(dec,.5),'decode_p95_ms':percentile(dec,.95),'clock_offset_ms':self.clock.offset_ms,'clock_sync_rtt_ms':self.clock.rtt_ms,'hot_depth':depth,'recent_errors':recent_errors}
