# V4.0.1-REX Qualification

- Corrige le contrat SQLite ayant tué le thread scanner du premier smoke-test.
- Corrige l'univers supposé : routes réelles depuis MEXC.
- Corrige le pont snapshot/delta selon la règle de couverture de `lastUpdateId+1`.
- Ajoute throttling snapshot, clock sync, erreurs persistées et métriques par symbole.
- Remplace les écritures de chaque décision par des agrégats cumulés.
- Ajoute lifecycle complet des opportunités.
- Ajoute dashboard technique + économique complet.
- Ajoute export online et scripts install/start/stop/smoke.
- 25 tests unitaires locaux au packaging.
