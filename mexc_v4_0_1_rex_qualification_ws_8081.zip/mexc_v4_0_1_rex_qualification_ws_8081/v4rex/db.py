from __future__ import annotations
import json
import os
import sqlite3
import threading
import time
from typing import Iterable

SCHEMA = r'''
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA temp_store=MEMORY;

CREATE TABLE IF NOT EXISTS meta(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS universe_symbols(
  symbol TEXT PRIMARY KEY, base TEXT, quote TEXT, status TEXT,
  spot_allowed INTEGER, api_default INTEGER,
  base_precision INTEGER, quote_precision INTEGER,
  base_size_precision TEXT, quote_amount_precision TEXT,
  max_quote_amount TEXT, maker_commission TEXT, taker_commission TEXT,
  trade_side_type TEXT
);

CREATE TABLE IF NOT EXISTS collector_errors(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL, kind TEXT NOT NULL, symbol TEXT, detail TEXT,
  extra_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_collector_errors_ts ON collector_errors(ts);

CREATE TABLE IF NOT EXISTS market_samples(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL, symbol TEXT NOT NULL, ready INTEGER,
  bid REAL, ask REAL, spread_bps REAL,
  local_age_ms REAL, exchange_age_ms REAL, transport_age_ms REAL,
  version INTEGER, generation INTEGER, msg_rate_10s REAL,
  gaps INTEGER, resyncs INTEGER, errors INTEGER
);
CREATE INDEX IF NOT EXISTS idx_market_samples_ts ON market_samples(ts);
CREATE INDEX IF NOT EXISTS idx_market_samples_symbol_ts ON market_samples(symbol,ts);

CREATE TABLE IF NOT EXISTS health_samples(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL, uptime_s REAL,
  ready_symbols INTEGER, total_symbols INTEGER,
  ws_msg_rate REAL, messages INTEGER, gaps INTEGER, resyncs INTEGER,
  reconnects INTEGER, collector_errors INTEGER,
  scan_ms REAL, evals_per_scan INTEGER, scans INTEGER,
  active_opportunities INTEGER,
  cpu_pct REAL, rss_mb REAL, db_mb REAL
);
CREATE INDEX IF NOT EXISTS idx_health_ts ON health_samples(ts);

CREATE TABLE IF NOT EXISTS route_aggregates(
  route TEXT NOT NULL, token TEXT NOT NULL, stable_a TEXT NOT NULL, stable_b TEXT NOT NULL,
  size REAL NOT NULL, fraction REAL NOT NULL,
  samples INTEGER NOT NULL DEFAULT 0,
  data_valid INTEGER NOT NULL DEFAULT 0,
  edge_samples INTEGER NOT NULL DEFAULT 0,
  raw_positive INTEGER NOT NULL DEFAULT 0,
  net_positive INTEGER NOT NULL DEFAULT 0,
  qualified INTEGER NOT NULL DEFAULT 0,
  sum_raw REAL NOT NULL DEFAULT 0,
  sum_net REAL NOT NULL DEFAULT 0,
  sum_expected REAL NOT NULL DEFAULT 0,
  max_raw REAL,
  max_net REAL,
  max_expected REAL,
  min_expected REAL,
  sum_cov1 REAL NOT NULL DEFAULT 0,
  sum_cov2 REAL NOT NULL DEFAULT 0,
  sum_local_age REAL NOT NULL DEFAULT 0,
  sum_exchange_age REAL NOT NULL DEFAULT 0,
  sum_local_skew REAL NOT NULL DEFAULT 0,
  sum_exchange_skew REAL NOT NULL DEFAULT 0,
  sum_traversable REAL NOT NULL DEFAULT 0,
  max_traversable REAL,
  last_ts REAL,
  last_reason TEXT,
  PRIMARY KEY(route,size,fraction)
);

CREATE TABLE IF NOT EXISTS reason_aggregates(
  reason TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0,
  last_ts REAL
);

CREATE TABLE IF NOT EXISTS opportunity_events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL, event_type TEXT NOT NULL, opp_id TEXT NOT NULL,
  route TEXT NOT NULL, token TEXT NOT NULL, size REAL NOT NULL, fraction REAL NOT NULL,
  raw_edge_bps REAL, net_edge_bps REAL, expected_edge_bps REAL,
  cov1 REAL, cov2 REAL, local_skew_ms REAL, exchange_skew_ms REAL,
  qualified INTEGER, reason TEXT, duration_ms REAL
);
CREATE INDEX IF NOT EXISTS idx_opp_events_ts ON opportunity_events(ts);
CREATE INDEX IF NOT EXISTS idx_opp_events_route ON opportunity_events(route,ts);

CREATE TABLE IF NOT EXISTS opportunity_lifecycles(
  opp_id TEXT PRIMARY KEY,
  route TEXT NOT NULL, token TEXT NOT NULL, size REAL NOT NULL, fraction REAL NOT NULL,
  open_ts REAL NOT NULL, close_ts REAL, duration_ms REAL,
  samples INTEGER NOT NULL DEFAULT 0,
  peak_raw_bps REAL, peak_net_bps REAL, peak_expected_bps REAL,
  last_raw_bps REAL, last_net_bps REAL, last_expected_bps REAL,
  qualified_ever INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL, last_reason TEXT
);
'''

class DB:
    def __init__(self, path: str):
        self.path = path
        self.lock = threading.RLock()
        with self.conn() as c:
            c.executescript(SCHEMA)
            c.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version','4.0.1')")

    def conn(self):
        c = sqlite3.connect(self.path, timeout=30)
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
        return c

    def set_meta(self, key, value):
        if not isinstance(value, str):
            value = json.dumps(value, separators=(",", ":"), default=str)
        with self.lock, self.conn() as c:
            c.execute("INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", (key, value))

    def save_universe(self, symbols):
        rows = []
        for s in symbols:
            rows.append((s.symbol,s.base,s.quote,s.status,int(s.spot_allowed),int(s.api_default),s.base_precision,s.quote_precision,s.base_size_precision,s.quote_amount_precision,s.max_quote_amount,s.maker_commission,s.taker_commission,s.trade_side_type))
        with self.lock, self.conn() as c:
            c.execute("DELETE FROM universe_symbols")
            c.executemany("INSERT INTO universe_symbols VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)

    def log_collector_error(self, event: dict):
        extra = {k:v for k,v in event.items() if k not in {"ts","kind","symbol","detail"}}
        with self.lock, self.conn() as c:
            c.execute("INSERT INTO collector_errors(ts,kind,symbol,detail,extra_json) VALUES(?,?,?,?,?)",
                      (event.get("ts",time.time()),event.get("kind"),event.get("symbol"),event.get("detail"),json.dumps(extra,separators=(",",":"),default=str)))

    def add_market_samples(self, rows: list[dict]):
        if not rows: return
        ts = time.time()
        data = [(ts,x["symbol"],int(bool(x.get("ready"))),x.get("bid"),x.get("ask"),x.get("spread_bps"),x.get("local_age_ms"),x.get("exchange_age_ms"),x.get("transport_age_ms"),x.get("version"),x.get("generation"),x.get("msg_rate_10s"),x.get("gaps",0),x.get("resyncs",0),x.get("errors",0)) for x in rows]
        with self.lock, self.conn() as c:
            c.executemany("""INSERT INTO market_samples(ts,symbol,ready,bid,ask,spread_bps,local_age_ms,exchange_age_ms,transport_age_ms,version,generation,msg_rate_10s,gaps,resyncs,errors)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", data)

    def add_health(self, x: dict):
        with self.lock, self.conn() as c:
            c.execute("""INSERT INTO health_samples(ts,uptime_s,ready_symbols,total_symbols,ws_msg_rate,messages,gaps,resyncs,reconnects,collector_errors,scan_ms,evals_per_scan,scans,active_opportunities,cpu_pct,rss_mb,db_mb)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (time.time(),x.get("uptime_s"),x.get("ready_symbols"),x.get("total_symbols"),x.get("ws_msg_rate"),x.get("messages"),x.get("gaps"),x.get("resyncs"),x.get("reconnects"),x.get("collector_errors"),x.get("scan_ms"),x.get("evals_per_scan"),x.get("scans"),x.get("active_opportunities"),x.get("cpu_pct"),x.get("rss_mb"),x.get("db_mb")))

    def upsert_route_aggs(self, rows: list[dict]):
        if not rows: return
        sql = """
        INSERT INTO route_aggregates(route,token,stable_a,stable_b,size,fraction,samples,data_valid,edge_samples,raw_positive,net_positive,qualified,
          sum_raw,sum_net,sum_expected,max_raw,max_net,max_expected,min_expected,sum_cov1,sum_cov2,sum_local_age,sum_exchange_age,sum_local_skew,sum_exchange_skew,sum_traversable,max_traversable,last_ts,last_reason)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(route,size,fraction) DO UPDATE SET
          samples=samples+excluded.samples,
          data_valid=data_valid+excluded.data_valid,
          edge_samples=edge_samples+excluded.edge_samples,
          raw_positive=raw_positive+excluded.raw_positive,
          net_positive=net_positive+excluded.net_positive,
          qualified=qualified+excluded.qualified,
          sum_raw=sum_raw+excluded.sum_raw,
          sum_net=sum_net+excluded.sum_net,
          sum_expected=sum_expected+excluded.sum_expected,
          max_raw=CASE WHEN max_raw IS NULL THEN excluded.max_raw WHEN excluded.max_raw IS NULL THEN max_raw ELSE MAX(max_raw,excluded.max_raw) END,
          max_net=CASE WHEN max_net IS NULL THEN excluded.max_net WHEN excluded.max_net IS NULL THEN max_net ELSE MAX(max_net,excluded.max_net) END,
          max_expected=CASE WHEN max_expected IS NULL THEN excluded.max_expected WHEN excluded.max_expected IS NULL THEN max_expected ELSE MAX(max_expected,excluded.max_expected) END,
          min_expected=CASE WHEN min_expected IS NULL THEN excluded.min_expected WHEN excluded.min_expected IS NULL THEN min_expected ELSE MIN(min_expected,excluded.min_expected) END,
          sum_cov1=sum_cov1+excluded.sum_cov1,
          sum_cov2=sum_cov2+excluded.sum_cov2,
          sum_local_age=sum_local_age+excluded.sum_local_age,
          sum_exchange_age=sum_exchange_age+excluded.sum_exchange_age,
          sum_local_skew=sum_local_skew+excluded.sum_local_skew,
          sum_exchange_skew=sum_exchange_skew+excluded.sum_exchange_skew,
          sum_traversable=sum_traversable+excluded.sum_traversable,
          max_traversable=CASE WHEN max_traversable IS NULL THEN excluded.max_traversable WHEN excluded.max_traversable IS NULL THEN max_traversable ELSE MAX(max_traversable,excluded.max_traversable) END,
          last_ts=excluded.last_ts,last_reason=excluded.last_reason
        """
        vals=[]
        for r in rows:
            vals.append((r["route"],r["token"],r["stable_a"],r["stable_b"],r["size"],r["fraction"],r["samples"],r["data_valid"],r.get("edge_samples", r.get("samples",0)),r["raw_positive"],r["net_positive"],r["qualified"],r["sum_raw"],r["sum_net"],r["sum_expected"],r.get("max_raw"),r.get("max_net"),r.get("max_expected"),r.get("min_expected"),r["sum_cov1"],r["sum_cov2"],r["sum_local_age"],r["sum_exchange_age"],r["sum_local_skew"],r["sum_exchange_skew"],r.get("sum_traversable",0.0),r.get("max_traversable"),r["last_ts"],r.get("last_reason")))
        with self.lock, self.conn() as c:
            c.executemany(sql, vals)

    def add_reason_counts(self, counts: dict[str,int]):
        if not counts: return
        ts=time.time()
        with self.lock, self.conn() as c:
            c.executemany("""INSERT INTO reason_aggregates(reason,count,last_ts) VALUES(?,?,?)
              ON CONFLICT(reason) DO UPDATE SET count=count+excluded.count,last_ts=excluded.last_ts""",
              [(k,int(v),ts) for k,v in counts.items()])

    def add_opportunity_event(self, e: dict):
        with self.lock, self.conn() as c:
            c.execute("""INSERT INTO opportunity_events(ts,event_type,opp_id,route,token,size,fraction,raw_edge_bps,net_edge_bps,expected_edge_bps,cov1,cov2,local_skew_ms,exchange_skew_ms,qualified,reason,duration_ms)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (e.get("ts",time.time()),e["event_type"],e["opp_id"],e["route"],e["token"],e["size"],e["fraction"],e.get("raw_edge_bps"),e.get("net_edge_bps"),e.get("expected_edge_bps"),e.get("cov1"),e.get("cov2"),e.get("local_skew_ms"),e.get("exchange_skew_ms"),int(bool(e.get("qualified"))),e.get("reason"),e.get("duration_ms")))

    def upsert_lifecycle(self, x: dict):
        with self.lock, self.conn() as c:
            c.execute("""INSERT INTO opportunity_lifecycles(opp_id,route,token,size,fraction,open_ts,close_ts,duration_ms,samples,peak_raw_bps,peak_net_bps,peak_expected_bps,last_raw_bps,last_net_bps,last_expected_bps,qualified_ever,status,last_reason)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(opp_id) DO UPDATE SET close_ts=excluded.close_ts,duration_ms=excluded.duration_ms,samples=excluded.samples,peak_raw_bps=excluded.peak_raw_bps,peak_net_bps=excluded.peak_net_bps,peak_expected_bps=excluded.peak_expected_bps,last_raw_bps=excluded.last_raw_bps,last_net_bps=excluded.last_net_bps,last_expected_bps=excluded.last_expected_bps,qualified_ever=excluded.qualified_ever,status=excluded.status,last_reason=excluded.last_reason""",
              (x["opp_id"],x["route"],x["token"],x["size"],x["fraction"],x["open_ts"],x.get("close_ts"),x.get("duration_ms"),x.get("samples",0),x.get("peak_raw_bps"),x.get("peak_net_bps"),x.get("peak_expected_bps"),x.get("last_raw_bps"),x.get("last_net_bps"),x.get("last_expected_bps"),int(bool(x.get("qualified_ever"))),x.get("status","OPEN"),x.get("last_reason")))

    def route_summary(self, limit=100):
        with self.conn() as c:
            rows=c.execute("""SELECT route,token,stable_a,stable_b,size,fraction,samples,data_valid,edge_samples,raw_positive,net_positive,qualified,
              CASE WHEN edge_samples>0 THEN sum_raw/edge_samples END avg_raw,
              CASE WHEN edge_samples>0 THEN sum_net/edge_samples END avg_net,
              CASE WHEN edge_samples>0 THEN sum_expected/edge_samples END avg_expected,
              max_raw,max_net,max_expected,min_expected,
              CASE WHEN samples>0 THEN sum_cov1/samples END avg_cov1,
              CASE WHEN samples>0 THEN sum_cov2/samples END avg_cov2,
              CASE WHEN samples>0 THEN sum_local_age/samples END avg_local_age,
              CASE WHEN samples>0 THEN sum_exchange_age/samples END avg_exchange_age,
              CASE WHEN samples>0 THEN sum_local_skew/samples END avg_local_skew,
              CASE WHEN samples>0 THEN sum_exchange_skew/samples END avg_exchange_skew,
              CASE WHEN samples>0 THEN sum_traversable/samples END avg_traversable, max_traversable,
              last_ts,last_reason
              FROM route_aggregates ORDER BY max_expected DESC, max_net DESC LIMIT ?""",(int(limit),)).fetchall()
        cols=["route","token","stable_a","stable_b","size","fraction","samples","data_valid","edge_samples","raw_positive","net_positive","qualified","avg_raw_bps","avg_net_bps","avg_expected_bps","max_raw_bps","max_net_bps","max_expected_bps","min_expected_bps","avg_cov1","avg_cov2","avg_local_age_ms","avg_exchange_age_ms","avg_local_skew_ms","avg_exchange_skew_ms","avg_traversable","max_traversable","last_ts","last_reason"]
        return [dict(zip(cols,r)) for r in rows]

    def reasons(self):
        with self.conn() as c:
            rows=c.execute("SELECT reason,count,last_ts FROM reason_aggregates ORDER BY count DESC").fetchall()
        total=sum(r[1] for r in rows) or 1
        return [{"reason":r[0],"count":r[1],"pct":100*r[1]/total,"last_ts":r[2]} for r in rows]

    def recent_events(self, limit=100):
        with self.conn() as c:
            rows=c.execute("""SELECT ts,event_type,opp_id,route,token,size,fraction,raw_edge_bps,net_edge_bps,expected_edge_bps,cov1,cov2,local_skew_ms,exchange_skew_ms,qualified,reason,duration_ms
              FROM opportunity_events ORDER BY id DESC LIMIT ?""",(int(limit),)).fetchall()
        cols=["ts","event_type","opp_id","route","token","size","fraction","raw_edge_bps","net_edge_bps","expected_edge_bps","cov1","cov2","local_skew_ms","exchange_skew_ms","qualified","reason","duration_ms"]
        return [dict(zip(cols,r)) for r in rows]

    def recent_lifecycles(self, limit=100):
        with self.conn() as c:
            rows=c.execute("""SELECT opp_id,route,token,size,fraction,open_ts,close_ts,duration_ms,samples,peak_raw_bps,peak_net_bps,peak_expected_bps,last_raw_bps,last_net_bps,last_expected_bps,qualified_ever,status,last_reason
              FROM opportunity_lifecycles ORDER BY open_ts DESC LIMIT ?""",(int(limit),)).fetchall()
        cols=["opp_id","route","token","size","fraction","open_ts","close_ts","duration_ms","samples","peak_raw_bps","peak_net_bps","peak_expected_bps","last_raw_bps","last_net_bps","last_expected_bps","qualified_ever","status","last_reason"]
        return [dict(zip(cols,r)) for r in rows]

    def health_series(self, minutes=60, limit=1000):
        since=time.time()-float(minutes)*60
        with self.conn() as c:
            rows=c.execute("""SELECT ts,ready_symbols,total_symbols,ws_msg_rate,gaps,resyncs,reconnects,collector_errors,scan_ms,evals_per_scan,active_opportunities,cpu_pct,rss_mb,db_mb
              FROM health_samples WHERE ts>=? ORDER BY ts ASC LIMIT ?""",(since,int(limit))).fetchall()
        cols=["ts","ready_symbols","total_symbols","ws_msg_rate","gaps","resyncs","reconnects","collector_errors","scan_ms","evals_per_scan","active_opportunities","cpu_pct","rss_mb","db_mb"]
        return [dict(zip(cols,r)) for r in rows]

    def recent_errors(self, limit=100):
        with self.conn() as c:
            rows=c.execute("SELECT ts,kind,symbol,detail,extra_json FROM collector_errors ORDER BY id DESC LIMIT ?",(int(limit),)).fetchall()
        return [{"ts":r[0],"kind":r[1],"symbol":r[2],"detail":r[3],"extra":json.loads(r[4] or "{}") } for r in rows]

    def counts(self):
        with self.conn() as c:
            names=["market_samples","health_samples","route_aggregates","opportunity_events","opportunity_lifecycles","collector_errors"]
            out={n:c.execute(f"SELECT count(*) FROM {n}").fetchone()[0] for n in names}
        try: out["db_mb"] = os.path.getsize(self.path)/1024/1024
        except OSError: out["db_mb"] = 0
        return out
