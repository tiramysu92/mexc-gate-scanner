from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Optional, Tuple, Iterable
import threading
import time

@dataclass(frozen=True)
class L:
    p: float
    q: float

@dataclass(frozen=True)
class Book:
    symbol: str
    bids: Tuple[L, ...]
    asks: Tuple[L, ...]
    gen: int
    ver: Optional[int]
    exchange_ms: Optional[int]
    recv_wall_ms: Optional[float]
    recv_ns: int
    apply_ns: int
    state: str = "VALID"

    @property
    def age_ms(self) -> float:
        return (time.monotonic_ns() - self.apply_ns) / 1e6

    def exchange_age_ms(self, clock_offset_ms: float = 0.0) -> Optional[float]:
        if not self.exchange_ms:
            return None
        return (time.time() * 1000.0 + clock_offset_ms) - float(self.exchange_ms)

    def transport_age_ms(self, clock_offset_ms: float = 0.0) -> Optional[float]:
        if not self.exchange_ms or self.recv_wall_ms is None:
            return None
        return (float(self.recv_wall_ms) + clock_offset_ms) - float(self.exchange_ms)

    @property
    def best_bid(self) -> Optional[float]:
        return self.bids[0].p if self.bids else None

    @property
    def best_ask(self) -> Optional[float]:
        return self.asks[0].p if self.asks else None

    @property
    def spread_bps(self) -> Optional[float]:
        if not self.bids or not self.asks or self.bids[0].p <= 0:
            return None
        return (self.asks[0].p / self.bids[0].p - 1.0) * 1e4

class Store:
    def __init__(self):
        self._lock = threading.RLock()
        self._books: dict[str, Book] = {}

    def put(self, book: Book) -> None:
        with self._lock:
            self._books[book.symbol] = book

    def get(self, symbol: str) -> Optional[Book]:
        with self._lock:
            return self._books.get(symbol)

    def snapshot(self) -> dict[str, Book]:
        with self._lock:
            return dict(self._books)

    def n(self) -> int:
        with self._lock:
            return len(self._books)


def buy(levels: Iterable[L], quote: float, fraction: float = 0.25):
    """Consume asks using quote currency.

    Returns (base_out, vwap, coverage_of_requested_quote).
    The fraction limits usage of each displayed level for conservative depth tests.
    """
    quote = float(quote)
    if quote <= 0:
        return 0.0, 0.0, 1.0
    f = max(0.0, min(1.0, float(fraction)))
    rem = quote
    base = spent = 0.0
    for x in levels:
        if x.p <= 0 or x.q <= 0:
            continue
        take = min(rem, x.p * x.q * f)
        if take <= 0:
            continue
        base += take / x.p
        spent += take
        rem -= take
        if rem <= 1e-10:
            break
    return base, (spent / base if base else 0.0), spent / quote


def sell(levels: Iterable[L], base: float, fraction: float = 0.25):
    """Consume bids using base currency.

    Returns (quote_out, vwap, coverage_of_requested_base).
    """
    base = float(base)
    if base <= 0:
        return 0.0, 0.0, 1.0
    f = max(0.0, min(1.0, float(fraction)))
    rem = base
    sold = out = 0.0
    for x in levels:
        if x.p <= 0 or x.q <= 0:
            continue
        take = min(rem, x.q * f)
        if take <= 0:
            continue
        sold += take
        out += take * x.p
        rem -= take
        if rem <= 1e-10:
            break
    return out, (out / sold if sold else 0.0), sold / base


def cost_for_base(asks: Iterable[L], base: float, fraction: float = 0.25):
    """Quote cost to acquire a requested base amount."""
    base = float(base)
    if base <= 0:
        return 0.0, 0.0, 1.0
    f = max(0.0, min(1.0, float(fraction)))
    rem = base
    got = cost = 0.0
    for x in asks:
        if x.p <= 0 or x.q <= 0:
            continue
        take = min(rem, x.q * f)
        if take <= 0:
            continue
        got += take
        cost += take * x.p
        rem -= take
        if rem <= 1e-10:
            break
    return cost, (cost / got if got else 0.0), got / base


def max_traversable_quote(asks: Iterable[L], bids: Iterable[L], fraction: float = 0.25) -> float:
    """Approximate maximum quote amount that can traverse both legs at the chosen fraction."""
    f = max(0.0, min(1.0, float(fraction)))
    ask_levels = tuple(asks)
    bid_levels = tuple(bids)
    ask_base = sum(max(0.0, x.q) * f for x in ask_levels)
    bid_base = sum(max(0.0, x.q) * f for x in bid_levels)
    base = min(ask_base, bid_base)
    cost, _, cov = cost_for_base(ask_levels, base, f)
    return cost if cov >= 0.999999 else 0.0


def pct(values, p: float) -> Optional[float]:
    values = sorted(v for v in values if v is not None)
    if not values:
        return None
    if len(values) == 1:
        return float(values[0])
    k = (len(values) - 1) * p
    lo = int(k)
    hi = min(len(values) - 1, lo + 1)
    w = k - lo
    return float(values[lo] * (1 - w) + values[hi] * w)
