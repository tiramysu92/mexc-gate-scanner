from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import gzip
import json
import time
import requests

REST = "https://api.mexc.com"

@dataclass(frozen=True)
class SymbolRule:
    symbol: str
    base: str
    quote: str
    status: str
    spot_allowed: bool
    api_default: bool
    base_precision: int | None
    quote_precision: int | None
    base_size_precision: str | None
    quote_amount_precision: str | None
    max_quote_amount: str | None
    maker_commission: str | None
    taker_commission: str | None
    trade_side_type: str | None

@dataclass(frozen=True)
class Route:
    route: str
    token: str
    stable_a: str
    stable_b: str
    symbol1: str
    symbol2: str

class Universe:
    def __init__(self, symbols: list[SymbolRule], routes: list[Route], excluded: list[dict], raw_exchange_info: dict, default_symbols: set[str]):
        self.symbols = symbols
        self.routes = routes
        self.excluded = excluded
        self.raw_exchange_info = raw_exchange_info
        self.default_symbols = default_symbols
        self.by_symbol = {s.symbol: s for s in symbols}

    def as_dict(self):
        by_token: dict[str, list[str]] = {}
        for s in self.symbols:
            by_token.setdefault(s.base, []).append(s.quote)
        return {
            "symbol_count": len(self.symbols),
            "route_count": len(self.routes),
            "symbols": [asdict(x) for x in self.symbols],
            "routes": [asdict(x) for x in self.routes],
            "quotes_by_token": {k: sorted(v) for k, v in sorted(by_token.items())},
            "excluded": self.excluded,
        }


def _status_ok(status: Any) -> bool:
    s = str(status).upper()
    return s in {"1", "ENABLED", "ONLINE", "TRADING"}


def parse_exchange_info(payload: dict, cfg: dict, default_symbols: set[str] | None = None) -> Universe:
    default_symbols = default_symbols or set()
    target_tokens = set(cfg.get("tokens", []))
    stablecoins = set(cfg.get("stablecoins", []))
    require_default = bool(cfg.get("require_default_symbols", True))
    rows = payload.get("symbols") or []
    selected: list[SymbolRule] = []
    excluded: list[dict] = []

    for x in rows:
        symbol = str(x.get("symbol") or "")
        base = str(x.get("baseAsset") or "")
        quote = str(x.get("quoteAsset") or "")
        if base not in target_tokens or quote not in stablecoins:
            continue
        reasons = []
        status = x.get("status")
        if not _status_ok(status):
            reasons.append("STATUS")
        spot = bool(x.get("isSpotTradingAllowed", False))
        if not spot:
            reasons.append("SPOT_API_DISABLED")
        api_default = (symbol in default_symbols) if default_symbols else True
        if require_default and default_symbols and not api_default:
            reasons.append("NOT_DEFAULT_API_SYMBOL")
        if reasons:
            excluded.append({"symbol": symbol, "base": base, "quote": quote, "reasons": reasons})
            continue
        selected.append(SymbolRule(
            symbol=symbol,
            base=base,
            quote=quote,
            status=str(status),
            spot_allowed=spot,
            api_default=api_default,
            base_precision=x.get("baseAssetPrecision"),
            quote_precision=x.get("quotePrecision"),
            base_size_precision=x.get("baseSizePrecision"),
            quote_amount_precision=x.get("quoteAmountPrecision"),
            max_quote_amount=x.get("maxQuoteAmount"),
            maker_commission=x.get("makerCommission"),
            taker_commission=x.get("takerCommission"),
            trade_side_type=str(x.get("tradeSideType")) if x.get("tradeSideType") is not None else None,
        ))

    market = {(s.base, s.quote): s.symbol for s in selected}
    routes: list[Route] = []
    for token in sorted(target_tokens):
        quotes = sorted(q for q in stablecoins if (token, q) in market)
        for a in quotes:
            for b in quotes:
                if a == b:
                    continue
                routes.append(Route(
                    route=f"{a}>{token}>{b}", token=token, stable_a=a, stable_b=b,
                    symbol1=market[(token, a)], symbol2=market[(token, b)]
                ))
    return Universe(selected, routes, excluded, payload, default_symbols)


class UniverseBuilder:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.session = requests.Session()

    def build(self) -> Universe:
        timeout = float(self.cfg.get("rest_timeout_s", 8))
        ex = self.session.get(REST + "/api/v3/exchangeInfo", timeout=timeout)
        ex.raise_for_status()
        exchange = ex.json()
        defaults: set[str] = set()
        try:
            r = self.session.get(REST + "/api/v3/defaultSymbols", timeout=timeout)
            r.raise_for_status()
            j = r.json()
            defaults = set(j.get("data") or [])
        except Exception:
            # exchangeInfo remains authoritative for market structure; defaultSymbols is an extra API-eligibility guard.
            defaults = set()
        return parse_exchange_info(exchange, self.cfg, defaults)

    @staticmethod
    def save_snapshot(universe: Universe, path: str):
        payload = {
            "saved_at": time.time(),
            "universe": universe.as_dict(),
            "exchange_info": universe.raw_exchange_info,
            "default_symbols": sorted(universe.default_symbols),
        }
        with gzip.open(path, "wt", encoding="utf-8") as f:
            json.dump(payload, f, separators=(",", ":"))
