from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import Counter
import math
import threading
import time
import uuid

from .core import buy, sell, max_traversable_quote

@dataclass
class Eval:
    route: str
    token: str
    stable_a: str
    stable_b: str
    symbol1: str
    symbol2: str
    size: float
    fraction: float
    raw_edge_bps: float | None
    net_edge_bps: float | None
    expected_edge_bps: float | None
    fee_bps_per_leg: float
    cov1: float
    cov2: float
    max_traversable_quote: float
    vwap1: float
    vwap2: float
    local_age1_ms: float
    local_age2_ms: float
    exchange_age1_ms: float | None
    exchange_age2_ms: float | None
    transport_age1_ms: float | None
    transport_age2_ms: float | None
    local_skew_ms: float
    exchange_skew_ms: float | None
    data_valid: bool
    accepted: bool
    reasons: tuple[str,...]
    ts: float

    def as_dict(self):
        d=asdict(self); d["reasons"]="|".join(self.reasons) if self.reasons else "OK"; return d

class OpportunityTracker:
    def __init__(self, cfg, db):
        self.cfg=cfg; self.db=db; self.active={}; self.lock=threading.RLock()
        self.raw_threshold=float(cfg.get("raw_watch_threshold_bps",0.0))
        self.update_delta=float(cfg.get("event_update_delta_bps",2.0))

    @staticmethod
    def key(e: Eval): return (e.route,float(e.size),float(e.fraction))

    def _event(self, typ, x, e, duration=None):
        ev={"ts":time.time(),"event_type":typ,"opp_id":x["opp_id"],"route":e.route,"token":e.token,"size":e.size,"fraction":e.fraction,
            "raw_edge_bps":e.raw_edge_bps,"net_edge_bps":e.net_edge_bps,"expected_edge_bps":e.expected_edge_bps,
            "cov1":e.cov1,"cov2":e.cov2,"local_skew_ms":e.local_skew_ms,"exchange_skew_ms":e.exchange_skew_ms,
            "qualified":e.accepted,"reason":"|".join(e.reasons) if e.reasons else "OK","duration_ms":duration}
        self.db.add_opportunity_event(ev)

    def process(self, evaluations: list[Eval]):
        now=time.time(); seen=set()
        with self.lock:
            for e in evaluations:
                k=self.key(e); seen.add(k)
                watch=e.data_valid and e.raw_edge_bps is not None and e.raw_edge_bps >= self.raw_threshold
                x=self.active.get(k)
                if watch and x is None:
                    x={"opp_id":uuid.uuid4().hex[:16],"route":e.route,"token":e.token,"size":e.size,"fraction":e.fraction,
                       "open_ts":now,"close_ts":None,"duration_ms":0.0,"samples":1,
                       "peak_raw_bps":e.raw_edge_bps,"peak_net_bps":e.net_edge_bps,"peak_expected_bps":e.expected_edge_bps,
                       "last_raw_bps":e.raw_edge_bps,"last_net_bps":e.net_edge_bps,"last_expected_bps":e.expected_edge_bps,
                       "qualified_ever":bool(e.accepted),"status":"OPEN","last_reason":"OK"}
                    self.active[k]=x; self._event("OPEN",x,e,0.0); self.db.upsert_lifecycle(x)
                elif watch and x is not None:
                    x["samples"]+=1; x["duration_ms"]=(now-x["open_ts"])*1000.0
                    prior_peak=x.get("peak_expected_bps")
                    x["peak_raw_bps"]=max(v for v in [x.get("peak_raw_bps"),e.raw_edge_bps] if v is not None)
                    if e.net_edge_bps is not None: x["peak_net_bps"]=max(v for v in [x.get("peak_net_bps"),e.net_edge_bps] if v is not None)
                    if e.expected_edge_bps is not None: x["peak_expected_bps"]=max(v for v in [x.get("peak_expected_bps"),e.expected_edge_bps] if v is not None)
                    was_qualified=bool(x["qualified_ever"]); x["qualified_ever"] = was_qualified or bool(e.accepted)
                    x["last_raw_bps"]=e.raw_edge_bps; x["last_net_bps"]=e.net_edge_bps; x["last_expected_bps"]=e.expected_edge_bps
                    improved=(e.expected_edge_bps is not None and (prior_peak is None or e.expected_edge_bps >= prior_peak+self.update_delta))
                    qualification_flip=(not was_qualified and e.accepted)
                    if improved or qualification_flip: self._event("UPDATE",x,e,x["duration_ms"])
                elif (not watch) and x is not None:
                    x["close_ts"]=now; x["duration_ms"]=(now-x["open_ts"])*1000.0; x["status"]="CLOSED"; x["last_reason"]="|".join(e.reasons) if e.reasons else "RAW_BELOW_WATCH"
                    self._event("CLOSE",x,e,x["duration_ms"]); self.db.upsert_lifecycle(x); del self.active[k]
            # If a route disappeared because a book vanished, close it explicitly.
            for k,x in list(self.active.items()):
                if k not in seen:
                    x["close_ts"]=now; x["duration_ms"]=(now-x["open_ts"])*1000.0; x["status"]="CLOSED"; x["last_reason"]="ROUTE_UNAVAILABLE"
                    dummy=Eval(x["route"],x["token"],"","","","",x["size"],x["fraction"],x["last_raw_bps"],x["last_net_bps"],x["last_expected_bps"],0,0,0,0,0,0,0,0,0,None,None,None,None,0,None,False,False,("ROUTE_UNAVAILABLE",),now)
                    self._event("CLOSE",x,dummy,x["duration_ms"]); self.db.upsert_lifecycle(x); del self.active[k]

    def flush_active(self):
        with self.lock:
            now=time.time()
            for x in self.active.values():
                x["duration_ms"]=(now-x["open_ts"])*1000.0; self.db.upsert_lifecycle(x)

    def status(self):
        with self.lock:
            now=time.time(); out=[]
            for x in self.active.values():
                z=dict(x); z["duration_ms"]=(now-z["open_ts"])*1000.0; out.append(z)
            return sorted(out,key=lambda z:(z.get("last_expected_bps") if z.get("last_expected_bps") is not None else -1e99),reverse=True)

class Engine:
    def __init__(self,cfg,store,db,universe,clock):
        self.cfg=cfg; self.store=store; self.db=db; self.universe=universe; self.clock=clock
        self.scans=0; self.evaluations=0; self.accepted=0; self.scan_ms=0.0; self.last_scan_evals=0
        self.pending={}; self.pending_reasons=Counter(); self.last_flush=time.monotonic(); self.lock=threading.RLock()
        self.latest_candidates=[]; self.tracker=OpportunityTracker(cfg,db)

    def _evaluate(self,r,size,f):
        x=self.store.get(r.symbol1); y=self.store.get(r.symbol2); now=time.time()
        if not x or not y: return None
        base,v1,c1=buy(x.asks,size,f); out,v2,c2=sell(y.bids,base,f)
        full=(c1>=0.999 and c2>=0.999)
        raw=((out/size)-1.0)*1e4 if full and size>0 else None
        fee=float(self.cfg.get("fee_bps_default",5.0)); fee_frac=fee/1e4
        net=((out*(1-fee_frac)**2/size)-1.0)*1e4 if full and size>0 else None
        reserve=float(self.cfg.get("slippage_reserve_bps",0))+float(self.cfg.get("latency_reserve_bps",0))+float(self.cfg.get("exit_risk_reserve_bps",0))
        expected=(net-reserve) if net is not None else None
        la1=x.age_ms; la2=y.age_ms; ea1=x.exchange_age_ms(self.clock.offset_ms); ea2=y.exchange_age_ms(self.clock.offset_ms)
        ta1=x.transport_age_ms(self.clock.offset_ms); ta2=y.transport_age_ms(self.clock.offset_ms)
        lsk=abs(x.apply_ns-y.apply_ns)/1e6
        esk=abs(float(x.exchange_ms)-float(y.exchange_ms)) if x.exchange_ms and y.exchange_ms else None
        reasons=[]
        if x.state!="VALID" or y.state!="VALID": reasons.append("BOOK")
        if la1>float(self.cfg.get("max_local_age_ms",250)) or la2>float(self.cfg.get("max_local_age_ms",250)): reasons.append("STALE_LOCAL")
        if ea1 is None or ea2 is None: reasons.append("EXCHANGE_TS_MISSING")
        elif ea1>float(self.cfg.get("max_exchange_age_ms",500)) or ea2>float(self.cfg.get("max_exchange_age_ms",500)): reasons.append("STALE_EXCHANGE")
        if ta1 is not None and ta1>float(self.cfg.get("max_transport_age_ms",500)): reasons.append("TRANSPORT_AGE")
        if ta2 is not None and ta2>float(self.cfg.get("max_transport_age_ms",500)): reasons.append("TRANSPORT_AGE")
        if lsk>float(self.cfg.get("max_local_skew_ms",150)): reasons.append("SKEW_LOCAL")
        if esk is None: reasons.append("EXCHANGE_SKEW_MISSING")
        elif esk>float(self.cfg.get("max_exchange_skew_ms",150)): reasons.append("SKEW_EXCHANGE")
        if c1<.999: reasons.append("DEPTH_L1")
        if c2<.999: reasons.append("DEPTH_L2")
        structural=tuple(dict.fromkeys(reasons))
        data_valid=not structural
        accepted=data_valid and expected is not None and expected>=float(self.cfg.get("min_expected_edge_bps",10.0))
        final=list(structural)
        if data_valid and not accepted: final.append("EDGE_EXPECTED")
        mtq=max_traversable_quote(x.asks,y.bids,f)
        return Eval(r.route,r.token,r.stable_a,r.stable_b,r.symbol1,r.symbol2,float(size),float(f),raw,net,expected,fee,c1,c2,mtq,v1,v2,la1,la2,ea1,ea2,ta1,ta2,lsk,esk,data_valid,accepted,tuple(final),now)

    def _agg(self,e:Eval):
        k=(e.route,e.size,e.fraction)
        a=self.pending.get(k)
        if a is None:
            a={"route":e.route,"token":e.token,"stable_a":e.stable_a,"stable_b":e.stable_b,"size":e.size,"fraction":e.fraction,
               "samples":0,"data_valid":0,"edge_samples":0,"raw_positive":0,"net_positive":0,"qualified":0,"sum_raw":0.0,"sum_net":0.0,"sum_expected":0.0,
               "max_raw":None,"max_net":None,"max_expected":None,"min_expected":None,"sum_cov1":0.0,"sum_cov2":0.0,"sum_local_age":0.0,"sum_exchange_age":0.0,"sum_local_skew":0.0,"sum_exchange_skew":0.0,"sum_traversable":0.0,"max_traversable":None,"last_ts":e.ts,"last_reason":""}
            self.pending[k]=a
        a["samples"]+=1; a["data_valid"]+=int(e.data_valid); a["edge_samples"]+=int(e.raw_edge_bps is not None); a["raw_positive"]+=int(e.raw_edge_bps is not None and e.raw_edge_bps>0); a["net_positive"]+=int(e.net_edge_bps is not None and e.net_edge_bps>0); a["qualified"]+=int(e.accepted)
        for name,val in (("raw",e.raw_edge_bps),("net",e.net_edge_bps),("expected",e.expected_edge_bps)):
            if val is not None:
                a["sum_"+name]+=val
                mx="max_"+name; a[mx]=val if a[mx] is None else max(a[mx],val)
                if name=="expected": a["min_expected"]=val if a["min_expected"] is None else min(a["min_expected"],val)
        a["sum_cov1"]+=e.cov1; a["sum_cov2"]+=e.cov2; a["sum_local_age"]+=max(e.local_age1_ms,e.local_age2_ms)
        a["sum_exchange_age"]+=max(v for v in [e.exchange_age1_ms,e.exchange_age2_ms] if v is not None) if (e.exchange_age1_ms is not None or e.exchange_age2_ms is not None) else 0.0
        a["sum_local_skew"]+=e.local_skew_ms; a["sum_exchange_skew"]+=(e.exchange_skew_ms or 0.0); a["sum_traversable"]+=e.max_traversable_quote; a["max_traversable"]=e.max_traversable_quote if a["max_traversable"] is None else max(a["max_traversable"],e.max_traversable_quote); a["last_ts"]=e.ts; a["last_reason"]="|".join(e.reasons) if e.reasons else "OK"
        if e.reasons:
            for reason in set(e.reasons): self.pending_reasons[reason]+=1
        else: self.pending_reasons["OK"]+=1

    def flush(self,force=False):
        if not force and time.monotonic()-self.last_flush<float(self.cfg.get("aggregate_flush_s",5.0)): return
        with self.lock:
            rows=list(self.pending.values()); reasons=dict(self.pending_reasons); self.pending={}; self.pending_reasons=Counter(); self.last_flush=time.monotonic()
        self.db.upsert_route_aggs(rows); self.db.add_reason_counts(reasons); self.tracker.flush_active()

    def once(self):
        t=time.monotonic_ns(); evaluations=[]
        for r in self.universe.routes:
            if not self.store.get(r.symbol1) or not self.store.get(r.symbol2): continue
            for size in self.cfg.get("test_sizes_usd",[10,20,25,50,100,200]):
                for f in self.cfg.get("depth_fractions",[.1,.15,.2,.25,.33,.5,.75,1]):
                    e=self._evaluate(r,size,f)
                    if e:
                        evaluations.append(e); self._agg(e)
        self.tracker.process(evaluations)
        ranked=sorted(evaluations,key=lambda e:(e.expected_edge_bps if e.expected_edge_bps is not None else -1e99),reverse=True)
        with self.lock:
            self.latest_candidates=[e.as_dict() for e in ranked[:int(self.cfg.get("dashboard_candidate_limit",100))]]
            self.scans+=1; self.last_scan_evals=len(evaluations); self.evaluations+=len(evaluations); self.accepted+=sum(1 for e in evaluations if e.accepted); self.scan_ms=(time.monotonic_ns()-t)/1e6
        self.flush()
        return len(evaluations)

    def status(self):
        with self.lock:
            return {"scans":self.scans,"evaluations":self.evaluations,"accepted_evaluations":self.accepted,"last_scan_ms":self.scan_ms,"last_scan_evals":self.last_scan_evals,"latest_candidates":list(self.latest_candidates)}
