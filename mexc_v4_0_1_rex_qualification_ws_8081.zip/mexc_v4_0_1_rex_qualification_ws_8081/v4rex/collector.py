from __future__ import annotations
import json
import random
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Callable, Optional

import requests
import websocket
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory

from .core import Book, L, Store

REST = "https://api.mexc.com"
WS = "wss://wbs-api.mexc.com/ws"


def _codec():
    """Minimal dynamic codec matching MEXC's official protobuf fields used by Diff.Depth."""
    fd = descriptor_pb2.FileDescriptorProto(name="mexc_v401.proto", package="v401", syntax="proto3")

    def msg(name):
        m = fd.message_type.add(); m.name = name; return m

    def fld(m, name, num, typ, repeated=False, target=None, oneof=None):
        f = m.field.add(); f.name = name; f.number = num; f.type = typ
        f.label = 3 if repeated else 1
        if target:
            f.type_name = ".v401." + target
        if oneof is not None:
            f.oneof_index = oneof
        return f

    level = msg("PublicAggreDepthV3ApiItem")
    fld(level, "price", 1, 9); fld(level, "quantity", 2, 9)

    depth = msg("PublicAggreDepthsV3Api")
    fld(depth, "asks", 1, 11, True, "PublicAggreDepthV3ApiItem")
    fld(depth, "bids", 2, 11, True, "PublicAggreDepthV3ApiItem")
    fld(depth, "eventType", 3, 9)
    fld(depth, "fromVersion", 4, 9)
    fld(depth, "toVersion", 5, 9)
    fld(depth, "lastOrderCreateTime", 6, 3)

    env = msg("PushDataV3ApiWrapper")
    fld(env, "channel", 1, 9)
    body = env.oneof_decl.add(); body.name = "body"
    fld(env, "publicAggreDepths", 313, 11, False, "PublicAggreDepthsV3Api", 0)
    fld(env, "symbol", 3, 9)
    fld(env, "symbolId", 4, 9)
    fld(env, "createTime", 5, 3)
    fld(env, "sendTime", 6, 3)

    pool = descriptor_pool.DescriptorPool(); pool.Add(fd)
    return message_factory.GetMessageClass(pool.FindMessageTypeByName("v401.PushDataV3ApiWrapper"))

Envelope = _codec()


def decode(payload: bytes):
    e = Envelope(); e.ParseFromString(payload)
    if not e.symbol or not e.HasField("publicAggreDepths"):
        return None
    d = e.publicAggreDepths
    try:
        fv, tv = int(d.fromVersion), int(d.toVersion)
    except (TypeError, ValueError):
        return None
    return {
        "channel": e.channel,
        "symbol": e.symbol,
        "send": int(e.sendTime or 0),
        "create": int(e.createTime or 0),
        "from": fv,
        "to": tv,
        "last_order_create": int(d.lastOrderCreateTime or 0),
        "bids": [(float(z.price), float(z.quantity)) for z in d.bids],
        "asks": [(float(z.price), float(z.quantity)) for z in d.asks],
    }


def bridge_first_ok(snapshot_version: int, first_from: int, first_to: int) -> bool:
    """Official bridge rule: first remaining delta must cover snapshot_version + 1."""
    nxt = snapshot_version + 1
    return first_from <= nxt <= first_to


class RateLimiter:
    def __init__(self, per_second: float):
        self.interval = 1.0 / max(0.1, float(per_second))
        self.lock = threading.Lock(); self.next_at = 0.0

    def wait(self):
        with self.lock:
            now = time.monotonic()
            wait = max(0.0, self.next_at - now)
            self.next_at = max(now, self.next_at) + self.interval
        if wait:
            time.sleep(wait)


class ClockSync:
    def __init__(self):
        self.offset_ms = 0.0
        self.rtt_ms = None
        self.last_sync = None

    def sync(self, session: requests.Session, samples=5, timeout=3):
        best = None
        for _ in range(samples):
            try:
                a = time.time() * 1000.0
                r = session.get(REST + "/api/v3/time", timeout=timeout); r.raise_for_status()
                b = time.time() * 1000.0
                server = float(r.json()["serverTime"])
                rtt = b - a
                offset = server - (a + b) / 2.0
                if best is None or rtt < best[0]:
                    best = (rtt, offset)
            except Exception:
                pass
            time.sleep(0.05)
        if best:
            self.rtt_ms, self.offset_ms = best
            self.last_sync = time.time()
        return self.offset_ms


class Collector:
    def __init__(self, cfg: dict, store: Store, symbols: list[str], error_sink: Optional[Callable[[dict], None]] = None):
        self.cfg = cfg; self.store = store; self.symbols = sorted(set(symbols)); self.error_sink = error_sink
        self.session = requests.Session()
        self.clock = ClockSync(); self.clock.sync(self.session)
        self.snapshot_limiter = RateLimiter(cfg.get("snapshot_rate_per_sec", 6.0))
        self.lock = threading.RLock(); self.stop = False
        self.raw: dict[str, dict] = {}
        self.buffers = {s: deque(maxlen=int(cfg.get("buffer_max_updates", 20000))) for s in self.symbols}
        self.ready: set[str] = set()
        self.symbol_gen: dict[str, int] = {}
        self._gen_counter = 0
        self.started = time.time()
        self.msg_times = deque(maxlen=200000)
        self.recent_errors = deque(maxlen=200)
        self.per_symbol = {
            s: {
                "messages": 0, "gaps": 0, "resyncs": 0, "errors": 0, "buffer_overflows": 0,
                "last_error": None, "last_error_ts": None, "last_from": None, "last_to": None,
                "last_send_ms": None, "last_message_ts": None, "msg_times": deque(maxlen=50000),
            } for s in self.symbols
        }
        self.messages = self.requests = self.errors = self.reconnects = self.gaps = self.resyncs = 0
        self.acks = self.pongs = self.decode_errors = self.buffer_overflows = 0

    def _next_gen(self):
        with self.lock:
            self._gen_counter += 1
            return self._gen_counter

    def _error(self, kind: str, symbol: str | None = None, detail: str = "", **extra):
        event = {"ts": time.time(), "kind": kind, "symbol": symbol, "detail": str(detail)[:1000], **extra}
        with self.lock:
            self.errors += 1
            self.recent_errors.appendleft(event)
            if symbol in self.per_symbol:
                st = self.per_symbol[symbol]; st["errors"] += 1; st["last_error"] = kind + (":" + str(detail)[:160] if detail else ""); st["last_error_ts"] = event["ts"]
        if self.error_sink:
            try: self.error_sink(event)
            except Exception: pass

    def _buffer(self, symbol: str, item):
        q = self.buffers[symbol]
        if len(q) >= q.maxlen:
            self.buffer_overflows += 1; self.per_symbol[symbol]["buffer_overflows"] += 1
            self._error("BUFFER_OVERFLOW", symbol, f"maxlen={q.maxlen}")
        q.append(item)

    @staticmethod
    def _apply_levels(state: dict, update: dict):
        for side in ("bids", "asks"):
            for p, q in update[side]:
                if q == 0:
                    state[side].pop(p, None)
                else:
                    state[side][p] = q

    def _publish(self, sym: str):
        with self.lock:
            x = self.raw.get(sym)
            if not x or not x.get("ready"):
                return
            bids = tuple(L(p, q) for p, q in sorted(x["bids"].items(), reverse=True)[:int(self.cfg.get("depth_levels", 100))])
            asks = tuple(L(p, q) for p, q in sorted(x["asks"].items())[:int(self.cfg.get("depth_levels", 100))])
            if not bids or not asks:
                return
            if bids[0].p >= asks[0].p:
                self._error("CROSSED_BOOK", sym, f"bid={bids[0].p} ask={asks[0].p}", version=x.get("ver"))
                return
            book = Book(
                sym, bids, asks, x["gen"], x.get("ver"), x.get("send") or None,
                x.get("recv_wall_ms"), x.get("recv_ns", time.monotonic_ns()), x.get("apply_ns", time.monotonic_ns()), "VALID"
            )
        self.store.put(book)

    def _apply(self, u: dict, gen: int, recv_ns: int, recv_wall_ms: float):
        sym = u["symbol"]
        with self.lock:
            if self.symbol_gen.get(sym) != gen:
                return
            st = self.per_symbol[sym]
            st["messages"] += 1; st["last_from"] = u["from"]; st["last_to"] = u["to"]; st["last_send_ms"] = u["send"]; st["last_message_ts"] = time.time()
            now = time.monotonic(); st["msg_times"].append(now); self.msg_times.append(now); self.messages += 1
            x = self.raw.get(sym)
            if not x or not x.get("ready"):
                self._buffer(sym, (u, recv_ns, recv_wall_ms)); return
            if u["to"] <= x["ver"]:
                return
            if x.get("bridge_pending"):
                continuous = bridge_first_ok(x["ver"], u["from"], u["to"])
            else:
                continuous = (u["from"] == x["ver"] + 1)
            if not continuous:
                x["ready"] = False; self.ready.discard(sym)
                self._buffer(sym, (u, recv_ns, recv_wall_ms))
                self.gaps += 1; st["gaps"] += 1
                expected = x["ver"] + 1
                self._error("LIVE_GAP", sym, f"expected_cover={expected} got={u['from']}..{u['to']}", expected=expected, from_version=u["from"], to_version=u["to"], bridge_pending=bool(x.get("bridge_pending")))
                threading.Thread(target=self._resync, args=(sym, gen, "LIVE_GAP"), daemon=True).start()
                return
            self._apply_levels(x, u)
            x.update(ver=u["to"], send=u["send"], recv_ns=recv_ns, recv_wall_ms=recv_wall_ms, apply_ns=time.monotonic_ns(), bridge_pending=False)
        self._publish(sym)

    def _resync(self, sym: str, gen: int, trigger: str = "INIT"):
        with self.lock:
            if self.symbol_gen.get(sym) != gen:
                return
            x = self.raw.setdefault(sym, {"gen": gen, "ready": False})
            if x.get("resyncing"):
                return
            x["ready"] = False; x["resyncing"] = True; self.ready.discard(sym)

        tries = int(self.cfg.get("snapshot_retries", 12))
        try:
            for attempt in range(tries):
                if self.stop or self.symbol_gen.get(sym) != gen:
                    return
                try:
                    self.snapshot_limiter.wait()
                    r = self.session.get(REST + "/api/v3/depth", params={"symbol": sym, "limit": int(self.cfg.get("snapshot_limit", 5000))}, timeout=float(self.cfg.get("rest_timeout_s", 8)))
                    self.requests += 1; r.raise_for_status(); j = r.json()
                    ver = int(j["lastUpdateId"])
                    bids = {float(p): float(q) for p, q in j.get("bids", []) if float(q) > 0}
                    asks = {float(p): float(q) for p, q in j.get("asks", []) if float(q) > 0}
                    snap_recv_ns = time.monotonic_ns(); snap_wall_ms = time.time() * 1000.0

                    with self.lock:
                        if self.symbol_gen.get(sym) != gen:
                            return
                        buffered = list(self.buffers[sym]); self.buffers[sym].clear()
                        rem = [z for z in buffered if z[0]["to"] > ver]
                        state = {
                            "bids": bids, "asks": asks, "ver": ver, "send": 0,
                            "recv_ns": snap_recv_ns, "recv_wall_ms": snap_wall_ms, "apply_ns": time.monotonic_ns(),
                            "gen": gen, "ready": True, "resyncing": True, "bridge_pending": not bool(rem),
                        }
                        if rem:
                            first, rns, rwms = rem[0]
                            if not bridge_first_ok(ver, first["from"], first["to"]):
                                # Preserve buffered updates; a newer REST snapshot may bridge them on the next attempt.
                                self.buffers[sym].extend(rem)
                                raise RuntimeError(f"snapshot bridge gap snapshot={ver} first={first['from']}..{first['to']}")
                            self._apply_levels(state, first)
                            state.update(ver=first["to"], send=first["send"], recv_ns=rns, recv_wall_ms=rwms, apply_ns=time.monotonic_ns(), bridge_pending=False)
                            for idx, (u, rns, rwms) in enumerate(rem[1:], start=1):
                                if u["to"] <= state["ver"]:
                                    continue
                                if u["from"] != state["ver"] + 1:
                                    self.buffers[sym].extend(rem[idx:])
                                    raise RuntimeError(f"post-bridge gap expected={state['ver']+1} got={u['from']}..{u['to']}")
                                self._apply_levels(state, u)
                                state.update(ver=u["to"], send=u["send"], recv_ns=rns, recv_wall_ms=rwms, apply_ns=time.monotonic_ns())
                        state["ready"] = True; state["resyncing"] = False
                        self.raw[sym] = state; self.ready.add(sym)
                        self.resyncs += 1; self.per_symbol[sym]["resyncs"] += 1
                    self._publish(sym)
                    return
                except Exception as exc:
                    # Bridge misses during startup are telemetry, not silent counters.
                    self._error("RESYNC_RETRY", sym, str(exc), attempt=attempt + 1, trigger=trigger)
                    time.sleep(min(4.0, 0.15 * (2 ** min(attempt, 5))) + random.random() * 0.05)
            self._error("RESYNC_EXHAUSTED", sym, f"trigger={trigger} tries={tries}")
        finally:
            with self.lock:
                if sym in self.raw:
                    self.raw[sym]["resyncing"] = False

    def _socket(self, group: list[str], wid: int):
        backoff = 0.5
        while not self.stop:
            gen = self._next_gen(); opened = time.monotonic()
            with self.lock:
                for s in group:
                    self.symbol_gen[s] = gen; self.ready.discard(s); self.raw[s] = {"gen": gen, "ready": False, "resyncing": False}; self.buffers[s].clear()

            def on_open(ws):
                params = [f"spot@public.aggre.depth.v3.api.pb@10ms@{s}" for s in group]
                ws.send(json.dumps({"method": "SUBSCRIPTION", "params": params}))
                for s in group:
                    threading.Thread(target=self._resync, args=(s, gen, "OPEN"), daemon=True).start()

            def on_message(ws, msg):
                recv_ns = time.monotonic_ns(); recv_wall_ms = time.time() * 1000.0
                try:
                    if isinstance(msg, str):
                        j = json.loads(msg)
                        if str(j.get("msg", "")).upper() == "PONG": self.pongs += 1
                        else: self.acks += 1
                        return
                    u = decode(msg)
                    if u and u["symbol"] in group:
                        self._apply(u, gen, recv_ns, recv_wall_ms)
                except Exception as exc:
                    self.decode_errors += 1; self._error("DECODE", None, repr(exc), wid=wid)

            def on_error(ws, err):
                self._error("WS_ERROR", None, repr(err), wid=wid, generation=gen)

            def on_close(ws, code, msg):
                if not self.stop:
                    self._error("WS_CLOSE", None, f"code={code} msg={msg}", wid=wid, generation=gen)

            app = websocket.WebSocketApp(WS, on_open=on_open, on_message=on_message, on_error=on_error, on_close=on_close)

            def ping_loop():
                while not self.stop:
                    time.sleep(float(self.cfg.get("ping_interval_s", 15)))
                    try: app.send(json.dumps({"method": "PING"}))
                    except Exception: return
            threading.Thread(target=ping_loop, daemon=True).start()

            try:
                app.run_forever(ping_interval=0)
            except Exception as exc:
                self._error("WS_RUN", None, repr(exc), wid=wid, generation=gen)
            if self.stop:
                break
            self.reconnects += 1
            lived = time.monotonic() - opened
            backoff = 0.5 if lived > 120 else min(30.0, max(0.5, backoff * 1.8))
            time.sleep(backoff + random.random() * 0.25)

    def run(self):
        group_size = int(self.cfg.get("ws_group_size", 20))
        groups = [self.symbols[i:i + group_size] for i in range(0, len(self.symbols), group_size)]
        for i, group in enumerate(groups):
            threading.Thread(target=self._socket, args=(group, i), daemon=True, name=f"mexc-ws-{i}").start()
        while not self.stop:
            # Re-sync MEXC/local clock periodically for exchange-age telemetry.
            time.sleep(300)
            self.clock.sync(self.session)

    @staticmethod
    def _rate(dq: deque, window=10.0):
        now = time.monotonic()
        while dq and dq[0] < now - window:
            dq.popleft()
        return len(dq) / window

    def symbol_status(self):
        books = self.store.snapshot(); out = []
        with self.lock:
            for sym in self.symbols:
                st = self.per_symbol[sym]; b = books.get(sym)
                out.append({
                    "symbol": sym,
                    "ready": sym in self.ready and b is not None,
                    "generation": self.symbol_gen.get(sym),
                    "version": b.ver if b else self.raw.get(sym, {}).get("ver"),
                    "messages": st["messages"], "msg_rate_10s": self._rate(st["msg_times"]),
                    "gaps": st["gaps"], "resyncs": st["resyncs"], "errors": st["errors"], "buffer_overflows": st["buffer_overflows"],
                    "last_from": st["last_from"], "last_to": st["last_to"], "last_send_ms": st["last_send_ms"],
                    "last_message_ts": st["last_message_ts"], "last_error": st["last_error"], "last_error_ts": st["last_error_ts"],
                    "bid": b.best_bid if b else None, "ask": b.best_ask if b else None, "spread_bps": b.spread_bps if b else None,
                    "local_age_ms": b.age_ms if b else None,
                    "exchange_age_ms": b.exchange_age_ms(self.clock.offset_ms) if b else None,
                    "transport_age_ms": b.transport_age_ms(self.clock.offset_ms) if b else None,
                })
        return out

    def status(self):
        with self.lock:
            return {
                "symbols": len(self.symbols), "ready": len(self.ready), "messages": self.messages,
                "msg_rate_10s": self._rate(self.msg_times), "requests": self.requests, "errors": self.errors,
                "decode_errors": self.decode_errors, "reconnects": self.reconnects, "gaps": self.gaps,
                "resyncs": self.resyncs, "buffer_overflows": self.buffer_overflows,
                "acks": self.acks, "pongs": self.pongs, "generation_counter": self._gen_counter,
                "clock_offset_ms": self.clock.offset_ms, "clock_sync_rtt_ms": self.clock.rtt_ms,
                "recent_errors": list(self.recent_errors)[:30],
            }
