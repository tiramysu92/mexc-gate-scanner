from v4rex.db import DB

def test_db_schema_and_error(tmp_path):
    db=DB(str(tmp_path/'x.db')); db.log_collector_error({'ts':1,'kind':'X','symbol':'SOLUSDT','detail':'d','a':2})
    assert db.counts()['collector_errors']==1; assert db.recent_errors(1)[0]['kind']=='X'

def test_route_aggregate_upsert(tmp_path):
    db=DB(str(tmp_path/'x.db'))
    r={'route':'USDT>SOL>USDC','token':'SOL','stable_a':'USDT','stable_b':'USDC','size':25.0,'fraction':.25,'samples':1,'data_valid':1,'raw_positive':1,'net_positive':0,'qualified':0,'sum_raw':5,'sum_net':-5,'sum_expected':-5,'max_raw':5,'max_net':-5,'max_expected':-5,'min_expected':-5,'sum_cov1':1,'sum_cov2':1,'sum_local_age':10,'sum_exchange_age':12,'sum_local_skew':2,'sum_exchange_skew':3,'last_ts':1,'last_reason':'EDGE_EXPECTED'}
    db.upsert_route_aggs([r]); db.upsert_route_aggs([r]); x=db.route_summary(1)[0]
    assert x['samples']==2; assert x['max_raw_bps']==5; assert x['avg_expected_bps']==-5
