import pytest
from v4rex.core import L,buy,sell,cost_for_base,max_traversable_quote,pct

def test_buy_single():
    b,v,c=buy((L(10,10),),50,1); assert b==pytest.approx(5); assert v==pytest.approx(10); assert c==pytest.approx(1)
def test_sell_single():
    q,v,c=sell((L(11,10),),5,1); assert q==pytest.approx(55); assert v==pytest.approx(11); assert c==pytest.approx(1)
def test_buy_multi_vwap():
    b,v,c=buy((L(10,2),L(11,4)),42,1); assert b==pytest.approx(4); assert v==pytest.approx(10.5); assert c==pytest.approx(1)
def test_sell_multi_vwap():
    q,v,c=sell((L(11,2),L(10,4)),5,1); assert q==pytest.approx(52); assert v==pytest.approx(10.4); assert c==pytest.approx(1)
def test_insufficient_buy():
    b,v,c=buy((L(10,2),),100,1); assert b==pytest.approx(2); assert c==pytest.approx(.2)
def test_insufficient_sell():
    q,v,c=sell((L(10,2),),10,1); assert q==pytest.approx(20); assert c==pytest.approx(.2)
@pytest.mark.parametrize('f,b,c',[(1,10,1),(.5,5,.5),(.25,2.5,.25),(.1,1,.1)])
def test_fraction(f,b,c):
    got,_,cov=buy((L(10,10),),100,f); assert got==pytest.approx(b); assert cov==pytest.approx(c)
def test_zero():
    assert buy((L(10,1),),0,1)==(0,0,1); assert sell((L(10,1),),0,1)==(0,0,1)
def test_cost_for_base():
    q,v,c=cost_for_base((L(10,2),L(12,3)),4,1); assert q==pytest.approx(44); assert v==pytest.approx(11); assert c==pytest.approx(1)
def test_max_traversable_quote():
    q=max_traversable_quote((L(10,10),),(L(11,4),),.5); assert q==pytest.approx(20)
def test_pct():
    assert pct([1,2,3,4],.5)==pytest.approx(2.5); assert pct([],.5) is None
