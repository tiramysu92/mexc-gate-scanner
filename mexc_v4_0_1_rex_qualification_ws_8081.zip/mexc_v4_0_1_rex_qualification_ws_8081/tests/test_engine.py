import time
from types import SimpleNamespace
from v4rex.core import Store,Book,L
from v4rex.engine import Engine
from v4rex.db import DB

class Clock: offset_ms=0

def book(sym,bid,ask,send=None,age_ms=0):
    now=time.monotonic_ns()-int(age_ms*1e6); wall=time.time()*1000
    return Book(sym,(L(bid,1000),),(L(ask,1000),),1,100,send or int(wall),wall,now,now,'VALID')

def make(tmp_path,b2_bid=10.2,age=0):
    cfg={'fee_bps_default':5,'min_expected_edge_bps':10,'max_local_age_ms':250,'max_exchange_age_ms':500,'max_transport_age_ms':500,'max_local_skew_ms':150,'max_exchange_skew_ms':150,'test_sizes_usd':[100],'depth_fractions':[1.0],'raw_watch_threshold_bps':0,'aggregate_flush_s':999}
    store=Store(); store.put(book('SOLUSDT',9.9,10.0,age_ms=age)); store.put(book('SOLUSDC',b2_bid,b2_bid+0.1,age_ms=age))
    route=SimpleNamespace(route='USDT>SOL>USDC',token='SOL',stable_a='USDT',stable_b='USDC',symbol1='SOLUSDT',symbol2='SOLUSDC')
    uni=SimpleNamespace(routes=[route]); db=DB(str(tmp_path/'x.db')); return Engine(cfg,store,db,uni,Clock()),route

def test_engine_positive_edge(tmp_path):
    e,r=make(tmp_path,10.2); x=e._evaluate(r,100,1.0)
    assert x.raw_edge_bps>0; assert x.net_edge_bps<x.raw_edge_bps; assert x.data_valid

def test_engine_fee_can_kill_edge(tmp_path):
    e,r=make(tmp_path,10.005); x=e._evaluate(r,100,1.0)
    assert x.raw_edge_bps>0; assert x.net_edge_bps<0

def test_engine_stale_rejected(tmp_path):
    e,r=make(tmp_path,10.2,age=400); x=e._evaluate(r,100,1.0)
    assert 'STALE_LOCAL' in x.reasons; assert not x.data_valid

def test_engine_once_aggregates(tmp_path):
    e,r=make(tmp_path,10.2); n=e.once(); assert n==1; assert e.scans==1; assert e.evaluations==1
