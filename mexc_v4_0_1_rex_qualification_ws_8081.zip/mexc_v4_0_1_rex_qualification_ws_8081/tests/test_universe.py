from v4rex.universe import parse_exchange_info

def payload():
    return {'symbols':[
      {'symbol':'SOLUSDT','status':'ENABLED','baseAsset':'SOL','quoteAsset':'USDT','isSpotTradingAllowed':True,'baseAssetPrecision':4,'quotePrecision':4},
      {'symbol':'SOLUSDC','status':'ENABLED','baseAsset':'SOL','quoteAsset':'USDC','isSpotTradingAllowed':True},
      {'symbol':'SOLUSD1','status':'PAUSED','baseAsset':'SOL','quoteAsset':'USD1','isSpotTradingAllowed':True},
      {'symbol':'SUIUSDT','status':'ENABLED','baseAsset':'SUI','quoteAsset':'USDT','isSpotTradingAllowed':False},
      {'symbol':'BTCUSDT','status':'ENABLED','baseAsset':'BTC','quoteAsset':'USDT','isSpotTradingAllowed':True},
    ]}

def test_universe_selects_real_markets():
    cfg={'tokens':['SOL','SUI'],'stablecoins':['USDT','USDC','USD1'],'require_default_symbols':True}
    u=parse_exchange_info(payload(),cfg,{'SOLUSDT','SOLUSDC','SOLUSD1','SUIUSDT'})
    assert {s.symbol for s in u.symbols}=={'SOLUSDT','SOLUSDC'}
    assert {r.route for r in u.routes}=={'USDT>SOL>USDC','USDC>SOL>USDT'}

def test_universe_exclusions_are_explicit():
    cfg={'tokens':['SOL','SUI'],'stablecoins':['USDT','USDC','USD1'],'require_default_symbols':True}
    u=parse_exchange_info(payload(),cfg,{'SOLUSDT','SOLUSDC','SOLUSD1','SUIUSDT'})
    ex={x['symbol']:x['reasons'] for x in u.excluded}
    assert 'STATUS' in ex['SOLUSD1']; assert 'SPOT_API_DISABLED' in ex['SUIUSDT']

def test_default_symbol_filter():
    cfg={'tokens':['SOL'],'stablecoins':['USDT','USDC'],'require_default_symbols':True}
    u=parse_exchange_info(payload(),cfg,{'SOLUSDT'})
    assert [s.symbol for s in u.symbols]==['SOLUSDT']; assert u.routes==[]
