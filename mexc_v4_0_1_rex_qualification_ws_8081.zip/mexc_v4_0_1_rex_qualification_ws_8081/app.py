from __future__ import annotations
import argparse
import json
import os
import signal
import threading
import time
import traceback
from pathlib import Path

import psutil
from flask import Flask, jsonify, render_template, request
from waitress import serve

from v4rex import __version__
from v4rex.core import Store, pct
from v4rex.db import DB
from v4rex.universe import UniverseBuilder
from v4rex.collector import Collector
from v4rex.engine import Engine

parser=argparse.ArgumentParser()
parser.add_argument("config",nargs="?",default="config.json")
args=parser.parse_args()
cfg=json.load(open(args.config,encoding="utf-8"))
if cfg.get("mode")!="SHADOW": raise SystemExit("V4.0.1 qualification build is SHADOW ONLY")

started=time.time(); stop_event=threading.Event(); thread_state={}; thread_lock=threading.RLock()
process=psutil.Process(os.getpid()); process.cpu_percent(None)

db=DB(cfg["db_path"])
universe=UniverseBuilder(cfg).build()
UniverseBuilder.save_snapshot(universe,cfg.get("universe_snapshot_path","exchange_info_v401_start.json.gz"))
db.save_universe(universe.symbols)
db.set_meta("version",__version__); db.set_meta("started_at",started); db.set_meta("config",cfg); db.set_meta("universe",universe.as_dict())

store=Store()
collector=Collector(cfg,store,[s.symbol for s in universe.symbols],error_sink=db.log_collector_error)
engine=Engine(cfg,store,db,universe,collector.clock)

app=Flask(__name__,template_folder="templates")

def safe_thread(name,fn):
    def wrapped():
        with thread_lock: thread_state[name]={"alive":True,"started":time.time(),"last_ok":None,"error":None}
        try:
            fn()
        except Exception as exc:
            with thread_lock: thread_state[name]["error"]=repr(exc); thread_state[name]["traceback"]=traceback.format_exc(); thread_state[name]["alive"]=False
            db.log_collector_error({"ts":time.time(),"kind":"THREAD_FATAL","symbol":None,"detail":f"{name}: {exc}","traceback":traceback.format_exc()})
        finally:
            with thread_lock:
                if name in thread_state: thread_state[name]["alive"]=False
    t=threading.Thread(target=wrapped,daemon=True,name=name); t.start(); return t

def scan_loop():
    interval=float(cfg.get("scan_interval_ms",200))/1000.0
    while not stop_event.is_set():
        t=time.monotonic(); engine.once()
        with thread_lock: thread_state["scanner"]["last_ok"]=time.time()
        remain=interval-(time.monotonic()-t)
        if remain>0: stop_event.wait(remain)

def market_sample_loop():
    interval=float(cfg.get("market_sample_interval_s",1.0))
    while not stop_event.is_set():
        rows=collector.symbol_status(); db.add_market_samples(rows)
        with thread_lock: thread_state["market-sampler"]["last_ok"]=time.time()
        stop_event.wait(interval)

def health_loop():
    interval=float(cfg.get("health_interval_s",5.0))
    while not stop_event.is_set():
        cs=collector.status(); es=engine.status(); counts=db.counts()
        try: cpu=process.cpu_percent(None); rss=process.memory_info().rss/1024/1024
        except Exception: cpu=rss=None
        db.add_health({"uptime_s":time.time()-started,"ready_symbols":cs["ready"],"total_symbols":cs["symbols"],"ws_msg_rate":cs["msg_rate_10s"],"messages":cs["messages"],"gaps":cs["gaps"],"resyncs":cs["resyncs"],"reconnects":cs["reconnects"],"collector_errors":cs["errors"],"scan_ms":es["last_scan_ms"],"evals_per_scan":es["last_scan_evals"],"scans":es["scans"],"active_opportunities":len(engine.tracker.status()),"cpu_pct":cpu,"rss_mb":rss,"db_mb":counts["db_mb"]})
        with thread_lock: thread_state["health"]["last_ok"]=time.time()
        stop_event.wait(interval)

def collector_loop():
    collector.run()

safe_thread("collector",collector_loop)
safe_thread("scanner",scan_loop)
safe_thread("market-sampler",market_sample_loop)
safe_thread("health",health_loop)

def quality_summary(symbols):
    return {
      "ready":sum(1 for x in symbols if x["ready"]),"total":len(symbols),
      "local_age_p50_ms":pct([x["local_age_ms"] for x in symbols],.50),"local_age_p95_ms":pct([x["local_age_ms"] for x in symbols],.95),
      "exchange_age_p50_ms":pct([x["exchange_age_ms"] for x in symbols],.50),"exchange_age_p95_ms":pct([x["exchange_age_ms"] for x in symbols],.95),
      "transport_age_p50_ms":pct([x["transport_age_ms"] for x in symbols],.50),"transport_age_p95_ms":pct([x["transport_age_ms"] for x in symbols],.95),
      "spread_p50_bps":pct([x["spread_bps"] for x in symbols],.50),"spread_p95_bps":pct([x["spread_bps"] for x in symbols],.95),
    }

def safe_cfg():
    return {k:v for k,v in cfg.items() if "key" not in k.lower() and "secret" not in k.lower()}

@app.get("/healthz")
def healthz():
    with thread_lock: threads={k:dict(v) for k,v in thread_state.items()}
    ok=all(v.get("alive") for v in threads.values()) if threads else False
    return jsonify(ok=ok,mode="SHADOW",version=__version__,port=cfg["port"],threads=threads)

@app.get("/api/status")
def status():
    syms=collector.symbol_status(); cs=collector.status(); es=engine.status(); counts=db.counts()
    try: cpu=process.cpu_percent(None); rss=process.memory_info().rss/1024/1024
    except Exception: cpu=rss=None
    with thread_lock: threads={k:dict(v) for k,v in thread_state.items()}
    return jsonify({
      "version":__version__,"mode":"SHADOW","uptime_s":time.time()-started,"port":cfg["port"],
      "universe":{"symbols":len(universe.symbols),"routes":len(universe.routes),"tokens":len(set(s.base for s in universe.symbols)),"excluded":len(universe.excluded)},
      "collector":cs,"quality":quality_summary(syms),
      "engine":{k:v for k,v in es.items() if k!="latest_candidates"},
      "active_opportunities":engine.tracker.status()[:30],
      "db":counts,"process":{"cpu_pct":cpu,"rss_mb":rss},"threads":threads,
      "config":safe_cfg(),"reasons":db.reasons()[:20],"top_routes":db.route_summary(20),"recent_events":db.recent_events(20)
    })

@app.get("/api/symbols")
def symbols(): return jsonify(collector.symbol_status())
@app.get("/api/candidates")
def candidates(): return jsonify(engine.status()["latest_candidates"][:int(request.args.get("limit",100))])
@app.get("/api/events")
def events(): return jsonify(db.recent_events(int(request.args.get("limit",100))))
@app.get("/api/lifecycles")
def lifecycles(): return jsonify(db.recent_lifecycles(int(request.args.get("limit",100))))
@app.get("/api/routes")
def routes(): return jsonify(db.route_summary(int(request.args.get("limit",200))))
@app.get("/api/reasons")
def reasons(): return jsonify(db.reasons())
@app.get("/api/errors")
def errors(): return jsonify(db.recent_errors(int(request.args.get("limit",100))))
@app.get("/api/health-series")
def health_series(): return jsonify(db.health_series(float(request.args.get("minutes",60)),int(request.args.get("limit",1000))))
@app.get("/api/universe")
def universe_api(): return jsonify(universe.as_dict())
@app.get("/api/export-summary")
def export_summary():
    return jsonify({"generated_at":time.time(),"version":__version__,"uptime_s":time.time()-started,"config":safe_cfg(),"universe":universe.as_dict(),"status":json.loads(status().get_data(as_text=True)),"routes":db.route_summary(10000),"lifecycles":db.recent_lifecycles(10000),"reasons":db.reasons(),"errors":db.recent_errors(1000)})
@app.get("/")
def index(): return render_template("index.html")

def shutdown(*sig):
    stop_event.set(); collector.stop=True; engine.flush(force=True); engine.tracker.flush_active()
    if sig:
        raise SystemExit(0)
for sig in (signal.SIGTERM,signal.SIGINT): signal.signal(sig,shutdown)

if __name__=="__main__":
    serve(app,host="0.0.0.0",port=int(cfg["port"]),threads=int(cfg.get("http_threads",8)))
