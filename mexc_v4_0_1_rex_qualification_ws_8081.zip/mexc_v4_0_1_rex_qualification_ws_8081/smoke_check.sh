#!/usr/bin/env bash
set -euo pipefail
BASE=${1:-http://127.0.0.1:8081}
echo '=== HEALTH ==='; curl -fsS "$BASE/healthz"; echo
echo '=== STATUS ==='; curl -fsS "$BASE/api/status"; echo
echo '=== DB ==='; ls -lh v4_rex_qualification.db* 2>/dev/null || true
echo '=== LOG TAIL ==='; tail -80 v4_rex.log 2>/dev/null || true
