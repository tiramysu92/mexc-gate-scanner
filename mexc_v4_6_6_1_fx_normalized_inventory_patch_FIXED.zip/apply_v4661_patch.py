#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, re
from pathlib import Path

HELPERS = r"""    def _inventory_recovery_active(self):
        if not bool(self.cfg.get("inventory_recovery_enabled", True)):
            return False
        usdc=self._available("USDC");usdt=self._available("USDT")
        trigger=float(self.cfg.get("inventory_recovery_trigger_usdc",60.0))
        reserve=float(self.cfg.get("live_min_stable_reserve_usd",20.0))
        return usdc < trigger and usdt > reserve + self.size

    def _stable_fx_mid(self):
        m=getattr(self,"maintenance",None)
        if m is None:
            # Legacy/unit-test instances are created with __new__ and have no API client.
            # Production executors always have a client; production never falls back to 1:1.
            if getattr(self,"client",None) is None:return 1.0
            return None
        try:return m.stable_fx_mid(float(self.cfg.get("stable_fx_cache_max_age_s",2.0)))
        except Exception:return None

    def _economic_net_bps(self,net_bps,e):
        mid=self._stable_fx_mid()
        if mid is None or mid<=0:return None
        ratio=1.0+float(net_bps)/1e4
        if e.stable_a=="USDC" and e.stable_b=="USDT":
            ratio=ratio/mid
        elif e.stable_a=="USDT" and e.stable_b=="USDC":
            ratio=ratio*mid
        else:
            return None
        return (ratio-1.0)*1e4

    def _economic_expected_from_eval(self,e):
        if e.net_edge_bps is None:return None
        econ=self._economic_net_bps(float(e.net_edge_bps),e)
        if econ is None:return None
        reserve=float(self.cfg.get("execution_price_reserve_bps",.5))
        return econ-reserve

    def _recovery_structure_ok(self,e,require_survival=False):
        if e.liquidity_class not in ("A","B"):return False
        if not bool(e.data_valid) or not bool(e.timing_valid) or not bool(e.depth_synced):return False
        if float(e.l1_reserve_x or 0)<float(self.cfg.get("liquidity_l1_reserve_multiple",5.0)):return False
        if float(e.l2_reserve_x or 0)<float(self.cfg.get("liquidity_l2_reserve_multiple",10.0)):return False
        if not require_survival:return True
        if int(e.survival_trials or 0)<int(self.cfg.get("live_min_survival_trials",1000)):return False
        k=e.liquidity_class
        req100=float(self.cfg.get("class_a_l2_survival_100_min",.99) if k=="A" else self.cfg.get("class_b_l2_survival_100_min",.98))
        req250=float(self.cfg.get("class_a_l2_survival_250_min",.98) if k=="A" else self.cfg.get("class_b_l2_survival_250_min",.95))
        req500=float(self.cfg.get("class_a_l2_survival_500_min",.95) if k=="A" else self.cfg.get("class_b_l2_survival_500_min",.90))
        return float(e.l2_survival_100 or 0)>=req100 and float(e.l2_survival_250 or 0)>=req250 and float(e.l2_survival_500 or 0)>=req500

    def _is_reverse_recovery_event(self,e):
        sizes={float(x) for x in self.cfg.get("inventory_recovery_sizes_usd",[40,25,20,10])}
        return (self._inventory_recovery_active() and getattr(e,"stable_a",None)=="USDT" and getattr(e,"stable_b",None)=="USDC" and
                float(getattr(e,"size",self.size)) in sizes and self._recovery_structure_ok(e,True))

    def _event_submission_mode(self,e):
        qf=float(self.cfg.get("qualification_depth_fraction",.25))
        if abs(float(getattr(e,"fraction",qf))-qf)>1e-12:return None
        if self._is_reverse_recovery_event(e):return "RECOVERY"
        if bool(getattr(e,"accepted",True)) and abs(float(getattr(e,"size",self.size))-self.size)<1e-9:return "STANDARD"
        return None

    def _record_recovery_shadow(self,e,economic_edge):
        now=time.time();key=(e.route,float(e.size));ttl=float(self.cfg.get("inventory_recovery_shadow_log_s",30.0))
        if now-float(self._recovery_shadow_last.get(key,0) or 0)<ttl:return
        self._recovery_shadow_last[key]=now
        self.db.add_live_event(None,"RECOVERY_SHADOW_CANDIDATE",{
            "route":e.route,"size":e.size,
            "nominal_expected_edge_bps":e.expected_edge_bps,
            "economic_expected_edge_bps":economic_edge,
            "net_edge_bps":e.net_edge_bps,"survival_trials":e.survival_trials,
            "survival_qualified":self._recovery_structure_ok(e,True),
            "l2_survival_100":e.l2_survival_100,"l2_survival_250":e.l2_survival_250,
            "l2_survival_500":e.l2_survival_500,"liquidity_class":e.liquidity_class,
            "stable_fx_mid":self._stable_fx_mid()})

    def select_live_candidate(self,ev,qf):
        qf=float(qf);same=[e for e in ev if abs(float(e.fraction)-qf)<1e-12]
        normal=[e for e in same if bool(e.accepted) and abs(float(e.size)-self.size)<1e-9]
        if self._inventory_recovery_active():
            sizes={float(x) for x in self.cfg.get("inventory_recovery_sizes_usd",[40,25,20,10])}
            reverse=[e for e in same if e.stable_a=="USDT" and e.stable_b=="USDC" and float(e.size) in sizes and self._recovery_structure_ok(e,False)]
            shadow_min=float(self.cfg.get("inventory_recovery_shadow_min_economic_bps",-1.0))
            shadow=[]
            for e in reverse:
                x=self._economic_expected_from_eval(e)
                if x is not None and x>shadow_min:shadow.append((e,x))
            if shadow:
                e,x=max(shadow,key=lambda t:(float(t[0].size),float(t[1])))
                self._record_recovery_shadow(e,x)

            live_min=float(self.cfg.get("inventory_recovery_live_min_economic_bps",0.0))
            recovery=[]
            for e in reverse:
                if not self._recovery_structure_ok(e,True):continue
                x=self._economic_expected_from_eval(e)
                if x is not None and x>live_min:recovery.append((e,x))
            if recovery:
                return max(recovery,key=lambda t:(float(t[0].size),float(t[1])))[0]

        if normal:return max(normal,key=lambda x:float(x.expected_edge_bps or -1e9))
        return None

"""

LIVE_GATE = r"""    def _live_gate(self,e):
        mode=self._event_submission_mode(e)
        if mode is None:return False,"EVENT_NO_LONGER_ELIGIBLE"
        trade_size=float(getattr(e,"size",self.size));reserve=float(self.cfg.get("live_min_stable_reserve_usd",20))
        bal_age=max(0.0,time.time()-float(self._balances_ts or 0)) if self._balances_ts else math.inf
        if bal_age>float(self.cfg.get("live_balance_cache_max_age_s",5.0)):return False,"BALANCE_CACHE_STALE"
        if self._available(e.stable_a) < trade_size+reserve:return False,"BALANCE_RESERVE"

        fx_mid=self._stable_fx_mid()
        if fx_mid is None:return False,"STABLE_FX_STALE"

        ss=self.db.survival_stat(e.route,trade_size);n=int(ss.get("trials") or 0)
        if n<int(self.cfg.get("live_min_survival_trials",1000)):return False,"SURVIVAL_SAMPLES"
        klass=e.liquidity_class
        req100=float(self.cfg.get("class_a_l2_survival_100_min",.99) if klass=="A" else self.cfg.get("class_b_l2_survival_100_min",.98))
        req250=float(self.cfg.get("class_a_l2_survival_250_min",.98) if klass=="A" else self.cfg.get("class_b_l2_survival_250_min",.95))
        req500=float(self.cfg.get("class_a_l2_survival_500_min",.95) if klass=="A" else self.cfg.get("class_b_l2_survival_500_min",.90))
        if float(ss.get("l2_survival_100") or 0)<req100 or float(ss.get("l2_survival_250") or 0)<req250 or float(ss.get("l2_survival_500") or 0)<req500:return False,"SURVIVAL_RATIO"

        fi1=self._fee_info(e.symbol1);fi2=self._fee_info(e.symbol2)
        if bool(self.cfg.get("live_require_account_fees",True)) and (not fi1.get("usable_live") or not fi2.get("usable_live")):
            return False,"ACCOUNT_FEE_UNKNOWN"
        f1=float(fi1.get("taker_bps") or 0);f2=float(fi2.get("taker_bps") or 0)
        raw=float(e.raw_edge_bps or -1e9)
        nominal_net=((1+raw/1e4)*(1-f1/1e4)*(1-f2/1e4)-1)*1e4
        economic_net=self._economic_net_bps(nominal_net,e)
        if economic_net is None:return False,"STABLE_FX_STALE"

        execution_reserve=float(self.cfg.get("execution_price_reserve_bps",.5))
        guaranteed=economic_net-execution_reserve
        standard=float(self.cfg.get("liquidity_a_min_net_edge_bps",1) if klass=="A" else self.cfg.get("liquidity_b_min_net_edge_bps",2))

        if mode=="RECOVERY":
            threshold=float(self.cfg.get("inventory_recovery_live_min_economic_bps",0.0))
        elif self._inventory_recovery_active() and e.stable_a=="USDC" and e.stable_b=="USDT":
            threshold=max(standard,float(self.cfg.get("inventory_forward_min_economic_bps",5.0)))
        else:
            threshold=standard

        if guaranteed<=threshold:return False,"ECONOMIC_EDGE"
        return True,{
            "fee1_bps":f1,"fee2_bps":f2,
            "fee1_source":fi1.get("source"),"fee2_source":fi2.get("source"),
            "nominal_net_bps":nominal_net,
            "economic_net_bps":economic_net,
            "live_net_bps":economic_net,
            "execution_reserve_bps":execution_reserve,
            "guaranteed_edge_bps":guaranteed,
            "threshold_bps":threshold,
            "stable_fx_mid":fx_mid,
            "balance_age_s":bal_age,"survival":ss,
            "trade_size":trade_size,"inventory_mode":mode
        }

"""

def replace_method(text,name,new_block):
    pat=re.compile(rf'^    def {re.escape(name)}\\s*\\(.*?(?=^    def |^class |\\Z)',re.M|re.S)
    m=pat.search(text)
    if not m:raise RuntimeError(f"method not found: {name}")
    return text[:m.start()]+new_block.rstrip()+"\\n\\n"+text[m.end():]

def replace_helper_bundle(text,new_block):
    # V4.6.6 helper bundle starts at _inventory_recovery_active and ends immediately
    # before submit(). Match method names rather than an exact next-line signature.
    pat=re.compile(r'^    def _inventory_recovery_active\\s*\\(.*?(?=^    def submit\\s*\\()',re.M|re.S)
    m=pat.search(text)
    if not m:raise RuntimeError("V4.6.6 inventory helper bundle not found")
    return text[:m.start()]+new_block.rstrip()+"\\n\\n"+text[m.end():]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("runtime")
    ap.add_argument("--maintenance-file",required=True)
    args=ap.parse_args()
    root=Path(args.runtime).resolve()
    live=root/"v4rex"/"live.py";maint=root/"v4rex"/"maintenance.py";cfgp=root/"config.json"
    if not live.exists() or not maint.exists() or not cfgp.exists():
        raise SystemExit("Target must already be a V4.6.6 runtime")

    for p in (live,maint,cfgp,root/"start.sh",root/"pnl_v466.py"):
        if p.exists():
            b=p.with_suffix(p.suffix+".PRE_V4661")
            if not b.exists():shutil.copy2(p,b)

    maint.write_text(Path(args.maintenance_file).read_text())

    s=live.read_text()
    s=replace_helper_bundle(s,HELPERS)
    s=replace_method(s,"_live_gate",LIVE_GATE)
    s=s.replace("V466_LIVE_10USD","V4661_LIVE_10USD")
    live.write_text(s)

    cfg=json.loads(cfgp.read_text())
    cfg.update({
        "execution_enabled":False,
        "live_arm_token":"V4661_LIVE_10USD",
        "maintenance_check_s":0.5,
        "stable_fx_pair":"USDCUSDT",
        "stable_fx_cache_max_age_s":2.0,
        "inventory_recovery_live_min_economic_bps":0.0,
        "inventory_recovery_shadow_min_economic_bps":-1.0,
        "inventory_forward_min_economic_bps":5.0,
        "dust_direct_min_est_usd":1.10,
        "dust_direct_reject_backoff_s":600.0,
        "dust_direct_check_s":30.0
    })
    cfgp.write_text(json.dumps(cfg,indent=2)+"\n")

    start=root/"start.sh"
    if start.exists():
        x=start.read_text().replace("V4.6.4 MICRO-LIVE","V4.6.6.1 FX-NORMALIZED LIVE").replace("V4.6.6 MICRO-LIVE","V4.6.6.1 FX-NORMALIZED LIVE")
        start.write_text(x)

    print("PATCHED V4.6.6.1:",root)
    print("NEW ARM TOKEN: V4661_LIVE_10USD")
    print("execution_enabled reset to false")
    print("Core execution/L1/L2 methods were not changed.")

if __name__=="__main__":
    main()
