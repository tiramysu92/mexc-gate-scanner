from types import SimpleNamespace

def econ(net_bps,mid,a,b):
    ratio=1+net_bps/1e4
    if a=="USDC" and b=="USDT":ratio/=mid
    elif a=="USDT" and b=="USDC":ratio*=mid
    return (ratio-1)*1e4

def test_fx_normalization_examples():
    mid=1.000755
    assert 7.1 < econ(-0.315,mid,"USDT","USDC") < 7.4
    assert -2.6 < econ(5.112,mid,"USDC","USDT") < -2.3
