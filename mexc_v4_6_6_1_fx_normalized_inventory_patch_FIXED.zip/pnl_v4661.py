#!/usr/bin/env python3
from __future__ import annotations
import json, sqlite3

cfg=json.load(open("config.json"))
db=sqlite3.connect(cfg["db_path"])
db.row_factory=sqlite3.Row

p=db.execute("""
SELECT COUNT(*) n,
       COALESCE(SUM(realized_pnl_nominal),0) cash,
       COALESCE(SUM(l1_quote_spent),0) turnover
FROM live_cycles
WHERE state IN ('CLOSED','CLOSED_WITH_RESIDUAL')
""").fetchone()

dust=float(db.execute("SELECT COALESCE(SUM(est_usd),0) FROM live_dust").fetchone()[0] or 0)

recovered=0.0
reb_friction=0.0
reb_nom=0.0
rebs=0
for r in db.execute("SELECT kind,status,value_usd,detail_json FROM maintenance_events ORDER BY id"):
    kind,status,value,detail=r
    try:d=json.loads(detail or "{}")
    except Exception:d={}
    if kind in ("DUST_DIRECT_SELL","DUST_MX_SELL") and status=="FILLED":
        recovered+=float(value or 0)
    if kind=="REBALANCE" and status=="FILLED":
        rebs+=1
        reb_nom+=float(d.get("nominal_pnl_1to1") or 0)
        reb_friction+=float(d.get("execution_cost_mid_quote") or 0)

cash=float(p["cash"] or 0);turn=float(p["turnover"] or 0)
nominal_before_fx=cash+dust+recovered

print("\n================ V4.6.6.1 PNL =================")
print("Closed cycles                  :",p["n"])
print(f"Turnover                       : {turn:.6f} $")
print(f"Cycle cash PnL (1:1 nominal)   : {cash:+.9f} $")
print(f"Outstanding strategy dust      : {dust:+.9f} $")
print(f"Recovered dust -> USDC         : {recovered:+.9f} $")
print("------------------------------------------------")
print(f"Nominal cycle+dust PnL         : {nominal_before_fx:+.9f} $")
print(f"Rebalance execution friction   : {reb_friction:+.9f} quote-units ({rebs} fills)")
print(f"Legacy 1:1 rebalance basis     : {reb_nom:+.9f} $  [NOT treated as trading cost]")
print("------------------------------------------------")
print("IMPORTANT: historical cycle PnL above is still the legacy 1:1 accounting.")
print("V4.6.6.1 LIVE admission is now FX-normalized using USDCUSDT BBO.")
print("=================================================\n")
