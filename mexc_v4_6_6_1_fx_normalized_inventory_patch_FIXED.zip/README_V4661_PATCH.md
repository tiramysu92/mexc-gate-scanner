# V4.6.6.1 FX-normalized LIVE patch

Target: an already installed V4.6.6 runtime.

Changes only:
- background USDCUSDT BBO cache;
- LIVE economic edge normalized into one stablecoin value;
- reverse recovery selected on economic edge, not nominal 1:1 edge;
- shadow reverse logging no longer requires 1000 trials (LIVE still does);
- forward USDC->USDT requires +5 bp ECONOMIC edge while recovery is active;
- direct dust minimum raised to 1.10 USDC;
- 10-minute per-asset backoff after a rejected direct-dust FOK;
- new arm token V4661_LIVE_10USD;
- execution_enabled reset to false.

Not changed:
- collector
- depth/BBO engine math
- fees
- survivability rules
- 1000-trial LIVE requirement
- L1 FOK
- Private WS / Query reconciliation
- FORCE-L2
- bag protection
